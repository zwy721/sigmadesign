#!/usr/bin/env bash
set -euo pipefail
export CONDA_PKGS_DIRS=/data/zhouwanyao/motiflow/cache/conda_pkgs
export PIP_CACHE_DIR=/data/zhouwanyao/motiflow/cache/pip
export TMPDIR=/data/zhouwanyao/motiflow/cache/tmp
mkdir -p "$CONDA_PKGS_DIRS" "$PIP_CACHE_DIR" "$TMPDIR"
/home/zhouwanyao/anaconda3/bin/python /home/zhouwanyao/MotiFlow/local_repro/fetch_conda.py
CONDA_NUMBER_CHANNEL_NOTICES=0 /home/zhouwanyao/anaconda3/bin/conda create --yes --offline --prefix /data/zhouwanyao/motiflow/envs/motiflow-env --file /data/zhouwanyao/motiflow/manifests/conda_cached_explicit.txt
