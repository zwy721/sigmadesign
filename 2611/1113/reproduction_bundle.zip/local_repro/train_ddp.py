#!/usr/bin/env python
"""Three-GPU adapter; scientific model, sampler, loss and evaluation are upstream."""

import hashlib
import json
import logging
import os
import random
import time
from datetime import timedelta
from pathlib import Path

import hydra
import numpy as np
import torch
import torch.distributed as dist
from omegaconf import DictConfig, OmegaConf
from torch.nn.parallel import DistributedDataParallel

from distributed import partition_batch, reduce_metrics
from motiflow.data.batching import create_data_loader
from motiflow.data.fragment_dataset import FragmentDataset, TrainSampler
from motiflow.modeling import build_model_bundle
from motiflow.training.checkpoints import save_checkpoint
from motiflow.training.evaluation import evaluate_checkpoint
from motiflow.training.losses import compute_motif_loss


class LossModule(torch.nn.Module):
    """Wrap the complete loss so DDP can identify unused SC parameters safely."""

    def __init__(self, bundle, config):
        super().__init__()
        self.model = bundle.model
        self.flow = bundle.flow_matcher
        self.config = config

    def forward(self, batch):
        batch = self.flow.sample_times(batch)
        batch = self.flow.forward_marginal(batch)
        model_config = OmegaConf.create(OmegaConf.to_container(self.config.model, resolve=True))
        # The upstream SC decision is one Bernoulli per global batch, not
        # three independent Bernoullis for the three local microbatches.
        decision = torch.rand((), device=batch["frag_mask"].device)
        dist.broadcast(decision, src=0)
        model_config.sc_training_prob = float(decision < self.config.model.sc_training_prob)
        loss, metrics = compute_motif_loss(
            model=self.model, flow_matcher=self.flow, batch=batch,
            model_config=model_config, flow_config=self.config.flow, loss_config=self.config.loss,
        )
        return loss, {name: value.detach() for name, value in metrics.items()}


@hydra.main(version_base=None, config_path="../configs", config_name="train")
def main(config: DictConfig):
    if config.training.get("resume_from"):
        raise ValueError("Use a fresh run: exact mid-epoch RNG/sampler resume is not implemented by upstream.")
    rank, local_rank = int(os.environ["RANK"]), int(os.environ["LOCAL_RANK"])
    world = int(os.environ["WORLD_SIZE"])
    torch.cuda.set_device(local_rank)
    device = torch.device("cuda", local_rank)
    # Rank zero periodically performs full upstream sampling evaluation.
    dist.init_process_group("nccl", timeout=timedelta(hours=2))
    try:
        run(config, rank, world, device)
    finally:
        dist.destroy_process_group()


def run(config, rank, world, device):
    torch.set_num_threads(int(config.runtime.torch_num_threads))
    torch.set_float32_matmul_precision(str(config.runtime.matmul_precision))
    torch.set_default_dtype(torch.float32)
    random.seed(int(config.seed))
    np.random.seed(int(config.seed))
    torch.manual_seed(int(config.seed))
    torch.cuda.manual_seed_all(int(config.seed))
    bundle = build_model_bundle(model_config=config.model, flow_config=config.flow, data_config=config.data, device=device)
    model = bundle.model
    objective = DistributedDataParallel(
        LossModule(bundle, config), device_ids=[device.index], broadcast_buffers=False,
        find_unused_parameters=True,
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=float(config.training.learning_rate))
    dataset = FragmentDataset(split="train", data_conf=config.data, is_training=True)
    sampler = TrainSampler(dataset=dataset, batch_size=int(config.training.batch_size))
    loader = create_data_loader(
        dataset, sampler=sampler, batch_size=int(config.training.batch_size),
        num_workers=int(config.training.num_loader_workers),
        maximum_squared_size=int(config.training.max_squared_res),
        prefetch_factor=int(config.training.prefetch_factor),
    )
    # Sampler has an explicit, rank-independent epoch RNG. Noise/augmentation
    # streams are independent across ranks; each source row contributes once.
    torch.manual_seed(int(config.seed) + rank)
    torch.cuda.manual_seed_all(int(config.seed) + rank)
    root = Path(str(config.training.checkpoint_dir))
    if rank == 0:
        root.mkdir(parents=True, exist_ok=True)
        OmegaConf.save(config, root / "resolved_config.yaml", resolve=True)
    dist.barrier()
    step, final_epoch = 0, 0
    maximum_steps = config.training.get("max_steps")
    if maximum_steps is not None and int(maximum_steps) < 1:
        raise ValueError("max_steps must be positive")
    log = (root / "steps.jsonl").open("a", buffering=1) if rank == 0 else None
    model.train()
    try:
        for epoch in range(int(config.training.num_epochs)):
            final_epoch = epoch
            sampler.set_epoch(epoch)
            for index, global_batch in enumerate(loader):
                if "dummy_batch" in global_batch:
                    continue
                if index == 0:
                    digest = hashlib.sha256(global_batch["frag_ids"].numpy().tobytes()).hexdigest()
                    digests = [None] * world
                    dist.all_gather_object(digests, digest)
                    if len(set(digests)) != 1:
                        raise RuntimeError("Ranks disagree on the upstream global batch")
                batch, local_count, weight = partition_batch(global_batch, rank, world)
                batch = {key: value.to(device) if torch.is_tensor(value) else value for key, value in batch.items()}
                optimizer.zero_grad(set_to_none=True)
                started = time.monotonic()
                loss, metrics = objective(batch)
                finite = torch.isfinite(loss).to(torch.int32)
                dist.all_reduce(finite, op=dist.ReduceOp.MIN)
                if not finite.item():
                    raise FloatingPointError(f"Non-finite loss on at least one rank at step {step}")
                (loss * weight).backward()
                grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), float(config.training.gradient_clip_norm))
                if not torch.isfinite(grad_norm):
                    raise FloatingPointError(f"Non-finite gradient at step {step}")
                optimizer.step()
                step += 1
                scalars = reduce_metrics(metrics, local_count, batch)
                record = {name: float(value) for name, value in scalars.items()}
                record.update(step=step, epoch=epoch, seconds=time.monotonic()-started, grad_norm=float(grad_norm))
                record["local_batch_sizes"] = [len(global_batch["frag_mask"]) // world + int(r < len(global_batch["frag_mask"]) % world) for r in range(world)]
                if rank == 0:
                    log.write(json.dumps(record) + "\n")
                    if step == 1 or step % int(config.training.log_every_steps) == 0:
                        print(json.dumps(record), flush=True)
                if step % int(config.training.checkpoint_every_steps) == 0:
                    if rank == 0:
                        checkpoint(root / f"step_{step}.pth", model, optimizer, config, epoch, step)
                    dist.barrier()
                every = config.training.get("eval_every_steps")
                if every is not None and step % int(every) == 0:
                    dist.barrier()
                    if rank == 0:
                        # Do not let rank-zero evaluation alter its training RNG stream.
                        with torch.random.fork_rng(devices=[device.index]):
                            evaluation = evaluate_checkpoint(
                                model=model, flow_matcher=bundle.flow_matcher, fragment_library=bundle.fragment_library,
                                data_config=config.data, model_config=config.model, training_config=config.training,
                                device=device, output_dir=Path(str(config.training.eval_dir)) / f"step_{step}",
                            )
                        print(json.dumps({"step": step, "evaluation": evaluation}), flush=True)
                    dist.barrier()
                if maximum_steps is not None and step >= int(maximum_steps):
                    break
            if maximum_steps is not None and step >= int(maximum_steps):
                break
        if rank == 0:
            target = root / f"step_{step}_final.pth"
            checkpoint(target, model, optimizer, config, final_epoch, step)
            print(json.dumps({"checkpoint": str(target), "step": step, "epoch": final_epoch}), flush=True)
        dist.barrier()
    finally:
        if log:
            log.close()


def checkpoint(path, model, optimizer, config, epoch, step):
    save_checkpoint(
        path, model=model, optimizer=optimizer, config=config, epoch=epoch, step=step,
        fragment_library_path=config.data.library_path,
        preprocessing_manifest_path=Path(str(config.data.processed_data_dir)) / "manifest.json",
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
