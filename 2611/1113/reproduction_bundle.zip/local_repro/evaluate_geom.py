"""Use upstream evaluation with support for its canonical alignment shards."""

import runpy
import sys
from pathlib import Path

from hydra.utils import to_absolute_path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from motiflow.evaluation import runner

_upstream_reference_molecules = runner._reference_molecules


def reference_molecules(path, dataset):
    source = Path(to_absolute_path(path))
    if not source.is_dir():
        yield from _upstream_reference_molecules(str(source), dataset)
        return
    # Upstream alignment now writes shard_*.pt, but its evaluator only scans
    # the earlier chunk_*.pt layout. Keep its reconstruction/metrics unchanged.
    direct = sorted(source.glob("shard_*.pt"))
    grouped = sorted(source.glob("*/shard_*.pt"))
    if direct and grouped:
        raise RuntimeError(f"Mixed direct and grouped reference shards: {source}")
    files = direct or grouped or sorted(source.rglob("chunk_*.pt"))
    if not files:
        raise RuntimeError(f"No aligned reference shards found: {source}")
    count = 0
    for file in files:
        for molecule in _upstream_reference_molecules(str(file), dataset):
            count += 1
            yield molecule
    if not count:
        raise RuntimeError(f"No valid reference molecules loaded from {source}")
    print(f"Reference evaluation loaded {count} valid molecules from {len(files)} aligned shards", flush=True)


if __name__ == "__main__":
    runner._reference_molecules = reference_molecules
    runpy.run_path(str(Path(__file__).resolve().parents[1] / "scripts/evaluate.py"), run_name="__main__")
