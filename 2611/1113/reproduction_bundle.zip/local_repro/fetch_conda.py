"""Fetch the frozen Conda plan with bounded, resumable ranges and full hashes."""

import concurrent.futures
import hashlib
import json
import time
from pathlib import Path

import requests

BASE = Path('/data/zhouwanyao/motiflow')
CACHE = BASE / 'cache/conda_pkgs'
PARTS = BASE / 'cache/conda_ranges'
CHUNK = 8 * 1024 * 1024


def digest(path, algorithm='sha256'):
    value = hashlib.new(algorithm)
    with path.open('rb') as source:
        for block in iter(lambda: source.read(8 * 1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def fetch(task):
    item, index = task
    start, stop = index * CHUNK, min((index + 1) * CHUNK, item['size'])
    target = PARTS / item['fn'] / str(index)
    target.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(8):
        offset = target.stat().st_size if target.exists() else 0
        if offset == stop - start:
            return stop - start
        if offset > stop - start:
            raise RuntimeError(f'Oversized cached range {target}')
        try:
            with requests.Session() as session:
                session.trust_env = False
                with session.get(item['url'], headers={'Range': f'bytes={start+offset}-{stop-1}'},
                                 stream=True, timeout=(15, 45)) as response:
                    response.raise_for_status()
                    expected = f'bytes {start+offset}-{stop-1}/{item["size"]}'
                    if response.status_code == 206:
                        if response.headers.get('Content-Range') != expected:
                            raise RuntimeError(f'Wrong range: {response.headers.get("Content-Range")} != {expected}')
                    elif not (response.status_code == 200 and start == offset == 0 and stop == item['size']):
                        raise RuntimeError(f'Server ignored Range for {item["fn"]}')
                    with target.open('ab') as output:
                        for block in response.iter_content(256 * 1024):
                            if output.tell() + len(block) > stop - start:
                                raise RuntimeError('Range response exceeded expected length')
                            output.write(block)
            if target.stat().st_size != stop - start:
                raise RuntimeError('Incomplete response')
            return stop - start
        except (requests.RequestException, RuntimeError) as error:
            print(json.dumps({'retry': item['fn'], 'range': index, 'attempt': attempt+1, 'error': str(error)}), flush=True)
            if attempt == 7:
                raise
            time.sleep(min(2 ** attempt, 16))


def main():
    plan = json.loads((BASE / 'manifests/conda_plan.json').read_text())
    items = sorted(plan['actions']['FETCH'], key=lambda item: item['size'])
    CACHE.mkdir(parents=True, exist_ok=True)
    tasks = []
    for item in items:
        path = CACHE / item['fn']
        if path.exists() and path.stat().st_size == item['size'] and digest(path) == item['sha256']:
            continue
        # Preserve the original Conda transfer prefix, including its final
        # incomplete range. Its contents are checked by the final package hash.
        prefix = CACHE / (item['fn'] + '.partial')
        if prefix.exists():
            with prefix.open('rb') as source:
                for index in range((prefix.stat().st_size + CHUNK - 1) // CHUNK):
                    block = source.read(CHUNK)
                    part = PARTS / item['fn'] / str(index)
                    part.parent.mkdir(parents=True, exist_ok=True)
                    if not part.exists():
                        part.write_bytes(block)
        tasks.extend((item, index) for index in range((item['size'] + CHUNK - 1) // CHUNK))
    started = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
        futures = [pool.submit(fetch, task) for task in tasks]
        for completed, future in enumerate(concurrent.futures.as_completed(futures), 1):
            future.result()
            print(json.dumps({'completed_ranges': completed, 'total_ranges': len(tasks),
                              'elapsed_seconds': round(time.monotonic()-started)}), flush=True)
    for item in items:
        target = CACHE / item['fn']
        if not (target.exists() and target.stat().st_size == item['size'] and digest(target) == item['sha256']):
            temporary = CACHE / (item['fn'] + '.assembling')
            with temporary.open('wb') as output:
                for index in range((item['size'] + CHUNK - 1) // CHUNK):
                    with (PARTS / item['fn'] / str(index)).open('rb') as source:
                        for block in iter(lambda: source.read(CHUNK), b''):
                            output.write(block)
            actual = digest(temporary)
            if actual != item['sha256']:
                raise RuntimeError(f'Package hash mismatch: {item["fn"]}: {actual}')
            temporary.replace(target)
        print(json.dumps({'verified_package': item['fn'], 'sha256': item['sha256']}), flush=True)
    explicit = ['@EXPLICIT'] + [(CACHE / item['fn']).as_uri() + '#' + item['md5'] for item in items]
    (BASE / 'manifests/conda_cached_explicit.txt').write_text('\n'.join(explicit) + '\n')
    (BASE / 'manifests/conda_fetch_verified.json').write_text(json.dumps({'packages': len(items),
         'total_bytes': sum(item['size'] for item in items), 'sha256_verified': True}, indent=2) + '\n')


if __name__ == '__main__':
    main()
