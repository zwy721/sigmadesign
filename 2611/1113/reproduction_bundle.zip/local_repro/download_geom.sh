#!/usr/bin/env bash
set -euo pipefail
export XDG_CACHE_HOME=/data/zhouwanyao/motiflow/cache
cd /data/zhouwanyao/motiflow/raw
/home/zhouwanyao/anaconda3/bin/gdown --continue 'https://drive.google.com/uc?id=1bL52Enn-MRxtVPgEhAf6LUYgkZpaSdht' -O Drugs.tar.gz
python - <<'PY'
import json, tarfile, hashlib
from pathlib import Path
repo=Path('/home/zhouwanyao/MotiFlow')
root=Path('/data/zhouwanyao/motiflow/raw')
manifest=json.loads((repo/'motiflow/data/manifests/geom_paper_split.json').read_text())
expected={Path(v['file']).name:v['sha256'] for v in manifest['splits'].values()}
out=root/'geom_drugs'; out.mkdir(exist_ok=True)
with tarfile.open(root/'Drugs.tar.gz','r:gz') as tf:
 for member in tf:
  name=Path(member.name).name
  if name not in expected: continue
  target=out/name
  if not target.exists():
   stream=tf.extractfile(member)
   with target.with_suffix('.pkl.part').open('wb') as dst:
    while chunk:=stream.read(8*1024*1024): dst.write(chunk)
   target.with_suffix('.pkl.part').rename(target)
  actual=hashlib.file_digest(target.open('rb'),'sha256').hexdigest()
  if actual!=expected[name]:raise RuntimeError(f'Hash mismatch: {target}: {actual}')
  print(f'Verified {name}: {actual}',flush=True)
for name in expected:
 if not (out/name).is_file():raise FileNotFoundError(name)
(root.parent/'manifests/geom_download_verified.json').write_text(json.dumps({'source':'https://drive.google.com/file/d/1bL52Enn-MRxtVPgEhAf6LUYgkZpaSdht/view','files':expected},indent=2)+'\n')
PY
