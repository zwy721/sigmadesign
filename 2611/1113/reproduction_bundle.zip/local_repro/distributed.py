"""Global-batch partitioning and sample-weighted DDP reductions."""

import torch
import torch.distributed as dist


def partition_batch(batch, rank, world_size):
    """Partition an already collated upstream batch; never pad the dataset."""
    size = len(batch["frag_mask"])
    if size < 1:
        raise ValueError("Cannot partition an empty batch")
    quotient, remainder = divmod(size, world_size)
    count = quotient + int(rank < remainder)
    start = rank * quotient + min(rank, remainder)
    # Empty ranks execute one zero-weight example so every rank participates
    # in the same forward/backward collectives, including the last batch.
    selected = slice(start, start + count) if count else slice(0, 1)
    local = {
        key: value[selected] if torch.is_tensor(value) and value.ndim and len(value) == size else value
        for key, value in batch.items()
    }
    valid_total = int(batch["frag_mask"].bool().any(dim=-1).sum())
    valid_local = int(local["frag_mask"].bool().any(dim=-1).sum()) if count else 0
    scale = world_size * valid_local / max(valid_total, 1)
    return local, count, scale


def reduce_metrics(metrics, local_count, batch):
    valid = batch["frag_mask"].bool().any(dim=-1).sum() if local_count else 0
    names = ("total_loss", "rot_loss", "trans_loss", "cat_loss")
    values = [metrics[name].detach() * valid for name in names]
    values += [metrics["frag_length"].detach() * local_count]
    values += [metrics["total_loss"].new_tensor(float(valid)), metrics["total_loss"].new_tensor(local_count)]
    packed = torch.stack(values)
    dist.all_reduce(packed)
    result = {name: packed[index] / packed[-2].clamp_min(1) for index, name in enumerate(names)}
    result["frag_length"] = packed[4] / packed[-1].clamp_min(1)
    result["examples_per_step"] = packed[-1]
    return result
