# GEOM-Drugs reproduction on CUDA 0, 1, 2

Upstream: https://github.com/rpoletukhin/MotiFlow , commit `5be946dd6d9489146d12580e9fe751ba2966f428`.
Paper: https://arxiv.org/html/2601.16955v2 .

Code is in `/home/zhouwanyao/MotiFlow`; all downloaded data, environment packages,
derived datasets, checkpoints and generated samples are under
`/data/zhouwanyao/motiflow`. The repository's `data` and `outputs` are symlinks there.
Existing SigmaDock data and its environment are not modified. No QMugs/ChEMBL data is downloaded.

The existing GEOM source is `/data/zhouwanyao/dataset/rdkit_folder.tar.gz.part`.
It is not the paper's GeoDiff partition. The required 525 MB `Drugs.tar.gz` comes
from the GeoDiff Drive folder linked by upstream; only `train_data_40k.pkl` and
`val_data_5k.pkl` are extracted. Their different SHA-256 hashes are retained
under the explicitly authorized official GeoDiff baseline described below.

## Live status

```bash
python /home/zhouwanyao/MotiFlow/local_repro/status.py
tail -f /data/zhouwanyao/motiflow/logs/pipeline.log
```

`pipeline_status.json` records the current stage and active child PID/log.
The status helper also reads current `/proc` evidence and GPU utilization;
a saved status alone does not prove that a process is alive.

## Authorized protocol

- Three-GPU DDP, CUDA 0,1,2; global batch 64, normally split 22/21/21.
- Official upstream model, flow, loss, length-aware sampler and collator.
- Every rank collates the same upstream source batch, then consumes its disjoint
  slice. This preserves upstream ordering, length truncation and incomplete batches.
- DDP averages gradients across ranks; local mean loss is scaled by
  `world_size * local_nonempty_count / global_nonempty_count` before backward.
- When a final batch has fewer than three samples, empty ranks execute a
  zero-weight dummy forward/backward. Dummies never enter metrics or denominators.
- The upstream per-batch self-conditioning Bernoulli is shared across ranks.
  Unused parameter detection is enabled for this conditional branch.
- Adam, learning rate 0.0001, clip norm 1, 135 epochs, training seed 0;
  fragmentation alpha 0.1 percent. No learning-rate or batch scaling.
- Official aligned counts must match: train 197220/199950, validation 24676/25000.
  Any mismatch stops the workflow for inspection.
- Alignment uses 16 CPU workers. WandB is disabled; every step has a JSONL record.
- After training, generate 10000 molecules for each sampling seed 0,1,2,
  using 100 flow steps, temperature 1, remasking rate 1.5. These are sampling
  replicates of one trained model, not three independent training replicates.
- Official OpenBabel/RDKit evaluation, preserving all raw generated frames.
  MMFF strain is an evaluation statistic and does not replace generated coordinates.

## Gates and artifacts

`pipeline.py` waits for environment installation and source download, installs the
project, freezes exact package versions, reruns the DDP gradient reference check
under PyTorch 2.1.0, verifies source hashes, aligns and fragments, then runs a
12-step real-model DDP smoke with periodic evaluation, checkpoint loading,
sampling and evaluation before starting the fresh formal run.

The unequal-batch gradient test has already passed on actual GPUs 0,1,2 using
the existing PyTorch 2.14 environment without changing it; that test does not
claim that the target environment or full MotiFlow model has passed yet.
The target-environment test and real-model smoke remain gated by downloads.

The adapter changes random number consumption relative to single-GPU training.
Weighted objectives and global batch semantics are preserved, but trajectories
are not expected to be bitwise identical. Exact mid-epoch RNG/sampler resume is
not implemented by upstream, so this adapter rejects `resume_from` rather than
claiming exact continuation.

- `manifests/reproduction_protocol.json`: settings and adapter hashes.
- `manifests/*source.tar.gz`: upstream and adapter source snapshots.
- `manifests/pip_freeze.txt`, `conda_explicit.txt`: exact environment after install.
- `manifests/ddp_gradient_check_torch210.json`: target-environment gradient check.
- `logs/`: per-stage commands, standard output and errors.
- `outputs/smoke/`: isolated diagnostic results, excluded from final statistics.
- `outputs/geom_ddp_seed0/checkpoints/steps.jsonl`: formal training progress.
- `outputs/generated/seed{0,1,2}.pt`: raw generated samples.
- `outputs/final_evaluation/`: final per-run metrics and mean/SD.
- `REPORT.md`: generated after the complete pipeline finishes.

An exception writes `stage=failed` and stops dependent stages. Inspect its log
before restarting. A background process still downloading dependencies is not
an active training run and is not a completed reproduction.

## Environment download recovery on 2026-11-13

The first Conda transfer stopped with `IncompleteRead` while fetching the
1.38 GB PyTorch package, before environment creation. The failed state, log,
protocol and adapter archive were preserved with `.before_recovery_20261113`
suffixes. The GEOM download continued independently.

The resumed setup uses the frozen 114-package Conda plan in
`manifests/conda_plan.json`. `fetch_conda.py` retains existing download prefixes,
fetches 8 MiB byte ranges with 16 workers and per-range retries, checks response
range boundaries, then verifies every whole-package SHA-256 before an offline
explicit Conda install. It does not change Python 3.10, PyTorch 2.1.0, CUDA 12.1,
OpenBabel 3.1 or the scientific training settings.

## Official GeoDiff baseline selected by the user

The downloaded official archive has different byte hashes from the frozen
MotiFlow manifest. The user explicitly chose the official GeoDiff baseline,
with its differences recorded, after this mismatch was reported. The original
MotiFlow hash manifest is retained unchanged; no exact-byte match is claimed.

Actual hashes:

- train: `37911fc44fbf5e185aa2dbcf5ffd1c0e094ff0f9ca48e2e35f9fc6546958ea22`
- validation: `bb362b6bacbb869400adb453a6450170880e84c53e0bbcd77420fd7832f219e0`

The published archive also stores PyG-1 Data objects that modern PyG cannot
read through its current attribute API. `geodiff_compat.py` reads these objects
into plain attribute containers; `align_geodiff.py` adapts only the source
reader and calls upstream alignment. It preserves original order, SMILES,
coordinates, RDKit topology and auxiliary energy/weight fields. No data
resampling or rewriting of the source pickles is performed.

The initial audit found 39990 training molecules / 199950 conformers and 5000
validation molecules / 25000 conformers, with exactly five conformers per
source SMILES, no missing topology or malformed coordinates, and zero source
SMILES overlap across splits. Full ordered identity/topology/coordinate
fingerprints are retained. This confirms the public archive's integrity and
counts, not equivalence to the author's unavailable frozen files.

The initial audit evidence is preserved in `manifests/geodiff_audit_torch214/`.
The target environment repeats the audit before preprocessing.

## Detached pip recovery on 2026-11-13

The first project installation stopped at 00:36 local time during the RDKit
wheel download because its inherited tool-session proxy had disappeared.
The Conda environment and verified source data remain intact. The pipeline
now removes HTTP/HTTPS/ALL/PIP proxy environment variables for its children,
uses the server's direct internet connection, and retries transient pip
errors. Existing pip downloads remain cached under the data directory.

`evaluate_geom.py` also accepts the canonical `shard_*.pt` files produced by
upstream alignment. The upstream evaluation reader scans only its older
`chunk_*.pt` layout; without this reader adapter it would silently use an empty
reference set. Reconstruction and metric functions remain upstream, and a
missing or empty reference now raises an error.

The imported Hydra entrypoints initially resolved `configs` as a Python
package and failed before alignment started. Both wrappers now execute the
upstream script with `runpy`, so Hydra resolves the configuration relative to
the upstream file. `pipeline.py --resume-preparation` reuses the installed
environment and completed audit after verifying current environment versions
and both original source SHA-256 hashes. It reruns GPU checks and starts
training fresh; it does not resume a partially trained checkpoint.
