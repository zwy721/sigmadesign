"""Report paper comparison, generated denominators, and the authorized DDP change."""

import json
from pathlib import Path

import torch

base = Path("/data/zhouwanyao/motiflow")
summary = json.loads((base / "outputs/final_evaluation/summary.json").read_text())
protocol = json.loads((base / 'manifests/reproduction_protocol.json').read_text())
counts = {}
for seed in range(3):
    payload = torch.load(base / f"outputs/generated/seed{seed}.pt", map_location="cpu", weights_only=False)
    samples = payload["samples"] if isinstance(payload, dict) else payload
    counts[str(seed)] = len(samples)
    if len(samples) != 10000:
        raise RuntimeError(f"Seed {seed} produced {len(samples)} instead of 10000 samples")
(base / "manifests/generated_denominators.json").write_text(json.dumps(counts, indent=2) + "\n")
lines = ["# MotiFlow GEOM-Drugs reproduction", "",
         'Dataset baseline: '+json.dumps(protocol.get('dataset_baseline', {'baseline':'exact_frozen_bytes'}))+'.',
         'If the official GeoDiff baseline was selected, its bytes differ from the frozen author files; semantic equivalence to those unavailable files is unproven.', '',
         "One model trained with seed 0 using CUDA 0,1,2 and the authorized DDP adapter, global batch 64 (22/21/21), 135 epochs.",
         "Three sampling seeds (0,1,2), each with 10000 attempts and 100 integration steps. These are sampling replicates, not three independent training runs.", "",
         "| Metric | This run, mean +/- SD (%) | Paper (%) |", "|---|---:|---:|"]
for key, label, expected in [("atom_stability", "Atom stability", "95.0 +/- 0.0"),
                             ("valid_and_connected", "Validity times connectivity", "81.2 +/- 0.3")]:
    value = summary[key]
    lines.append(f"| {label} | {100*value['mean']:.3f} +/- {100*value['std']:.3f} | {expected} |")
lines += ["", "Atom stability uses all assessed atoms. Validity and connectivity use all 10000 generated attempts per seed.",
          "Properties and strain use the upstream valid, connected subsets; strain is an evaluation metric, not a replacement of the raw network coordinates.",
          "Raw generated motif identities and frames, failures, excluded preprocessing records, package versions, hashes and source snapshots remain in this directory.", "",
          "Paper: https://arxiv.org/html/2601.16955v2 . Official code: https://github.com/rpoletukhin/MotiFlow .", "",
          "Full results: outputs/final_evaluation/runs.csv and summary.json.",
          "Protocol and source fingerprints: manifests/reproduction_protocol.json.",
          "The DDP adaptation preserves the source batch grouping and weighted mean objective; its random streams are not bitwise identical to upstream single-GPU training."]
(base / "REPORT.md").write_text("\n".join(lines) + "\n")
