"""Read upstream PyG-1 Data pickles without changing their scientific fields."""

import pickle


class LegacyData:
    """A plain attribute container for the old Data object's pickled state."""

    def __setstate__(self, state):
        if '_store' in state:
            raise ValueError('This adapter is only for the official PyG-1 GeoDiff archive')
        self.__dict__.update(state)


class GeoDiffUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) == ('torch_geometric.data.data', 'Data'):
            return LegacyData
        return super().find_class(module, name)


def load(path):
    with open(path, 'rb') as source:
        return GeoDiffUnpickler(source).load()
