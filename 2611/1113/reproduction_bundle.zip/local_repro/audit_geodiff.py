"""Audit the published GeoDiff source without rewriting or resampling records."""

import argparse
import hashlib
import json
import platform
from collections import Counter
from pathlib import Path

import torch
import rdkit

from geodiff_compat import load

BASE = Path('/data/zhouwanyao/motiflow')
REPO = Path(__file__).resolve().parents[1]


def verify_existing():
    """Reuse a completed audit only after checking source bytes and environment."""
    report = json.loads((BASE / 'manifests/geodiff_source_audit.json').read_text())
    expected = json.loads((REPO / 'motiflow/data/manifests/geom_paper_split.json').read_text())
    environment = {'python': platform.python_version(), 'torch': torch.__version__, 'rdkit': rdkit.__version__}
    for split, name in [('val', 'val_data_5k.pkl'), ('train', 'train_data_40k.pkl')]:
        stats = report[split]
        assert stats.get('reader_environment') == environment, f'Stale audit environment: {split}'
        assert stats['conformers'] == expected['splits'][split]['conformer_count']
        assert stats['unique_source_smiles'] == expected['splits'][split]['molecule_count']
        assert not stats['missing_topology'] and not stats['malformed']
        path = BASE / 'raw/geom_drugs' / name
        hasher = hashlib.sha256()
        with path.open('rb') as source:
            for block in iter(lambda: source.read(8 * 1024 * 1024), b''):
                hasher.update(block)
        assert path.stat().st_size == stats['bytes'] and hasher.hexdigest() == stats['sha256'], f'Changed source: {split}'
    assert report['source_smiles_overlap'] == 0
    print(json.dumps({'existing_audit_verified': True, 'reader_environment': environment}), flush=True)


def main():
    expected = json.loads((REPO / 'motiflow/data/manifests/geom_paper_split.json').read_text())
    report, identities = {}, {}
    for split, name in [('val', 'val_data_5k.pkl'), ('train', 'train_data_40k.pkl')]:
        path = BASE / 'raw/geom_drugs' / name
        print(f'Loading {path}', flush=True)
        records = load(path)
        counts, missing, malformed = Counter(), 0, []
        content = hashlib.sha256()
        for index, record in enumerate(records):
            molecule = getattr(record, 'rdmol', None)
            if molecule is None:
                missing += 1
                malformed.append({'index': index, 'reason': 'missing_topology'})
                continue
            smiles = record.smiles
            counts[smiles] += 1
            positions = torch.as_tensor(record.pos).detach().cpu().contiguous()
            if positions.shape != (molecule.GetNumAtoms(), 3) or not torch.isfinite(positions).all():
                malformed.append({'index': index, 'reason': 'nonfinite_or_mismatched_positions'})
            content.update(smiles.encode() + b'\0')
            content.update(str(positions.dtype).encode() + str(tuple(positions.shape)).encode())
            content.update(positions.numpy().tobytes())
            topology = {'atoms': [atom.GetAtomicNum() for atom in molecule.GetAtoms()],
                        'bonds': [(bond.GetBeginAtomIdx(), bond.GetEndAtomIdx(), str(bond.GetBondType()))
                                  for bond in molecule.GetBonds()]}
            content.update(json.dumps(topology, separators=(',', ':')).encode() + b'\n')
        hasher = hashlib.sha256()
        with path.open('rb') as source:
            for block in iter(lambda: source.read(8 * 1024 * 1024), b''):
                hasher.update(block)
        actual_hash = hasher.hexdigest()
        stats = {'file': str(path), 'bytes': path.stat().st_size, 'sha256': actual_hash,
                 'reader_environment': {'python':platform.python_version(),'torch':torch.__version__,'rdkit':rdkit.__version__},
                 'motiflow_frozen_sha256': expected['splits'][split]['sha256'],
                 'conformers': len(records), 'unique_source_smiles': len(counts),
                 'conformers_per_smiles_histogram': dict(Counter(counts.values())),
                 'missing_topology': missing, 'malformed': malformed,
                 'ordered_smiles_topology_positions_sha256': content.hexdigest()}
        report[split] = stats
        identities[split] = set(counts)
        print(json.dumps(stats), flush=True)
        (BASE / f'manifests/geodiff_{split}_audit.json').write_text(json.dumps(stats, indent=2) + '\n')
        expected_split = expected['splits'][split]
        if len(records) != expected_split['conformer_count'] or len(counts) != expected_split['molecule_count']:
            raise ValueError(f'Counts differ for {split}: {len(records)} conformers, {len(counts)} molecules')
        if missing or malformed:
            raise ValueError(f'Invalid scientific fields in {split}')
        del records
    report['source_smiles_overlap'] = len(identities['train'] & identities['val'])
    report['exact_frozen_bytes_match'] = False
    report['semantic_equivalence_to_author_files_proven'] = False
    report['source_url'] = 'https://drive.google.com/file/d/1bL52Enn-MRxtVPgEhAf6LUYgkZpaSdht/view'
    (BASE / 'manifests/geodiff_source_audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'audit_complete': True, 'source_smiles_overlap': report['source_smiles_overlap']}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-existing', action='store_true')
    arguments = parser.parse_args()
    verify_existing() if arguments.verify_existing else main()
