"""Read pipeline state together with current process, transfer and GPU evidence."""

import json
import subprocess
from pathlib import Path

base = Path("/data/zhouwanyao/motiflow")
status = json.loads((base / "pipeline_status.json").read_text())
processes = {}
for name in ["pipeline", "setup_env", "download_geom"]:
    file = base / f"logs/{name}.pid"
    if not file.exists():
        continue
    pid = int(file.read_text())
    try:
        stat = Path(f"/proc/{pid}/stat").read_text().split(")", 1)[1].split()
        command = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
        expected_script = {"pipeline": "pipeline.py", "setup_env": "setup_env.sh", "download_geom": "download_geom.sh"}[name]
        processes[name] = {"pid": pid, "process_state": stat[0], "command": command,
                           "running": stat[0] != "Z" and expected_script in command}
    except FileNotFoundError:
        processes[name] = {"pid": pid, "running": False}
downloads = [{"file": str(path), "bytes": path.stat().st_size,
              "expected_bytes": 524880147, "fraction": round(path.stat().st_size / 524880147, 4)}
             for path in (base / "raw").glob("Drugs*") if path.is_file()]
conda = None
plan = base / "manifests/conda_plan.json"
if plan.is_file():
    total = sum(item['size'] for item in json.loads(plan.read_text())['actions']['FETCH'])
    received = sum(path.stat().st_size for path in (base / "cache/conda_ranges").rglob('*') if path.is_file())
    conda = {"received_bytes": received, "expected_bytes": total, "fraction": round(received / total, 4),
             "all_hashes_verified": (base / "manifests/conda_fetch_verified.json").is_file()}
print(json.dumps({"pipeline": status, "live_processes": processes, "downloads": downloads,
                  "conda_dependency_transfers": conda}, indent=2), flush=True)
subprocess.run(["nvidia-smi", "--id=0,1,2", "--query-gpu=index,name,memory.used,utilization.gpu", "--format=csv"])
