"""Compare real three-GPU reduced gradients against full-batch autograd."""

import copy
import json
import os
from pathlib import Path

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel

from distributed import partition_batch


class Objective(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.base = torch.nn.Linear(5, 3)
        self.optional = torch.nn.Linear(3, 3)

    def forward(self, batch, use_optional):
        x = self.base(batch["x"])
        if use_optional:
            with torch.no_grad():
                preliminary = self.optional(x)
            x = self.optional(x + preliminary)
        return ((x - batch["target"]) ** 2).sum(-1).mean()


def main():
    rank, world = int(os.environ["RANK"]), int(os.environ["WORLD_SIZE"])
    device = torch.device("cuda", int(os.environ["LOCAL_RANK"]))
    torch.cuda.set_device(device)
    dist.init_process_group("nccl")
    results = []
    try:
        for trial, size in enumerate([64, 63, 5, 2, 1]):
            torch.manual_seed(200 + trial)
            module = Objective().to(device)
            reference = copy.deepcopy(module)
            ddp = DistributedDataParallel(module, device_ids=[device.index], find_unused_parameters=True)
            batch = {"x": torch.randn(size, 5, device=device), "target": torch.randn(size, 3, device=device),
                     "frag_mask": torch.ones(size, 2, device=device)}
            # Inputs are identical across ranks, independently of CUDA RNG implementation.
            for value in batch.values():
                dist.broadcast(value, src=0)
            local, count, scale = partition_batch(batch, rank, world)
            use_optional = bool(trial % 2)
            loss = ddp(local, use_optional)
            (loss * scale).backward()
            reference(batch, use_optional).backward()
            maximum = 0.0
            for actual, expected in zip(module.parameters(), reference.parameters()):
                if actual.grad is None or expected.grad is None:
                    assert actual.grad is None and expected.grad is None
                else:
                    maximum = max(maximum, float((actual.grad - expected.grad).abs().max()))
                    torch.testing.assert_close(actual.grad, expected.grad, atol=2e-6, rtol=2e-5)
            results.append({"global_batch": size, "local_counts": [size // world + int(r < size % world) for r in range(world)],
                            "max_gradient_error": maximum, "optional_branch": use_optional})
        if rank == 0:
            payload = {"passed": True, "torch": torch.__version__, "gpu": torch.cuda.get_device_name(device),
                       "world_size": world, "checks": results}
            print(json.dumps(payload, indent=2), flush=True)
            if os.environ.get("MOTIFLOW_CHECK_OUTPUT"):
                Path(os.environ["MOTIFLOW_CHECK_OUTPUT"]).write_text(json.dumps(payload, indent=2) + "\n")
    finally:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
