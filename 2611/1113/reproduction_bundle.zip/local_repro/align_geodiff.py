"""Use upstream alignment with only the legacy PyG source reader adapted."""

import os
import runpy
import sys
from pathlib import Path

from geodiff_compat import load

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from motiflow.data import loaders


def load_geom_tasks(config, split):
    path = os.path.join(config['data_root'], config['dataset']['split_files'][split])
    records = load(path)
    tasks = []
    for index, record in enumerate(records):
        task = {'dataset': 'geom', 'sample_id': str(index)}
        if getattr(record, 'rdmol', None) is None:
            task['load_error'] = 'GEOM record has no RDKit molecule'
        else:
            task.update(mol_bytes=record.rdmol.ToBinary(), pos=record.pos, smiles=record.smiles,
                        aux={'totalenergy': getattr(record, 'totalenergy', None),
                             'boltzmannweight': getattr(record, 'boltzmannweight', None)})
        tasks.append(task)
    return tasks


if __name__ == '__main__':
    loaders.load_geom_tasks = load_geom_tasks
    # Execute as a script so Hydra resolves ../../configs from the upstream
    # file, rather than treating the non-package configs directory as a module.
    runpy.run_path(str(Path(__file__).resolve().parents[1] / 'scripts/data_prep/align.py'), run_name='__main__')
