#!/usr/bin/env python
"""Run the authorized GEOM reproduction and retain live, inspectable stage state."""

import argparse
import fcntl
import hashlib
import json
import os
import subprocess
import tarfile
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
BASE = Path("/data/zhouwanyao/motiflow")
PYTHON = BASE / "envs/motiflow-env/bin/python"
STATE = BASE / "pipeline_status.json"
ENV = dict(os.environ, CUDA_VISIBLE_DEVICES="0,1,2", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
           OPENBLAS_NUM_THREADS="1", PYTHONUNBUFFERED="1", PIP_CACHE_DIR=str(BASE / "cache/pip"),
           TMPDIR=str(BASE / "cache/tmp"))
# Tool-session proxies can disappear when a detached job outlives its session.
# Downloads must use the server's verified direct connection instead.
for key in list(ENV):
    if key.lower() in {"http_proxy", "https_proxy", "all_proxy", "pip_proxy"}:
        ENV.pop(key)


def state(stage, **extra):
    payload = {"stage": stage, "pid": os.getpid(), "updated_utc": datetime.now(timezone.utc).isoformat(), **extra}
    temporary = STATE.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n")
    temporary.replace(STATE)
    print(json.dumps(payload), flush=True)


def running(pid):
    try:
        stat = Path(f"/proc/{pid}/stat").read_text()
        return stat.split(")", 1)[1].split()[0] != "Z"
    except FileNotFoundError:
        return False


def command(stage, args, *, env=None):
    log_path = BASE / "logs" / (stage + ".log")
    with log_path.open("a", buffering=1) as log:
        log.write(json.dumps({"argv": list(map(str, args)), "time": datetime.now(timezone.utc).isoformat()}) + "\n")
        process = subprocess.Popen(list(map(str, args)), cwd=REPO, env=env or ENV,
                                   stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
        state(stage, child_pid=process.pid, log=str(log_path))
        result = process.wait()
        if result:
            raise RuntimeError(f"{stage} exited {result}; see {log_path}")


def distributed_args(script):
    return [PYTHON, "-m", "torch.distributed.run", "--standalone", "--nproc_per_node=3", REPO / "local_repro" / script]


def training_args(name):
    return ["experiment=unconditional/geom", "tracking=disabled", "seed=0", "training.batch_size=64",
            "training.num_epochs=135", f"data.processed_data_dir={BASE}/data/fragmented/geom/alpha_0p1",
            f"training.checkpoint_dir={BASE}/outputs/{name}/checkpoints",
            f"training.eval_dir={BASE}/outputs/{name}/evaluation",
            f"hydra.run.dir={BASE}/outputs/{name}/hydra", "+runtime.world_size=3",
            "+runtime.distributed_adapter=local_repro/train_ddp.py"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--resume-preparation', action='store_true',
                        help='Reuse the installed environment and verify the completed source audit; training remains fresh')
    arguments = parser.parse_args()
    lock = (BASE / "pipeline.lock").open("w")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    (BASE / "logs/pipeline.pid").write_text(str(os.getpid()) + "\n")
    with tarfile.open(BASE / 'manifests/local_adapter_source.tar.gz', 'w:gz') as archive:
        archive.add(REPO / 'local_repro', arcname='local_repro',
                    filter=lambda entry: None if '__pycache__' in entry.name else entry)
    source_hashes = {str(path.relative_to(REPO)): hashlib.sha256(path.read_bytes()).hexdigest()
                     for path in sorted((REPO / "local_repro").glob("*")) if path.is_file()}
    protocol = {"upstream_url": "https://github.com/rpoletukhin/MotiFlow",
                "upstream_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
                "dataset": "GEOM-Drugs", "source": "GeoDiff Drugs.tar.gz",
                "existing_raw_geom_archive": "/data/zhouwanyao/dataset/rdkit_folder.tar.gz.part",
                "cuda_visible_devices": "0,1,2", "world_size": 3, "global_batch_size": 64,
                "full_microbatches": [22, 21, 21], "epochs": 135, "training_seed": 0,
                "learning_rate": 1e-4, "alpha_threshold_percent": 0.1,
                "sampling_seeds": [0, 1, 2], "samples_per_seed": 10000, "sampling_steps": 100,
                "temperature": 1.0, "remasking_rate": 1.5,
                "deviations": ["Authorized three-GPU DDP adapter replaces upstream single-GPU runner",
                               "Runtime alignment workers increased from 4 to 16",
                               "WandB disabled; per-step JSONL retained",
                               "Evaluation reader accepts canonical shard_*.pt reference files with upstream reconstruction and metrics",
                               "Optional notebook dependencies omitted"],
                "local_source_sha256": source_hashes}
    (BASE / "manifests/reproduction_protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    pending = {} if arguments.resume_preparation else {
        name: int((BASE / "logs" / (name + ".pid")).read_text()) for name in ["setup_env"]}
    if arguments.resume_preparation and not (BASE / 'manifests/environment_ready.json').is_file():
        raise RuntimeError('Preparation reuse requires a completed environment check')
    while pending:
        state("waiting_for_downloads", dependencies=pending)
        for name, pid in list(pending.items()):
            if running(pid):
                continue
            if name == "setup_env" and not (PYTHON.parent.parent / "conda-meta/history").is_file():
                raise RuntimeError("Environment setup stopped before completion; inspect logs/setup_env.log")
            if name == "download_geom" and not (BASE / "manifests/geom_download_verified.json").is_file():
                raise RuntimeError("Data download or source hash verification failed; inspect logs/download_geom.log")
            pending.pop(name)
        if pending:
            time.sleep(15)
    if not arguments.resume_preparation:
        command("install_project", [PYTHON, "-m", "pip", "install", "--retries", "10",
                                    "--timeout", "120", "-e", ".[dev,tracking]"])
    command("environment_check", [PYTHON, "-c", "import hydra,openbabel,rdkit,torch,torch_geometric,ase; "
            "print(torch.__version__,rdkit.__version__,torch.cuda.is_available(),torch.cuda.device_count()); "
            "assert torch.cuda.is_available() and torch.cuda.device_count()==3; "
            "assert torch.__version__.startswith('2.1.0')"])
    with (BASE / "manifests/pip_freeze.txt").open("w") as handle:
        subprocess.run([PYTHON, "-m", "pip", "freeze"], env=ENV, stdout=handle, check=True)
    with (BASE / "manifests/conda_explicit.txt").open("w") as handle:
        subprocess.run(["/home/zhouwanyao/anaconda3/bin/conda", "list", "--prefix", str(PYTHON.parent.parent), "--explicit"], stdout=handle, check=True)
    command("ddp_gradient_check", distributed_args("check_ddp.py"),
            env=dict(ENV, MOTIFLOW_CHECK_OUTPUT=str(BASE / "manifests/ddp_gradient_check_torch210.json")))
    (BASE / "manifests/environment_ready.json").write_text(json.dumps({'python':str(PYTHON),'cuda':'0,1,2', 'target_gradient_check_passed':True})+'\n')
    decision_path = BASE / 'manifests/dataset_baseline_decision.json'
    while not (BASE / 'manifests/geom_download_verified.json').is_file() and not decision_path.is_file():
        state('waiting_for_dataset_decision', environment_ready=True,
              reason='Official GeoDiff archive differs from frozen MotiFlow hashes; awaiting user baseline choice')
        time.sleep(15)
    align_script = 'scripts/data_prep/align.py'
    if (BASE / 'manifests/geom_download_verified.json').is_file():
        command("verify_geom_splits", [PYTHON, "scripts/data_prep/verify_geom_splits.py", "--data-root", BASE])
    else:
        decision = json.loads(decision_path.read_text())
        if decision.get('baseline') != 'official_geodiff':
            raise RuntimeError('The chosen exact-byte baseline is not available; scientific stages remain stopped')
        audit_args = [PYTHON, 'local_repro/audit_geodiff.py']
        if arguments.resume_preparation:
            audit_args.append('--verify-existing')
        command('audit_geodiff_target_environment', audit_args)
        protocol['dataset_baseline'] = decision
        protocol['deviations'] += ['Official GeoDiff archive bytes differ from the MotiFlow frozen manifest; equivalence to author files is unproven',
                                  'Legacy PyG-1 source objects read as plain containers; source fields are not rewritten or resampled']
        (BASE / 'manifests/reproduction_protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
        align_script = 'local_repro/align_geodiff.py'
    command("align_geom", [PYTHON, align_script, "dataset=geom", f"data_root={BASE}/data",
            f"output_root={BASE}/data/preprocessed", "processing.num_workers=16",
            f"hydra.run.dir={BASE}/outputs/preprocessing/align_hydra"])
    aligned_counts = {}
    for split, requested, retained in [("train", 199950, 197220), ("val", 25000, 24676)]:
        manifest = json.loads((BASE / f"data/preprocessed/geom/{split}/manifest.json").read_text())
        counts = manifest["counts"][split]
        aligned_counts[split] = counts
        if counts["requested"] != requested or counts["succeeded"] != retained:
            raise RuntimeError(f"Aligned {split} counts differ from upstream README: {counts}; expected {requested}/{retained}")
    (BASE / "manifests/aligned_count_check.json").write_text(json.dumps(aligned_counts, indent=2) + "\n")
    command("fragment_geom", [PYTHON, "scripts/data_prep/fragment.py", "dataset=geom", "alpha_threshold=0.1",
            f"data_root={BASE}/data", f"aligned_root={BASE}/data/preprocessed", f"output_root={BASE}/data/fragmented",
            f"hydra.run.dir={BASE}/outputs/preprocessing/fragment_hydra"])
    command("ddp_model_smoke", distributed_args("train_ddp.py") + training_args("smoke") +
            ["training.max_steps=12", "training.log_every_steps=1", "training.checkpoint_every_steps=12",
             "training.eval_every_steps=6", "training.max_eval_batches=1", "training.eval_batch_size=4",
             "training.num_loader_workers=0"])
    smoke_checkpoint = BASE / "outputs/smoke/checkpoints/step_12_final.pth"
    command("smoke_sample", [PYTHON, "scripts/sample.py", "experiment=unconditional/geom", f"sampling.checkpoint_path={smoke_checkpoint}",
            f"data.processed_data_dir={BASE}/data/fragmented/geom/alpha_0p1", "sampling.num_samples=8", "sampling.num_steps=4",
            f"sampling.output_path={BASE}/outputs/smoke/generated.pt", f"hydra.run.dir={BASE}/outputs/smoke/sample_hydra"])
    command("smoke_evaluate", [PYTHON, "local_repro/evaluate_geom.py", "evaluation=geom",
            f"evaluation.generated_paths=[{BASE}/outputs/smoke/generated.pt]", "evaluation.reference_path=null",
            "evaluation.compute_properties=false", "evaluation.compute_strain=false",
            f"evaluation.library_path={BASE}/data/fragmented/geom/alpha_0p1/fragment_library.pt",
            f"evaluation.output_dir={BASE}/outputs/smoke/final_evaluation", f"hydra.run.dir={BASE}/outputs/smoke/evaluate_hydra"])
    command("train_geom_ddp", distributed_args("train_ddp.py") + training_args("geom_ddp_seed0"))
    checkpoints = list((BASE / "outputs/geom_ddp_seed0/checkpoints").glob("*_final.pth"))
    if len(checkpoints) != 1:
        raise RuntimeError(f"Expected one final checkpoint, found {checkpoints}")
    processes, handles, generated = [], [], []
    for seed in range(3):
        target = BASE / f"outputs/generated/seed{seed}.pt"
        generated.append(str(target))
        target.parent.mkdir(exist_ok=True, parents=True)
        handle = (BASE / f"logs/sample_seed{seed}.log").open("a", buffering=1)
        handles.append(handle)
        args = [PYTHON, "scripts/sample.py", "experiment=unconditional/geom", f"seed={seed}",
                f"sampling.checkpoint_path={checkpoints[0]}", "sampling.num_samples=10000", "sampling.num_steps=100",
                f"data.processed_data_dir={BASE}/data/fragmented/geom/alpha_0p1", f"sampling.output_path={target}",
                f"hydra.run.dir={BASE}/outputs/generated/seed{seed}_hydra"]
        processes.append(subprocess.Popen(list(map(str, args)), cwd=REPO, env=dict(ENV, CUDA_VISIBLE_DEVICES=str(seed)),
                                          stdout=handle, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL))
    state("sample_three_seeds", child_pids=[process.pid for process in processes])
    codes = [process.wait() for process in processes]
    for handle in handles:
        handle.close()
    if any(codes):
        raise RuntimeError(f"Sampling failed: exit codes {codes}; inspect logs/sample_seed*.log")
    command("evaluate_geom", [PYTHON, "local_repro/evaluate_geom.py", "evaluation=geom", f"evaluation.generated_paths={json.dumps(generated)}",
            f"evaluation.library_path={BASE}/data/fragmented/geom/alpha_0p1/fragment_library.pt",
            f"evaluation.reference_path={BASE}/data/preprocessed/geom/train", f"evaluation.output_dir={BASE}/outputs/final_evaluation",
            f"hydra.run.dir={BASE}/outputs/final_evaluation/hydra"])
    command("write_report", [PYTHON, "local_repro/report.py"])
    state("complete", report=str(BASE / "REPORT.md"))


if __name__ == "__main__":
    try:
        main()
    except BaseException:
        state("failed", error=traceback.format_exc())
        raise
