import sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
from scipy.spatial.transform import Rotation

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from port_selection import select_frames


class Library:
    def template(self,label):
        return None,np.array([[-1.,0,0],[1.,0,0]])


def fixture():
    graph=SimpleNamespace(edge_index=torch.tensor([[0,4],[4,0]]),
        node_entity=torch.tensor([1,0,1,0,2]),frag_idx_map=torch.tensor([0,0,1,1,0]))
    xyz=np.array([[-1.,0,0],[1,0,0],[-1,2,0],[1,2,0],[-1,0,1]])
    state=SimpleNamespace(pn=0,groups=[[0,1],[2,3]],graph=graph,
        orientation_case=dict(connections=[dict(i=0,j=1,a=0,b=0,order=1)]),physical=lambda:xyz)
    return state,xyz


def test_predicted_port_selects_roll_without_moving_real_atoms_or_graph():
    state,xyz=fixture()
    graph=state.graph.edge_index.clone()
    rotations,rows=select_frames(state,Library(),[1,1],np.zeros((2,3)),np.array([np.eye(3)]*2),
        [dict(mode='rank_one',old_fit_RMSD_A=0.)]*2,'port')
    assert rows[0]['selected']==3
    assert rows[0]['candidates'][0]['port_direction_angle_deg']==[90.]
    assert rows[0]['candidates'][3]['port_direction_angle_deg'][0]<1e-6
    assert np.allclose(xyz[:2]@rotations[0].T,xyz[:2],atol=1e-13)
    assert torch.equal(state.graph.edge_index,graph)
    assert len(state.graph.node_entity)==5


def test_port_choice_is_SE3_equivariant_for_original_helpers():
    state,xyz=fixture()
    audit=[dict(mode='rank_one',old_fit_RMSD_A=0.)]*2
    first,rows=select_frames(state,Library(),[1,1],np.zeros((2,3)),np.array([np.eye(3)]*2),audit,'hybrid')
    world=Rotation.from_rotvec([.4,-.2,.7]).as_matrix()
    state.physical=lambda:xyz@world.T+[2,3,4]
    second,other=select_frames(state,Library(),[1,1],np.zeros((2,3)),np.array([world]*2),audit,'hybrid')
    assert rows[0]['selected']==other[0]['selected']
    assert np.allclose(second[0],world@first[0],atol=1e-12)
