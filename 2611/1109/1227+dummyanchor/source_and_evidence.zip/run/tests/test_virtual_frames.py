import sys
from pathlib import Path
import numpy as np
import pytest
from scipy.spatial.transform import Rotation

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'source'))
from virtual_frames import baseline, fit, register


def assert_fit(x, y, ref):
    t, r, error, audit = fit(x, y, ref)
    reconstructed = x @ r.T + t
    assert np.isfinite(reconstructed).all()
    assert np.max(np.abs(r.T @ r - np.eye(3))) < 1e-12
    assert abs(np.linalg.det(r) - 1) < 1e-12
    assert error <= audit['old_fit_RMSD_A'] + 1.00001e-7
    distances = lambda z: np.linalg.norm(z[:, None] - z[None, :], axis=-1)
    assert np.max(np.abs(distances(x) - distances(reconstructed))) < 1e-12
    assert audit['anchors_in_model_graph'] is False
    return t, r, error, audit


@pytest.mark.parametrize('x', [np.zeros((1, 3)), np.array([[-1., 0, 0], [1, 0, 0]]),
    np.array([[-1., 0, 0], [0, 0, 0], [1, 0, 0]])])
def test_exact_degeneracies_match_current_reference_method(x):
    ref = Rotation.from_rotvec([.3, -.5, .7]).as_matrix()
    actual = Rotation.from_rotvec([-.2, .4, .5]).as_matrix()
    y = x @ actual.T + [2, 3, 4]
    t, r, e, audit = assert_fit(x, y, ref)
    tt, rr, _, _ = baseline.fit(x, y, ref)
    assert np.allclose(r, rr, atol=1e-13) and np.allclose(t, tt, atol=1e-13)
    assert e < 1e-13 and audit['frame_anchor_count'] == (2 if len(x) == 1 else 1)


def test_nondegenerate_planar_and_symmetric_templates_preserve_baseline():
    for x in [np.array([[0., 0, 0], [1, 0, 0], [0, 1, 0]]),
              np.array([[1., 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]])]:
        actual = Rotation.from_rotvec([.2, .5, -.3]).as_matrix()
        y = x @ actual.T + [4, 5, 6]
        t, r, _, audit = assert_fit(x, y, np.eye(3))
        tt, rr, _, _ = baseline.fit(x, y, np.eye(3))
        assert np.array_equal(t, tt) and np.array_equal(r, rr)
        assert audit['frame_anchor_count'] == 0


@pytest.mark.parametrize('epsilon', [1e-7, 1e-6, 1e-5, 1e-4])
def test_near_linear_templates_preserve_atom_fit_budget(epsilon):
    x = np.array([[-1., 0, 0], [0, epsilon, 0], [1, 0, 0], [2, -.2*epsilon, 0]])
    actual = Rotation.from_rotvec([-.2, .4, .5]).as_matrix()
    y = x @ actual.T + [2, 3, 4]
    assert_fit(x, y, np.eye(3))


def test_global_SE3_equivariance_including_antipodal_case():
    x = np.array([[-1., 0, 0], [1, 0, 0]])
    ref = Rotation.from_rotvec([.3, -.5, .7]).as_matrix()
    world = Rotation.from_rotvec([-.2, .4, .5]).as_matrix()
    shift = np.array([5., -3, 2])
    for y in [x @ ref.T + [1, 2, 3], -x @ ref.T + [1, 2, 3]]:
        t, r, _, _ = assert_fit(x, y, ref)
        tt, rr, _, _ = assert_fit(x, y @ world.T + shift, world @ ref)
        assert np.allclose(rr, world @ r, atol=1e-12)
        assert np.allclose(tt, t @ world.T + shift, atol=1e-12)


@pytest.mark.parametrize('noise', [1e-7, 1e-6, 1e-5, 1e-4])
def test_perturbed_real_coordinates_are_gauge_aware(noise):
    x = np.array([[-1., 0, 0], [1, 0, 0]])
    ref = Rotation.from_rotvec([.3, -.5, .7]).as_matrix()
    y = x @ ref.T + [2, 3, 4]
    z = y + np.random.default_rng(73).normal(size=y.shape) * noise
    t, r, _, _ = assert_fit(x, z, ref)
    tt, rr, _, _ = baseline.fit(x, z, ref)
    assert np.max(np.abs((x @ r.T + t) - (x @ rr.T + tt))) < 1e-12
    assert baseline.distance(r, ref) < 5 * noise


def test_previous_rotation_transport_over_101_steps():
    x = np.array([[-1., 0, 0], [1, 0, 0]])
    last = np.eye(3)
    for step in range(101):
        ref = Rotation.from_rotvec(np.array([.002, -.001, .003]) * step).as_matrix()
        _, r, _, _ = assert_fit(x, x @ ref.T, ref)
        assert baseline.distance(r, ref) < 1e-12
        assert baseline.distance(r, last) < .004
        last = r


def test_near_linear_rank_transition_has_no_large_roll_jump():
    ref=Rotation.from_rotvec([.5,.2,.4]).as_matrix()
    actual=Rotation.from_rotvec([-.1,.7,-.4]).as_matrix()
    rotations=[]
    for epsilon in np.geomspace(1e-7,1e-4,1001):
        x=np.array([[-1.,0,0],[0,epsilon,0],[1,0,0]])
        _,r,_,_=assert_fit(x,x@actual.T+[2,3,4],ref)
        rotations.append(r)
    assert max(baseline.distance(a,b) for a,b in zip(rotations,rotations[1:]))<.08


def test_antipodal_approach_preserves_observable_atoms():
    x = np.array([[-1., 0, 0], [1, 0, 0]])
    previous = None
    for theta in np.linspace(np.pi - .01, np.pi + .01, 101):
        true = Rotation.from_rotvec([0, theta, 0]).as_matrix()
        y = x @ true.T
        t, r, _, _ = assert_fit(x, y, np.eye(3))
        reconstructed = x @ r.T + t
        assert np.allclose(reconstructed, y, atol=1e-12)
        if previous is not None:
            assert np.max(np.linalg.norm(reconstructed - previous, axis=-1)) < .00021
        previous = reconstructed
    # No globally unique continuous SO(3) representative exists at the cut locus.
    # The unconstrained roll must not be confused with a physical atom jump.


@pytest.mark.parametrize('reverse', [False, True])
def test_identity_change_uses_explicit_new_template_chart(reverse):
    linear = np.array([[-1., 0, 0], [1, 0, 0]])
    triangle = np.array([[-1., 0, 0], [1, 0, 0], [0, 1, 0]])
    new = linear if reverse else triangle
    world = Rotation.from_rotvec([.3, -.5, .7]).as_matrix()
    chart = Rotation.from_rotvec([-.1, .2, .4]).as_matrix()
    changed_template = new @ chart.T
    transported = world @ chart.T
    target = new @ world.T + [2, 3, 4]
    t, r, _, _ = assert_fit(changed_template, target, transported)
    assert np.allclose(changed_template @ r.T + t, target, atol=1e-12)
    assert baseline.distance(r, transported) < 1e-12
    # Artificial known chart only; this does not establish real atom matching
    # across arbitrary vocabulary identities in live generation.


def test_cached_existing_helper_reuse_and_CPU_chunking_consistency():
    x = np.array([[-.75, 0, 0], [.75, 0, 0]])
    frame = register(x, [[0, 0, 2], [0, 1, 0]])
    assert frame['origin'] == 'existing_official_reference_helpers'
    assert np.allclose(frame['vectors'][0], [0, 0, 1])
    reference = [Rotation.from_rotvec(np.array([.01, .02, -.03]) * i).as_matrix() for i in range(32)]
    expected = [fit(x, x @ r.T, r)[1] for r in reference]
    for size in [1, 4, 8, 16, 32]:
        actual = []
        for start in range(0, 32, size):
            actual.extend(fit(x, x @ r.T, r)[1] for r in reference[start:start+size])
        assert all(np.array_equal(a, b) for a, b in zip(expected, actual))
    # This checks component cache/order independence, not neural Batch replay.


def test_case_specific_helpers_do_not_leak_across_batch_order():
    import virtual_frames as vf
    x=np.array([[-1.,0,0],[0,1e-7,0],[1,0,0]])
    ref=Rotation.from_rotvec([.3,-.5,.7]).as_matrix()
    y=x@Rotation.from_rotvec([-.1,.2,.4]).as_matrix().T
    contexts=[{vf.key(x):vf.register(x,[[0,np.cos(t),np.sin(t)]],cache=False)} for t in [0.,1.,2.,3.]]
    def solve(context):
        with vf.using(context):
            return fit(x,y,ref)[1]
    expected=[solve(c) for c in contexts]
    for order in [[3,2,1,0],[0,2,1,3]]:
        actual={i:solve(contexts[i]) for i in order}
        assert all(np.array_equal(expected[i],actual[i]) for i in range(4))
