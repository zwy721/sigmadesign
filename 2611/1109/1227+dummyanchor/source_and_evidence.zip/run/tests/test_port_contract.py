import sys
from pathlib import Path
import numpy as np
from types import SimpleNamespace

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from port_selection import identity_correspondence,score,ANGLES


class Library:
    def template(self,label):
        return None,np.array([[-1.,0,0],[1.,0,0]])


def test_changed_identity_port_role_is_not_claimed_real_atom_correspondence():
    old=[dict(i=0,j=1,a=0,b=1,order=1)]
    new=[dict(i=0,j=1,a=1,b=0,order=1)]
    rows=identity_correspondence(Library(),[2,3],[4,5],old,new)
    assert rows[0]['real_atom_pairs']==[]
    assert rows[0]['shared_port_pairs']==[dict(neighbor_slot=1,order=1,old_atom=0,new_atom=1)]
    assert rows[0]['unresolved_physical_orientation'] is True


def test_changed_identity_without_retained_port_remains_explicitly_unresolved():
    rows=identity_correspondence(Library(),[2,3],[4,5],[],[])
    assert all(r['unresolved_physical_orientation'] and not r['real_atom_pairs'] and not r['shared_port_pairs'] for r in rows)


def test_hybrid_penalizes_severe_clashes_without_changing_geometry_thresholds():
    m=dict(cross_bond_MAE_A=.15,cross_angle_MAE_deg=15.,severe_cross_internal_pairs=1,severe_protein_pairs=1)
    assert score(m,'port')==(2.,[])
    assert score(m,'hybrid')==(22.,[])
    assert len(ANGLES)==4 and ANGLES[0]==0


def test_unavailable_geometry_is_preserved_as_unavailable():
    value,missing=score(dict(cross_bond_MAE_A=None,cross_angle_MAE_deg=None),'port')
    assert value==0 and set(missing)=={'cross_bond_MAE_A','cross_angle_MAE_deg'}
