# A100吞吐与锚点成本

各方法每步一次真正PyG Batch主干前向；4进程CPU连接搜索、16进程QC。全程保持相同v5精度适配与语义辅助流，没有逐分子复制或调用完整主干。

{
  "device": "NVIDIA A100-SXM4-80GB",
  "rows": [
    {
      "batch_size": 16,
      "unique_inputs": 64,
      "measured_steps": 3,
      "wall_seconds": 9.476867537014186,
      "molecule_steps_per_second": 20.259858993501577,
      "peak_allocated_GiB": 4.072909355163574,
      "backbone_forward_calls": 16,
      "OOM_splits": [],
      "orientation_component": [
        {
          "method": "A_Current",
          "calls": 640,
          "CPU_frame_seconds": 2.491462677018717,
          "milliseconds_per_molecule": 3.892910432841745
        },
        {
          "method": "B_VirtualAnchor",
          "calls": 640,
          "CPU_frame_seconds": 2.9941443370189518,
          "milliseconds_per_molecule": 4.678350526592112
        },
        {
          "method": "C_PortAware",
          "calls": 640,
          "CPU_frame_seconds": 5.392966822953895,
          "milliseconds_per_molecule": 8.42651066086546
        },
        {
          "method": "D_Hybrid",
          "calls": 640,
          "CPU_frame_seconds": 5.765617253957316,
          "milliseconds_per_molecule": 9.008776959308307
        }
      ],
      "batch64_dynamic_certified": true
    },
    {
      "batch_size": 32,
      "unique_inputs": 64,
      "measured_steps": 3,
      "wall_seconds": 8.814903423190117,
      "molecule_steps_per_second": 21.78129365489011,
      "peak_allocated_GiB": 7.390233993530273,
      "backbone_forward_calls": 8,
      "OOM_splits": [],
      "orientation_component": [
        {
          "method": "A_Current",
          "calls": 640,
          "CPU_frame_seconds": 2.532399117015302,
          "milliseconds_per_molecule": 3.9568736203364097
        },
        {
          "method": "B_VirtualAnchor",
          "calls": 640,
          "CPU_frame_seconds": 2.921358516206965,
          "milliseconds_per_molecule": 4.564622681573383
        },
        {
          "method": "C_PortAware",
          "calls": 640,
          "CPU_frame_seconds": 5.36675254884176,
          "milliseconds_per_molecule": 8.38555085756525
        },
        {
          "method": "D_Hybrid",
          "calls": 640,
          "CPU_frame_seconds": 5.757764211855829,
          "milliseconds_per_molecule": 8.996506581024732
        }
      ],
      "batch64_dynamic_certified": true
    },
    {
      "batch_size": 64,
      "unique_inputs": 64,
      "measured_steps": 3,
      "wall_seconds": 8.40240789600648,
      "molecule_steps_per_second": 22.850592636814774,
      "peak_allocated_GiB": 11.873442649841309,
      "backbone_forward_calls": 4,
      "OOM_splits": [],
      "orientation_component": [
        {
          "method": "A_Current",
          "calls": 640,
          "CPU_frame_seconds": 2.520690267905593,
          "milliseconds_per_molecule": 3.938578543602489
        },
        {
          "method": "B_VirtualAnchor",
          "calls": 640,
          "CPU_frame_seconds": 2.9218867169693112,
          "milliseconds_per_molecule": 4.565447995264549
        },
        {
          "method": "C_PortAware",
          "calls": 640,
          "CPU_frame_seconds": 6.135844802018255,
          "milliseconds_per_molecule": 9.587257503153523
        },
        {
          "method": "D_Hybrid",
          "calls": 640,
          "CPU_frame_seconds": 5.830393654061481,
          "milliseconds_per_molecule": 9.109990084471065
        }
      ],
      "batch64_dynamic_certified": false
    }
  ],
  "scope": "Same 64 inputs; one warmup and three measured static steps; frame cost includes CPU geometry/port diagnostics; primary batch remains32",
  "other_workload_interference": "Device and CPU may be shared; absolute comparisons require this caveat"
}

| 方法 | 分子数 | 批次墙钟秒 | 主干调用 |
|---|---|---|---|
| D_Hybrid | 32 | 98.2466 | 24 |
| C_PortAware | 32 | 94.9591 | 24 |
| A_Current | 32 | 369.35 | 24 |
| B_VirtualAnchor | 32 | 92.9634 | 24 |

batch墙钟包含CPU搜索、几何评价和证据写盘；CUDA计时范围见原始batch timings。其他GPU工作负载会影响绝对吞吐，本轮不以资源干扰下的小差异改变算法。64只作性能探索，未通过动态64验收就不用于正式动态对照。
