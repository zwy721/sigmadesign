# 动态重复与批量比较

单算法要求离散身份/连接/接受决策完全相同，24步最大原子差≤0.025 Å、RMSD≤0.005 Å、内部距离差≤0.0002 Å。不同算法之间允许结果不同；未放宽阈值、删除失败或重抽样。

| 比较 | 样本 | 通过 | 离散一致 | 最大原子差 Å | 最大RMSD Å |
|---|---|---|---|---|---|
| A_Current_full_b1_b16 | 32 | True | True | 0 | 0 |
| A_Current_full_b1_b32 | 32 | True | True | 0 | 0 |
| A_Current_full_b1_b4 | 32 | True | True | 0 | 0 |
| A_Current_full_b1_b8 | 32 | True | True | 0 | 0 |
| A_Current_full_repeat | 32 | True | True | 0 | 0 |
| A_Current_stress_b1_b4 | 8 | True | True | 0 | 0 |
| A_Current_stress_repeat | 8 | True | True | 0 | 0 |
| A_b4_matches_frozen_current_baseline | 8 | True | True | 0 | 0 |
| A_matches_frozen_current_baseline | 8 | True | True | 0 | 0 |
| B_VirtualAnchor_full_b1_b16 | 32 | True | True | 0 | 0 |
| B_VirtualAnchor_full_b1_b32 | 32 | True | True | 0 | 0 |
| B_VirtualAnchor_full_b1_b4 | 32 | True | True | 0 | 0 |
| B_VirtualAnchor_full_b1_b8 | 32 | True | True | 0 | 0 |
| B_VirtualAnchor_full_repeat | 32 | True | True | 0 | 0 |
| B_VirtualAnchor_stress_b1_b4 | 8 | True | True | 0 | 0 |
| B_VirtualAnchor_stress_repeat | 8 | True | True | 0 | 0 |
| C_PortAware_full_b1_b16 | 32 | True | True | 0 | 0 |
| C_PortAware_full_b1_b32 | 32 | True | True | 0 | 0 |
| C_PortAware_full_b1_b4 | 32 | True | True | 0 | 0 |
| C_PortAware_full_b1_b8 | 32 | True | True | 0 | 0 |
| C_PortAware_full_repeat | 32 | True | True | 0 | 0 |
| C_PortAware_stress_b1_b4 | 8 | True | True | 0 | 0 |
| C_PortAware_stress_repeat | 8 | True | True | 0 | 0 |
| D_Hybrid_full_b1_b16 | 32 | True | True | 0 | 0 |
| D_Hybrid_full_b1_b32 | 32 | True | True | 0 | 0 |
| D_Hybrid_full_b1_b4 | 32 | True | True | 0 | 0 |
| D_Hybrid_full_b1_b8 | 32 | True | True | 0 | 0 |
| D_Hybrid_full_repeat | 32 | True | True | 0 | 0 |
| D_Hybrid_stress_b1_b4 | 8 | True | True | 0 | 0 |
| D_Hybrid_stress_repeat | 8 | True | True | 0 | 0 |

A另与前项v5压力集逐步对照，验证它确为当前基线。四方法初始化必须字节一致。32例批量对照只有通过全部8例预检后才运行；性能基准的64不等于动态64通过。完整失败与traceback保存在status.json及run.log。
