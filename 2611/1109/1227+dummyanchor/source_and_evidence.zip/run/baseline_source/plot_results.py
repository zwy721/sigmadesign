"""Export descriptive primary-vs-historical overview, with explicit caveat."""
from reporting import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    old=[flatten(r,'historical') for r in records(PRIOR,'main') if r['arm'] in ['B','C','E_connection_only']]
    new=[flatten(r) for r in records(OUT,'main')]
    assert len(new)==216 and len(old)==216
    groups=['B','C','E_connection_only'];labels=['B: fixed graph','C: dynamic identity + graph','E: graph only']
    fig,axes=plt.subplots(2,2,figsize=(12,7.5));x=np.arange(3);width=.36
    specs=[('high_quality','Native HQ / 72',True),('cross_bond_MAE_A','Cross-fragment bond MAE (A)',False),
        ('cross_angle_MAE_deg','Cross-fragment angle MAE (deg)',False),('severe_protein_pairs','Attempts with severe protein clash / 72',True)]
    for ax,(field,title,count) in zip(axes.flat,specs):
        values=[]
        for rows in [old,new]:
            means=[]
            for arm in groups:
                selected=[r for r in rows if r['arm']==arm];assert len(selected)==72
                if field=='high_quality':value=sum(r[field] is True for r in selected)
                elif count:value=sum((r.get(field) or 0)>0 for r in selected)
                else:value=mean(selected,field)
                means.append(np.nan if value is None else value)
            values.append(means)
        for offset,value,color,label in [(-width/2,values[0],'#b8bec4','Historical'),(width/2,values[1],'#246a8b','Revised')]:
            bars=ax.bar(x+offset,value,width,color=color,label=label)
            ax.bar_label(bars,fmt='%d' if count else '%.3f',padding=3,fontsize=9)
        ax.set_xticks(x,['B','C','E']);ax.set_title(title);ax.set_ylim(bottom=0)
        if count:ax.set_ylim(0,80)
        ax.spines[['top','right']].set_visible(False)
    axes[0,0].legend(frameon=False)
    fig.suptitle('Saved diagnostic cohort: six pockets x twelve fixed seeds',fontsize=14)
    fig.text(.5,.015,'Historical comparison is descriptive: common numerical execution also changed. No endpoint repair or training.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,.96));fig.savefig(OUT/'REVISED_BCE_OVERVIEW.png',dpi=180);plt.close(fig)


if __name__=='__main__':main()
