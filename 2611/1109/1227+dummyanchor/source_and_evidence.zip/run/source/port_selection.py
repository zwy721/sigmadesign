"""Four orientation candidates on a fixed predicted graph, without graph search."""
import numpy as np
from scipy.spatial.transform import Rotation
from virtual_frames import baseline

ANGLES = [0., np.pi/2, np.pi, -np.pi/2]


def axis_of(x):
    x = np.asarray(x, dtype=np.float64)
    if len(x) < 2 or np.linalg.norm(x - x.mean(0)) < 1e-12:
        return None
    return np.linalg.svd(x - x.mean(0), full_matrices=True)[2][0]


def score(metrics, method):
    unavailable = [k for k in ['cross_bond_MAE_A', 'cross_angle_MAE_deg'] if metrics.get(k) is None]
    value = ((metrics.get('cross_bond_MAE_A') or 0) / .15) ** 2
    value += ((metrics.get('cross_angle_MAE_deg') or 0) / 15.) ** 2
    if method == 'hybrid':
        value += 10. * (metrics.get('severe_cross_internal_pairs', 0) > 0)
        value += 10. * (metrics.get('severe_protein_pairs', 0) > 0)
    return float(value), unavailable


def identity_correspondence(lib, old_labels, new_labels, old_connections, new_connections):
    """A unique retained neighbor-role is a port correspondence, not atom identity."""
    rows = []
    for slot, (old, new) in enumerate(zip(old_labels, new_labels)):
        if old == new:
            mol, xyz = lib.template(old)
            rows.append(dict(slot=slot, unchanged_identity=True, real_atom_pairs=[[i, i] for i in range(len(xyz))],
                             shared_port_pairs=[], correspondence='Same exact template/atom order',
                             unresolved_physical_orientation=np.linalg.matrix_rank(xyz-xyz.mean(0), tol=1e-8) < 2))
            continue
        ports = []
        def endpoints(connections):
            result = {}
            for c in connections:
                if c['i'] == slot:
                    result.setdefault((c['j'], c['order']), []).append(c['a'])
                elif c['j'] == slot:
                    result.setdefault((c['i'], c['order']), []).append(c['b'])
            return result
        a, b = endpoints(old_connections), endpoints(new_connections)
        for role in sorted(a.keys() & b.keys()):
            if len(a[role]) == len(b[role]) == 1:
                ports.append(dict(neighbor_slot=role[0], order=role[1], old_atom=a[role][0], new_atom=b[role][0]))
        rows.append(dict(slot=slot, unchanged_identity=False, real_atom_pairs=[], shared_port_pairs=ports,
                         correspondence='Predicted neighbor role only; no presumed same-index atom identity',
                         unresolved_physical_orientation=True,
                         fallback='Explicit new-template placement map supplies a gauge prior; chemical orientation is not uniquely observed'))
    return rows


def select_frames(state, lib, labels, translations, rotations, audits, method):
    """Gauge-only choices use original dummy directions and current predicted ports."""
    xyz = state.physical()
    case = state.orientation_case
    graph = state.graph
    edge = graph.edge_index.cpu().numpy()
    entity = graph.node_entity.cpu().numpy()
    fragments = graph.frag_idx_map.cpu().numpy()
    chosen = rotations.copy()
    rows = []
    for slot, (group, audit) in enumerate(zip(state.groups, audits)):
        summary = dict(slot=slot, candidates=[], selected=0, extra_real_atom_displacement_A=0.,
                       helper_semantics='Existing generated official dummy, not new frame anchor or bound-ligand direction')
        if audit['mode'] == 'kabsch':
            summary['reason'] = 'Nondegenerate real atoms: unchanged original Kabsch'
            rows.append(summary)
            continue
        directions = []
        for c in case['connections']:
            if c['i'] == slot:
                local, other_slot, other_local = c['a'], c['j'], c['b']
            elif c['j'] == slot:
                local, other_slot, other_local = c['b'], c['i'], c['a']
            else:
                continue
            anchor = state.pn + group[local]
            neighbor = state.pn + state.groups[other_slot][other_local]
            helpers = sorted(set(int(j) for i, j in edge.T if i == anchor and entity[j] == 2 and fragments[j] == slot))
            if not helpers:
                continue
            # Existing helper ordinal is a declared convention if multiple fit.
            raw = xyz[helpers[0]] - xyz[anchor]
            target = xyz[neighbor] - xyz[anchor]
            if min(np.linalg.norm(raw), np.linalg.norm(target)) < 1e-10:
                continue
            directions.append((raw @ rotations[slot], target / np.linalg.norm(target)))
        if not directions:
            summary['reason'] = 'No identifiable existing predicted port direction; preserve gauge'
            rows.append(summary)
            continue
        _, template = lib.template(int(labels[slot]))
        core = xyz[state.pn + np.asarray(group)]
        axis = axis_of(template)
        world_axis = rotations[slot] @ axis if axis is not None else directions[0][1]
        base = rotations[slot]
        # Keep index zero exactly equal to the existing reference candidate.
        # A single-port single-atom frame may remain unresolved in this limited
        # roll search; it does not claim to explore all of SO(3).
        candidates = []
        for index, angle in enumerate(ANGLES):
            r = Rotation.from_rotvec(world_axis * angle).as_matrix() @ base
            real = (template-template.mean(0)) @ r.T + core.mean(0)
            error = float(np.sqrt(np.mean(np.sum((real-core)**2, axis=-1))))
            if error > audit['old_fit_RMSD_A'] + 1e-7 + 1e-12:
                summary['candidates'].append(dict(index=index, permitted=False, reason='Real atom fit budget', real_fit_RMSD_A=error))
                continue
            angular = []
            for local, target in directions:
                world = r @ local
                angular.append(float(np.degrees(np.arccos(np.clip(world @ target / np.linalg.norm(world), -1, 1)))))
            value = float(np.mean(np.square(np.asarray(angular) / 15.)))
            continuity = baseline.distance(rotations[slot], r)
            candidates.append((value, continuity, index, r))
            summary['candidates'].append(dict(index=index, permitted=True, port_direction_angle_deg=angular,
                                             score=value, continuity_rad=continuity, real_fit_RMSD_A=error))
        if candidates:
            best = min(candidates, key=lambda x: (round(x[0], 12), x[1], x[2]))
            chosen[slot] = best[3]
            summary['selected'] = best[2]
            summary['extra_real_atom_displacement_A'] = float(np.max(np.linalg.norm(
                (template-template.mean(0)) @ (chosen[slot]-rotations[slot]).T, axis=-1)))
        rows.append(summary)
    return chosen, rows


def select_placement(lib, labels, connections, spec, groups, context, wanted, rotations, old_labels, method):
    """One deterministic coordinate sweep; connection predictor/search is not rerun."""
    from runtime import Geometry
    geometry = Geometry(spec, context)
    selected = [np.asarray(x).copy() for x in wanted]
    result_rotations = rotations.copy()
    records = []
    xyz = np.empty((geometry.mol.GetNumAtoms(), 3))
    for group, part in zip(groups, selected):
        xyz[group] = part
    for slot, (old, new) in enumerate(zip(old_labels, labels)):
        if old == new:
            continue
        _, template = lib.template(new)
        center = selected[slot].mean(0)
        axis = axis_of(template)
        if axis is None:
            records.append(dict(slot=slot, selected=0, reason='Single atom: rotating cannot move its real coordinates'))
            continue
        world_axis = rotations[slot] @ axis
        candidates = []
        details = []
        original = xyz[groups[slot]].copy()
        for index, angle in enumerate(ANGLES):
            r = Rotation.from_rotvec(world_axis * angle).as_matrix() @ rotations[slot]
            candidate = (template-template.mean(0)) @ r.T + center
            xyz[groups[slot]] = candidate
            metrics = geometry.metrics(xyz)
            value, unavailable = score(metrics, method)
            continuity = baseline.distance(rotations[slot], r)
            candidates.append((value, continuity, index, candidate.copy(), r))
            details.append(dict(index=index, angle_rad=angle, score=value, score_unavailable=unavailable,
                                continuity_rad=continuity, geometry=metrics,
                                extra_real_atom_RMSD_A=float(np.sqrt(np.mean(np.sum((candidate-original)**2, axis=-1))))))
        best = min(candidates, key=lambda x: (round(x[0], 12), x[1], x[2]))
        xyz[groups[slot]] = best[3]
        selected[slot] = best[3]
        result_rotations[slot] = best[4]
        records.append(dict(slot=slot, selected=best[2], candidates=details, graph_search_repeated=False,
                            unresolved_chart=True, meaning='Limited geometry-based orientation proposal; not a unique atom correspondence'))
    return selected, result_rotations, records
