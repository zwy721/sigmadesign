"""Official batched forwards and differentiable rigid-body guidance.

The backbone is evaluated once per time step and batch. Its unmodified
mechanics and diffusion updates are used on the collated variable-size graphs.
"""
from common import *
import copy
import time
import torch
from rdkit import Chem
from rdkit.Chem import AllChem
from torch_geometric.data import Batch
from joint_sampler import NativeState
from oracle_graph import assemble
from run_validation import seed_all
from sigmadock.oracle import HPARAMS
from random_frames import attach, replay_frames

SCALE = HPARAMS.general.dimensional_scale


def state_from(case, den):
    seed_all(case['seed'])
    with torch.no_grad():
        if case.get('desired') is not None and not case.get('oracle'):
            import orientation
            from vocab_chemistry import VocabLibrary
            global _ORIENTATION_LIBRARY
            if '_ORIENTATION_LIBRARY' not in globals():_ORIENTATION_LIBRARY=VocabLibrary()
            with orientation.using('current'):
                state=orientation.construct_state(den,case['graph'],case['groups'],'cuda:0',_ORIENTATION_LIBRARY,case['labels'],
                    desired=case['desired'],preferred=case['R'],reference_chart=case.get('reference_chart_rotation'))
        else:
            state = NativeState(den, case['graph'], case['groups'], 'cuda:0',
                                desired=case.get('desired'), preferred=case.get('R'))
    state.base = state.batch.to_data_list()[0]
    return attach(state, case)


class BatchEngine:
    def __init__(self, den):
        self.den = den
        self.calls = 0
        self.timings = []
        self.oom = []

    @torch.no_grad()
    def step(self, states, t, dt, bf16=False, controlled=True, trace=None):
        if not states:
            return
        start = time.perf_counter()
        den = self.den
        batch = Batch.from_data_list([s.base for s in states])
        pos0 = torch.cat([s.pos0 for s in states])
        pos = torch.cat([s.pos for s in states])
        C = torch.cat([s.C for s in states])
        Q = torch.cat([s.Q for s in states])
        R0 = torch.cat([s.R0 for s in states])
        T0 = torch.cat([s.T0 for s in states])
        try:
            with torch.profiler.record_function('dynamic_graph_and_collation'):
                batch = den._update_batch(batch, pos0, pos)
            a, b = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            a.record()
            with torch.profiler.record_function('batched_official_backbone'):
                forward_batch = copy.deepcopy(batch)
                import contextlib
                edge_trace = trace if trace is not None and trace.get('_edge_detail', True) else None
                replay = replay_frames(forward_batch, states, states[0].step_index, edge_trace) if controlled else contextlib.nullcontext()
                with replay, torch.autocast('cuda', dtype=torch.bfloat16, enabled=bf16):
                    forces, index = den._compute_forces(forward_batch, t.expand(len(states)))
            b.record()
            forces = forces.float()
            with torch.profiler.record_function('official_rigid_mechanics_and_reverse'):
                if controlled:
                    # The backbone remains one batched forward. Preserve each
                    # sample's original small-matrix mechanics operation shapes.
                    dynamics, cs, qs, positions = [], [], [], []
                    for i, s in enumerate(states):
                        s.batch['pos_0'], s.batch['pos_t'] = s.pos0, s.pos
                        keep = (index >= batch.ptr[i]) & (index < batch.ptr[i+1])
                        values = den._compute_fragment_dynamics(s.batch, s.Q, s.R0, s.C, forces[keep], index[keep]-batch.ptr[i])
                        ff, tt, mm, ii = values
                        updates = den._predict_fragment_updates(ff, tt, mm, ii)
                        scores = den._compute_scores(dict(T_t=s.C, R_t=s.Q), updates, t.expand(len(s.C)))
                        cc, qq = den.diffuser.reverse(s.C, s.Q, scores['pred_T_score'], scores['pred_R_score'], t, dt, noise_scale=0.)
                        pp = den._apply_transformations(s.pos0, s.batch, s.T0, s.R0, qq, cc) if s.step_index > 0 else den._apply_transformations(s.pos, s.batch, s.C, s.Q, qq, cc)
                        cs.append(cc); qs.append(qq); positions.append(pp); dynamics.append(values)
                    f, torque, mass, inertia = [torch.cat([v[j] for v in dynamics]) for j in range(4)]
                    newC, newQ, newpos = torch.cat(cs), torch.cat(qs), torch.cat(positions)
                else:
                    f, torque, mass, inertia = den._compute_fragment_dynamics(batch, Q, R0, C, forces, index)
                    updates = den._predict_fragment_updates(f, torque, mass, inertia)
                    scores = den._compute_scores(dict(T_t=C, R_t=Q), updates, t.expand(len(C)))
                    newC, newQ = den.diffuser.reverse(C, Q, scores['pred_T_score'], scores['pred_R_score'], t, dt, noise_scale=0.)
                    newpos = den._apply_transformations(pos, batch, C, Q, newQ, newC)
            if trace is not None:
                for name, value in dict(pseudoforce=forces, force_index=index, fragment_force=f, fragment_torque=torque,
                                        mass=mass, inertia=inertia, C_before=C, Q_before=Q, C=newC, Q=newQ, pos=newpos,
                                        node_ptr=batch.ptr, num_fragments=torch.tensor([len(s.C) for s in states])).items():
                    trace[name] = value.detach().cpu().clone()
            assert torch.isfinite(newpos).all(), 'Nonfinite batched trajectory'
            assert torch.equal(batch.batch[batch.edge_index[0]], batch.batch[batch.edge_index[1]]), 'Cross-sample edges'
            offset = 0
            for i, state in enumerate(states):
                n = len(state.C)
                state.C, state.Q = newC[offset:offset+n], newQ[offset:offset+n]
                state.pos = newpos[batch.ptr[i]:batch.ptr[i+1]]
                state.step_index += 1
                offset += n
            b.synchronize()
            self.calls += 1
            self.timings.append(dict(batch=len(states), wall_seconds=time.perf_counter()-start,
                                     forward_ms=a.elapsed_time(b), nodes=len(pos), edges=batch.edge_index.shape[1],
                                     peak_memory_bytes=torch.cuda.max_memory_allocated()))
        except torch.OutOfMemoryError:
            self.oom.append(dict(batch=len(states), t=float(t), action='split_same_states_without_resampling'))
            torch.cuda.empty_cache()
            if len(states) == 1:
                raise
            half = len(states)//2
            self.step(states[:half], t, dt, bf16)
            self.step(states[half:], t, dt, bf16)


class Geometry:
    """MMFF equilibrium geometry from predicted chemistry; no bound xyz."""
    def __init__(self, spec, context):
        mol = assemble(spec)
        self.mol = mol
        n = mol.GetNumAtoms()
        self.groups = [f['atom_ids'] for f in spec['fragments']]
        self.fids = np.empty(n, dtype=int)
        for i, group in enumerate(self.groups):
            self.fids[group] = i
        q = Chem.AddHs(Chem.Mol(mol), addCoords=True)
        props = AllChem.MMFFGetMoleculeProperties(q, mmffVariant='MMFF94s')
        self.bonds, self.angles = [], []
        self.unavailable = []
        for bond in mol.GetBonds():
            i, j = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
            if self.fids[i] == self.fids[j]:
                continue
            value = props.GetMMFFBondStretchParams(q, i, j) if props else None
            if value is None:
                self.unavailable.append(dict(kind='bond', atoms=[i, j]))
            else:
                self.bonds.append((i, j, value[-1]))
        from itertools import combinations
        for atom in mol.GetAtoms():
            j = atom.GetIdx()
            for i, k in combinations([a.GetIdx() for a in atom.GetNeighbors()], 2):
                if len({self.fids[i], self.fids[j], self.fids[k]}) == 1:
                    continue
                value = props.GetMMFFAngleBendParams(q, i, j, k) if props else None
                if value is None:
                    self.unavailable.append(dict(kind='angle', atoms=[i, j, k]))
                else:
                    self.angles.append((i, j, k, value[-1]))
        topology = Chem.GetDistanceMatrix(mol)
        self.pairs = np.array([(i, j) for i in range(n) for j in range(i+1, n)
                               if self.fids[i] != self.fids[j] and topology[i, j] > 2], dtype=int).reshape(-1, 2)
        pt = Chem.GetPeriodicTable()
        self.radii = np.array([pt.GetRvdw(a.GetAtomicNum()) for a in mol.GetAtoms()])
        from denovo_quality.protein import read_protein
        atoms = [a for a in read_protein(context['pdb_path'])['atoms'] if a['kind'] != 'water']
        self.protein = np.array([a['xyz'] for a in atoms])
        self.protein_limits = .75*(self.radii[:, None] + np.array([a['vdw_radius_A'] for a in atoms])[None, :])
        inorganic = np.array([a['kind'] == 'inorganic_cofactor' for a in atoms])
        if inorganic.any():
            rc = np.array([pt.GetRcovalent(a.GetAtomicNum()) for a in mol.GetAtoms()])
            self.protein_limits[:, inorganic] = .75*(rc[:, None] + np.array([a['covalent_radius_A'] for a in atoms])[None, inorganic])
        self.device_cache = None

    def tensors(self, device):
        if self.device_cache is None:
            def tensor(x, dtype=torch.float32):
                return torch.tensor(x, dtype=dtype, device=device)
            self.device_cache = dict(bonds=tensor(self.bonds).reshape(-1, 3), angles=tensor(self.angles).reshape(-1, 4),
                                     pairs=tensor(self.pairs, torch.long), radii=tensor(self.radii),
                                     protein=tensor(self.protein), limits=tensor(self.protein_limits))
        return self.device_cache

    def energy(self, xyz):
        d = self.tensors(xyz.device)
        zero = xyz.sum()*0
        bond = d['bonds']
        angle = d['angles']
        pairs = d['pairs']
        eb = (((xyz[bond[:, 0].long()]-xyz[bond[:, 1].long()]).norm(dim=-1)-bond[:, 2])**2).mean() if len(bond) else zero
        if len(angle):
            u = xyz[angle[:, 0].long()]-xyz[angle[:, 1].long()]
            v = xyz[angle[:, 2].long()]-xyz[angle[:, 1].long()]
            cos = (u*v).sum(-1)/(u.norm(dim=-1)*v.norm(dim=-1)).clamp_min(1e-6)
            ea = ((cos-angle[:, 3].deg2rad().cos())**2).mean()
        else:
            ea = zero
        er = (torch.relu(.6*(d['radii'][pairs[:, 0]]+d['radii'][pairs[:, 1]])-(xyz[pairs[:, 0]]-xyz[pairs[:, 1]]).norm(dim=-1))**2).sum()/len(xyz) if len(pairs) else zero
        ep = (torch.relu(d['limits']-torch.cdist(xyz, d['protein']))**2).sum()/len(xyz)
        return torch.stack([eb, ea, er, ep])

    def metrics(self, xyz):
        xyz = np.asarray(xyz)
        bonds = [abs(np.linalg.norm(xyz[i]-xyz[j])-target) for i, j, target in self.bonds]
        angles = []
        for i, j, k, target in self.angles:
            u, v = xyz[i]-xyz[j], xyz[k]-xyz[j]
            value = np.degrees(np.arccos(np.clip(u@v/max(np.linalg.norm(u)*np.linalg.norm(v), 1e-12), -1, 1)))
            angles.append(abs(value-target))
        pairs = self.pairs
        internal = int(np.sum(np.linalg.norm(xyz[pairs[:, 0]]-xyz[pairs[:, 1]], axis=-1) < .6*(self.radii[pairs[:, 0]]+self.radii[pairs[:, 1]]))) if len(pairs) else 0
        protein = int(np.sum(np.linalg.norm(xyz[:, None]-self.protein[None], axis=-1) < self.protein_limits))
        return dict(cross_bond_MAE_A=float(np.mean(bonds)) if bonds else None,
                    cross_bond_max_error_A=max(bonds, default=None), cross_bonds=len(bonds),
                    cross_bonds_error_gt_0_15A=sum(v > .15 for v in bonds),
                    cross_angle_MAE_deg=float(np.mean(angles)) if angles else None,
                    cross_angle_max_error_deg=max(angles, default=None), cross_angles=len(angles),
                    cross_angles_error_gt_15deg=sum(v > 15 for v in angles),
                    severe_cross_internal_pairs=internal, severe_protein_pairs=protein,
                    equilibrium_unavailable=self.unavailable)

    def guide(self, state, config):
        start = time.perf_counter()
        xyz0 = state.pos[state.pn:state.pn+self.mol.GetNumAtoms()].detach().clone()*SCALE
        xyz0 = xyz0 + torch.tensor(state.graph.pocket_com.cpu().numpy().reshape(3), device=xyz0.device)
        before = self.metrics(xyz0.cpu().numpy())
        with torch.enable_grad():
            twist = torch.zeros((len(self.groups), 6), device=xyz0.device, requires_grad=True)
            v = twist[:, 3:]
            z = torch.zeros_like(v[:, 0])
            skew = torch.stack([z, -v[:, 2], v[:, 1], v[:, 2], z, -v[:, 0], -v[:, 1], v[:, 0], z], -1).reshape(-1, 3, 3)
            rotations = torch.matrix_exp(skew)
            pieces = xyz0.clone()
            for i, group in enumerate(self.groups):
                center = state.C[i].detach()*SCALE + torch.tensor(state.graph.pocket_com.cpu().numpy().reshape(3), device=xyz0.device)
                pieces[group] = (xyz0[group]-center)@rotations[i].T + center + twist[i, :3]
            components = self.energy(pieces)
            weights = torch.tensor(config['weights'], device=xyz0.device)
            loss = (components*weights).sum()
            gradient, = torch.autograd.grad(loss, twist)
        assert torch.isfinite(gradient).all()
        delta = -config['step']*gradient
        delta[:, :3] *= (config['max_translation_A']/delta[:, :3].norm(dim=-1, keepdim=True).clamp_min(config['max_translation_A'])).clamp_max(1)
        delta[:, 3:] *= (config['max_rotation_rad']/delta[:, 3:].norm(dim=-1, keepdim=True).clamp_min(config['max_rotation_rad'])).clamp_max(1)
        from scipy.spatial.transform import Rotation
        rot = torch.tensor(Rotation.from_rotvec(delta[:, 3:].cpu().numpy()).as_matrix(), device=state.C.device, dtype=state.C.dtype)
        oldC, oldQ = state.C, state.Q
        state.C = oldC + delta[:, :3]/SCALE
        state.Q = rot@oldQ
        with torch.no_grad():
            state.pos = state.den._apply_transformations(state.pos, state.batch, oldC, oldQ, state.Q, state.C)
        after_xyz = state.physical()[state.pn:state.pn+self.mol.GetNumAtoms()]
        internal_delta = 0.
        before_xyz = xyz0.cpu().numpy()
        for group in self.groups:
            a, b = after_xyz[group], before_xyz[group]
            internal_delta = max(internal_delta, float(np.abs(np.linalg.norm(a[:, None]-a[None], axis=-1)-np.linalg.norm(b[:, None]-b[None], axis=-1)).max()))
        assert internal_delta <= .0002, 'Guidance violates rigid internal-distance gate'
        drift = float(np.sqrt(np.mean(np.sum((after_xyz-xyz0.cpu().numpy())**2, axis=-1))))
        return dict(before=before, after=self.metrics(after_xyz), energy_components=components.detach().cpu().tolist(),
                    gradient_norm=float(gradient.norm()), correction_RMSD_A=drift,
                    max_translation_A=float(delta[:, :3].norm(dim=-1).max()),
                    max_rotation_rad=float(delta[:, 3:].norm(dim=-1).max()), seconds=time.perf_counter()-start)
