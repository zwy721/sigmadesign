"""Frozen 8-case then 32-case tests; no automatic 216-case experiment."""
from common import *
import copy
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from multiprocessing import get_context
from datetime import datetime, timezone
import torch
import orientation
import run_experiment as rx
from run_validation import load_official
from stable_precision import install
from qc import evaluate
from runtime import state_from, BatchEngine

PREVIOUS = ROOT / 'pose_orientation_stability_and_causal_validation'
PRIOR = ROOT / 'pose_generation_four_arm_comparison/paired_final'
METHODS = {'A_Current': 'current', 'B_VirtualAnchor': 'virtual', 'C_PortAware': 'port', 'D_Hybrid': 'hybrid'}


def cases():
    protocol = load(PRIOR / 'effective_protocol.json')
    rows = []
    for pid in protocol['cohort']:
        for seed in protocol['seeds']:
            path = PRIOR / 'main/initial' / f'{pid}_{seed}' / 'case.pt'
            c = torch.load(path, weights_only=False, map_location='cpu')
            c['role'] = 'main'
            rows.append(c)
    rows.sort(key=lambda c: (len(c['graph'].x), c['pid'], c['seed']))
    lookup = {(c['pid'], c['seed']): c for c in rows}
    stress_keys = [('7ILZ',41008),('9RT3',41010),('9T4A',41003),('9T4A',41004),('9RT3',41012),('12AV',41001),('9SYL',41001),('9T51',41001)]
    first = [('7ILZ',41008),('12AV',41001),('9RT3',41001),('9SYL',41001),('9T4A',41001),('9T51',41001)]
    full = [lookup[k] for k in first] + [c for c in rows if (c['pid'],c['seed']) not in first]
    return [lookup[k] for k in stress_keys], full[:32], rows[:64]


def freeze():
    audit = load(OUT / 'interface_audit.json')
    gate = load(PREVIOUS / 'dynamic_replay_verification.json')
    assert gate['passed'] and gate['namespace'] == 'v5'
    for name, digest in gate['core_sha256'].items():
        assert sha256(PREVIOUS/'source'/name) == digest
        assert sha256(OUT/'baseline_source'/name) == digest
    for item in audit['frozen_weights'].values():
        assert sha256(item['path'])==item['sha256'], 'Frozen weight mismatch'
    eight, full, _ = cases()
    protocol = dict(version=1, prompt_sha256=sha256(OUT/'prompt.md'), methods=METHODS,
        user_confirmed='All currently proposed choices adopted by user on 2026-11-09',
        stage1='Artificial component geometry, not neural full-batch validation',
        stage2_cases=[dict(pid=c['pid'],seed=c['seed'],N=c['N']) for c in eight],
        stage3_cases=[dict(pid=c['pid'],seed=c['seed'],N=c['N']) for c in full],
        cases_selection='Exact existing 8 diagnostic stress keys and previous choose_cases(...,32) keys; no outcome selection',
        per_method_stress=8,per_method_primary=32,primary_denominator=128,
        dynamic_protocol=dict(steps=24, revision_steps=[5,10,15,20], arm='C', noise_scale=0.,
            same_initial_N_identity_rng_inputs=True, unchanged_legal_graph_search=True, transfer_acceptance_A=.5),
        checks=dict(max_atom_delta_A=.025,coordinate_RMSD_A=.005,internal_distance_delta_A=.0002, discrete='exact'),
        required_batch_sizes=[1,4,8,16,32],repeat_batch_size=32,stress_batch_size=4,
        orientation_candidates=dict(per_slot=4,angles_degrees=[0,90,180,-90],keep_original=True,
            graph_search_rerun=False,selection='One fixed slot-order coordinate sweep; no tuning on 8/32 outcomes',
            C='(bond_MAE/.15)^2 + (angle_MAE/15)^2; frame gauge uses existing predicted dummy-to-neighbor direction angle/15 squared',
            D='C + 10*any_severe_internal_clash + 10*any_severe_protein_clash; frozen historical diagnostic scales',
            tie='Score rounded to 12 decimals, then smallest reference SO3 distance, then candidate ordinal',
            missing_metric='Explicit unavailable flag; only available terms used; no invented geometry target',
            singleton='Fixed four rolls cannot explore full SO3; retain explicit unresolved-orientation flag'),
        correspondence='Exact template atom indices only for unchanged identities; changed identities use unique predicted neighbor roles as port correspondences, not asserted real-atom identity. Insufficient correspondence retains explicit construction map and unresolved flag.',
        endpoint_repair=False,new_graph_anchors=False,anchor_length_A=1.,weights=audit['frozen_weights'],
        precision='Same frozen v5 FP32 interfaces and weights, fixed-row32 FP64 contractions and FP64 message sums',
        no_training=True,do_not_start_new216=True,CPU_search_workers=4,CPU_QC_workers=16,
        previous_dynamic_gate_sha256=sha256(PREVIOUS/'dynamic_replay_verification.json'),
        quality_config_sha256=sha256(OUT/'quality_config.json'),PB_config_sha256=sha256(OUT/'posebusters_no_water.json'))
    path = OUT/'protocol.json'
    if path.exists():
        assert load(path) == protocol
        frozen = load(OUT/'frozen_run.json')
        for name,digest in frozen['source_sha256'].items():assert sha256(OUT/'source'/name)==digest,name
    else:
        dump(path,protocol)
        dump(OUT/'frozen_run.json',dict(UTC=datetime.now(timezone.utc).isoformat(),
            source_sha256={p.name:sha256(p) for p in (OUT/'source').glob('*.py')},
            tests_sha256={p.name:sha256(p) for p in (OUT/'tests').glob('*.py')},
            initial_inputs_sha256={f'{c["pid"]}_{c["seed"]}':sha256(PRIOR/'main/initial'/f'{c["pid"]}_{c["seed"]}'/'case.pt') for c in full},
            protocol_sha256=sha256(path),previous_dynamic_gate_sha256=protocol['previous_dynamic_gate_sha256']))
    return protocol


def execute(chosen,method,role,size,den,client,pool,lib):
    rows=[]
    with orientation.using(METHODS[method]):
        for start in range(0,len(chosen),size):
            part=copy.deepcopy(chosen[start:start+size])
            for c in part:c['role']=role
            rows.extend(rx.run_batch(part,'C',den,client,pool,lib,tag=method))
    return rows


def compare(left,right,label):
    lookup={(r['receptor_id'],r['seed']):r for r in left}
    checks=[]
    for r in right:
        a=lookup[r['receptor_id'],r['seed']]
        decisions=lambda x:[(e['proposed_labels'],rx.topology_key(e['old_labels'],e.get('proposed_connections',[])),e['accepted'],e.get('reason')) for e in x['events']]
        discrete=decisions(a)==decisions(r) and rx.topology_key(a['labels'],a['connections'])==rx.topology_key(r['labels'],r['connections'])
        steps=[]
        for step in range(24):
            x=np.load(Path(a['folder'])/'trajectory'/f'step_{step:02d}.npz')['xyz']
            y=np.load(Path(r['folder'])/'trajectory'/f'step_{step:02d}.npz')['xyz']
            row=dict(step=step,shape_equal=x.shape==y.shape,passed=False)
            if x.shape==y.shape:
                d=np.linalg.norm(x-y,axis=-1)
                row.update(max_atom_A=float(d.max()),RMSD_A=float(np.sqrt(np.mean(d*d))))
                row['passed']=row['max_atom_A']<=.025 and row['RMSD_A']<=.005
            steps.append(row)
        checks.append(dict(pid=r['receptor_id'],seed=r['seed'],discrete_equal=discrete,steps=steps,
                           passed=discrete and all(s['passed'] for s in steps)))
    result=dict(label=label,compared=len(checks),passed=bool(checks) and all(r['passed'] for r in checks),checks=checks)
    dump(OUT/'comparisons'/f'{label}.json',result)
    print('COMPARE',label,result['passed'],flush=True)
    return result


def performance(den,big,lib):
    set_status('performance',dynamic_attempts_completed=128)
    path=OUT/'performance.json'
    if path.exists():return
    rows=[]
    for size in [16,32,64]:
        states=[]
        for case in big:
            with orientation.using('current'):
                state=state_from(case,den)
                orientation.initialize(state,case,lib)
            states.append(state)
        engine=BatchEngine(den)
        grid=(1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3
        parts=[states[start:start+size] for start in range(0,len(states),size)]
        for part in parts:engine.step(part,grid[0],grid[0]-grid[1])
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        engine.timings=[]
        started=time.perf_counter()
        for step in range(1,4):
            for part in parts:engine.step(part,grid[step],grid[step]-grid[step+1])
        torch.cuda.synchronize()
        elapsed=time.perf_counter()-started
        frame=[]
        for name,method in METHODS.items():
            with orientation.using(method):
                # Same 64 generated states; ten repeated event-frame recoveries.
                start=time.perf_counter()
                for repeat in range(10):
                    for state,case in zip(states,big):
                        orientation.frames(state,lib,case['labels'],[None]*case['N'])
                duration=time.perf_counter()-start
            frame.append(dict(method=name,calls=len(states)*10,CPU_frame_seconds=duration,
                              milliseconds_per_molecule=1000*duration/(len(states)*10)))
        rows.append(dict(batch_size=size,unique_inputs=len(states),measured_steps=3,wall_seconds=elapsed,
            molecule_steps_per_second=len(states)*3/elapsed,peak_allocated_GiB=torch.cuda.max_memory_allocated()/2**30,
            backbone_forward_calls=engine.calls,OOM_splits=engine.oom,orientation_component=frame,
            batch64_dynamic_certified=False if size==64 else True))
        del states,parts,engine
        torch.cuda.empty_cache()
    dump(path,dict(device=torch.cuda.get_device_name(0),rows=rows,scope='Same 64 inputs; one warmup and three measured static steps; frame cost includes CPU geometry/port diagnostics; primary batch remains32',
                   other_workload_interference='Device and CPU may be shared; absolute comparisons require this caveat'))


def main():
    protocol=freeze()
    torch.set_num_threads(2)
    torch.cuda.set_device(0)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    lib=rx.VocabLibrary()
    den=load_official(bootstrap.CHECKPOINT,OUT/'cache/official','cuda:0')
    install(den)
    eight,full,big=cases()
    checks=[]
    with ProcessPoolExecutor(4,mp_context=get_context('spawn'),initializer=rx.cpu_init) as pool:
        client=rx.Client()
        try:
            with ProcessPoolExecutor(16,mp_context=get_context('spawn')) as quality_pool:
                jobs=[]
                for method in METHODS:
                    set_status('stress8',method=method,dynamic_attempts_completed=0)
                    first=execute(eight,method,'stress8/b4',4,den,client,pool,lib)
                    again=execute(eight,method,'stress8/repeat',4,den,client,pool,lib)
                    serial=execute(eight,method,'stress8/b1',1,den,client,pool,lib)
                    results=[compare(first,again,method+'_stress_repeat'),compare(serial,first,method+'_stress_b1_b4')]
                    if method == 'A_Current':
                        previous = [load(PREVIOUS/'gates/v5/fixed_serial/structures'/f'{c["pid"]}_{c["seed"]}_C/result.json') for c in eight]
                        results.append(compare(previous,serial,'A_matches_frozen_current_baseline'))
                    if method != 'A_Current':
                        reference = [load(OUT/'stress8/b4/structures'/f'{c["pid"]}_{c["seed"]}_A_Current/result.json') for c in eight]
                        assert all(a['initial_xyz_sha256']==b['initial_xyz_sha256'] for a,b in zip(reference,first)), 'Algorithms received different initial coordinates'
                    checks.extend(results)
                    assert all(r['passed'] for r in results),'8-case replay failed; do not scale'
                    jobs.extend(quality_pool.submit(evaluate,r['folder']) for r in first)
                # All four must pass the preliminary gate before any full stage.
                dump(OUT/'stress8_verification.json',dict(passed=True,comparisons=checks))
                primary=[]
                for method in METHODS:
                    set_status('full32',method=method,batch_size=1,dynamic_attempts_completed=len(primary))
                    serial=execute(full,method,'full32/b1',1,den,client,pool,lib)
                    canonical=None
                    for size in [4,8,16,32]:
                        set_status('full32',method=method,batch_size=size,dynamic_attempts_completed=len(primary))
                        packed=execute(full,method,f'full32/b{size}',size,den,client,pool,lib)
                        result=compare(serial,packed,method+f'_full_b1_b{size}')
                        checks.append(result)
                        assert result['passed'],'32-case required batch gate failed; preserve all failures'
                        if size==32:canonical=packed
                    repeat=execute(full,method,'full32/repeat',32,den,client,pool,lib)
                    result=compare(canonical,repeat,method+'_full_repeat')
                    checks.append(result)
                    assert result['passed'],'32-case repeated gate failed'
                    primary.extend(canonical)
                    jobs.extend(quality_pool.submit(evaluate,r['folder']) for r in canonical)
                dump(OUT/'dynamic_verification.json',dict(passed=True,comparisons=checks,primary_attempts=128,
                    no_failed_comparison_removed=True,original_thresholds_unchanged=True))
                performance(den,big,lib)
                set_status('QC',dynamic_attempts_completed=128)
                for index,future in enumerate(as_completed(jobs),1):
                    future.result()
                    if index%16==0:print('QC',index,'/',len(jobs),flush=True)
                from report_results import main as reports
                reports()
        finally:
            client.close()


if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        set_status('failed',error=repr(exc),traceback=traceback.format_exc())
        try:
            from report_results import main as reports
            reports()
        except Exception:
            traceback.print_exc()
        raise
