"""Graph-external frame anchors: they are never molecule atoms or model nodes."""
import importlib.util
import contextlib
from pathlib import Path
import numpy as np

_spec = importlib.util.spec_from_file_location('frozen_anchor_baseline_orientation',
    Path(__file__).resolve().parents[1] / 'baseline_source/orientation.py')
baseline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(baseline)
CACHE = {}
ACTIVE = {}
ANCHOR_LENGTH_A = 1.0


def key(source):
    a = np.ascontiguousarray(source, dtype=np.float64)
    return a.shape, a.tobytes()


@contextlib.contextmanager
def using(frames):
    global ACTIVE
    previous = ACTIVE
    ACTIVE = frames
    try:
        yield
    finally:
        ACTIVE = previous


def register(source, helpers=None, *, cache=True):
    """Reuse existing rigid-reference helper directions when provided.

    Cached vectors live in the source coordinate chart. No chemistry or graph
    is changed, and the vectors do not imply a measured binding orientation.
    """
    x = np.asarray(source, dtype=np.float64)
    k = key(x)
    if k in CACHE and helpers is None:
        return CACHE[k]
    a = x - x.mean(0)
    _, singular, vt = np.linalg.svd(a, full_matrices=True)
    rank = int(np.sum(singular > max(singular[0] if len(singular) else 0, 1e-30) * 1e-12))
    directions = []
    candidates = [] if helpers is None else list(np.asarray(helpers) - x.mean(0))
    origin = 'existing_official_reference_helpers' if candidates else 'fixed_template_chart'
    candidates += list(np.eye(3))
    axis = vt[0] if rank else None
    for candidate in candidates:
        v = np.asarray(candidate, dtype=np.float64).copy()
        if rank >= 1:
            v -= axis * (v @ axis)
        for previous in directions:
            v -= previous * (v @ previous)
        if np.linalg.norm(v) > 1e-10:
            directions.append(v / np.linalg.norm(v))
        if len(directions) == (2 if rank == 0 else 1):
            break
    result = dict(vectors=np.asarray(directions) * ANCHOR_LENGTH_A, origin=origin, source_rank=rank)
    if cache:
        CACHE[k] = result
    return result


def fit(source, target, reference, **kwargs):
    """Weighted anchored Procrustes, with the unchanged real-centroid constraint."""
    t0, r0, error0, original = baseline.fit(source, target, reference, **kwargs)
    audit = dict(original, method='virtual_anchor', frame_anchor_count=0,
                 anchors_in_model_graph=False, anchors_in_final_molecule=False)
    if original['mode'] == 'kabsch':
        return t0, r0, error0, audit
    x, y = np.asarray(source, dtype=np.float64), np.asarray(target, dtype=np.float64)
    a, b = x - x.mean(0), y - y.mean(0)
    reference = baseline.proper(reference)
    u, singular, vt = np.linalg.svd(a.T @ b)
    if singular[0] <= 1e-24:
        continuous = reference
    else:
        continuous = baseline.align_axis(reference @ u[:, 0], vt[0], reference) @ reference
    frame = ACTIVE.get(key(x))
    if frame is None:
        frame = register(x)
    local = frame['vectors']
    world = local @ continuous.T
    covariance = a.T @ b
    anchor_covariance = local.T @ world
    ratio = original['second_to_first_ratio'] / original['relative_covariance_tolerance']
    weight = max(float(singular[0]), 1.0) * max(1.0 - ratio, 0.0) ** 2

    def solve(w):
        uu, _, vv = np.linalg.svd(covariance + w * anchor_covariance)
        correction = np.eye(3)
        correction[-1, -1] = np.linalg.det(vv.T @ uu.T)
        return vv.T @ correction @ uu.T

    error = lambda r: float(np.sqrt(np.mean(np.sum((a @ r.T - b) ** 2, axis=-1))))
    r = solve(weight)
    budget = baseline.FIT_NUMERICAL_BUDGET_A
    if error(r) > original['old_fit_RMSD_A'] + budget:
        low, high = 0.0, weight
        for _ in range(60):
            mid = (low + high) / 2
            if error(solve(mid)) <= original['old_fit_RMSD_A'] + budget:
                low = mid
            else:
                high = mid
        weight = low
        r = solve(weight)
    e = error(r)
    t = y.mean(0) - x.mean(0) @ r.T
    assert np.isfinite(r).all() and np.linalg.det(r) > .9999999999
    assert np.max(np.abs(r.T @ r - np.eye(3))) < 1e-10
    assert e <= original['old_fit_RMSD_A'] + budget + 1e-12
    audit.update(rotation=r.tolist(), fit_RMSD_A=e, fit_excess_A=e - original['old_fit_RMSD_A'],
                 reference_distance_rad=baseline.distance(reference, r), frame_anchor_count=len(local),
                 frame_anchor_source=frame['origin'], local_frame_anchor_vectors=local.tolist(),
                 target_frame_anchor_vectors=world.tolist(), anchor_weight=weight,
                 orthogonality_max_error=float(np.max(np.abs(r.T @ r - np.eye(3)))), determinant=float(np.linalg.det(r)),
                 construction='Reference-axis minimal transport followed by real-centroid-constrained weighted Kabsch',
                 gauge_only=True)
    return t, r, e, audit
