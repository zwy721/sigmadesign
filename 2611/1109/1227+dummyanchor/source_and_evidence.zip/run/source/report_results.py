"""Denominator-safe live/final reports for the isolated anchor ablation."""
from common import *
from collections import defaultdict
from datetime import datetime, timezone

METHODS = ['A_Current','B_VirtualAnchor','C_PortAware','D_Hybrid']
METRICS = ['cross_bond_MAE_A','cross_angle_MAE_deg','severe_cross_internal_pairs','severe_protein_pairs']


def records(role):
    return [load(p) for p in sorted((OUT/role/'structures').glob('*/result.json'))]


def flatten(r):
    path=Path(r['folder'])/'quality_complete.json'
    q=load(path) if path.exists() else {}
    m=next((x for x in q.get('metrics',[]) if x.get('metadata',{}).get('group')=='native_final'),{})
    return dict(method=r['strategy'],pid=r['receptor_id'],seed=r['seed'],N=r['N'],attempt_id=r['attempt_id'],
        status=r['status'],QC_available=bool(m),folder=r['folder'],initial_xyz_sha256=r['initial_xyz_sha256'],
        accepted_updates=sum(e['accepted'] for e in r['events']),
        identity_updates=sum(e['accepted'] and e['old_labels']!=e['proposed_labels'] for e in r['events']),
        high_quality=m.get('checks',{}).get('high_quality'),posebusters_all_pass=m.get('checks',{}).get('posebusters_all_pass'),
        quality_checks=m.get('checks',{}),unavailable_checks=m.get('unavailable_checks',[]),
        quality_errors=m.get('errors',{}),declared_stereo=q.get('declared_stereo'),
        input_unchanged=q.get('input_unchanged'),**r.get('final_geometry',{}))


def mean(rows,key):
    values=[r[key] for r in rows if r.get(key) is not None]
    return float(np.mean(values)) if values else None


def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+
        ['| '+' | '.join(str(v) for v in row)+' |' for row in rows])


def write(name,parts):
    (OUT/name).write_text('\n\n'.join(parts)+'\n')


def num(x):
    return '不可用' if x is None else f'{x:.6g}'


def main():
    primary=records('full32/b32')
    stress=records('stress8/b4')
    rows=[flatten(r) for r in primary]
    pre=[flatten(r) for r in stress]
    if rows:csvwrite(OUT/'PER_GENERATION_RESULTS.csv',rows)
    if pre:csvwrite(OUT/'PRECHECK_GENERATION_RESULTS.csv',pre)
    events=[]
    reconstruction=[]
    for r in primary+stress:
        for e in r['events']:
            row=dict(cohort=r['phase'],method=r['strategy'],pid=r['receptor_id'],seed=r['seed'],N=r['N'],
                step=e['step'],accepted=e['accepted'],reason=e.get('reason'),
                type='identity_change' if e['old_labels']!=e['proposed_labels'] else 'connection_only',
                old_labels=e['old_labels'],proposed_labels=e['proposed_labels'],
                proposed_connections=e.get('proposed_connections'),new_connections=e.get('new_connections'),
                identity_stats=e.get('identity_stats'),identity_logits_path=e.get('identity_logits_path'),
                degenerate_slots=e.get('degenerate_slots'),orientation=e['orientation'],
                correspondence=e.get('identity_correspondence'),placement_selection=e.get('placement_selection'),
                transfer_target_RMSD_A=e.get('transfer_target_RMSD_A'),transfer_fit_RMSD_A=e.get('transfer_fit_rmsd_A'),
                semantic_random_key=e.get('sample_random_key'))
            for stage in ['before','proposed_topology_before_transfer','proposed_topology_after_transfer','after_transfer','after_next_network']:
                for k,v in e.get(stage,{}).items():row[stage+'__'+k]=v
            events.append(row)
        reconstruction.extend(dict(method=r['strategy'],pid=r['receptor_id'],seed=r['seed'],**p) for p in r.get('pose_reconstruction',[]))
    if events:csvwrite(OUT/'PER_EVENT_GEOMETRY.csv',events)
    if reconstruction:csvwrite(OUT/'POSE_RECONSTRUCTION.csv',reconstruction)
    comparisons=[load(p) for p in sorted((OUT/'comparisons').glob('*.json'))]
    summary=[]
    for method in METHODS:
        group=[r for r in rows if r['method']==method]
        summary.append(dict(method=method,completed=len(group),expected=32,
            HQ_pass=sum(r['high_quality'] is True for r in group),HQ_unavailable=sum(r['high_quality'] is None for r in group),
            PB_pass=sum(r['posebusters_all_pass'] is True for r in group),PB_unavailable=sum(r['posebusters_all_pass'] is None for r in group),
            means={k:mean(group,k) for k in METRICS},accepted_updates=sum(r['accepted_updates'] for r in group)))
    dump(OUT/'summary.json',dict(primary_attempts=len(rows),expected=128,stress_attempts=len(pre),expected_stress=32,
        methods=summary,comparisons=len(comparisons),failed_comparisons=[r['label'] for r in comparisons if not r['passed']]))
    write('ORIENTATION_ABLATION_RESULTS.md',['# 四种朝向方法消融',
        f'当前主分母已完成{len(rows)}/128，每方法固定32。8样本预检每方法8，共32，与主分母分开；批量和重复回放不是新的独立样本。处理与指标不可用项均保留。',
        table(['方法','已完成/32','HQ通过','HQ不可用','PB通过','键MAE Å','角MAE °','严重内碰撞对均值','严重蛋白碰撞对均值'],[
            [s['method'],s['completed'],s['HQ_pass'],s['HQ_unavailable'],s['PB_pass']]+[num(s['means'][k]) for k in METRICS] for s in summary]),
        'A为当前已修复基线；B增加图外参考锚点；C使用当前预测端口和四个固定朝向候选；D结合锚点与端口几何/碰撞评分。模型、身份条件、初始化、合法图搜索、更新时刻和HQ门槛冻结。候选仅改变朝向，不重新运行图搜索。',
        'C/D在旧图的退化frame中使用原图生成状态内的dummy方向作端口参考；新身份放置时在新预测拓扑上比较真实原子键长、键角和碰撞。后者是物理朝向选择，不能把收益归为纯gauge稳定性。对应不足时明确记录未唯一确定，不将同编号原子或端口角色等同于真实原子身份。',
        '所有方法无端点修复。C/D的额外位移保存在PER_EVENT_GEOMETRY.csv的placement_selection候选记录中；不得把该物理修正称为网络自身表现。MMFF仅用于既有QC与平衡几何诊断。',
        '阶段坐标、身份logits和搜索候选见各structures/的before.npz、identity_*.npz、search_*.json、proposal_transfer.npz及24步trajectory/。本轮未新增216次正式实验。'])
    dynamic_rows=[]
    for result in comparisons:
        steps=[s for c in result['checks'] for s in c['steps'] if s.get('shape_equal')]
        dynamic_rows.append([result['label'],result['compared'],result['passed'],all(c['discrete_equal'] for c in result['checks']),
            num(max((r['max_atom_A'] for r in steps),default=None)),num(max((r['RMSD_A'] for r in steps),default=None))])
    write('DYNAMIC_REPLAY_COMPARISON.md',['# 动态重复与批量比较',
        '单算法要求离散身份/连接/接受决策完全相同，24步最大原子差≤0.025 Å、RMSD≤0.005 Å、内部距离差≤0.0002 Å。不同算法之间允许结果不同；未放宽阈值、删除失败或重抽样。',
        table(['比较','样本','通过','离散一致','最大原子差 Å','最大RMSD Å'],dynamic_rows),
        'A另与前项v5压力集逐步对照，验证它确为当前基线。四方法初始化必须字节一致。32例批量对照只有通过全部8例预检后才运行；性能基准的64不等于动态64通过。完整失败与traceback保存在status.json及run.log。'])
    perf=load(OUT/'performance.json') if (OUT/'performance.json').exists() else None
    batches=[load(p) for p in (OUT/'full32/b32/batches').glob('*.json')]
    write('A100_PERFORMANCE.md',['# A100吞吐与锚点成本',
        '各方法每步一次真正PyG Batch主干前向；4进程CPU连接搜索、16进程QC。全程保持相同v5精度适配与语义辅助流，没有逐分子复制或调用完整主干。',
        json.dumps(perf,ensure_ascii=False,indent=2) if perf else '独立的16/32/64性能基准尚未完成，不填估计值。',
        table(['方法','分子数','批次墙钟秒','主干调用'],[[r.get('strategy',r['arm']),r['batch'],num(r['wall_seconds']),r['forward_calls']] for r in batches]),
        'batch墙钟包含CPU搜索、几何评价和证据写盘；CUDA计时范围见原始batch timings。其他GPU工作负载会影响绝对吞吐，本轮不以资源干扰下的小差异改变算法。64只作性能探索，未通过动态64验收就不用于正式动态对照。'])
    units=(OUT/'unit_tests.log').read_text() if (OUT/'unit_tests.log').exists() else '未执行'
    write('DEGENERATE_GEOMETRY_TESTS.md',['# 退化构型测试',
        '几何组件覆盖单原子、双原子、三点共线、多点近共线、非退化三点、重复奇异值对称模板、接近反向、1e-7到1e-4 Å扰动、两类身份变化的显式局部坐标变换。',
        '验证拟合误差、距离保持、proper旋转、SE(3)等变和无NaN/Inf。CPU分块检查仅证明组件缓存/顺序独立，不能代替真实网络batch验收。人工身份变更使用已知坐标图映射，不声称可自动确定任意新旧化学模板的原子对应。',
        '接近反向处的最小旋转存在cut locus，不能要求整个SO(3)上存在唯一且处处连续的代表；应另外检查真实原子连续性及gauge等价。',
        '```text\n'+units+'\n```'])
    passed=(OUT/'dynamic_verification.json').exists() and load(OUT/'dynamic_verification.json')['passed']
    complete=passed and len(rows)==128 and len(pre)==32 and all(r['QC_available'] and r['input_unchanged'] for r in rows+pre)
    recommendation='证据尚不完整，暂不选择获胜方案，也不启动新的216次正式对照。'
    if complete:
        a=summary[0]
        best=max(summary,key=lambda s:(s['HQ_pass'],-(s['means']['cross_bond_MAE_A'] or 0)))
        if best['method']=='A_Current' or best['HQ_pass']<=a['HQ_pass']:
            recommendation='当前32例诊断中尚未证明虚拟锚点提高原生HQ，保留当前参考旋转方法；若几何仍差，下一步优先讨论连接几何或SigmaDock几何监督。'
        else:
            recommendation=f'{best["method"]}在本固定32例中HQ为{best["HQ_pass"]}/32，A为{a["HQ_pass"]}/32；这只是已有困难样本的探索性结果，需检查逐口袋配对与位移代价后再讨论216次验证，不能直接替换当前默认方法。'
    write('NEXT_STEP_DECISION.md',['# 下一步判断',recommendation,
        '虚拟锚点维持参考坐标系，不自动带来真实化学信息。严格rank0/rank1组件测试中A/B物理重建等价；动态身份、连接分歧和最终HQ必须由实际消融分别回答。',
        '端口角色及原有非结合态dummy可提供连接上下文，但不是结合构象真值；多解、缺失对应、不可用QC和失败都应保留。四候选搜索有限，单原子完整SO(3)或任意新旧模板对应并未被穷举。'])
    if complete:
        frozen=load(OUT/'frozen_run.json')
        source_ok=all(sha256(OUT/'source'/name)==digest for name,digest in frozen['source_sha256'].items())
        config=load(OUT/'protocol.json')
        weights_ok=all(sha256(item['path'])==item['sha256'] for item in config['weights'].values())
        original=load(ROOT/'pose_generation_four_arm_comparison/paired_final/input_audit.json')['frozen_files']
        original_ok=all(sha256(path)==digest for path,digest in original.items())
        verification=dict(passed=source_ok and weights_ok and original_ok,
            source_unchanged=source_ok,weights_unchanged=weights_ok,original_sources_and_weights_checked=len(original),
            original_unchanged=original_ok,primary=128,stress=32,QC_input_unchanged=True,
            protocol_unchanged=sha256(OUT/'protocol.json')==frozen['protocol_sha256'],UTC=datetime.now(timezone.utc).isoformat())
        verification['passed']=verification['passed'] and verification['protocol_unchanged']
        dump(OUT/'completion_verification.json',verification)
        assert verification['passed']
        state=load(OUT/'status.json')
        state.update(stage='complete',execution_complete=True,dynamic_attempts_completed=128,completion_UTC=verification['UTC'])
        dump(OUT/'status.json',state)
    return complete


if __name__=='__main__':main()
