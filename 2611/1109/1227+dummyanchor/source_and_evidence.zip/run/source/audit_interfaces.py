"""Read-only audit of official dummy semantics and cached generated inputs."""
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parent
PREVIOUS = ROOT / 'pose_orientation_stability_and_causal_validation'
PROJECT = ROOT.parent / 'oracle_rebuild_20261031'
OFFICIAL = ROOT.parent / 'third_party/sigmadock_official_repo_20261030/src/sigmadock'
sys.path.insert(0, str(PROJECT))
import bootstrap
import numpy as np
import torch


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    torch.set_num_threads(1)
    assert not (OUT / 'interface_audit.json').exists(), 'Preserve the first interface audit'
    prompt = ROOT / '2611/1109/1227+dummyanchor/prompt.md'
    shutil.copyfile(prompt, OUT / 'prompt.md')
    files = [OFFICIAL / 'chem/fragmentation.py', OFFICIAL / 'chem/processing.py',
             OFFICIAL / 'chem/__init__.py', OFFICIAL / 'diff/denoiser.py',
             PROJECT / 'joint_sampler.py', PROJECT / 'pipeline_utils.py',
             PROJECT / 'oracle_graph.py', PROJECT / 'vocab_chemistry.py',
             PROJECT / 'trajectory_connections.py']
    frozen = {}
    baseline = OUT / 'baseline_source'
    baseline.mkdir(exist_ok=True)
    for path in sorted((PREVIOUS / 'source').glob('*.py')):
        shutil.copyfile(path, baseline / path.name)
        frozen[path.name] = sha(path)
    rows = []
    for path in sorted((ROOT / 'pose_generation_four_arm_comparison/paired_final/main/initial').glob('*/case.pt')):
        case = torch.load(path, weights_only=False, map_location='cpu')
        graph = case['graph']
        protein_nodes = int((graph.frag_idx_map == -1).sum())
        for slot, group in enumerate(case['groups']):
            core_indices = protein_nodes + np.asarray(group)
            all_indices = torch.where(graph.frag_idx_map == slot)[0]
            rank = lambda x: int(np.linalg.matrix_rank(x.astype('float64') - x.astype('float64').mean(0), tol=1e-5))
            core = graph.ref_pos[core_indices].numpy()
            full = graph.ref_pos[all_indices].numpy()
            entities = graph.node_entity[all_indices].numpy()
            rows.append(dict(pid=case['pid'], seed=case['seed'], slot=slot, label=case['labels'][slot],
                             real_atoms=len(group), existing_dummy_nodes=int(np.sum(entities == 2)),
                             existing_virtual_nodes=int(np.sum(entities == 3)),
                             real_atom_rank=rank(core), full_fragment_rank=rank(full),
                             reference_source=case['spec']['reference_source']))
    required = []
    for arm in ['C', 'E_connection_only']:
        for suffix in ['b1_b4', 'b1_b8', 'b1_b16', 'b1_b32', 'b32_repeat']:
            path = PREVIOUS / 'diagnostics/comparisons' / f'v5_{arm}_{suffix}.json'
            record = json.loads(path.read_text())
            required.append(dict(path=str(path.relative_to(ROOT)), passed=record['passed'], sha256=sha(path)))
    protocol = json.loads((ROOT / 'pose_generation_four_arm_comparison/paired_final/effective_protocol.json').read_text())
    audit = dict(UTC=datetime.now(timezone.utc).isoformat(), prompt_sha256=sha(prompt),
                 original_source_sha256={str(p): sha(p) for p in files}, baseline_source_sha256=frozen,
                 frozen_weights=protocol['weights'], cached_initial_cases=72, fragment_slots=len(rows),
                 real_rank_deficient_slots=sum(r['real_atom_rank'] < 2 for r in rows),
                 rank_deficient_slots_with_nondegenerate_existing_nodes=sum(r['real_atom_rank'] < 2 and r['full_fragment_rank'] >= 2 for r in rows),
                 current_required_CE_gates=required, current_required_CE_gates_passed=all(r['passed'] for r in required),
                 previous_status_at_audit=json.loads((PREVIOUS / 'status.json').read_text()), rows=rows)
    dump(OUT / 'interface_audit.json', audit)
    report = '''# 虚拟锚点接口审计

## 原始 SigmaDock 语义

`chem/fragmentation.py:185` 的 `fragment_on_bonds_with_mapping` 在断键处调用 `FragmentOnBonds(addDummies=True)`，记录 `torsional_bonds` 和 `anchor_to_dummy`。dummy 是断键后原邻接原子的几何占位，携带断键方向及局部几何；不能默认它为所有片段提供唯一旋转。

`chem/processing.py:608` 将已有 dummy 与 virtual 节点保留在图中，分别标记 `ligand_dummy` 和 `ligand_virtual`；`chem/__init__.py:1` 定义 torsional、triangulation、anchor-dummy 等不同边。原 virtual 节点还用于图表示，不能与本轮图外 frame anchor 混称。

`diff/denoiser.py:303` 的惯量计算排除 `ligand_virtual`，但保留满足 mask 的 dummy；`_get_initial_states` 从完整参考图构造刚体状态。因此任意往模型图中添加新点都会改变输入或力学，违反本轮对照要求。本轮只添加图外参考坐标，不改变上述节点、特征、边、质量或惯量。

## NativeState 与模板接口

`joint_sampler.py:82` 的 NativeState 保留完整图、pos0、pos、C/Q 与参考坐标，但 `slot_frames` 只按 groups 提取真实 core 原子。`vocab_chemistry.py:33` 的 H-capped 模板仅返回真实重原子；`sites` 给出端口原子、容量和合法键级，没有直接输出端口方向矢量。

动态身份替换经 `chemical_graph` 重新嵌入当前预测合法分子，再用官方接口重建 dummy/virtual；旧 dummy 的原子编号及局部方向不会自动成为新模板的对应。它们来自非结合态参考，不能当成真实结合位姿或唯一端口约束。可缓存官方图内节点在各刚体参考中的坐标，供图外坐标系审计复用；不能直接把旧端口复制到新身份。

## 当前已修复基线

基线为 `pose_orientation_stability_and_causal_validation/source/orientation.py` 的当前 fixed 方法：rank0 保留运输参考，rank1 采用最小轴对齐旋转，近共线连续混合且额外原子拟合误差≤1e-7 Å，非退化保持 proper Kabsch；另修正 NativeState 参考转移的坐标域与退化先验。不能用更早错误 SVD 代替 A 组。源代码快照和哈希见 baseline_source/ 与 interface_audit.json。

由上一状态 R 定义的图外锚点只保存 gauge，没有新增化学观测；在严格 rank0/rank1 下，它可能与当前方法数学等价。必须同时比较真实原子、更新决策及最终几何，不能以矩阵更平滑证明 HQ 提升。

## MotiFlow 参考边界

[MotiFlow 原论文 §3.1](https://arxiv.org/html/2601.16955v1#S3.SS1) 对共线/单原子 motif 利用原分子邻接几何补充单位距离 dummy，使 frame 可定义。这是该论文的数据表示约定。本轮仅借鉴补足坐标系的思想，不读取真实配体邻接构象、不复制其训练输入、不改变 SigmaDock 图。

## 本次实测与未决项

INITIAL_SUMMARY

`7ILZ_41008` 的221号双原子槽位真实原子秩1；原图已有2个dummy、1个virtual，完整片段秩3。说明信息仍在完整状态中，但 real-core-only 的 T/R 提取没有利用它；完整图方向也包含参考构象约定，并非新增真实化学信息。

C/E 的batch=1/4/8/16/32及重复回放共10项必要比较已通过，完整64资格和前项正式任务状态以其独立日志为准。本轮另建目录，前项仍在运行，不能把其未完成结果写成本轮结论。

C/D候选预算与评分、身份变更中不足对应的处理已向用户提出确认，尚未实现或启动相关动态消融。A/B纯几何测试可独立推进。新的216次正式对照仅在后续有证据支持且讨论确定后考虑。
'''
    report = report.replace('INITIAL_SUMMARY', f"读取72套既存生成初始图、{len(rows)}个槽位；真实原子秩不足2的槽位{audit['real_rank_deficient_slots']}个，其中完整既存节点达到秩≥2的槽位{audit['rank_deficient_slots_with_nondegenerate_existing_nodes']}个。详细记录全部保留在interface_audit.json；未读取任何真实配体构象。")
    (OUT / 'VIRTUAL_ANCHOR_INTERFACE_AUDIT.md').write_text(report)
    dump(OUT / 'status.json', dict(stage='interface_audited_pending_method_discussion', execution_complete=False,
                                 task_directory='2611/1109/1227+dummyanchor', no_training=True,
                                 graph_unchanged=True, dynamic_attempts_completed=0))
    print(json.dumps({k: audit[k] for k in ['cached_initial_cases', 'fragment_slots', 'real_rank_deficient_slots',
                                          'rank_deficient_slots_with_nondegenerate_existing_nodes', 'current_required_CE_gates_passed']}, indent=2))


if __name__ == '__main__':
    main()
