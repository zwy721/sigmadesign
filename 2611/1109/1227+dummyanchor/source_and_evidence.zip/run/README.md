# Dummy anchor 动态朝向消融

原任务：[prompt.md](prompt.md)。独立目录，不修改历史实验和权重。

[接口审计](VIRTUAL_ANCHOR_INTERFACE_AUDIT.md) · [实现与冻结规则](VIRTUAL_ANCHOR_IMPLEMENTATION.md) · [状态](status.json) · [运行日志](run.log)

本轮已完成：26项组件/接口测试、四方法各8例预检和各32例主消融，以及全部重复与batch=1/4/8/16/32验收。A/B的768个轨迹步和128次身份logits逐位一致，HQ均2/32；C为2/32，D为1/32。保留当前方法，未新增216次实验。详见[结果](ORIENTATION_ABLATION_RESULTS.md)、[逐次表格](PER_GENERATION_RESULTS.csv)和[完成核验](completion_verification.json)。

## 复现

```bash
CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONDONTWRITEBYTECODE=1 \
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 PYTHONPATH="$PWD/.quality_deps:$PWD" \
../.venv-cutoff-train/bin/python -B virtual_anchor_orientation_ablation/source/run_ablation.py
```

使用已有冻结输入与环境；该命令会运行GPU实验。报告只以status.json与completion_verification.json的实测证据为准。26项CPU测试可运行：`python -B -m pytest -q -p no:cacheprovider virtual_anchor_orientation_ablation/tests/`。
