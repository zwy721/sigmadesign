"""Target-free skeleton beam followed by globally coupled chemical-port beam.

Neither search function accepts target topology, target coordinates or labels.
All hard constraints are derived from the supplied fragment chemistry. The
bounded beams are approximate; they are not exhaustive k-best enumerators.
"""
from collections import Counter,defaultdict
from dataclasses import asdict,dataclass
import math

from rdkit import Chem

from topology_diversity import complete_key
from trajectory_connections import edge_key,is_fragment_tree
from vocab_chemistry import ChemistryRejected,assemble_slots,canonical


@dataclass(frozen=True)
class SearchConfig:
    skeleton_width:int=128
    skeleton_count:int=24
    port_width:int=64
    pair_options:int=64
    per_skeleton:int=16
    equivalent_representatives:int=2
    # Fixed prior-score/novelty tradeoff; no learned or target-based reranking.
    skeleton_bonus:float=1.0


def adjacency_key(edges):
    """Slot-labelled adjacency only: no ports, orders or stereo conditions."""
    return tuple(sorted((min(int(e['i']),int(e['j'])),max(int(e['i']),int(e['j']))) for e in edges))


def option_groups(runtime,prediction,*,stereo=True):
    """Joint port/order/stereo potentials from the frozen head and template sites."""
    stereo_prob={tuple(map(int,m)):p for m,p in zip(prediction.get('meta',[]),prediction.get('sp',[]))}
    result=defaultdict(list);seen=set()
    for c in prediction['pool']:
        i,j,a,b,o=edge_key(c)
        if not 0<=i<j<len(runtime.labels) or o not in (1,2):continue
        if any(o not in runtime.allowed.get(v,set()) or o>runtime.capacity.get(v,0) for v in ((i,a),(j,b))):continue
        probs=stereo_prob.get((i,j,a,b))
        variants=range(3) if stereo and o==2 and probs is not None else [int(c.get('stereo',0)) if o==2 else 0]
        for s in variants:
            key=(i,j,a,b,o,s)
            if key in seen:continue
            seen.add(key)
            # A non-stereogenic double bond later admits only s=0. An E/Z
            # capable bond must have an explicit s=1/2 condition before docking.
            score=float(c['log_odds'])+(math.log(max(float(probs[s]),1e-8)) if o==2 and probs is not None else 0.)
            result[i,j].append(dict(c,stereo=s,search_score=score))
    for pair in result:result[pair].sort(key=lambda e:(-e['search_score'],complete_key([e])))
    return dict(result)


def skeleton_beam(runtime,groups,*,width=128,count=24):
    """Grow connected partial trees from slot 0, deduplicating edge sets.

    Skeleton potentials maximize over each pair's port/order choices but do not
    commit to any port. Degree bounds are necessary template-capacity bounds;
    feasibility is decided jointly in the second stage.
    """
    n=len(runtime.labels)
    if n==1:return [dict(pairs=(),score=0.)]
    scores={pair:max(e['search_score'] for e in vv) for pair,vv in groups.items() if vv}
    degree_max=[sum(v for (slot,_),v in runtime.capacity.items() if slot==i) for i in range(n)]
    # score, edge set, reached slots, degree vector
    beam=[(0.,(),frozenset([0]),(0,)*n)]
    for _ in range(n-1):
        proposed={}
        for score,edges,reached,degree in beam:
            for (i,j),potential in scores.items():
                if (i in reached)==(j in reached) or degree[i]>=degree_max[i] or degree[j]>=degree_max[j]:continue
                key=tuple(sorted((*edges,(i,j))))
                if key in proposed:continue
                dd=list(degree);dd[i]+=1;dd[j]+=1
                proposed[key]=(score+potential,key,reached|{i,j},tuple(dd))
        beam=sorted(proposed.values(),key=lambda r:(-r[0],r[1]))[:width]
        if not beam:break
    return [dict(pairs=edges,score=score) for score,edges,reached,_ in beam if len(reached)==n][:count]


class PrefixChemistry:
    """Slot-coloured chemical equivalence of a partial port assignment.

    Local graphs attach neighbour-coloured dummy atoms to all committed ports.
    This distinguishes e.g. ortho/meta/para combinations before a molecule is
    complete. It also sanitizes the whole local substitution pattern. A cache
    keeps leaf/low-degree fragment combinations inexpensive. Two score-best
    representatives of each chemical prefix are retained by default because
    the frozen geometry-conditioned head can break atom symmetry.
    """
    def __init__(self,runtime):
        self.runtime=runtime;self.parts=[];self.cache={};self.checks=0
        for i,label in enumerate(runtime.labels):
            mol,_=runtime.lib.template(label,runtime.oov[i]);self.parts.append(Chem.AddHs(mol))

    def local(self,slot,assignments):
        assignments=tuple(sorted(assignments));key=(slot,assignments)
        if key in self.cache:return self.cache[key]
        self.checks+=1;rw=Chem.RWMol(self.parts[slot]);used=Counter();remove=[]
        for neighbour,atom,order in assignments:
            used[atom]+=order
            dummy=Chem.Atom(0);dummy.SetIsotope(neighbour+1)
            j=rw.AddAtom(dummy);rw.AddBond(atom,j,Chem.BondType.SINGLE if order==1 else Chem.BondType.DOUBLE)
        try:
            for atom,units in used.items():
                hs=[a.GetIdx() for a in rw.GetAtomWithIdx(atom).GetNeighbors() if a.GetAtomicNum()==1]
                if len(hs)<units:raise ChemistryRejected('Coupled H-substitution capacity exceeded')
                remove+=hs[:units]
            for atom in sorted(remove,reverse=True):rw.RemoveAtom(atom)
            mol=rw.GetMol();Chem.SanitizeMol(mol);mol=Chem.RemoveHs(mol)
            value=Chem.MolToSmiles(mol,isomericSmiles=True)
        except (ValueError,RuntimeError,ChemistryRejected):value=None
        self.cache[key]=value;return value

    def key(self,edges):
        slots=defaultdict(list)
        for e in edges:
            i,j,a,b,o=edge_key(e);slots[i].append((j,a,o));slots[j].append((i,b,o))
        result=[]
        for slot in sorted(slots):
            value=self.local(slot,slots[slot])
            if value is None:return None
            result.append((slot,value))
        return tuple(result),tuple(sorted((e['i'],e['j'],int(e.get('stereo',0))) for e in edges if e['order']==2))


def stereo_compatible(mol,edges,groups):
    """Verify predicted E/Z is necessary and survives full graph sanitization.

    Tetrahedral tags already present in identity templates are preserved by
    assembly. Newly created tetrahedral centres have no predictor in the frozen
    head; they remain explicitly outside this experiment's stereo completeness.
    """
    potential={int(p.centeredOn) for p in Chem.FindPotentialStereo(mol) if p.type==Chem.StereoType.Bond_Double}
    for e in edges:
        if e['order']!=2:continue
        bond=mol.GetBondBetweenAtoms(groups[e['i']][e['a']],groups[e['j']][e['b']])
        s=int(e.get('stereo',0));possible=bond.GetIdx() in potential
        if possible!=(s in (1,2)):return False
        if s in (1,2) and bond.GetStereo()!= (Chem.BondStereo.STEREOE if s==1 else Chem.BondStereo.STEREOZ):return False
    return True


def port_beam(runtime,pairs,groups,*,config=SearchConfig(),chemistry=None,limit=None):
    """Joint, capacity-coupled beam over all edges of one fixed skeleton.

    A partial state contains assignments for every committed edge and a shared
    per-atom valence budget. Future-edge feasibility is checked before pruning;
    each complete graph is independently assembled and globally sanitized.
    """
    n=len(runtime.labels);pairs=tuple(sorted(tuple(sorted(p)) for p in pairs))
    if not is_fragment_tree(n,[dict(i=i,j=j) for i,j in pairs]):return [],dict(reason='not_a_tree')
    if any(not groups.get(pair) for pair in pairs):return [],dict(reason='missing_pair_options')
    chemistry=chemistry or PrefixChemistry(runtime)
    choices={pair:groups[pair][:config.pair_options] for pair in pairs}
    # Most constrained edge first. All decisions remain reversible in the beam.
    degree=Counter(i for pair in pairs for i in pair)
    ordered=sorted(pairs,key=lambda p:(len(choices[p]),-degree[p[0]]-degree[p[1]],p))
    beam=[(0.,[],{})];expanded=capacity_rejected=forward_rejected=chemical_rejected=0
    def fits(e,used):
        i,j,a,b,o=edge_key(e)
        return all(used.get(v,0)+o<=runtime.capacity.get(v,0) for v in ((i,a),(j,b)))
    for depth,pair in enumerate(ordered):
        possible=[];remaining=ordered[depth+1:]
        for score,selected,used in beam:
            for edge in choices[pair]:
                expanded+=1
                if not fits(edge,used):capacity_rejected+=1;continue
                updated=dict(used);i,j,a,b,o=edge_key(edge)
                for v in ((i,a),(j,b)):updated[v]=updated.get(v,0)+o
                # This is a necessary lookahead; shared future capacities are
                # still resolved by complete beam states, never greedily fixed.
                if any(not any(fits(e,updated) for e in choices[p]) for p in remaining):forward_rejected+=1;continue
                possible.append((score+edge['search_score'],selected+[edge],updated))
        possible.sort(key=lambda r:(-r[0],complete_key(r[1])))
        beam=[];equivalence=Counter()
        for state in possible:
            key=chemistry.key(state[1])
            if key is None:chemical_rejected+=1;continue
            if equivalence[key]>=config.equivalent_representatives:continue
            equivalence[key]+=1;beam.append(state)
            if len(beam)>=config.port_width:break
        if not beam:break
    result=[];seen=set();full_rejected=0
    for score,edges,_ in beam:
        if len(edges)!=n-1:continue
        try:mol,parts,_=assemble_slots(runtime.lib,runtime.labels,edges,oov=runtime.oov)
        except ChemistryRejected:full_rejected+=1;continue
        if not stereo_compatible(mol,edges,parts):full_rejected+=1;continue
        key=canonical(mol,True)
        if key in seen:continue
        seen.add(key);result.append(dict(connections=sorted(edges,key=edge_key),score=score,
            constitution=canonical(mol,False),isomeric=key,kind='hierarchical_joint_beam'))
        if len(result)>=(limit or config.per_skeleton):break
    return result,dict(expanded=expanded,capacity_rejected=capacity_rejected,forward_rejected=forward_rejected,
        prefix_chemical_rejected=chemical_rejected,full_chemical_or_stereo_rejected=full_rejected,
        terminal_states=len(beam),valid_unique=len(result),prefix_chemistry_cache=len(chemistry.cache))


def hierarchical_search(runtime,prediction,*,k=8,config=SearchConfig()):
    groups=option_groups(runtime,prediction);skeletons=skeleton_beam(runtime,groups,width=config.skeleton_width,count=config.skeleton_count)
    chemistry=PrefixChemistry(runtime);pool=[];stats=[];seen=set()
    for rank,skeleton in enumerate(skeletons):
        candidates,info=port_beam(runtime,skeleton['pairs'],groups,config=config,chemistry=chemistry)
        stats.append(dict(rank=rank,pairs=skeleton['pairs'],score=skeleton['score'],**info))
        for port_rank,c in enumerate(candidates):
            key=complete_key(c['connections'])
            if key in seen:continue
            seen.add(key);pool.append(dict(c,skeleton_rank=rank,port_rank=port_rank))
    # Score prior plus a diminishing novelty bonus. This allocates the finite
    # sample budget between alternate skeletons AND alternate port assignments.
    # No GT labels, target coordinates or reranker are consulted.
    selected=[];constitution_seen=set();skeleton_uses=Counter();denom=max(1,len(runtime.labels)-1)
    while len(selected)<k:
        available=[c for c in pool if c['constitution'] not in constitution_seen]
        if not available:break
        def priority(c):
            return (c['score']/denom+config.skeleton_bonus/(1+skeleton_uses[adjacency_key(c['connections'])]),
                c['score'],complete_key(c['connections']))
        chosen=max(available,key=priority);selected.append(chosen);constitution_seen.add(chosen['constitution'])
        skeleton_uses[adjacency_key(chosen['connections'])]+=1
    return dict(candidates=selected,pool=pool,skeletons=skeletons,port_statistics=stats,
        prefix_chemical_checks=chemistry.checks,config=asdict(config),truth_used=False)
