#!/usr/bin/env python3
"""Publish the predictor audit with unchanged Oracle/docking acceptance gates."""
import json
from pathlib import Path
import re

import bootstrap
import torch
from prediction_metrics import identity_metrics
from run_validation import write_json
from validation import digest

MARKER='## 预测问题专项诊断与改进（2026-10-31）'


def main():
    p=bootstrap.PROJECT;b=p/'results/prediction_diagnostics'
    read=lambda path:json.loads((b/path).read_text())
    audit=read('input_audit.json');old=read('legacy_gpu/report.json');controlled=read('legacy_controlled/report.json')
    full=read('identity_full_evaluation.json');connection=read('connection_noise_v2/report.json')
    near=read('connection_near_clean/report.json');wide=read('connection_wide_candidates/report.json')
    regression=read('oracle_regression/report.json');fixed=read('fixed_identity_12.json')
    assert old['status']=='complete' and len(old['levels'])==24
    assert len(controlled['levels'])==8 and controlled.get('elapsed_seconds')
    for r in (old,controlled,connection,near,wide,regression,fixed):assert not r['failures']
    assert read('identity_controls/status.json')['status']=='complete'
    assert read('identity_server_smoke.json')['passed']
    assert set(full['methods'])=={'direct','retrieval','iterative'}
    frozen=json.loads((p/'results/acceptance/report.json').read_text())['manifest']
    assert digest(bootstrap.CHECKPOINT)==frozen['checkpoint_sha256']
    assert all(digest(bootstrap.SOURCE/'sigmadock'/name)==sha for name,sha in frozen['source_sha256'].items())
    assert regression['summary']['oracle_sampler_regression_passed']
    assert all(r['official_sampler_max_difference_A']==0 for r in regression['rows'])
    testlog=(b/'tests.log').read_text();assert '\nOK\n' in testlog
    tests=int(re.findall(r'Ran (\d+) tests',testlog)[-1])
    # Frequency baseline is computed from training labels only; never CASF labels.
    saved=torch.load(b/'identity_controls/direct/best.pt',map_location='cpu',weights_only=False)
    ranked=saved['prior'].topk(20).indices.tolist()
    rows=full['methods']['direct']['fresh_noise_val']['clean']['rows']
    baseline=[dict(id=r['id'],labels=r['labels'],topk=[ranked]*len(r['labels'])) for r in rows]
    props=json.loads((bootstrap.WORKSPACE/'geom_m12/assets/properties.json').read_text())
    prior=identity_metrics(baseline,[r['train_occurrences'] for r in props])
    names=dict(direct='直接分类',retrieval='化学模板检索',iterative='迭代身份纠错')
    lines=[MARKER,'',
        '本轮完成输入审计、GEOM 身份推理路径修复、三个独立身份头对照及连接噪声分层验证。'
        '**暂不启动完整联合训练**：身份恢复已有明显进展，但高噪声连接模型仍不适用。','',
        '### 发现与修复','',
        '- GEOM 检查点在 CASF 推理时切换到 PDBbind 的口袋/交叉注意力读出。该路径未经过 GEOM 训练；'
        '现将身份服务默认切回实际训练过的 `geom_matched` 路径，只使用当前输入位姿中心化后的无口袋表示。'
        '旧 `pdb_original` 路径保留为显式诊断选项。官方 docking 仍读取完整真实化学图和口袋。',
        '- GEOM packed feedback 未接收 `connection_prior`，仅设置配置概率不会训练该通道。'
        '实际身份服务默认关闭该未训练先验，允许诊断时显式开启；独立新身份头明确训练了给定邻接。',
        f'- 3684 双向 ID 映射、模板库、检查点资产指纹一致。审计 {audit["summary"]["molecules_checked"]} 个分子、'
        f'{audit["summary"]["known_slots_checked"]} 个已知槽位，原子/键顺序不匹配和化学结构不匹配均为 0，模板局部坐标误差为 0。',
        '- MASK 固定为 3684，4 个角色节点的原子特征清零并移除化学键；OOV=-1，仅在旧模型中保留显式化学，'
        '不将 OOV 保留算作类型预测成功。新身份头所有槽位均遮蔽，不读取真原子数、端口或原子特征。','',
        '### 原检查点：完整 CASF 上的数据路径与噪声诊断','',
        '下面是 271 个可用 CASF、1,099 个词表内槽位。主诊断同时扰动平移和旋转；clean 不扰动。'
        '低/中/高噪声采用缓存原训练的 native C/Q → VP/IGSO3 → canonical T/R 流程，时间为 0.2/0.6/0.9。','',
        '| 噪声 | 原 PDB 路径 Top-1 | GEOM 匹配路径 Top-1 | 匹配路径 Top-5 | Top-20 |',
        '| --- | ---: | ---: | ---: | ---: |']
    for t,label in [(0.,'clean'),(.2,'低'),(.6,'中'),(.9,'高')]:
        x=old['levels'][f'val/{t}/pdb_original']['metrics']['topk_accuracy']
        y=old['levels'][f'val/{t}/geom_matched']['metrics']['topk_accuracy']
        lines.append(f'| {label} | {x["1"]:.2%} | {y["1"]:.2%} | {y["5"]:.2%} | {y["20"]:.2%} |')
    lines+=['',f'原先 12 个 CASF 样本的相同 53 个已知槽位：修复后 Top-1={fixed["summary"]["top1_accuracy"]:.2%}（32/53），'
        f'Top-5={fixed["summary"]["top5_accuracy"]:.2%}；原记录为 9.43% / 30.19%。',
        'GEOM 训练集和 dev 各 64 个固定哈希抽样也已评估全部噪声档；t=0.02 的 Top-1 分别为 '
        f'{old["levels"]["geom_train/0.02/training_matched"]["metrics"]["topk_accuracy"]["1"]:.2%} / '
        f'{old["levels"]["geom_dev/0.02/training_matched"]["metrics"]["topk_accuracy"]["1"]:.2%}，'
        '到 t=0.2 约为 13%，说明高噪声下性能差也存在于训练分布中，不能仅靠修复数据路径解决。'
        '旧模型的 PDBbind 训练集诊断为 64 个固定样本，下面新身份头的训练集评估覆盖全部 17,420 个。','',
        '### 三个独立身份改进实验','',
        '每个方法在 17,420 个非 CASF PDBbind 分子上训练 8 轮；CASF 271 个分子仅作验证，交集为零。'
        '三者使用相同的帧几何特征、真实中心、真实槽位邻接/键级、给定 N，始终遮蔽身份；'
        '不要求输入真端口。训练包含四档旋转噪声，平移中心保留真值。它们是独立轻量身份头，'
        '没有重新训练 Equiformer/SigmaDock 主干，也没有注入官方原子特征。',
        '直接分类输出 3684 类；模板检索将当前帧/邻接查询与所有库模板的化学指纹、端口容量及形状描述符匹配，'
        '不以真模板作查询；迭代纠错通过软身份分布及邻接聚合再更新两次，附加 0.3 倍初始分类辅助损失。'
        '模型容量与目标并不完全相同，因此结果是受控方法比较，不能归因于一个孤立组件。','',
        '| 方法（clean） | Top-1 | Top-5 | Top-10 | Top-20 | 全词表内分子身份完全正确 |',
        '| --- | ---: | ---: | ---: | ---: | ---: |',
        f'| PDBbind 训练频率先验 | {prior["topk_accuracy"]["1"]:.2%} | {prior["topk_accuracy"]["5"]:.2%} | '
        f'{prior["topk_accuracy"]["10"]:.2%} | {prior["topk_accuracy"]["20"]:.2%} | '
        f'{prior["complete_in_vocab_correct"]}/132 |']
    for kind,v in full['methods'].items():
        m=v['fresh_noise_val']['clean']['metrics'];k=m['topk_accuracy']
        lines.append(f'| {names[kind]} | {k["1"]:.2%} | {k["5"]:.2%} | {k["10"]:.2%} | {k["20"]:.2%} | '
                     f'{m["complete_in_vocab_correct"]}/132 ({m["complete_in_vocab_accuracy"]:.2%}) |')
    lines+=['', '1,262 个槽位中的 163 个 OOV 排除出身份指标；132 个分子全部槽位均在词表内。'
        '另外单独报告 253 个含已知槽位分子的“所有已知槽位正确”，不把纯 OOV 分子当作成功。'
        'PDBbind 训练覆盖 1,089 个类别；CASF 有 175 个已知类别，其中 5 类/5 个槽位未在本次 PDBbind 训练中出现。'
        'CASF 用于选 checkpoint，仍是验证指标，不是独立盲测。三个最佳检查点均为第 8 轮，尚不能宣称已收敛。','',
        '| 方法 | 低噪声 Top-1 / Top-5 | 中噪声 Top-1 / Top-5 | 高噪声 Top-1 / Top-5 |',
        '| --- | ---: | ---: | ---: |']
    for kind,v in full['methods'].items():
        vals=[v['fresh_noise_val'][level]['metrics']['topk_accuracy'] for level in ('low','medium','high')]
        lines.append('| '+names[kind]+' | '+' | '.join(f'{x["1"]:.2%} / {x["5"]:.2%}' for x in vals)+' |')
    lines+=['','本表身份实验保留真中心，仅扰动旋转；不能与前面同时扰动平移的表直接比较。'
        '选模使用噪声 seed=1；此表在新的 seed=2/3/4 上复核，每档 813 次分子评估。'
        '直接分类、检索和迭代模型使用完全相同的新噪声样本。','',
        '| 迭代身份纠错 | clean | 低 | 中 | 高 |','| --- | ---: | ---: | ---: | ---: |']
    v=full['methods']['iterative']
    lines.append('| 全部训练集 Top-1 | '+' | '.join(f'{v["full_training"][k]["topk_accuracy"]["1"]:.2%}' for k in ('clean','low','medium','high'))+' |')
    lines.append('| CASF Top-1 | '+' | '.join(f'{v["fresh_noise_val"][k]["metrics"]["topk_accuracy"]["1"]:.2%}' for k in ('clean','low','medium','high'))+' |')
    lines+=['','全部训练集每档 17,420 个分子 / 111,744 个已知槽位，使用训练中见过的噪声 seed=0；'
        '该指标用于观察拟合程度。训练集与 CASF 的差距仍明显。','',
        '| clean 频率分组（冻结 GEOM train_occurrences） | 已知槽位 | 直接分类 Top-1 | 检索 Top-1 | 迭代 Top-1 |',
        '| --- | ---: | ---: | ---: | ---: |']
    for group,label in [('rare_1_100','≤100'),('medium_101_1000','101–1000'),('frequent_gt1000','>1000')]:
        values=[full['methods'][kind]['fresh_noise_val']['clean']['metrics']['frequency_groups'][group] for kind in names]
        lines.append(f'| {label} | {values[0]["slots"]} | '+' | '.join(f'{x["topk_accuracy"]["1"]:.2%}' for x in values)+' |')
    iter_report=read('identity_controls/iterative/report.json')['val']['clean']
    lines+=['',f'迭代模型同一个检查点的初始输出 Top-1={iter_report["initial_metrics"]["topk_accuracy"]["1"]:.2%}，'
        f'两次纠错后为 {iter_report["metrics"]["topk_accuracy"]["1"]:.2%}，并非仅重新调用相同分类结果。',
        '[身份训练 loss / CASF 曲线](results/prediction_diagnostics/identity_controls/identity_curves.png) · '
        '[最佳迭代身份头](results/prediction_diagnostics/identity_controls/iterative/best.pt)','',
        '### 连接预测：适用范围','',
        '真实身份、给定 N；平移和旋转一起按原 native 扩散加噪，271 个分子 × 3 个 seed。'
        '特征/候选不读取真边、真端口；阈值仍为 0.65，不强行补树，不用真边修复。'
        '完整图比例同时给出全体和多片段子集，避免单片段无边样本抬高结果。','',
        '| t | 平移扰动 RMS (Å) | 端口/键级 F1 | 完整合法图（全部） | 完整合法图（多片段） | 完整端口图正确（多片段） |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for level,source in [('clean',connection),('near_0_02',near),('near_0_05',near),('near_0_1',near),('low',connection),('medium',connection),('high',connection)]:
        x=source['summary'][level];m=x['multi_fragment_only'];t=source['levels'][level]
        lines.append(f'| {t:g} | {x["translation_rms_A"]:.3f} | {x["f1"]:.2%} | {x["complete_legal"]:.2%} | '
                     f'{m["complete_legal"]:.2%} | {m["full_port_graph_exact"]:.2%} |')
    lines+=['', '原连接训练只覆盖 0/0.2/0.5 Å 附近的平移抖动及很小旋转；“扩散时间 t=0.2”并不是“0.2 Å”。'
        '实际 t=0.2 的平移 RMS 约 2.81 Å、平均旋转约 51°，与旧增强分布明显不同。',
        f'高噪声端口候选由每对槽位 Top-8 扩大到 Top-64 后，候选覆盖率从 '
        f'{connection["summary"]["high"]["candidate_coverage"]:.2%} 提升到 '
        f'{wide["summary"]["high"]["candidate_coverage"]:.2%}，F1 仍只有 '
        f'{wide["summary"]["high"]["f1"]:.2%}，多片段完整图恢复率仍为 0。'
        '因此候选剪枝和打分分布均有问题，只扩大候选池不能解决高噪声连接预测。','',
        '### 回归与下一步决定','',
        f'- {tests} 项测试通过；修复后的实际身份服务通过 N=10 与 N=6 的请求，未读取目标位姿作中心化。',
        '- 两个口袋重新运行完整 25 时间点 Oracle 采样；相对原官方 sampler 的最终坐标最大差均为 **0 Å**，'
        '几何动态更新审计通过。原官方源码关键文件与 EMA 权重指纹不变。',
        '- 官方检出目录沿用 10 月 30 日已有的 PoseBusters 延迟导入、错误透传及禁用自动重试兼容补丁；'
        '本轮未改这些文件，也未改网络、力学或扩散主干。',
        '- 暂不启动联合动态生成训练。后续优先训练覆盖实际 VP/IGSO3 噪声、带时间条件的连接模块，'
        '配合高噪声宽候选/低噪声提交策略；身份方向优先迭代纠错，并继续考察长尾和全分子准确率。'
        '即使 clean Top-1 已提升，完整身份恢复仍只有 25/132，不能据此宣称从头生成已解决。',
        '- 新身份头保留为独立受控入口，没有直接替换联合采样默认预测器；默认旧 GEOM 服务仅完成特征路径修复。','',
        '完整 JSON： [输入审计](results/prediction_diagnostics/input_audit.json)、'
        '[旧模型全噪声诊断](results/prediction_diagnostics/legacy_gpu/report.json)、'
        '[真实中心对照](results/prediction_diagnostics/legacy_controlled/report.json)、'
        '[全训练集与新 seed 身份评估](results/prediction_diagnostics/identity_full_evaluation.json)、'
        '[连接噪声分层](results/prediction_diagnostics/connection_noise_v2/report.json)、'
        '[近真实噪声边界](results/prediction_diagnostics/connection_near_clean/report.json)、'
        '[宽候选](results/prediction_diagnostics/connection_wide_candidates/report.json)、'
        '[Oracle 回归](results/prediction_diagnostics/oracle_regression/report.json)。'
        '复现命令见 [PREDICTION.md](PREDICTION.md)。','']
    text='\n'.join(lines);(p/'PREDICTION_RESULTS.md').write_text(text)
    original=(p/'STAGED_RESULTS.md').read_text().split(MARKER)[0].rstrip()
    (p/'STAGED_RESULTS.md').write_text(original+'\n\n'+text)
    reports=['input_audit.json','legacy_gpu/report.json','legacy_controlled/report.json','identity_full_evaluation.json',
             'connection_noise_v2/report.json','connection_near_clean/report.json','connection_wide_candidates/report.json',
             'oracle_regression/report.json','identity_server_smoke.json']
    write_json(p/'PREDICTION_MANIFEST.json',dict(official_backbone_unchanged=True,official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),
        scripts={str(x.relative_to(p)):digest(x) for x in sorted(p.glob('*.py'))},
        tests={str(x.relative_to(p)):digest(x) for x in sorted((p/'tests').glob('*.py'))},tests_passed=tests,
        official_source_sha256={str(x.relative_to(bootstrap.OFFICIAL)):digest(x)
                                for x in sorted((bootstrap.SOURCE/'sigmadock').rglob('*.py'))},
        existing_official_compatibility_patches=['scripts/sample.py','src/sigmadock/data.py','src/sigmadock/chem/ligalign.py'],
        reports={x:digest(b/x) for x in reports},
        checkpoints={kind:digest(b/f'identity_controls/{kind}/best.pt') for kind in names},
        joint_training_started=False))
    print(p/'PREDICTION_RESULTS.md')


if __name__=='__main__':main()
