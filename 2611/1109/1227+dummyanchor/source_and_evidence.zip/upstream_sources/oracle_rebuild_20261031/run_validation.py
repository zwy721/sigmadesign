#!/usr/bin/env python3
"""CASF chemistry/graph equivalence and paired full official docking acceptance."""
import argparse
import copy
import json
import os
import random
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path

import bootstrap
import numpy as np
import torch
from rdkit import Chem
from torch_geometric.data import Batch

import sigmadock
import sigmadock.oracle
from sigmadock.data import SigmaDataset
from sigmadock.datafronts import ExplicitPairsFront
from sigmadock.diff.sampling import sampler
from sigmadock.oracle import HPARAMS
from sigmadock.utils import load_from_checkpoint

from oracle_graph import assemble, oracle_from_official, rebuild
from serialization import save_graph
from validation import (SamplingAudit, compare_3684_partition, compare_graphs,
                        compare_values, digest, inventory)

DEFAULT_IDS = '1a30,1r5y,2j7h,2wvt,3b1m,3f3e,3mss,3ryj,4agn,4f9w,4m0y,5tmn'


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed % (2**32 - 1))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    tmp.replace(path)


def official_graph(sdf, pdb, seed):
    seed_all(seed)
    class CaptureReference(SigmaDataset):
        def fragment_and_annotate(self, mol, idx):
            self.inference_reference = Chem.Mol(mol)
            return super().fragment_and_annotate(mol, idx)

    dataset = CaptureReference(ExplicitPairsFront([(sdf, pdb, None)]),
                        pocket_com_noise=0., pocket_distance_cutoff=5., pocket_distance_noise=0.,
                        prot_coordinate_distance_noise=0., use_esm_embeddings=False,
                        ignore_triangulation=False, lig_coordinate_distance_noise=0.,
                        alignment_tries=0, fragmentation_strategy='canonical',
                        ignore_conjugated_torsion=False, pb_check=False, get_mol_info=True,
                        seed=seed, random_rotation=False, sample_conformer=True,
                        skip_bounds_check=True, force_retry=False)
    graph = dataset[0]
    return graph, dataset.inference_reference


def chemical_smiles(mol):
    mol = Chem.Mol(mol)
    Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
    return Chem.MolToSmiles(mol, isomericSmiles=True)


def load_official(checkpoint, output, device):
    # Historic serialized hparams refer to alphadock.oracle, the original name.
    sys.modules['alphadock'] = sigmadock
    sys.modules['alphadock.oracle'] = sigmadock.oracle
    raw = torch.load(checkpoint, map_location='cpu', weights_only=False)
    cache = output / 'diffusion_cache'
    # Copy 26 MB instead of permitting the official loader to write old assets.
    shutil.copytree(bootstrap.CACHE, cache, dirs_exist_ok=True)
    raw['hyper_parameters']['denoiser_config']['cache_path'] = str(cache.resolve())
    den = load_from_checkpoint(raw, load_ema=True).to(device).eval()
    den.diffuser._so3_diffuser.set_device(device)
    for p in den.parameters():
        p.requires_grad_(False)
    return den


def docking(den, graph, *, seed, steps, device, noise_scale, save):
    seed_all(seed)
    # Do not collate RDKit/target molecules into the sampler: only input graph fields.
    data = graph.clone()
    del data.mol_info
    batch = Batch.from_data_list([data]).to(device)
    started = time.time()
    with torch.inference_mode(), SamplingAudit(den) as audit:
        sampled, trajectory, _ = sampler(den, batch, num_steps=steps, t_min=.005,
                                         rho=3., noise_scale=noise_scale, noise_decay=2.,
                                         solver='euler', discretization='edm',
                                         use_true_scores=False, verbose=False)
    pn = int((graph.frag_idx_map == -1).sum())
    mol = graph.mol_info['original']
    indices = torch.tensor([a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum() > 1])
    # This matches official scripts/sample.py: final reverse state, no extra denoise.
    pred = sampled.pos_t.detach().cpu()[pn + indices] * HPARAMS.general.dimensional_scale
    pred = pred + graph.pocket_com.cpu().reshape(1, 3)
    result = dict(seconds=time.time() - started, audit=audit.report())
    save.parent.mkdir(parents=True, exist_ok=True)
    torch.save(dict(heavy_xyz_A=pred, trajectory_normalized=trajectory.detach().cpu(),
                    heavy_atom_indices=indices, pocket_com=graph.pocket_com.cpu(),
                    dimensional_scale=HPARAMS.general.dimensional_scale,
                    seed=seed), save)
    # Construct a view in chemical atom order, not dummy/virtual order.
    predicted_mol = Chem.Mol(mol)
    conf = predicted_mol.GetConformer()
    for k, xyz in zip(indices.tolist(), pred.tolist()):
        conf.SetAtomPosition(k, xyz)
    with Chem.SDWriter(str(save.with_suffix('.sdf'))) as writer:
        writer.write(predicted_mol)
    return pred, trajectory.detach().cpu(), result


def summary(rows):
    result = {}
    for cohort in ('official_partition', 'matching_3684_partition'):
        selected = [r for r in rows if cohort == 'official_partition'
                    or r['partition3684']['usable_as_same_graph']]
        for name in ('official', 'reconstructed'):
            vals = [d[name]['rmsd_A'] for r in selected for d in r['docking']]
            if vals:
                result[f'{cohort}/{name}'] = dict(n=len(vals), ligands=len(selected),
                    mean_A=float(np.mean(vals)), median_A=float(np.median(vals)),
                    under2_fraction=float(np.mean(np.array(vals) < 2)),
                    under5_fraction=float(np.mean(np.array(vals) < 5)))
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--ids', default=DEFAULT_IDS)
    p.add_argument('--inputs', type=Path, default=bootstrap.INPUTS)
    p.add_argument('--records', type=Path, default=bootstrap.RECORDS)
    p.add_argument('--checkpoint', type=Path, default=bootstrap.CHECKPOINT)
    p.add_argument('--output', type=Path, default=bootstrap.PROJECT / 'results/acceptance')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--seeds', default='0,1,2')
    p.add_argument('--graph-seed', type=int, default=0)
    p.add_argument('--steps', type=int, default=25)
    p.add_argument('--noise-scale', type=float, default=0.)
    p.add_argument('--graphs-only', action='store_true')
    p.add_argument('--trajectory-atol', type=float, default=1e-4,
                   help='Maximum paired coordinate difference in A, no best-seed selection')
    a = p.parse_args()
    if a.steps < 2 or not 0 <= a.noise_scale <= 1:
        p.error('Require steps >= 2 and 0 <= noise-scale <= 1')
    a.output = a.output.resolve()
    if (a.output / 'report.json').exists():
        p.error('Output report already exists; choose a new output directory')
    a.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(2)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    torch.use_deterministic_algorithms(True)
    device = torch.device(a.device)
    if device.type == 'cuda':
        torch.cuda.set_device(device)
    source = bootstrap.verify_imports()
    ids = a.ids.split(',')
    seeds = [int(s) for s in a.seeds.split(',')]
    if len(ids) != len(set(ids)) or len(seeds) != len(set(seeds)) or not seeds:
        p.error('IDs and seeds must be nonempty and unique')
    commit = subprocess.check_output(['git', '-C', str(bootstrap.OFFICIAL), 'rev-parse', 'HEAD'], text=True).strip()
    paths = ['data.py', 'chem/processing.py', 'chem/fragmentation.py', 'diff/denoiser.py', 'diff/sampling.py']
    manifest = dict(official_commit=commit, source=source, checkpoint=str(a.checkpoint.resolve()),
                    checkpoint_sha256=digest(a.checkpoint), load_ema=True,
                    source_sha256={x: digest(bootstrap.SOURCE / 'sigmadock' / x) for x in paths},
                    project_sha256={x.name: digest(x) for x in bootstrap.PROJECT.glob('*.py')},
                    torch=torch.__version__, rdkit=Chem.rdBase.rdkitVersion, device=str(device),
                    cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'), graph_seed=a.graph_seed,
                    deterministic_algorithms=True, tf32=False,
                    ids=ids, seeds=seeds, steps=a.steps, noise_scale=a.noise_scale,
                    graph_protocol='Official canonical fragmentation and RDKit sampled inference reference; '
                                   '5 A receptor crop; all crop/jitter/rotation noise disabled; identical receptor.',
                    sampling_protocol='Unmodified official sampler; 25 points by default, 24 Euler updates; '
                                      'EDM rho=3, t_min=.005; final reverse state; same RNG seed per pair.',
                    rmsd_protocol='Heavy atoms in original chemical atom order, in receptor coordinate frame; '
                                  'no alignment and no symmetry correction. Target xyz used only for metrics.',
                    trajectory_atol_A=a.trajectory_atol, graphs_only=a.graphs_only)
    result = dict(manifest=manifest, rows=[], failures=[], accepted=False, stage='running')
    write_json(a.output / 'report.json', result)
    den = None if a.graphs_only else load_official(a.checkpoint, a.output, device)
    for pid in ids:
        case_out = a.output / pid
        case_out.mkdir(exist_ok=True)
        try:
            if not pid.isalnum() or len(pid) != 4:
                raise ValueError(f'Invalid CASF id {pid!r}')
            sdf = a.inputs / pid / f'{pid}_LIG_ligand.sdf'
            pdb = a.inputs / pid / f'{pid}_LIG_pocket.pdb'
            baseline, reference = official_graph(sdf, pdb, a.graph_seed)
            torch.save(dict(pocket=baseline.mol_info['pocket'], pocket_com=baseline.pocket_com.numpy(),
                            pdb_path=pdb, ligand_path=sdf), case_out / 'pocket_context.pt')
            spec = oracle_from_official(baseline, reference)
            write_json(case_out / 'oracle.json', spec)
            # Disk round-trip is mandatory: no hidden in-memory molecule fallback.
            spec = json.loads((case_out / 'oracle.json').read_text())
            restored = rebuild(spec, pocket=baseline.mol_info['pocket'],
                               pocket_com=baseline.pocket_com.numpy(), pdb_path=pdb, ligand_path=sdf)
            checks = compare_graphs(baseline, restored)
            write_json(case_out / 'graph_comparison.json', checks)
            if not checks['equal']:
                raise AssertionError(f'Graph differs: {[x for x in checks["fields"] if not x["equal"]][:8]}')
            native_smiles = chemical_smiles(baseline.mol_info['original'])
            restored_smiles = chemical_smiles(assemble(spec))
            if native_smiles != restored_smiles:
                raise AssertionError(f'Reassembled chemistry differs: {native_smiles} vs {restored_smiles}')
            partition = compare_3684_partition(baseline, a.records / f'{pid}.pt')
            save_graph(baseline, case_out / 'official_graph.pt')
            save_graph(restored, case_out / 'reconstructed_graph.pt')
            row = dict(id=pid, inputs_sha256=dict(sdf=digest(sdf), pdb=digest(pdb),
                       cached_record=digest(a.records / f'{pid}.pt')), graph_exact=checks['exact'],
                       graph=inventory(baseline), partition3684=partition,
                       chemical_identity_equal=True, docking=[])
            print(pid, 'GRAPH EXACT', checks['exact'], '3684 SAME PARTITION', partition['same_partition'], flush=True)
            write_json(case_out / 'partition3684.json', partition)
            for seed in ([] if a.graphs_only else seeds):
                pair = dict(seed=seed)
                predictions, trajectories = {}, {}
                for name, graph in [('official', baseline), ('reconstructed', restored)]:
                    pred, traj, stats = docking(den, graph, seed=seed, steps=a.steps, device=device,
                                               noise_scale=a.noise_scale,
                                               save=case_out / f'{name}_seed{seed}.pt')
                    # Both groups are scored against the SAME original crystal molecule.
                    original = baseline.mol_info['original']
                    heavy = [x.GetIdx() for x in original.GetAtoms() if x.GetAtomicNum() > 1]
                    target = torch.as_tensor(original.GetConformer().GetPositions()[heavy])
                    stats['rmsd_A'] = float(((pred.double() - target).square().sum(-1).mean()).sqrt())
                    predictions[name], trajectories[name], pair[name] = pred, traj, stats
                delta = float((predictions['official'] - predictions['reconstructed']).abs().max())
                traj_delta = float((trajectories['official'] - trajectories['reconstructed']).abs().max()
                                   * HPARAMS.general.dimensional_scale)
                pair.update(max_coordinate_difference_A=delta, max_trajectory_difference_A=traj_delta,
                            per_step_hashes_identical=pair['official']['audit'] == pair['reconstructed']['audit'])
                row['docking'].append(pair)
                print(pid, 'seed', seed, 'RMSD', pair['official']['rmsd_A'], pair['reconstructed']['rmsd_A'],
                      'trajectory max delta A', traj_delta, flush=True)
                if max(delta, traj_delta) > a.trajectory_atol:
                    raise AssertionError(f'Paired trajectory exceeds {a.trajectory_atol} A: {traj_delta}')
            result['rows'].append(row)
        except Exception as exc:
            result['failures'].append(dict(id=pid, error=repr(exc), traceback=traceback.format_exc()))
            print('FAILED', pid, traceback.format_exc(), flush=True)
        finally:
            result['summary'] = summary(result['rows'])
            write_json(a.output / 'report.json', result)
    bootstrap.verify_imports()
    for x, before in manifest['source_sha256'].items():
        if digest(bootstrap.SOURCE / 'sigmadock' / x) != before:
            raise RuntimeError(f'Official source changed while running: {x}')
    result['accepted'] = not result['failures'] and len(result['rows']) == len(ids)
    result['stage'] = 'graph_validation_complete' if a.graphs_only else 'paired_docking_complete'
    result['next_stage_enabled'] = False
    result['scope'] = 'Oracle reconstruction only. Identity/connection training and de novo generation remain disabled.'
    write_json(a.output / 'report.json', result)
    print('ACCEPTED', result['accepted'], 'SUMMARY', json.dumps(result['summary']), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
