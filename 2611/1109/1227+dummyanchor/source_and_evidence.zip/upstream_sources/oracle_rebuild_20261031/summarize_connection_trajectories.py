#!/usr/bin/env python3
"""Summarize distribution diagnostics, adaptation and independent Top-K tests."""
import argparse
import csv
from datetime import datetime,timezone
import json
from pathlib import Path

import bootstrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch

from run_validation import write_json
from validation import digest


def percent(x):return f'{100*x:.2f}%'
def f1(rows):return 2*sum(x['tp'] for x in rows)/max(1,sum(x['predicted']+x['true_bonds'] for x in rows))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=bootstrap.PROJECT/'results/connection_trajectory_20261101')
    a=p.parse_args();root=a.root
    reports=[json.loads((root/n/'report.json').read_text()) for n in ['diagnostic_a','diagnostic_b']]
    rows=[r for report in reports for r in report['rows']]
    legacy=json.loads((root/'diagnostic_legacy/report.json').read_text())
    regression=json.loads((root/'smoke_deterministic/report.json').read_text())['regression']
    steps={mode:[] for mode in ['oracle','shadow','closed','diagnostic_reset']}
    allsteps=[]
    for folder in ['diagnostic_a','diagnostic_b']:
        report=json.loads((root/folder/'report.json').read_text())
        for r in report['rows']:
            frames=json.loads((root/folder/f"{r['id']}_{r['seed']}_{r['mode']}/steps.json").read_text())
            steps[r['mode']].append(frames)
            allsteps.extend(dict(id=r['id'],seed=r['seed'],mode=r['mode'],**f) for f in frames)
    forward=[x['steps'] for r in reports for x in r['forward_controls']]
    four={}
    for mode in steps:
        rr=[r for r in rows if r['mode']==mode];final=[r['final'] for r in rr]
        four[mode]=dict(runs=len(rr),final_topology_correct=sum(x['current_topology_exact'] for x in final),
            final_constitution_correct=sum(x['current_constitution_exact'] for x in final),
            final_connection_f1=f1(final),final_proposal_legal=sum(x['proposal_legal'] for x in final)/len(final),
            slot_atom_rmsd_median_A=float(np.median([x['slot_atom_rmsd_A'] for x in final])),
            initial_wrong_topology=sum(not r['initial']['current_topology_exact'] for r in rr),
            first_applied_wrong_update=[dict(id=r['id'],seed=r['seed'],step=r['first_applied_wrong_topology_step']) for r in rr],
            revisions=sum(r['revisions'] for r in rr))
    write_json(root/'four_mode_summary.json',four)
    write_json(root/'all_diagnostic_steps.json',allsteps)
    with (root/'first_topology_errors.csv').open('w') as stream:
        writer=csv.DictWriter(stream,fieldnames=['id','seed','mode','first_wrong_topology_step','first_applied_wrong_topology_step','first_wrong_proposal_step'])
        writer.writeheader()
        for r in rows:writer.writerow({k:r[k] for k in writer.fieldnames})
    search_reports=[json.loads(path.read_text()) for path in sorted(root.glob('search_*/report.json'))]
    search=[r for report in search_reports for r in report['rows']]
    branch_groups={}
    for report in search_reports:
        for b in report['branches']:branch_groups.setdefault((b['id'],b['model'],b['seed']),[]).append(b)
    if len(search)!=216:raise ValueError(f'Expected 12*3*2*3=216 search summaries, got {len(search)}')
    topk={}
    for model in ('baseline','adapted'):
        topk[model]={}
        for k in (1,4,8):
            rr=[r for r in search if r['model']==model and r['K']==k];n=len(rr)
            bad=lambda r:not r['chemical_valid'] or r['selected_rank']['geometry']['bond_error_over_0_5A']>0 or r['selected_rank']['geometry']['ligand_nonbonded_clashes_under_1_2A']>0
            topk[model][str(k)]=dict(runs=n,full_connections_correct=sum(r['selected_topology_exact'] for r in rr),
                constitution_correct=sum(r['selected_constitution_exact'] for r in rr),chemical_valid=sum(r['chemical_valid'] for r in rr),
                topology_pool_has_truth=sum(r['final_topology_pool_contains_truth'] for r in rr),
                constitution_pool_has_truth=sum(any(b['success'] and b['branch']<k and b['final_constitution_exact'] for b in branch_groups[r['id'],model,r['seed']]) for r in rr),
                initial_pool_has_truth=sum(r['initial_topology_pool_contains_truth'] for r in rr),
                geometry_abnormal=sum(bad(r) for r in rr),
                selected_pocket_clash=sum(r['selected_rank'] is not None and r['selected_rank']['geometry'].get('ligand_atoms_clashing_pocket_under_1_2A',0)>0 for r in rr),
                branch_completion_rate=sum(r['completed'] for r in rr)/max(1,sum(r['attempted'] for r in rr)),
                mean_attempted_branches=float(np.mean([r['attempted'] for r in rr])),mean_backbone_evaluations=float(np.mean([r['backbone_evaluations'] for r in rr])),
                median_seconds=float(np.median([r['seconds'] for r in rr])),
                mean_distinct_final_constitutions=float(np.mean([r['distinct_final_constitutions'] for r in rr])),
                mean_initial_pose_drift_A=float(np.mean([r['initial_pose_drift']['mean_A'] for r in rr])),
                mean_final_pose_drift_A=float(np.mean([r['final_pose_drift']['mean_A'] for r in rr])))
    write_json(root/'topk_summary.json',topk)
    with (root/'topk_metrics.csv').open('w') as f:
        fields=['model','K']+list(topk['baseline']['1'])
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for model in topk:
            for k,m in topk[model].items():writer.writerow(dict(model=model,K=k,**m))
    forward_old=json.loads((root/'forward_baseline/report.json').read_text())['summary']['full_noise']
    forward_new=json.loads((root/'forward_adapted/report.json').read_text())['summary']['full_noise']
    fixed_old=json.loads((root/'forward_original_policy/report.json').read_text())['summary']['full_noise']
    fixed_new=json.loads((root/'forward_adapted_original_policy/report.json').read_text())['summary']['full_noise']
    status=json.loads((root/'adaptation_conservative/status.json').read_text())
    histories={n:json.loads((root/n/'history.json').read_text()) for n in ['adaptation','adaptation_conservative']}
    plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25,'figure.dpi':160})
    colors={'oracle':'#0077bb','shadow':'#009988','closed':'#cc3311','diagnostic_reset':'#ee7733'}
    fig,axes=plt.subplots(2,2,figsize=(11,7))
    for mode in steps:
        ss=steps[mode]
        axes[0,0].plot(range(25),[np.median([x[i]['slot_atom_rmsd_A'] for x in ss]) for i in range(25)],label=mode,color=colors[mode],ls='--' if mode=='shadow' else '-')
        axes[0,1].plot(range(25),[100*f1([x[i] for x in ss]) for i in range(25)],label=mode,color=colors[mode],ls='--' if mode=='shadow' else '-')
        axes[1,0].plot(range(25),[100*np.mean([x[i]['proposal_legal'] for x in ss]) for i in range(25)],label=mode,color=colors[mode],ls='--' if mode=='shadow' else '-')
        axes[1,1].plot(range(25),[100*np.mean([x[i]['current_topology_exact'] for x in ss]) for i in range(25)],label=mode,color=colors[mode],ls='--' if mode=='shadow' else '-')
    axes[0,0].plot(range(25),[np.median([x[i]['slot_atom_rmsd_A'] for x in forward]) for i in range(25)],color='#777777',ls=':',label='Forward marginal')
    axes[0,1].plot(range(25),[100*f1([x[i] for x in forward]) for i in range(25)],color='#777777',ls=':',label='Forward marginal')
    for ax,title,ylabel in zip(axes.flat,['Fixed slot/atom pose diagnostic','Predicted exact-port/order F1','Predicted complete legal graph','Current full topology exact'],['Median RMSD (A)','Percent','Percent','Percent']):
        ax.set(title=title,xlabel='Reverse step (0: t=0.9, 24: t=0.005)',ylabel=ylabel)
    axes[0,0].legend(fontsize=8);fig.tight_layout();fig.savefig(root/'trajectory_domain_gap.png');fig.savefig(root/'trajectory_domain_gap.pdf');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for name,h in histories.items():
        h=[x for x in h if 'train_loss' in x]
        axes[0].plot([r['epoch'] for r in h],[r['train_loss'] for r in h],label=name)
        axes[1].plot([r['epoch'] for r in h],[100*r['selection_score'] for r in h],label=name)
    axes[0].set(xlabel='Epoch',ylabel='Loss (objectives have different weights)',title='Trajectory adaptation training loss')
    axes[1].axhline(histories['adaptation_conservative'][0]['selection_score']*100,color='#777777',ls='--',label='Frozen baseline')
    axes[1].set(xlabel='Epoch',ylabel='Non-CASF calibration F1 (%)',title='Checkpoint selection; CASF unused')
    for ax in axes:ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(root/'adaptation_loss.png');plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(10,7))
    for model,color in [('baseline','#666666'),('adapted','#cc3311')]:
        mm=[topk[model][str(k)] for k in (1,4,8)]
        for ax,key,title in zip(axes.flat,['full_connections_correct','constitution_correct','geometry_abnormal','mean_backbone_evaluations'],['All connections exact','Constitution exact','Geometry abnormal (lower is better)','Backbone evaluations (NFE)']):
            vals=[m[key] if key=='mean_backbone_evaluations' else 100*m[key]/m['runs'] for m in mm]
            ax.plot([1,4,8],vals,marker='o',color=color,label=model);ax.set(title=title,xlabel='K',ylabel='NFE' if key=='mean_backbone_evaluations' else 'Percent',xticks=[1,4,8])
    for ax in axes.flat:ax.set_ylim(bottom=0)
    axes[0,0].legend();fig.tight_layout();fig.savefig(root/'topk_comparison.png');fig.savefig(root/'topk_comparison.pdf');plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4))
    for model,style in [('baseline','--'),('adapted','-')]:
        for field in ['mean_initial_pose_drift_A','mean_final_pose_drift_A']:
            ax.plot([1,4,8],[topk[model][str(k)][field] for k in (1,4,8)],marker='o',ls=style,label=f'{model}: {field.split("_")[1]}')
    ax.set(title='Different legal topology branches, same initial seed',xlabel='K',ylabel='Pairwise slot-centroid RMS displacement (A)',xticks=[1,4,8]);ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(root/'topology_pose_shift.png');plt.close(fig)
    prefix=root.relative_to(bootstrap.PROJECT).as_posix()
    text=['# 真实逆扩散轨迹与连接拓扑专项（2026-11-01）','',
        '本轮固定真实片段身份和 N，不更新身份模型或官方 SigmaDock 主干。完成四模式定位、非 CASF 轨迹适配、独立 CASF 上 K=1/4/8 搜索与官方回归。',
        '', '## 主要发现','',
        f"Oracle 真实轨迹末端的连接 F1 为 {percent(four['oracle']['final_connection_f1'])}，预测拓扑闭环为 {percent(four['closed']['final_connection_f1'])}；仅在诊断中阶段性恢复真拓扑后为 {percent(four['diagnostic_reset']['final_connection_f1'])}。Oracle 与只读连接预测的轨迹逐步最大差为 0 Å。",
        '', '上一版闭环低噪声阶段调用冻结旧连接头，未使用新时间条件头。本轮主对照统一使用新头，旧路由另作配对对照。另定位到预测头允许额外片段闭环：这些图可被 RDKit 认为合法，却不符合本数据切分规范。已核对 17,420 个训练及 271 个验证分子，片段图全部为 N−1 条边的树。后续适配采集与 Top-K 搜索加入目标无关的树约束；真实拓扑未用于非 Oracle 结果修复。',
        '', '## 四模式与逐步分布差异','',
        '同一 12 个受体，每个 seed=601/602/603；各模式 36 次。25 时间点、24 次原主干 Euler 更新，t=0.9→0.005；同一 native stationary 随机种子。Oracle 采用真实化学图；shadow 只预测不应用；closed 只用预测图；diagnostic_reset 在 step=8/16/20 恢复真实拓扑、转移当前物理坐标，未恢复晶体位姿。',
        '', '| 模式 | 完整连接正确 | 分子构造正确 | 末端连接 F1 | 位姿诊断 RMSD 中位数 Å | 初始候选错误 | 图修订 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for mode,m in four.items():text.append(f"| {mode} | {m['final_topology_correct']}/{m['runs']} | {m['final_constitution_correct']}/{m['runs']} | {percent(m['final_connection_f1'])} | {m['slot_atom_rmsd_median_A']:.3f} | {m['initial_wrong_topology']}/{m['runs']} | {m['revisions']} |")
    lr=legacy['rows'];text+=['',f"旧低噪声路由的配对 closed 对照：完整连接 {sum(r['final']['current_topology_exact'] for r in lr)}/{len(lr)}，末端 F1={percent(f1([r['final'] for r in lr]))}。路由、宽候选、树约束与参数适配属于不同改动，后面的搜索比较对 baseline/adapted 使用完全相同的宽候选和树约束。",
        '', '这里的逐步 RMSD 是按给定片段/局部原子顺序，与晶体坐标直接比较的受体坐标系诊断值，不作整体对齐；对不同拓扑也能比较同一批原子的位移，但不能称作化学结构一致的对接成功 RMSD。Oracle/重置恢复的是完整真实化学图，含二维立体化学条件；其与普通生成的差异不能全部归因于单一边数量。Oracle/重置均为诊断结果，禁止计入生成成绩。',
        '', f'![轨迹分布差异]({prefix}/trajectory_domain_gap.png)',
        '', '每一步另记录候选覆盖率、按槽位对的端口/键级 Top-1/4/8/16/64 覆盖、完整合法提案率、当前连接正确率、模板刚性拟合误差、真实连接端点距离及几何异常。初始错误候选与后续错误修订分开记录。所有逐样本数值见 `all_diagnostic_steps.json` 和 `first_topology_errors.csv`。',
        '', '## 非 CASF 轨迹适配','',
        '使用 96 个训练分子×Oracle/错误闭环两模式，共 192 条轨迹、4,800 帧；另外 24 个训练分子用于独立校准，共 48 条轨迹、1,200 帧。按固定哈希在 2–4/5–8/9–12 槽位分层取样。训练/校准 ID 不重叠，二者与全部 CASF ID 的交集为 0。给定口袋沿用原数据库的已知结合位点定义。',
        '', '特征只读取给定片段模板、当前 T/R 和 t；监督连接标签单独生成。每个帧只枚举模板允许的端口，不插入真端口。宽候选为 Top-64/32 Å；保留原 VP/IGSO3 forward-marginal 训练分布并进行教师约束。',
        '', '更新整个时间条件连接头的 30 轮适配没有超过原头，同时出现 clean 退化，选模回退到 epoch=0。保守试验冻结身份 embedding 和特征网络，仅更新 bond/stereo 输出层，训练 50 轮；用非 CASF 校准集选择第 '+str(status['best_epoch'])+' 轮。',
        '', f"保守适配的校准时间分箱平均 F1：{percent(histories['adaptation_conservative'][0]['selection_score'])} → {percent(status['best_score'])}。这是小幅、离线轨迹校准收益，不代表闭环生成提升。baseline 的阈值也在相同非 CASF 校准集重新选择，避免把单纯阈值校准算成权重学习收益。",
        '', f'![适配 loss]({prefix}/adaptation_loss.png)',
        '', '## 独立 CASF 加噪回归','',
        '全部可用 271 个 CASF 分子，seed=901/902/903；未用于本轮选模。该表只比较适配前后同一时间条件结构的 full-noise 分支，候选均为原 adaptive 策略，用于检查既有能力；真实搜索则统一用 wide 策略。',
        '', '| t | baseline F1 | adapted F1 | baseline 多片段全连接正确 | adapted 多片段全连接正确 |',
        '| --- | ---: | ---: | ---: | ---: |']
    for t in forward_old:
        b,n=forward_old[t],forward_new[t]
        text.append(f"| {t} | {percent(b['f1'])} | {percent(n['f1'])} | {percent(b['multi_fragment']['full_ports_exact'])} | {percent(n['multi_fragment']['full_ports_exact'])} |")
    text+=['', '额外固定原阈值的配对回归揭示：在错误轨迹上重校准阈值会影响既有低噪声能力。以下使用完全相同 seed=901/902/903，参数不再更新，阈值固定为上一轮原头的设置；该对照只作回归，不用于重新选模或调整本轮 Top-K 结果。',
        '', '| t | 原权重＋原阈值 F1 | 适配权重＋原阈值 F1 |',
        '| --- | ---: | ---: |']
    for t in ['0.0','0.02','0.05','0.2','0.9']:
        text.append(f"| {t} | {percent(fixed_old[t]['f1'])} | {percent(fixed_new[t]['f1'])} |")
    text+=['', f"例如 t=0.05 保留原阈值时，baseline 为 {percent(fixed_old['0.05']['f1'])}，轨迹校准阈值时为 {percent(forward_old['0.05']['f1'])}。因此不建议直接用错误轨迹的最优分类阈值替换已有低噪声阈值。原阈值下参数适配本身仅有小幅改善，仍不足以解决闭环拓扑错误。"]
    text+=['', '## 独立 CASF Top-K 合法拓扑搜索','',
        '同一 12 个受体，独立初始 seed=801/802/803；每个模型、每个 K 均为 36 次。先用高噪声预测分数作有容量约束的树偏离搜索，最多考察 64 个端口图，再按分子构造去重，取前 8 个。K=1/4/8 使用嵌套前缀；不足 K 个不同构造时不复制候选。搜索是有界近似，不是穷尽精确 k-best。',
        '', '各候选独立运行同一冻结原主干，并在低噪声应用本模型的合法连接提案。最终选择只用预测连接 log-odds、生成结构的键长误差和配体/口袋碰撞；不使用真拓扑、目标位姿、RMSD 或 Vina。真实拓扑仅用于报告候选池覆盖上界。',
        '', '| 模型 | K | 完整连接正确 | 分子构造正确 | 选中结构合法 | 池中含正确构造 | 几何异常 | 平均实际分支 | 平均 NFE | 中位耗时 s |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for model,mm in topk.items():
        for k,m in mm.items():
            n=m['runs'];text.append(f"| {model} | {k} | {m['full_connections_correct']}/{n} | {m['constitution_correct']}/{n} | {m['chemical_valid']}/{n} | {m['constitution_pool_has_truth']}/{n} | {m['geometry_abnormal']}/{n} | {m['mean_attempted_branches']:.2f} | {m['mean_backbone_evaluations']:.1f} | {m['median_seconds']:.2f} |")
    text+=['', '几何异常定义：任一片段间键偏离共价半径目标长度超过 0.5 Å，或存在 <1.2 Å 的配体非键合碰撞；失败也计异常。口袋碰撞另列在 JSON/CSV。合法图率仅代表化学连接可组装，不代表正确拓扑或合理位姿。耗时受原始 RDKit 参考构象生成和图缓存影响；NFE 记录已完成分支的主干调用，失败耗时保留。所有 K 均计入同一次完整候选枚举成本。',
        '', f'![Top-K 结果]({prefix}/topk_comparison.png)',
        '', f'![拓扑与位姿偏移]({prefix}/topology_pose_shift.png)',
        '', '位姿偏移按同一片段槽位的质心在不同候选间直接比较，不整体对齐。相同随机 seed 在不同参考化学图下仍可能产生初始物理坐标差，因此初始与最终偏移均单列，不能把全部最终差异归因于后续动力学。',
        '', '## 回归、产物与限制','',
        '- 两例完整官方 sampler 回归最终最大坐标差均为 0 Å，Oracle/shadow 的逐步坐标差均为 0 Å。确定性计算设置与此前官方回归一致；首次未启用确定性设置的开发运行已排除。',
        '- 官方主干源码和 EMA 权重、迭代身份头保持原指纹；保守适配只修改独立连接头输出层。所有真实图修订重新构建官方图，并检查当前几何更新及物理位姿转移。',
        '- 四模式旧闭环原始诊断在加入树约束前完成；其源码快照为 diagnostic_trajectory_source.py / diagnostic_runner_source.py。轨迹采集保留该版本的错误轨迹，并补采树约束版本的剩余样本。每条采集记录与输入文件指纹均保存，未混入 CASF。',
        '- 发现 3oxc 在低噪声提出额外闭环，原始构象生成耗时数分钟。加入切分规范的树约束后，同一 seed 的完整采样约 6 秒，另记录首次循环提案位置。该过滤只用预测边和 N，不读取真边。',
        '- 这是 96 分子轨迹适配和 12 受体搜索的受控试验。完整身份、N 和口袋仍给定；未进行身份更新、主干训练或全联合训练。',
        '', f'[逐步分布数据]({prefix}/all_diagnostic_steps.json) · [首次错误 CSV]({prefix}/first_topology_errors.csv) · [搜索指标 CSV]({prefix}/topk_metrics.csv) · [保守适配头]({prefix}/adaptation_conservative/best.pt) · [复现说明](CONNECTION_TRAJECTORY.md)', '']
    # Outcome-driven conclusion, generated from held-out results without tuning them.
    b=topk['baseline']['1'];best_k=max(topk['adapted'],key=lambda k:topk['adapted'][k]['constitution_correct'])
    n=topk['adapted'][best_k]
    text[4:4]=[f"独立 CASF 搜索中，K=1 的分子构造正确为 {b['constitution_correct']}/36，K=4 为 {topk['baseline']['4']['constitution_correct']}/36；baseline 和 adapted 的 K=4 结果相同。本轮提升主要来自多拓扑搜索，参数适配没有改善这一闭环指标；K=8 没有优于 K=4。",'']
    recommendation=['','## 后续采用与优先级','',
        '保留原时间条件连接头和原阈值作为基准，使用本轮修复的新头路由和片段树约束。保守适配权重与轨迹校准阈值保留为对照，暂不替换主模型；本试验中增加训练轮数没有形成稳定闭环收益。',
        f"在该受控样本上 K=4 的成本与质量较合适：构造正确 {topk['baseline']['4']['constitution_correct']}/36，中位耗时 {topk['baseline']['4']['median_seconds']:.2f}s；K=8 为 {topk['baseline']['8']['constitution_correct']}/36、{topk['baseline']['8']['median_seconds']:.2f}s。K=8 候选池实际含正确构造 {topk['baseline']['8']['constitution_pool_has_truth']}/36，选中仅 {topk['baseline']['8']['constitution_correct']}/36，提示候选覆盖和无真值排序均需继续改善。",
        '下一步优先扩大不同连接骨架的候选覆盖，并在非 CASF 的多候选轨迹上学习排序/置信度；训练信号应奖励最终几何与口袋相容性，保持独立 CASF 检验。继续冻结官方主干和身份模型。该决定来自本次小样本比较，尚不能作为整体盲生成性能结论。','']
    text+=recommendation
    (bootstrap.PROJECT/'CONNECTION_TRAJECTORY_RESULTS.md').write_text('\n'.join(text))
    old=json.loads((bootstrap.PROJECT/'PREDICTION_MANIFEST.json').read_text())
    changed=[n for n,h in old['official_source_sha256'].items() if digest(bootstrap.OFFICIAL/n)!=h]
    if changed or digest(bootstrap.CHECKPOINT)!=old['official_checkpoint_sha256']:raise RuntimeError('Frozen official backbone changed')
    identity=bootstrap.PROJECT/'results/prediction_diagnostics/identity_controls/iterative/best.pt'
    if digest(identity)!=old['checkpoints']['iterative']:raise RuntimeError('Identity model changed')
    tests=(root/'tests.log').read_text();test_result=next(x for x in tests.splitlines() if x.startswith('Ran '))
    audit_files=list(root.glob('diagnostic_*/*/audit.json'))+list(root.glob('search_*/*/audit.json'))+list(root.glob('collect_*/*/audit.json'))
    audits=[json.loads(path.read_text()) for path in audit_files]
    if not all(x['all_dynamic_recomputations_equal'] for x in audits):raise RuntimeError('Dynamic geometry audit failed')
    base=torch.load(root/'adaptation_conservative/baseline_calibrated.pt',map_location='cpu',weights_only=False)
    adapted=torch.load(root/'adaptation_conservative/best.pt',map_location='cpu',weights_only=False)
    parameter_changes=[k for k,v in base['model'].items() if not torch.equal(v,adapted['model'][k])]
    if any(not k.startswith(('bond.','stereo.')) for k in parameter_changes):raise RuntimeError('Conservative adaptation changed frozen features')
    manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),prompt_sha256=digest(bootstrap.WORKSPACE/'prompt.md'),
        official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),official_source_changed=changed,official_source_files_checked=len(old['official_source_sha256']),
        identity_sha256=digest(identity),baseline_connection_sha256=digest(root/'adaptation_conservative/baseline_calibrated.pt'),
        adapted_connection_sha256=digest(root/'adaptation_conservative/best.pt'),adapted_parameters_changed=parameter_changes,
        original_threshold_regression={n:digest(root/n/'report.json') for n in ['forward_original_policy','forward_adapted_original_policy']},
        oracle_regression=regression,oracle_shadow_max_difference_A=max(r.get('oracle_shadow_max_coordinate_difference_A',0.) for r in rows),
        audited_trajectories=len(audits),audited_backbone_forwards=sum(len(x['forwards']) for x in audits),
        tests=test_result,test_success='\nOK\n' in tests,identity_updated=False,backbone_trained=False,
        diagnostic_seed=[601,602,603],training_seed=701,calibration_seed=702,search_seeds=[801,802,803],forward_test_seeds=[901,902,903],
        scripts={n:digest(bootstrap.PROJECT/n) for n in ['trajectory_connections.py','run_connection_trajectories.py','prepare_trajectory_inputs.py','adapt_connection_trajectories.py','evaluate_topology_search.py','summarize_connection_trajectories.py']},
        reports={str(path.relative_to(root)):digest(path) for path in [root/'four_mode_summary.json',root/'topk_summary.json',root/'topk_metrics.csv',root/'adaptation_conservative/protocol.json']})
    write_json(bootstrap.PROJECT/'CONNECTION_TRAJECTORY_MANIFEST.json',manifest)
    staged=bootstrap.PROJECT/'STAGED_RESULTS.md';marker='\n## 2026-11-01：真实轨迹与拓扑搜索专项'
    previous=staged.read_text().split(marker)[0]
    staged.write_text(previous+marker+'\n\n已完成四模式诊断、非 CASF 轨迹适配、独立 CASF Top-K 搜索和官方回归。详细指标、计算成本与限制见 [新专项报告](CONNECTION_TRAJECTORY_RESULTS.md)，复现见 [CONNECTION_TRAJECTORY.md](CONNECTION_TRAJECTORY.md)。\n')
    print(json.dumps(dict(four_modes=four,topk=topk,tests=test_result,parameter_changes=parameter_changes),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
