#!/usr/bin/env python3
"""Oracle identity baseline versus predicted identities with true slot topology."""
import argparse
import json
import os
import traceback
from pathlib import Path

import bootstrap
import numpy as np
import torch

from oracle_graph import rebuild
from pipeline_utils import molecule_metrics, remap_oracle_adjacency
from run_validation import docking, load_official, write_json
from serialization import save_graph
from validation import digest
from vocab_chemistry import (VocabLibrary, assemble_slots, atom_correspondence, embedded_reference,
                            explicit_oov, oracle_chiral, oracle_cip, spec_from_slots, true_connections)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--predictions', type=Path, default=bootstrap.PROJECT/'results/stage2_identity_predictions.json')
    p.add_argument('--baseline', type=Path, default=bootstrap.PROJECT/'results/acceptance')
    p.add_argument('--output', type=Path, default=bootstrap.PROJECT/'results/stage2')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--seeds', default='0,1,2')
    p.add_argument('--steps', type=int, default=25)
    a = p.parse_args()
    a.output = a.output.resolve(); a.output.mkdir(parents=True, exist_ok=True)
    if (a.output/'report.json').exists(): p.error('Output exists')
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    torch.set_num_threads(2); torch.use_deterministic_algorithms(True)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32=False; torch.backends.cudnn.allow_tf32=False
    device = torch.device(a.device)
    if device.type == 'cuda': torch.cuda.set_device(device)
    lib=VocabLibrary(); den=load_official(bootstrap.CHECKPOINT,a.output,device)
    predictions=json.loads(a.predictions.read_text())
    result=dict(stage=2, prediction_sha256=digest(a.predictions), identity_summary=predictions['summary'],
                protocol='True slot count, positions/orientations and slot adjacency/order; predicted identities '
                         'are converted to chemical templates. Changed types use geometry/capacity port remapping. '
                         'Docking starts independently from reference noise, not the oracle pose.',rows=[],failures=[])
    seeds=list(map(int,a.seeds.split(',')))
    for prediction in predictions['rows']:
        pid=prediction['id']; out=a.output/pid; out.mkdir(exist_ok=True)
        record=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
        original_graph=torch.load(a.baseline/pid/'official_graph.pt',weights_only=False)
        target=original_graph.mol_info['original']
        context=torch.load(a.baseline/pid/'pocket_context.pt',weights_only=False)
        old_labels=record['labels'].tolist();oov=explicit_oov(record);relations=true_connections(record)
        mapping=atom_correspondence(record,target)
        row=dict(id=pid,known_slots=prediction['known_slots'],correct_types=prediction['correct'],results={})
        for mode,labels in [('true_identity',old_labels),('predicted_identity',prediction['predicted_labels'])]:
            try:
                if mode=='true_identity':
                    connections=relations
                    mol,groups,cuts=assemble_slots(lib,labels,connections,oov=oov,
                        cip=oracle_cip(record,target,mapping),chiral=oracle_chiral(record,target,mapping))
                else:
                    connections,(mol,groups,cuts),_=remap_oracle_adjacency(lib,old_labels,labels,relations,
                        record['T0'].numpy(),record['R0'].numpy(),oov=oov)
                reference=embedded_reference(mol,seed=0)
                spec=spec_from_slots(reference,groups,cuts,labels,'independent template chemistry; no target pose')
                write_json(out/f'{mode}.json',spec)
                graph=rebuild(spec,**context);save_graph(graph,out/f'{mode}_graph.pt')
                stats=dict(status='complete_legal',connections=connections,chemistry=molecule_metrics(mol,target),docking=[])
                for seed in seeds:
                    pred,_,d=docking(den,graph,seed=seed,steps=a.steps,device=device,noise_scale=0.,save=out/f'{mode}_seed{seed}.pt')
                    d['quality']=molecule_metrics(mol,target,pred.numpy())
                    if mode=='true_identity':
                        xyz=np.asarray(target.GetConformer().GetPositions())[mapping]
                        d['fixed_correspondence_rmsd_A']=float(np.sqrt(np.mean(np.sum((pred.numpy()-xyz)**2,axis=-1))))
                    stats['docking'].append(dict(seed=seed,**d))
                row['results'][mode]=stats
                print(pid,mode,stats['status'],'chemical exact',stats['chemistry']['stereo_chemical_exact'],flush=True)
            except Exception as exc:
                row['results'][mode]=dict(status='rejected_before_backbone',reason=repr(exc))
                if mode=='true_identity': result['failures'].append(dict(id=pid,error=repr(exc),traceback=traceback.format_exc()))
                print(pid,mode,'REJECTED',repr(exc),flush=True)
        result['rows'].append(row);write_json(a.output/'report.json',result)
    predicted=[r['results']['predicted_identity'] for r in result['rows']]
    result['summary']=dict(samples=len(predicted),legal_predicted_molecules=sum(r['status']=='complete_legal' for r in predicted),
        predicted_chemical_exact=sum(r.get('chemistry',{}).get('stereo_chemical_exact',False) for r in predicted),
        note='Rejected samples remain in the denominator; differing atom counts/types are never compared by raw atom index')
    write_json(a.output/'report.json',result)
    return 0 if not result['failures'] else 1


if __name__=='__main__': raise SystemExit(main())
