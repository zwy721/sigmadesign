#!/usr/bin/env python3
"""Non-CASF reranker cohorts and previously unused CASF receptor holdout."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

import bootstrap
import torch
from prepare_trajectory_inputs import prepare_one,SOURCE
from run_validation import write_json
from validation import digest
from vocab_chemistry import VocabLibrary

ROOT=bootstrap.PROJECT/'results/connection_reranker_20261101'
PREVIOUS=bootstrap.PROJECT/'results/connection_trajectory_20261101'


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    a=p.parse_args();a.root.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    old=json.loads((PREVIOUS/'cohorts.json').read_text())
    train=sum([old['train'][i:i+16] for i in (0,32,64)],[])
    calibration=sum([old['calibration'][i:i+4] for i in (0,8,16)],[])
    val=torch.load(bootstrap.PROJECT/'results/connection_robust_20261101/cache/val.pt',weights_only=False)['rows']
    buckets=[[],[],[]]
    for row in val:
        n=len(row['chem']['labels']);pid=row['id']
        if pid in old['casf_diagnostic'] or not 2<=n<=12:continue
        buckets[0 if n<=4 else 1 if n<=8 else 2].append(pid)
    for b in buckets:b.sort(key=lambda x:hashlib.sha256(('reranker-holdout-v1:'+x).encode()).hexdigest())
    holdout=sum([b[:4] for b in buckets],[])
    assert len(holdout)==12 and not set(train)&set(calibration) and not (set(train)|set(calibration))&set(holdout)
    assert not set(holdout)&set(old['casf_diagnostic'])
    cohorts=dict(train=train,calibration=calibration,casf_holdout=holdout,historical_casf=old['casf_diagnostic'],
        train_seed=1701,calibration_seed=1702,test_seeds=[1801,1802,1803],
        selection='Fixed hash/stratified slots 2-4,5-8,9-12; CASF receptors exclude all 12 historical diagnostic receptors',
        truth_candidate_enrichment='TRAIN ONLY; never added to calibration or CASF search pools')
    write_json(a.root/'cohorts.json',cohorts)
    for pid in train+calibration:
        folder=a.root/'inputs'/pid;folder.mkdir(parents=True,exist_ok=True)
        source=PREVIOUS/f'inputs/{pid}/fixture.pt'
        fixture=torch.load(source,weights_only=False)
        if fixture['audit']['casf'] or fixture['audit']['split']!='train':raise ValueError('Non-CASF split violation')
        shutil.copyfile(source,folder/'fixture.pt')
    sources={r['pdb_id']:r for r in map(json.loads,SOURCE.open())};lib=VocabLibrary();failures=[]
    for pid in holdout:
        try:prepare_one(pid,a.root,sources,lib);print('PREPARE_HOLDOUT',pid,flush=True)
        except Exception as exc:
            import traceback
            failures.append(dict(id=pid,error=repr(exc),traceback=traceback.format_exc()))
    write_json(a.root/'preparation.json',dict(cohorts=cohorts,failures=failures,source_manifest_sha256=digest(SOURCE)))
    if failures:raise RuntimeError('Holdout preparation failures; see preparation.json')


if __name__=='__main__':main()
