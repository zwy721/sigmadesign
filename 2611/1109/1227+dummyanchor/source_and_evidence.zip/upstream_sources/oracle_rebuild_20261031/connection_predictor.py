"""Independent learned port/bond predictor; never edits pretrained atom features."""
import hashlib
import math
from pathlib import Path

import bootstrap
import numpy as np
import torch
from rdkit import Chem
from scipy.spatial.transform import Rotation
from torch import nn

from vocab_chemistry import ChemistryRejected, VocabLibrary, explicit_oov, true_connections


def slot_templates(library, labels, oov=None):
    return [library.template(int(t), (oov or [None] * len(labels))[i]) for i, t in enumerate(labels)]


def candidates(library, labels, T, R, *, oov=None, topk=8, cutoff=16.):
    """Only supplied identities/poses enter features; targets are a separate call."""
    labels = list(map(int, labels))
    T, R = np.asarray(T), np.asarray(R)
    states = []
    periodic = Chem.GetPeriodicTable()
    for i, (mol, xyz) in enumerate(slot_templates(library, labels, oov)):
        sites = library.sites(labels[i], (oov or [None] * len(labels))[i])
        positions = xyz @ R[i].T + T[i]
        values = []
        for site in sites:
            a = int(site['anchor_core'])
            atom = mol.GetAtomWithIdx(a)
            ns = [n.GetIdx() for n in atom.GetNeighbors()]
            dirs = xyz[a] - xyz[ns] if ns else np.zeros((1, 3))
            outward = (dirs / np.linalg.norm(dirs, axis=-1, keepdims=True).clip(1e-8)).sum(0)
            outward = outward / max(1e-8, np.linalg.norm(outward)) @ R[i].T
            features = np.array([atom.GetAtomicNum() / 54, atom.GetFormalCharge() / 3,
                                 site['capacity_bond_order_units'] / 4, atom.GetIsAromatic(),
                                 atom.IsInRing(), atom.GetDegree() / 4, mol.GetNumAtoms() / 44], dtype=np.float32)
            values.append((a, positions[a], outward, features, periodic.GetRcovalent(atom.GetAtomicNum())))
        states.append(values)
    ids, numeric, meta = [], [], []
    for i in range(len(labels)):
        for j in range(i + 1, len(labels)):
            if np.linalg.norm(T[i] - T[j]) > cutoff or not states[i] or not states[j]:
                continue
            hypotheses = []
            for a in states[i]:
                for b in states[j]:
                    delta = b[1] - a[1]
                    distance = float(np.linalg.norm(delta))
                    unit = delta / max(distance, 1e-8)
                    cos = [float(a[2] @ unit), float(b[2] @ -unit), float(a[2] @ -b[2])]
                    rbf = np.exp(-((distance - np.linspace(0, 8, 16)) / .75) ** 2)
                    radius = a[4] + b[4]
                    x = np.concatenate((a[3] + b[3], np.abs(a[3] - b[3]), rbf, cos,
                                        [distance - radius, distance - radius * .9]))
                    score = abs(distance - radius) - .1 * sum(cos[:2])
                    hypotheses.append((score, a[0], b[0], x))
            for _, a, b, x in sorted(hypotheses, key=lambda h: h[:3])[:topk]:
                ids.append([max(labels[i], 3684 if labels[i] < 0 else 0),
                            max(labels[j], 3684 if labels[j] < 0 else 0)])
                numeric.append(x)
                meta.append([i, j, a, b])
    return dict(types=torch.tensor(ids, dtype=torch.int16).reshape(-1, 2),
                x=torch.tensor(np.asarray(numeric, dtype=np.float32).reshape(-1, 35)),
                candidates=torch.tensor(meta, dtype=torch.int16).reshape(-1, 4))


def targets(features, record):
    y = torch.zeros(len(features['x']), dtype=torch.int8)
    stereo = torch.zeros_like(y)
    for k, (i, j, a, b) in enumerate(features['candidates'].tolist()):
        if int(record['edges'][i, j]) > 0 and record['anchors'][i, j].tolist() == [a, b]:
            y[k] = record['edges'][i, j]
            stereo[k] = max(0, int(record['stereo'][i, j]))
    return dict(y=y, stereo=stereo, true_bonds=len(true_connections(record)))


class PortConnectionPredictor(nn.Module):
    def __init__(self):
        super().__init__()
        self.identity = nn.Embedding(3685, 32)
        self.network = nn.Sequential(nn.Linear(99, 128), nn.SiLU(), nn.Linear(128, 64), nn.SiLU())
        self.bond = nn.Linear(64, 3)
        self.stereo = nn.Linear(64, 3)

    def forward(self, types, x):
        a, b = self.identity(types.long()).unbind(1)
        z = self.network(torch.cat((a + b, (a - b).abs(), x.float()), dim=-1))
        return self.bond(z), self.stereo(z)


def proposals(model, features, device, threshold=.65):
    if not len(features['x']): return [], []
    with torch.inference_mode():
        bond, stereo = model(features['types'].to(device), features['x'].to(device))
        p = bond.softmax(-1).cpu()
        sp = stereo.softmax(-1).cpu()
    accepted, all_candidates = [], []
    for k, (i, j, a, b) in enumerate(features['candidates'].tolist()):
        probability, order = p[k, 1:].max(0)
        order = int(order) + 1
        c = dict(i=i, j=j, a=a, b=b, order=order, stereo=int(sp[k].argmax()) if order == 2 else 0,
                 confidence=float(probability), log_odds=float(torch.log(probability.clamp_min(1e-8))
                                                             - torch.log(p[k, 0].clamp_min(1e-8))))
        all_candidates.append(c)
        # An uncertain candidate graph must retain alternative legal bond orders.
        # The most likely order can be unavailable at a particular attachment port.
        alternative=3-order
        alt_probability=p[k,alternative]
        all_candidates.append(dict(c,order=alternative,stereo=int(sp[k].argmax()) if alternative==2 else 0,
                                   confidence=float(alt_probability),
                                   log_odds=float(torch.log(alt_probability.clamp_min(1e-8))-torch.log(p[k,0].clamp_min(1e-8)))))
        if probability >= threshold and probability > p[k, 0]: accepted.append(c)
    return accepted, all_candidates


def legal_decode(library, labels, proposed, *, oov=None):
    """No truth completion or forced MST: disconnected proposals remain candidates."""
    used, slot_pairs, result = {}, set(), []
    for c in sorted(proposed, key=lambda x: (-x['log_odds'], x['i'], x['j'], x['a'], x['b'])):
        i, j = c['i'], c['j']
        if (i, j) in slot_pairs: continue
        okay = True
        for slot, atom in ((i, c['a']), (j, c['b'])):
            sites = {s['anchor_core']: s for s in library.sites(int(labels[slot]), (oov or [None] * len(labels))[slot])}
            if atom not in sites or c['order'] not in sites[atom]['carbon_stub_sanitize_validated_orders']:
                okay = False; break
            if used.get((slot, atom), 0) + c['order'] > sites[atom]['capacity_bond_order_units']:
                okay = False; break
        if okay:
            result.append(c)
            slot_pairs.add((i, j))
            for key in ((i, c['a']), (j, c['b'])): used[key] = used.get(key, 0) + c['order']
    from vocab_chemistry import assemble_slots
    try:
        mol, groups, cuts = assemble_slots(library, labels, result, oov=oov)
        return dict(status='complete_legal', connections=result), (mol, groups, cuts)
    except ChemistryRejected as exc:
        return dict(status='candidates_only', connections=result, reason=str(exc)), None
