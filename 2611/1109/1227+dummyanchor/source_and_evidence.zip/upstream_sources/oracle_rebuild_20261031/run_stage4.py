#!/usr/bin/env python3
"""Controlled Oracle removal and alternating legal chemical graph sampling."""
import argparse
import json
import os
import traceback
from pathlib import Path

import bootstrap
import numpy as np
import torch
from rdkit import Chem

from connection_predictor import PortConnectionPredictor
from joint_sampler import IdentityClient,sample_joint
from oracle_graph import assemble,rebuild
from pipeline_utils import molecule_metrics,pose_geometry
from run_validation import docking,load_official,write_json
from validation import digest
from vocab_chemistry import VocabLibrary,atom_correspondence,oracle_chiral,oracle_cip


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=bootstrap.PROJECT/'results/stage4')
    p.add_argument('--baseline',type=Path,default=bootstrap.PROJECT/'results/acceptance')
    p.add_argument('--connection-checkpoint',type=Path,default=bootstrap.PROJECT/'results/stage3_training/best.pt')
    p.add_argument('--ids',default='1a30,3b1m')
    p.add_argument('--profiles',default='oracle,learned_connections,learned_identity,joint')
    p.add_argument('--seeds',default='0')
    p.add_argument('--steps',type=int,default=25)
    p.add_argument('--stride',type=int,default=5)
    p.add_argument('--identity-threshold',type=float,default=.3)
    p.add_argument('--slots',type=int)
    p.add_argument('--device',default='cuda:4')
    p.add_argument('--identity-device',default='cuda:3')
    a=p.parse_args();a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True)
    if (a.output/'report.json').exists():p.error('Choose a new output folder')
    if a.steps<2 or a.stride<1:p.error('Invalid sampling schedule')
    if a.slots and a.profiles!='joint':p.error('Custom slot count is supported by the joint profile')
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True);torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    library=VocabLibrary();den=load_official(bootstrap.CHECKPOINT,a.output,device)
    saved=torch.load(a.connection_checkpoint,weights_only=False,map_location='cpu')
    predictor=PortConnectionPredictor().to(device).eval();predictor.load_state_dict(saved['model'],strict=True)
    needs_identity=any(x in ('joint','learned_identity') for x in a.profiles.split(','))
    client=IdentityClient(a.output/'identity_server.log',a.identity_device) if needs_identity else None
    report=dict(stage=4,rows=[],failures=[],connection_checkpoint_sha256=digest(a.connection_checkpoint),
        source_sha256={name:digest(bootstrap.PROJECT/name) for name in
                      ('joint_sampler.py','identity_server.py','connection_predictor.py','vocab_chemistry.py','pipeline_utils.py')},
        protocol='Separate identity and connection predictors alternate with original pretrained SE3 force/mechanics/reverse updates. '
                 'Graph changes regenerate chemistry, reference geometry, masks, virtual structures, inertia and current edges. '
                 'Invalid changes retain the last legal graph. Low-confidence bootstrap graphs are labeled candidate hypotheses.',
        oracle_profiles=dict(oracle=['identity','connections','predictor_centers'],learned_connections=['identity','predictor_centers'],
                             learned_identity=['connections','predictor_centers'],joint=['slot_count unless --slots is supplied']),
        note='A runnable staged prototype; identity uncertainty and molecule quality are evaluated, not assumed correct.')
    try:
        for pid in a.ids.split(','):
            record=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
            context=torch.load(a.baseline/pid/'pocket_context.pt',weights_only=False)
            target=torch.load(a.baseline/pid/'official_graph.pt',weights_only=False).mol_info['original']
            mapping=atom_correspondence(record,target)
            stereo=dict(cip=oracle_cip(record,target,mapping),chiral=oracle_chiral(record,target,mapping))
            for profile in a.profiles.split(','):
                for seed in map(int,a.seeds.split(',')):
                    out=a.output/f'{pid}_{profile}_seed{seed}';out.mkdir(exist_ok=True)
                    try:
                        result=sample_joint(den,library,predictor,client,pid=pid,record=record,context=context,profile=profile,
                            device=device,steps=a.steps,seed=seed,stride=a.stride,identity_threshold=a.identity_threshold,
                            slots=a.slots,oracle_chemical_stereo=stereo)
                        mol=assemble(result['spec']);xyz=result.pop('xyz');initial=result.pop('initial_xyz')
                        row=dict(result,id=pid,status='sampled',
                                 quality=molecule_metrics(mol,target,xyz))
                        row['geometry_quality']=pose_geometry(mol,xyz,row['spec']['connections'],context['pocket'])
                        write_json(out/'final_chemistry.json',row['spec'])
                        torch.save(dict(heavy_xyz_A=torch.tensor(xyz),initial_xyz_A=torch.tensor(initial)),out/'coordinates.pt')
                        predicted=Chem.Mol(mol)
                        for k,point in enumerate(xyz):predicted.GetConformer().SetAtomPosition(k,point.tolist())
                        with Chem.SDWriter(str(out/'molecule.sdf')) as writer:writer.write(predicted)
                        if profile=='oracle':
                            # Essential regression: unchanged graph must reproduce the original sampler.
                            graph=rebuild(result['spec'],**context)
                            official,_,_=docking(den,graph,seed=seed,steps=a.steps,device=device,noise_scale=0.,save=out/'official_control.pt')
                            delta=float(np.max(np.abs(official.numpy()-xyz)))
                            row['official_sampler_max_difference_A']=delta
                            if delta>1e-4:raise AssertionError(f'Native step adapter changed official trajectory: {delta} A')
                        report['rows'].append(row)
                        print(pid,profile,seed,'revisions',row['revisions'],'atoms',len(xyz),
                              'Tanimoto',row['quality']['tanimoto'],flush=True)
                    except Exception as exc:
                        report['failures'].append(dict(id=pid,profile=profile,seed=seed,status='rejected_or_failed',
                                                      reason=repr(exc),traceback=traceback.format_exc()))
                        print('FAILED',pid,profile,repr(exc),traceback.format_exc(),flush=True)
                    write_json(a.output/'report.json',report)
    finally:
        if client:client.close()
    oracle_rows=[r for r in report['rows'] if r['profile']=='oracle']
    report['summary']=dict(sampled=len(report['rows']),rejected_or_failed=len(report['failures']),
                          total_graph_revisions=sum(r['revisions'] for r in report['rows']),
                          oracle_sampler_regression_passed=(bool(oracle_rows) and all(r['official_sampler_max_difference_A']<=1e-4 for r in oracle_rows)) if 'oracle' in a.profiles.split(',') else None)
    write_json(a.output/'report.json',report);print('SUMMARY',report['summary'],flush=True)


if __name__=='__main__':main()
