"""Assertions on the actual tensors presented to SigmaDock, not graph counts."""
import hashlib
from collections import Counter
from pathlib import Path

import bootstrap  # noqa: F401
import numpy as np
import torch
from rdkit import Chem
from scipy.optimize import linear_sum_assignment

from sigmadock.chem.fragmentation import get_fragment_map
from sigmadock.oracle import HPARAMS


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def compare_values(a, b, path='', atol=0.):
    rows = []
    if torch.is_tensor(a) and torch.is_tensor(b):
        same_shape = a.shape == b.shape
        exact = same_shape and a.dtype == b.dtype and torch.equal(a.cpu(), b.cpu())
        delta = None
        if same_shape and a.numel():
            delta = float((a.detach().cpu().double() - b.detach().cpu().double()).abs().max())
        passed = exact or (same_shape and a.dtype == b.dtype and delta is not None and delta <= atol)
        rows.append(dict(field=path, equal=bool(passed), exact=bool(exact),
                         shape=list(a.shape), other_shape=list(b.shape), max_abs=delta))
    elif isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b):
            rows.append(dict(field=path + '.keys', equal=False, exact=False))
        for k in sorted(set(a) & set(b), key=str):
            rows.extend(compare_values(a[k], b[k], f'{path}.{k}', atol))
    elif isinstance(a, (tuple, list)) and isinstance(b, (tuple, list)):
        if len(a) != len(b):
            rows.append(dict(field=path + '.length', equal=False, exact=False))
        for k, (av, bv) in enumerate(zip(a, b)):
            rows.extend(compare_values(av, bv, f'{path}[{k}]', atol))
    else:
        passed = a is None and b is None or type(a) is type(b) and a == b
        rows.append(dict(field=path, equal=bool(passed), exact=bool(passed)))
    return rows


GRAPH_FIELDS = ('x', 'ref_pos', 'edge_index', 'edge_attr', 'node_entity', 'edge_entity',
                'mask', 'frag_atom_idx', 'frag_counter', 'frag_idx_map', 'residue_types',
                'protein_embeddings', 'triangulation_indexes', 'overconstrained_anchors',
                'overconstrained_dummies', 'frag_sizes', 'dummy_frag_sizes', 'pocket_com')


def compare_graphs(a, b):
    rows = []
    for key in GRAPH_FIELDS:
        rows.extend(compare_values(a[key], b[key], key))
    rows.extend(compare_values(get_fragment_map(a.mol_info['fragmented']),
                               get_fragment_map(b.mol_info['fragmented']), 'fragmentation_mapping'))
    return dict(equal=all(x['equal'] for x in rows), exact=all(x['exact'] for x in rows), fields=rows)


def inventory(graph):
    return dict(nodes=graph.num_nodes, edges=graph.edge_index.shape[1],
                protein_nodes=int((graph.frag_idx_map == -1).sum()),
                fragments=int(graph.mol_info['num_fragments']),
                node_types=dict(sorted(Counter(graph.node_entity.tolist()).items())),
                edge_types=dict(sorted(Counter(graph.edge_entity.tolist()).items())))


def compare_3684_partition(graph, record_path):
    """Map cached true atoms by crystal xyz+element, then compare atom sets.

    Crystal coordinates are used ONLY here for atom correspondence and metrics.
    No coordinates from this comparison enter the reconstructed graph or sampler.
    """
    record = torch.load(record_path, map_location='cpu', weights_only=False)
    case = record['graph']['case']
    mol = graph.mol_info['original']
    original_heavy = [a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum() > 1]
    original_xyz = mol.GetConformer().GetPositions()[original_heavy]
    original_z = np.array([mol.GetAtomWithIdx(k).GetAtomicNum() for k in original_heavy])
    cached_mol = Chem.MolFromMolBlock(case['native_molblock'], removeHs=False)
    heavy_global = case['heavy_global']
    cached_z = np.array([cached_mol.GetAtomWithIdx(k).GetAtomicNum() for k in heavy_global])
    cached_xyz = np.concatenate([np.asarray(x) for x in record['target_xyz']]) + np.asarray(case['origin'])
    if original_xyz.shape != cached_xyz.shape:
        raise ValueError('3684 cached and official heavy atom counts differ')
    cost = np.linalg.norm(cached_xyz[:, None] - original_xyz[None], axis=2)
    cost[cached_z[:, None] != original_z[None]] = 1e9
    rows, cols = linear_sum_assignment(cost)
    error = float(cost[rows, cols].max())
    if error > 1e-3:
        raise ValueError(f'Cannot establish chemical atom correspondence: {error} A')
    mapping = {int(i): original_heavy[int(j)] for i, j in zip(rows, cols)}
    groups = []
    offset = 0
    for points in record['target_xyz']:
        groups.append(sorted(mapping[k] for k in range(offset, offset + len(points))))
        offset += len(points)
    fragmented = graph.mol_info['fragmented']
    official_groups = [sorted(k for k in group if k in original_heavy) for group in Chem.GetMolFrags(fragmented)]
    a = {frozenset(g) for g in official_groups}
    b = {frozenset(g) for g in groups}
    slots = {atom: i for i, g in enumerate(groups) for atom in g}
    cross = sorted(sorted([bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()]) for bond in mol.GetBonds()
                   if bond.GetBeginAtomIdx() in slots and bond.GetEndAtomIdx() in slots
                   and slots[bond.GetBeginAtomIdx()] != slots[bond.GetEndAtomIdx()])
    declared_connections = []
    for i in range(len(groups)):
        for j in range(i + 1, len(groups)):
            if record['edges'][i, j] <= 0:
                continue
            ai, aj = map(int, record['anchors'][i, j].tolist())
            # Anchor indices are template-local; target_xyz retains that order.
            oi = sum(len(x) for x in record['target_xyz'][:i])
            oj = sum(len(x) for x in record['target_xyz'][:j])
            if not (0 <= ai < len(groups[i]) and 0 <= aj < len(groups[j])):
                raise ValueError('Cached true anchor outside its fragment')
            declared_connections.append(sorted([mapping[oi + ai], mapping[oj + aj]]))
    declared_connections.sort()
    topology_equal = declared_connections == cross
    slot_to_official = [next((i for i, og in enumerate(official_groups) if set(g) == set(og)), None)
                        for g in groups]
    return dict(same_partition=a == b, same_true_connection_topology=topology_equal,
                usable_as_same_graph=a == b and topology_equal,
                atom_matching_max_A=error, official_atom_groups=official_groups,
                vocab3684_atom_groups=groups, vocab3684_labels=record['labels'].tolist(),
                vocab3684_to_official_slot=slot_to_official,
                only_official_groups=[list(sorted(g)) for g in a - b],
                only_vocab3684_groups=[list(sorted(g)) for g in b - a],
                chemical_cross_fragment_bonds=cross, cached_true_connections=declared_connections,
                note='Exact atom partitions, not just fragment counts. Different partitions excluded from 3684 equivalence.')


class SamplingAudit:
    """Observe every original update/forward without changing inputs or outputs."""
    def __init__(self, denoiser):
        self.den = denoiser
        self.updates = []
        self.forwards = []
        self.geometry = []
        self.static_hash = None

    def __enter__(self):
        self.original_update = self.den._update_batch
        self.original_forces = self.den._compute_forces
        self.original_geometry = self.den.model.generate_geometry
        dynamic = HPARAMS.get_edge_group_indices('local_dynamic')

        def update(*args, **kwargs):
            graph = self.original_update(*args, **kwargs)
            # Recompute from current coordinates, never from reference positions.
            expected = self.den._compute_interaction_edges(graph, graph.pos_t)
            types = torch.tensor(dynamic, device=graph.edge_entity.device)
            keep = torch.isin(graph.edge_entity, types)
            static_hash = _tensor_hash(graph.edge_index[:, ~keep], graph.edge_attr[~keep], graph.edge_entity[~keep])
            if self.static_hash is None:
                self.static_hash = static_hash
            elif self.static_hash != static_hash:
                raise AssertionError('Static chemical/virtual/connection graph changed during sampling')
            actual = dict(edge_index=graph.edge_index[:, keep], edge_attr=graph.edge_attr[keep],
                          edge_entity=graph.edge_entity[keep])
            # merge_and_process_edges can reorder/coalesce. Apply the same official merge.
            empty = dict(edge_index=graph.edge_index[:, :0], edge_attr=graph.edge_attr[:0],
                         edge_entity=graph.edge_entity[:0])
            expected = self.den.merge_and_process_edges(empty, expected)
            checks = compare_values(actual, expected, 'dynamic')
            if not all(x['equal'] for x in checks):
                raise AssertionError(f'Stale dynamic graph at update {len(self.updates)}: {checks}')
            if not torch.isfinite(graph.pos_t).all():
                raise AssertionError('Nonfinite coordinates during official sampling')
            self.updates.append(dict(step=len(self.updates), dynamic_edges=int(keep.sum()),
                                     pos_hash=_tensor_hash(graph.pos_t),
                                     edges_hash=_tensor_hash(graph.edge_index, graph.edge_attr, graph.edge_entity)))
            return graph

        def forces(*args, **kwargs):
            graph = kwargs.get('batch', args[0] if args else None)
            before = dict(step=len(self.forwards),
                          input_hash=_tensor_hash(graph.x, graph.pos_t, graph.edge_index, graph.edge_attr,
                                                  graph.node_entity, graph.edge_entity, graph.mask))
            out = self.original_forces(*args, **kwargs)
            if not torch.isfinite(out[0]).all():
                raise AssertionError('Nonfinite pretrained model output')
            before['forces_hash'] = _tensor_hash(*out)
            self.forwards.append(before)
            return out

        def geometry(data, pos_key='pos_t'):
            distances, vectors = self.original_geometry(data, pos_key=pos_key)
            src, dst = data.edge_index
            # Official generate_geometry uses first edge row minus second.
            expected_vec = data.pos_t[src] - data.pos_t[dst]
            if pos_key != 'pos_t' or not torch.equal(vectors, expected_vec):
                raise AssertionError('Official network used stale directions or coordinate frame')
            if not torch.equal(distances, expected_vec.norm(dim=-1)):
                raise AssertionError('Official network used stale edge distances')
            boundary = torch.isin(data.edge_entity, torch.tensor(
                self.den.model.hparams.get_edge_group_indices('boundary'), device=data.x.device))
            bs, bd = src[boundary], dst[boundary]
            relative = ((data.pos_t[bd] - data.pos_t[bs]).norm(dim=-1)
                        - (data.pos_0[bd] - data.pos_0[bs]).norm(dim=-1)).abs()
            self.geometry.append(dict(step=len(self.geometry), edges=len(distances),
                                      distances_hash=_tensor_hash(distances), vectors_hash=_tensor_hash(vectors),
                                      boundary_relative_distances_hash=_tensor_hash(relative)))
            return distances, vectors

        self.den._update_batch = update
        self.den._compute_forces = forces
        self.den.model.generate_geometry = geometry
        return self

    def __exit__(self, *exc):
        # Remove instance overrides, returning ordinary class method resolution.
        del self.den._update_batch
        del self.den._compute_forces
        del self.den.model.generate_geometry

    def report(self):
        return dict(updates=self.updates, forwards=self.forwards, geometry=self.geometry,
                    all_dynamic_recomputations_equal=True, static_graph_unchanged=True)


def _tensor_hash(*tensors):
    h = hashlib.sha256()
    for t in tensors:
        a = t.detach().contiguous().cpu()
        h.update(str((str(a.dtype), tuple(a.shape))).encode())
        h.update(a.numpy().tobytes())
    return h.hexdigest()
