#!/usr/bin/env python3
"""Rebuild a graph using only an Oracle chemistry JSON and receptor context."""
import argparse
import json
from pathlib import Path

import bootstrap
import torch
from oracle_graph import rebuild
from serialization import save_graph


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--oracle', type=Path, required=True)
    parser.add_argument('--context', type=Path, required=True,
                        help='pocket_context.pt: receptor mol/center and provenance paths only')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Output already exists; choose a new filename')
    spec = json.loads(args.oracle.read_text())
    context = torch.load(args.context, map_location='cpu', weights_only=False)
    expected = {'pocket', 'pocket_com', 'pdb_path', 'ligand_path'}
    if set(context) != expected:
        parser.error('Context must contain only receptor information, not a ligand graph')
    graph = rebuild(spec, **context)
    bootstrap.verify_imports()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    save_graph(graph, args.output)
    print(f'Saved {graph.num_nodes} nodes, {graph.edge_index.shape[1]} edges to {args.output}')


if __name__ == '__main__':
    main()
