#!/usr/bin/env python3
"""Reproducible report, plots and frozen-model audits for two-level search."""
import argparse
import csv
from datetime import datetime,timezone
import json
from pathlib import Path

import bootstrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from prepare_hierarchical_experiment import ROOT
from run_validation import write_json
from validation import digest


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args();root=a.root
    result=json.loads((root/'evaluation.json').read_text());summary=result['summary'];layer=result['oracle_layered']
    cal=result['calibration_oracle_layered'];cohorts=json.loads((root/'cohorts.json').read_text());lock=json.loads((root/'search_lock.json').read_text())
    n=layer['groups'];prefix=root.relative_to(bootstrap.PROJECT).as_posix()
    with (root/'matched_budget_metrics.csv').open('w') as f:
        columns=['method','K']+list(summary['ordinary']['1'])
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
        for method in ['ordinary','hierarchical']:
            for k in ['1','4','8']:writer.writerow(dict(method=method,K=k,**summary[method][k]))
    with (root/'per_case_metrics.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(result['rows'][0]));writer.writeheader();writer.writerows(result['rows'])
    plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25,'figure.dpi':160})
    fig,axes=plt.subplots(1,3,figsize=(15,4))
    for method,color in [('ordinary','#0077bb'),('hierarchical','#cc3311')]:
        for ax,field,title in zip(axes,['initial_constitution_coverage','final_constitution_coverage','constitution_correct'],['Initial pool: correct constitution','Final pool: correct constitution','Selected: correct constitution']):
            ax.plot([1,4,8],[summary[method][str(k)][field] for k in [1,4,8]],marker='o',color=color,label=method)
            ax.set(title=title,xlabel='K',ylabel=f'Correct / {n}',xticks=[1,4,8],ylim=(0,n))
    axes[0].legend();fig.tight_layout();fig.savefig(root/'hierarchical_coverage.png');fig.savefig(root/'hierarchical_coverage.pdf');plt.close(fig)
    labels=['All true edges\nin frozen pool','True skeleton\nin stage-1 pool','True skeleton supplied:\nport beam Top-8','True skeleton supplied:\nwide beam Top-128','Any internal\ncomplete candidate','Selected initial\nTop-8 pool']
    values=[layer['all_required_edges_in_support'],layer['stage1']['colored_skeleton'],layer['true_skeleton_port_beam']['8']['constitution'],
        layer['true_skeleton_wide_port_beam']['128']['constitution'],layer['internal_pool']['constitution'],layer['hierarchical_initial']['8']['constitution']]
    fig,ax=plt.subplots(figsize=(13,4.5));bars=ax.bar(range(len(values)),values,color=['#777777','#0077bb','#aa4499','#aa4499','#0077bb','#cc3311'])
    for bar,value in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,value+.35,f'{value}/{n}',ha='center')
    ax.set_xticks(range(len(values)),labels);ax.set(ylabel=f'Groups / {n}',ylim=(0,n+3),title='Layered diagnosis: conditional Oracle columns are NOT generation success')
    fig.tight_layout();fig.savefig(root/'oracle_layered_coverage.png');fig.savefig(root/'oracle_layered_coverage.pdf');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(14,4))
    for method,color in [('ordinary','#0077bb'),('hierarchical','#cc3311')]:
        for ax,field,title in zip(axes,['mean_backbone_evaluations','median_search_seconds','median_sampling_plus_search_seconds'],['Matched denoiser cost','Candidate search only','Sampling + search budget time']):
            ax.plot([1,4,8],[summary[method][str(k)][field] for k in [1,4,8]],marker='o',color=color,label=method)
            ax.set(title=title,xlabel='K',xticks=[1,4,8],ylim=(0,None))
    for ax,field in zip(axes,['mean_backbone_evaluations','median_search_seconds','median_sampling_plus_search_seconds']):
        upper=max(summary[method][str(k)][field] for method in summary for k in [1,4,8])
        ax.set_ylim(0,max(.01,upper*1.12))
    axes[0].set_ylabel('Mean NFE');axes[1].set_ylabel('Median seconds');axes[2].set_ylabel('Median seconds');axes[0].legend()
    fig.tight_layout();fig.savefig(root/'hierarchical_cost.png');plt.close(fig)
    old=json.loads((bootstrap.PROJECT/'PREDICTION_MANIFEST.json').read_text())
    source_changes=[name for name,h in old['official_source_sha256'].items() if digest(bootstrap.OFFICIAL/name)!=h]
    if source_changes or digest(bootstrap.CHECKPOINT)!=old['official_checkpoint_sha256']:raise RuntimeError('Official pretrained source/checkpoint changed')
    connection=bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt'
    previous=json.loads((bootstrap.PROJECT/'CONNECTION_ROBUST_MANIFEST.json').read_text())
    if digest(connection)!=previous['new_connection_sha256']:raise RuntimeError('Frozen connection head changed')
    identity=bootstrap.PROJECT/'results/prediction_diagnostics/identity_controls/iterative/best.pt'
    if digest(identity)!=old['checkpoints']['iterative']:raise RuntimeError('Frozen identity head changed')
    if any(digest(bootstrap.PROJECT/name)!=h for name,h in lock['source_sha256'].items()):raise RuntimeError('Search source changed after lock')
    regression=json.loads((root/'oracle_regression/report.json').read_text())
    if regression['failures'] or any(r['max_coordinate_difference_A']!=0 for r in regression['regression']):raise RuntimeError('Official sampling regression failed')
    shadow=max(r.get('oracle_shadow_max_coordinate_difference_A',0.) for r in regression['rows'])
    if shadow!=0:raise RuntimeError('Oracle/shadow changed coordinates')
    audits=[json.loads(p.read_text()) for p in root.glob('holdout_*/*/*/audit.json')]
    if not audits or not all(r['all_dynamic_recomputations_equal'] for r in audits):raise RuntimeError('Dynamic geometry audit failed')
    reports=[json.loads(p.read_text()) for p in root.glob('holdout_*/report.json')]
    failures=[r for p in reports for r in p['failures']]
    tests=(root/'tests.log').read_text();test_line=next(x for x in tests.splitlines() if x.startswith('Ran '))
    if '\nOK\n' not in tests:raise RuntimeError('Tests failed')
    b=summary['ordinary']['8'];h=summary['hierarchical']['8']
    conclusion=(f"两级搜索 K=8 的初始正确构造覆盖为 {h['initial_constitution_coverage']}/{n}，最终池覆盖 {h['final_constitution_coverage']}/{n}，最终启发式选中 {h['constitution_correct']}/{n}；普通 Top-K 分别为 {b['initial_constitution_coverage']}/{n}、{b['final_constitution_coverage']}/{n}、{b['constitution_correct']}/{n}。")
    lines=['# 两级骨架与联合端口搜索专项（2026-11-01）','',conclusion,'',
        '同预算下完整构造覆盖变差，几何异常也未改善，本轮没有可采用的完整生成收益。两级搜索保留为研究对照，默认普通搜索保持不变。','',
        '本轮暂停 Reranker 训练；固定真实片段身份和 N，冻结官方 SigmaDock、身份头和时间条件连接头。实现先搜索片段骨架、再联合分配端口/键级/E/Z 的两级 beam，比较两组相同候选预算与原主干 NFE。','',
        '## 具体改动','',
        '第一阶段按冻结连接头给出的槽位对势能生成连接树，保留多个槽位标记骨架，不在此阶段固定原子端口。使用模板可替换 H 容量对节点度作必要上界检查。第二阶段针对整棵骨架保留多个联合端口状态，共享每个原子的价态/H 替换预算，前瞻检查剩余边的可行性；每一步对完整局部替换模式做化学清理，最后对完整分子做组装、连通性、价态及 E/Z 合法性检查。','',
        '第二阶段按带邻片段颜色的部分化学图去重，区分邻/间/对位等组合，避免大量原子对称副本填满 beam；每个等价前缀保留两个按模型分数排序的代表，以容纳几何条件连接头打破对称的情况。这是有界近似搜索，不保证全局最优，也不保证列出全部端口组合。','',
        '发现并修复公共组装接口中的 E/Z 丢失：原代码设置双键立体标签后直接清理，RDKit 会将其清除；现在先设置相邻单键方向，再执行清理。两种搜索都使用同一修复后的化学组装代码，均重新采样，未复用上一轮的旧轨迹。原官方网络及其消息传递和扩散逻辑未改。','',
        '新搜索为双键枚举冻结头的未知/E/Z 条件，再按完整候选化学判断是否确实存在 E/Z；可立体异构的双键须保留明确 E/Z 条件。片段模板中已有的原子立体标签保留。连接后新形成的四面体中心没有新增预测头，本轮不会从真值补齐，因此构造指标不代表完整立体恢复。','',
        '## 数据、参数与隔离','',
        f"开发集合按完整化学构造去重：{len(cohorts['train'])} 个非 CASF 训练来源分子（本轮不再训练）、{len(cohorts['calibration'])} 个非 CASF 校准分子。先统一剔除与全部 271 个可用 CASF 配体重复的 {', '.join(cohorts['excluded_casf_duplicates'])}，再剔除开发集合内部重复：{cohorts['excluded_development_duplicates']}。构造定义为去 H、忽略立体的 canonical 化学图，非 scaffold 拆分。",
        '', '校准先完成 Oracle 分层诊断，并对小/中/大片段数各一个分子执行完整采样检查。参数使用预先定义默认值，没有搜索参数扫描或按 CASF 分数选参数。参数锁及代码哈希见 `search_lock.json`。','',
        '```json',json.dumps(lock['config'],indent=2),'```','',
        '两级最终预算候选按联合连接先验分数加递减骨架新颖度奖励选取，再按忽略立体的分子构造去重。K=1/4/8 为嵌套前缀。两组最终位姿轨迹均采用相同原闭环：低噪声时仍可使用冻结连接头更新合法图，动态几何特征按原官方流程逐步重算。最终排序统一沿用上一轮无真值启发式：平均连接 log-odds 减键长与碰撞惩罚；不使用新 Reranker、目标位姿、RMSD 或 Vina。','',
        f"固定 CASF 受体：`{', '.join(cohorts['casf_holdout'])}`；种子 `{cohorts['test_seeds']}`，合计 {n} 次。这是上一轮 12 个受体的固定复测，不是新盲测，也不是 {n} 个独立受体。此轮参数在 CASF 运行前冻结。原历史模型未重训，化学隔离只约束本轮开发集合。",
        '', '## Oracle 分层覆盖诊断','',
        '真实骨架只送入独立、明确标记的诊断端口 beam，永不加入普通生成池。骨架定义为忽略原子端口和键级的片段邻接树；标色骨架进一步允许相同片段类别之间的图同构，槽位标记骨架则要求给定槽位对应一致。OOV 共用类别 −1，标色可能合并不同显式 OOV 片段，因此同时列出严格槽位骨架覆盖，完整构造指标仍按真实化学图比较。','',
        '| 诊断 | 非 CASF 校准 | CASF 复测 |','| --- | ---: | ---: |',
        f"| 所有真实端口/键级在冻结头候选支持中 | {cal['all_required_edges_in_support']}/{cal['groups']} | {layer['all_required_edges_in_support']}/{n} |",
        f"| 所有真实端口/键级在每对截断的 64 个联合选项中 | {cal['all_required_edges_in_pair_top64']}/{cal['groups']} | {layer['all_required_edges_in_pair_top64']}/{n} |",
        f"| 第一阶段 24 骨架池含真实槽位标记骨架 | {cal['stage1']['labelled_skeleton']}/{cal['groups']} | {layer['stage1']['labelled_skeleton']}/{n} |",
        f"| 第一阶段 24 骨架池含真实标色骨架 | {cal['stage1']['colored_skeleton']}/{cal['groups']} | {layer['stage1']['colored_skeleton']}/{n} |",
        f"| 给定真实骨架：端口 beam Top-8 含正确构造 | {cal['true_skeleton_port_beam']['8']['constitution']}/{cal['groups']} | {layer['true_skeleton_port_beam']['8']['constitution']}/{n} |",
        f"| 给定真实骨架：宽 beam Top-128 含正确构造 | {cal['true_skeleton_wide_port_beam']['128']['constitution']}/{cal['groups']} | {layer['true_skeleton_wide_port_beam']['128']['constitution']}/{n} |",
        f"| 无真值搜索内部全部完整候选含正确构造 | {cal['internal_pool']['constitution']}/{cal['groups']} | {layer['internal_pool']['constitution']}/{n} |",
        f"| 无真值搜索最终初始 Top-8 池含正确构造 | {cal['hierarchical_initial']['8']['constitution']}/{cal['groups']} | {layer['hierarchical_initial']['8']['constitution']}/{n} |",'',
        '给定真实骨架是条件覆盖上界诊断，不是可部署生成正确率。内部候选池最多 24×16 个，未执行主干采样；其覆盖不能与实际 K=8/NFE=192 的结果混称。宽诊断采用 port_width=256、最多 128 个完整构造；真实端口/键级没有注入其选项。','',
        '| 给定真实骨架的端口预算 | 严格连接命中 | 构造命中 | 宽 beam 严格连接命中 | 宽 beam 构造命中 |','| --- | ---: | ---: | ---: | ---: |']
    for k in ['1','4','8','16','64','128']:
        r=layer['true_skeleton_port_beam'][k];w=layer['true_skeleton_wide_port_beam'][k]
        lines.append(f"| {k} | {r['exact_connections']}/{n} | {r['constitution']}/{n} | {w['exact_connections']}/{n} | {w['constitution']}/{n} |")
    lines+=['',f'![Oracle 分层诊断]({prefix}/oracle_layered_coverage.png)','',
        '## 相同候选预算和 NFE 的完整采样','',
        '| 搜索 | K | 初始正确骨架池覆盖 | 初始正确构造池覆盖 | 最终正确构造池覆盖 | 选中构造正确 | 选中全连接正确 | 化学合法 | 几何异常 | 平均 NFE |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for method in ['ordinary','hierarchical']:
        for k in ['1','4','8']:
            r=summary[method][k];fields=['initial_colored_skeleton_coverage','initial_constitution_coverage','final_constitution_coverage','constitution_correct','connections_correct','chemical_valid','geometry_abnormal']
            lines.append(f'| {method} | {k} | '+' | '.join(f'{r[f]}/{n}' for f in fields)+f" | {r['mean_backbone_evaluations']:.1f} |")
    lines+=['','每个完成候选使用 24 次原主干调用，K=1/4/8 分别为 NFE=24/96/192。若任一搜索可用候选不足 K，两组统一取较小可用数，不复制候选凑数；逐案例 CSV 保存实际数量。共享的相同完整候选只采样一次，但比较成本对每种方法分别计入其候选调用。','',
        '构造正确忽略立体且允许化学图同构。全连接正确按给定槽位匹配全部端口和键级，不包含所有立体恢复要求。几何异常为任意片段间键误差>0.5 Å 或非键合原子间距离<1.2 Å；失败也计异常。化学合法仅指组装和采样成功，不代表正确构造或结合位姿。','',
        f'![同预算覆盖和选优]({prefix}/hierarchical_coverage.png)','',
        '| 搜索 | K | 搜索中位耗时 s | 采样中位耗时 s | 搜索＋采样中位耗时 s | 初始正确构造采样后丢失 | 池正确但排序选错 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for method in ['ordinary','hierarchical']:
        for k in ['1','4','8']:
            r=summary[method][k];lines.append(f"| {method} | {k} | {r['median_search_seconds']:.3f} | {r['median_sampling_seconds']:.2f} | {r['median_sampling_plus_search_seconds']:.2f} | {r['initial_correct_constitution_lost']}/{n} | {r['final_pool_correct_but_ranked_wrong']}/{n} |")
    lines+=['',f'![成本比较]({prefix}/hierarchical_cost.png)','',
        '耗时包含图重建、原采样和目标无关特征提取；搜索没有主干 NFE，但新增 CPU 化学检查并非免费。GPU 6/7 各有两个采样进程，wall time 受共享资源影响，使用 NFE 验证采样预算公平。K 前缀都计入同一次最多 8 候选的枚举开销。','',
        f"K=8 最终选中候选中，普通搜索有 {b['unresolved_selected_double_centres']} 个未指定双键中心、{b['unresolved_selected_tetra_centres']} 个未指定四面体中心；两级搜索分别为 {h['unresolved_selected_double_centres']}、{h['unresolved_selected_tetra_centres']}。这些按全部 {n} 次运行计数，包括同一受体不同 seed。低噪声闭环仍使用原解码器，初始 beam 中的约束并不保证后续每次预测都保留同一立体条件。",
        '', '## 回归、边界和后续依据','',
        f"原官方源代码、权重、身份头和连接头哈希保持不变。2 个原版采样回归样本的最大坐标差均为 0 Å，Oracle/shadow 最大差为 {shadow:g} Å。CASF 完成 {len(audits)} 个唯一候选采样，审计 {sum(len(x['forwards']) for x in audits)} 次原主干调用，当前动态边/距离/方向重算检查全部通过；候选失败 {len(failures)} 个。{test_line}，结果 OK。",
        '', f"初始正确构造覆盖→最终覆盖→最终选择的本轮结果为：{conclusion} 这些是固定小样本复测结果，不足以宣称新配体泛化改善；候选覆盖、闭环更新丢失和无真值排序需分别判断。",
        '', f"本轮所有 {n} 组的真实端口/键级都存在于候选支持，不能将低正确率归因于这些原子端口根本未被枚举。第一阶段的 24 骨架池只覆盖 {layer['stage1']['labelled_skeleton']}/{n} 个严格骨架；给定真实骨架后，宽端口 beam Top-128 的构造覆盖为 {layer['true_skeleton_wide_port_beam']['128']['constitution']}/{n}，说明端口组合的有限宽度及先验排序也会丢失正确答案。",
        '', f"无真值内部池有 {layer['internal_pool']['constitution']}/{n} 组含正确构造，压缩到实际 Top-8 后仅 {h['initial_constitution_coverage']}/{n}；其中 {layer['internal_pool']['constitution']-h['initial_constitution_coverage']} 组在采样预算分配前就已丢失。两组采样后丢失初始正确构造的组数分别为 {b['initial_correct_constitution_lost']} 和 {h['initial_correct_constitution_lost']}，本次结果未显示这些已命中构造被动态去噪破坏。下一步应在非 CASF 数据上改进骨架与端口候选的联合分数及预算分配；仅继续增加骨架多样性不足以解决当前完整构造恢复问题。本轮不按该 CASF 结果继续调参。",
        '', '本阶段只替换候选生成方式，不训练任何网络，也未默认启用新搜索。真实连接只用于明确分离的诊断与评估。当前树约束保留片段内部的环，但不支持新跨片段闭环；若未来数据允许跨片段成环，须扩展骨架搜索及全局化学检查后另行评估。',
        '', f'[逐组指标 CSV]({prefix}/per_case_metrics.csv) · [同预算汇总 CSV]({prefix}/matched_budget_metrics.csv) · [完整分层诊断]({prefix}/evaluation.json) · [搜索参数锁]({prefix}/search_lock.json) · [复现接口](HIERARCHICAL_TOPOLOGY.md)','']
    (bootstrap.PROJECT/'HIERARCHICAL_TOPOLOGY_RESULTS.md').write_text('\n'.join(lines))
    manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),prompt_sha256=digest(root/'prompt_used.md'),
        source_changes=source_changes,official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),connection_checkpoint_sha256=digest(connection),identity_checkpoint_sha256=digest(identity),
        search_lock=lock,cohorts=cohorts,regression=regression['regression'],oracle_shadow_difference_A=shadow,
        completed_candidate_audits=len(audits),audited_forwards=sum(len(x['forwards']) for x in audits),failures=failures,tests=test_line,test_success=True,
        scripts={name:digest(bootstrap.PROJECT/name) for name in ['hierarchical_topology.py','prepare_hierarchical_experiment.py','run_hierarchical_experiment.py','lock_hierarchical_search.py','evaluate_hierarchical_experiment.py','summarize_hierarchical_experiment.py','vocab_chemistry.py']},
        results={name:digest(root/name) for name in ['evaluation.json','matched_budget_metrics.csv','cohorts.json','search_lock.json']})
    write_json(bootstrap.PROJECT/'HIERARCHICAL_TOPOLOGY_MANIFEST.json',manifest)
    stage=bootstrap.PROJECT/'STAGED_RESULTS.md';marker='\n## 2026-11-01：两级骨架与联合端口 beam'
    stage.write_text(stage.read_text().split(marker)[0]+marker+'\n\n'+conclusion+'\n\n[专项报告](HIERARCHICAL_TOPOLOGY_RESULTS.md) · [复现和接口](HIERARCHICAL_TOPOLOGY.md)。\n')
    print(json.dumps(dict(summary=summary,layered=layer,completed_candidates=len(audits),tests=test_line),indent=2))


if __name__=='__main__':main()
