"""Freeze predefined search settings after non-CASF diagnostics, before CASF."""
import argparse
from dataclasses import asdict
from datetime import datetime,timezone
import json
from pathlib import Path

import bootstrap
from hierarchical_topology import SearchConfig
from prepare_hierarchical_experiment import ROOT
from run_validation import write_json
from validation import digest


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args()
    if (a.root/'search_lock.json').exists():raise ValueError('Search already locked; use an independent experiment root')
    if any(a.root.glob('holdout_*/protocol.json')):raise ValueError('Cannot lock settings after starting CASF runs')
    cohorts=json.loads((a.root/'cohorts.json').read_text());path=a.root/'calibration_diagnostic/report.json'
    report=json.loads(path.read_text());groups=report['groups'];config=asdict(SearchConfig())
    if report['contract']['role']!='calibration' or report['contract']['config']!=config:raise ValueError('Unexpected calibration protocol')
    if {g['id'] for g in groups}!=set(cohorts['calibration']) or report['failures']:raise ValueError('Incomplete calibration diagnostics')
    sources=['hierarchical_topology.py','run_hierarchical_experiment.py','trajectory_connections.py','vocab_chemistry.py','topology_reranker.py','evaluate_topology_search.py']
    lock=dict(created_utc=datetime.now(timezone.utc).isoformat(),config=config,source_sha256={n:digest(bootstrap.PROJECT/n) for n in sources},
        reason='Default predefined search widths verified on chemistry-disjoint non-CASF calibration; no hyperparameter sweep or reranker training; fixed before CASF runs.',
        calibration_report_sha256=digest(path),calibration_molecules=len(groups),reranker_training=False,casf_used_for_config_selection=False,
        casf_caveat='Fixed 12-receptor repeat benchmark examined in the previous phase; this is not a new blind cohort.')
    write_json(a.root/'search_config.json',config);write_json(a.root/'search_lock.json',lock);print(json.dumps(lock,indent=2))


if __name__=='__main__':main()
