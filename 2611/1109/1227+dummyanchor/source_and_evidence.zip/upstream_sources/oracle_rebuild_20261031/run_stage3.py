#!/usr/bin/env python3
"""Held-out connection prediction, legal graph construction and docking."""
import argparse
import json
import os
import traceback
from pathlib import Path

import bootstrap
import numpy as np
import torch

from connection_predictor import PortConnectionPredictor, candidates, legal_decode, proposals
from oracle_graph import rebuild
from pipeline_utils import molecule_metrics
from run_validation import DEFAULT_IDS, docking, load_official, write_json
from serialization import save_graph
from validation import digest
from vocab_chemistry import VocabLibrary, assemble_slots, canonical, embedded_reference, explicit_oov, spec_from_slots, true_connections


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=Path,default=bootstrap.PROJECT/'results/stage3_training/best.pt')
    p.add_argument('--output',type=Path,default=bootstrap.PROJECT/'results/stage3')
    p.add_argument('--baseline',type=Path,default=bootstrap.PROJECT/'results/acceptance')
    p.add_argument('--ids',default=DEFAULT_IDS)
    p.add_argument('--device',default='cuda:1')
    p.add_argument('--threshold',type=float,default=.65)
    p.add_argument('--seeds',default='0,1,2')
    p.add_argument('--steps',type=int,default=25)
    a=p.parse_args();a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True)
    if (a.output/'report.json').exists():p.error('Output exists')
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True);torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    saved=torch.load(a.checkpoint,weights_only=False,map_location='cpu')
    model=PortConnectionPredictor().to(device).eval();model.load_state_dict(saved['model'],strict=True)
    lib=VocabLibrary();den=load_official(bootstrap.CHECKPOINT,a.output,device)
    val_ids=json.loads((bootstrap.RECORDS.parent/'val_ids.json').read_text())
    selected=set(a.ids.split(','));seeds=list(map(int,a.seeds.split(',')))
    result=dict(stage=3,checkpoint_sha256=digest(a.checkpoint),trained_epoch=saved['epoch'],threshold=a.threshold,
                protocol='Known identities and true fragment rigid poses; connections, ports and bond orders predicted. '
                         'All legal decoding is target-free. Incomplete/invalid proposals never enter the original backbone.',
                rows=[],failures=[],docking_selected=sorted(selected))
    for pid in val_ids:
        try:
            record=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
            labels=record['labels'].tolist();oov=explicit_oov(record)
            x=candidates(lib,labels,record['T0'].numpy(),record['R0'].numpy(),oov=oov)
            proposed,all_candidates=proposals(model,x,device,threshold=a.threshold)
            decision,assembled=legal_decode(lib,labels,proposed,oov=oov)
            truth=true_connections(record)
            actual={(c['i'],c['j'],c['a'],c['b'],c['order']) for c in truth}
            guessed={(c['i'],c['j'],c['a'],c['b'],c['order']) for c in decision['connections']}
            row=dict(id=pid,status=decision['status'],true_bonds=len(actual),predicted_bonds=len(guessed),
                     exact_port_bond_tp=len(actual&guessed),exact_connections=actual==guessed,
                     candidates=len(all_candidates),connections=decision['connections'],docking=[])
            if assembled is None:
                row['reason']=decision['reason']
            else:
                mol,groups,cuts=assembled
                oracle_mol,_,_=assemble_slots(lib,labels,truth,oov=oov)
                row['constitution_exact']=canonical(mol,False)==canonical(oracle_mol,False)
                if pid in selected:
                    out=a.output/pid;out.mkdir(exist_ok=True)
                    reference=embedded_reference(mol,seed=0)
                    spec=spec_from_slots(reference,groups,cuts,labels,'predicted legal connection graph; independent ETKDG')
                    write_json(out/'predicted_connections.json',spec)
                    context=torch.load(a.baseline/pid/'pocket_context.pt',weights_only=False)
                    graph=rebuild(spec,**context);save_graph(graph,out/'graph.pt')
                    target=torch.load(a.baseline/pid/'official_graph.pt',weights_only=False).mol_info['original']
                    row['chemistry']=molecule_metrics(mol,target)
                    for seed in seeds:
                        pred,_,stats=docking(den,graph,seed=seed,steps=a.steps,device=device,noise_scale=0.,save=out/f'seed{seed}.pt')
                        stats['quality']=molecule_metrics(mol,target,pred.numpy())
                        row['docking'].append(dict(seed=seed,**stats))
            result['rows'].append(row)
            if pid in selected:print(pid,row['status'],'exact ports',row['exact_connections'],'docking',len(row['docking']),flush=True)
        except Exception as exc:
            result['failures'].append(dict(id=pid,error=repr(exc),traceback=traceback.format_exc()))
            print('FAILED',pid,repr(exc),flush=True)
        if len(result['rows'])%32==0 or pid in selected:write_json(a.output/'report.json',result)
    rows=result['rows'];tp=sum(r['exact_port_bond_tp'] for r in rows)
    predicted=sum(r['predicted_bonds'] for r in rows);actual=sum(r['true_bonds'] for r in rows)
    precision,recall=tp/max(1,predicted),tp/max(1,actual)
    result['summary']=dict(validation_molecules=len(val_ids),evaluated=len(rows),
        complete_legal=sum(r['status']=='complete_legal' for r in rows),
        constitution_exact=sum(r.get('constitution_exact',False) for r in rows),
        exact_connections=sum(r['exact_connections'] for r in rows),precision=precision,recall=recall,
        f1=2*precision*recall/max(1e-8,precision+recall),backbone_sampling_runs=sum(len(r['docking']) for r in rows))
    write_json(a.output/'report.json',result);print('SUMMARY',result['summary'],flush=True)


if __name__=='__main__':main()
