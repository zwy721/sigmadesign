#!/usr/bin/env python3
"""Four-mode diagnostic and non-CASF reverse-trajectory collection."""
import argparse
import json
import os
from pathlib import Path
import time
import traceback

import bootstrap
import numpy as np
import torch
from rdkit import Chem

from evaluate_robust_connections import edge_set
from oracle_graph import assemble
from pipeline_utils import pose_geometry
from robust_connection_data import compile_targets,pack_records,noisy_frames
from run_validation import load_official,docking,write_json
from trajectory_connections import ConnectionRuntime,GraphFactory,load_connection,run_trajectory,connection_metrics
from validation import digest
from vocab_chemistry import VocabLibrary,canonical

ROOT=bootstrap.PROJECT/'results/connection_trajectory_20261101'
BASE=bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt'


class Observer:
    def __init__(self,fixture,runtime,*,extra_heads=False):
        self.fixture=fixture;self.runtime=runtime;self.extra_heads=extra_heads;self.cache={}
        self.truth=edge_set(fixture['oracle_edges']);self.target=np.asarray(fixture['target_xyz'])
        self.target_smiles=canonical(fixture['target_mol'],False)
        sizes=[len(runtime.lib.template(t,runtime.oov[i])[1]) for i,t in enumerate(runtime.labels)]
        self.offset=np.cumsum([0]+sizes)

    def __call__(self,frame,xyz,pred,spec):
        m=connection_metrics(pred,self.fixture['oracle_edges'])
        connections=frame['current_connections'];key=tuple(sorted(edge_set(connections)))
        if key not in self.cache:
            mol=assemble(spec)
            self.cache[key]=(mol,canonical(mol,False)==self.target_smiles)
        mol,exact=self.cache[key]
        bond_distances=[float(np.linalg.norm(xyz[self.offset[e['i']]+e['a']]-xyz[self.offset[e['j']]+e['b']])) for e in self.fixture['oracle_edges']]
        centroid=[xyz[self.offset[i]:self.offset[i+1]].mean(0) for i in range(len(self.offset)-1)]
        target_centroid=[self.target[self.offset[i]:self.offset[i+1]].mean(0) for i in range(len(self.offset)-1)]
        geometry=pose_geometry(mol,xyz,spec['connections'],self.fixture['context']['pocket'])
        row=dict(step=frame['step'],t=frame['t'],**m,
            slot_atom_rmsd_A=float(np.sqrt(np.mean(np.sum((xyz-self.target)**2,-1)))),
            slot_centroid_rmsd_A=float(np.sqrt(np.mean(np.sum((np.asarray(centroid)-target_centroid)**2,-1)))),
            current_topology_exact=edge_set(connections)==self.truth,current_constitution_exact=exact,
            template_fit_max_A=float(max(frame['fit'],default=0)),template_fit_mean_A=float(np.mean(frame['fit'])),
            true_interfragment_distance_mean_A=float(np.mean(bond_distances)) if bond_distances else 0.,
            true_interfragment_distance_max_A=max(bond_distances,default=0.),geometry=geometry)
        if self.extra_heads:
            for head,policy,name in [('full','wide','full_wide'),('legacy_staged','adaptive','old_staged')]:
                other=self.runtime.predict(frame['T'],frame['R'],frame['t'],head=head,policy=policy)
                row[name]=connection_metrics(other,self.fixture['oracle_edges'])
        return row


def forward_control(den,runtime,fixture,seed,steps=25):
    r=torch.load(bootstrap.RECORDS/f"{fixture['id']}.pt",weights_only=False)
    c=runtime.cpu
    row=dict(chem=c,target=compile_targets(c,r),noise={k:r[k] for k in ('T0','R0','C0','Q0','refR','offset')})
    packed=pack_records([row],runtime.device);result=[]
    grid=(.9**(1/3)+np.arange(steps)/(steps-1)*(.005**(1/3)-.9**(1/3)))**3
    # Instrumentation must not change the trajectory random stream.
    devices=[runtime.device.index] if runtime.device.type=='cuda' else []
    with torch.random.fork_rng(devices=devices):
        for step,t in enumerate(grid):
            T,R=noisy_frames(packed,den.diffuser,torch.tensor([float(t)],device=runtime.device),seed=seed+100000)
            T=T.cpu().numpy()+np.asarray(r['graph']['case']['origin']);R=R.cpu().numpy()
            pred=runtime.predict(T,R,float(t));m=connection_metrics(pred,fixture['oracle_edges'])
            positions=[runtime.lib.template(label,runtime.oov[i])[1]@R[i].T+T[i] for i,label in enumerate(runtime.labels)]
            xyz=np.concatenate(positions)
            result.append(dict(step=step,t=float(t),**m,
                slot_atom_rmsd_A=float(np.sqrt(np.mean(np.sum((xyz-fixture['target_xyz'])**2,-1))))))
    return result


def save_result(folder,result,fixture):
    folder.mkdir(parents=True,exist_ok=True)
    torch.save(dict(frames=result['frames'],positions=result['positions'],id=fixture['id'],
        labels=fixture['labels'],mode=result['mode'],seed=result['seed'],source_split=fixture['audit']['split'],
        casf=fixture['audit']['casf']),folder/'trajectory.pt')
    write_json(folder/'steps.json',result['metrics']);write_json(folder/'events.json',result['events'])
    write_json(folder/'audit.json',result['audit']);write_json(folder/'chemistry.json',result['spec'])
    mol=assemble(result['spec']);conf=mol.GetConformer()
    for i,x in enumerate(result['positions'][-1]):conf.SetAtomPosition(i,x.tolist())
    with Chem.SDWriter(str(folder/'final.sdf')) as writer:writer.write(mol)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--checkpoint',type=Path,default=BASE);p.add_argument('--ids',required=True)
    p.add_argument('--seeds',default='601,602,603');p.add_argument('--steps',type=int,default=25)
    p.add_argument('--modes',default='oracle,shadow,closed,diagnostic_reset');p.add_argument('--device',default='cuda:0')
    p.add_argument('--head',choices=['full','legacy_staged'],default='full')
    p.add_argument('--policy',choices=['adaptive','wide'],default='adaptive')
    p.add_argument('--forward-controls',action='store_true');p.add_argument('--extra-heads',action='store_true')
    p.add_argument('--training-only',action='store_true');p.add_argument('--oracle-regression',action='store_true')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    torch.use_deterministic_algorithms(True);torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    den=load_official(bootstrap.CHECKPOINT,a.output,device);lib=VocabLibrary();checkpoint=load_connection(a.checkpoint,device)
    report=dict(rows=[],failures=[],forward_controls=[],regression=[],head=a.head,policy=a.policy,
        checkpoint_sha256=digest(a.checkpoint),official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),
        source_sha256={n:digest(bootstrap.PROJECT/n) for n in ['trajectory_connections.py','run_connection_trajectories.py']},
        seeds=list(map(int,a.seeds.split(','))),steps=a.steps,
        diagnostic_reset_steps=[8,16,20],reset_is_diagnostic_only=True,identity_updates=False,
        rmsd_definition='Fixed supplied slot/local-atom correspondence, receptor frame, no alignment; meaningful as a pose diagnostic even for different topology. Not a chemical docking success metric.',
        observer_is_read_only=True)
    started=time.time()
    for pid in a.ids.split(','):
        fixture=torch.load(a.root/f'inputs/{pid}/fixture.pt',weights_only=False)
        if a.training_only and (fixture['audit']['casf'] or fixture['audit']['split']!='train'):
            raise ValueError('CASF/non-training molecule forbidden in adaptation collection')
        runtime=ConnectionRuntime(lib,checkpoint,fixture['labels'],fixture['oov'],device,policy=a.policy,head=a.head)
        factory=GraphFactory(lib,fixture['labels'],fixture['oov'],fixture['context'])
        oracle_graph=torch.load(a.root/f'inputs/{pid}/oracle_graph.pt',weights_only=False)
        bundle=(oracle_graph,fixture['groups'],fixture['spec'])
        for seed in report['seeds']:
            oracle_positions=None
            if a.forward_controls:
                report['forward_controls'].append(dict(id=pid,seed=seed,steps=forward_control(den,runtime,fixture,seed,a.steps)))
            for mode in a.modes.split(','):
                folder=a.output/f'{pid}_{seed}_{mode}'
                try:
                    observer=Observer(fixture,runtime,extra_heads=a.extra_heads)
                    diag=mode!='closed'
                    result=run_trajectory(den,runtime,factory,seed=seed,steps=a.steps,mode=mode,
                        oracle_bundle=bundle if diag else None,oracle_edges=fixture['oracle_edges'] if diag else None,observer=observer)
                    save_result(folder,result,fixture);metrics=result['metrics'];truth=edge_set(fixture['oracle_edges'])
                    first=next((r['step'] for r in metrics if not r['current_topology_exact']),None)
                    first_applied=next((e['step'] for e in result['events'] if e['accepted'] and edge_set(e['connections_after'])!=truth),None)
                    row=dict(id=pid,seed=seed,mode=mode,success=True,seconds=result['seconds'],revisions=result['revisions'],
                        first_wrong_topology_step=first,first_applied_wrong_topology_step=first_applied,
                        first_wrong_proposal_step=next((r['step'] for r in metrics if not r['proposal_exact']),None),
                        initial=metrics[0],final=metrics[-1],truth_used_for_generation=result['truth_used_for_generation'])
                    if mode=='oracle':oracle_positions=result['positions']
                    if mode=='shadow' and oracle_positions is not None:
                        row['oracle_shadow_max_coordinate_difference_A']=float(np.abs(oracle_positions-result['positions']).max())
                        if row['oracle_shadow_max_coordinate_difference_A']>1e-5:raise AssertionError('Read-only head changed oracle trajectory')
                    report['rows'].append(row)
                except Exception as exc:
                    if isinstance(exc,torch.OutOfMemoryError):raise
                    folder.mkdir(parents=True,exist_ok=True);(folder/'error.txt').write_text(traceback.format_exc())
                    report['failures'].append(dict(id=pid,seed=seed,mode=mode,error=repr(exc)))
                    print('TRAJECTORY_FAILED',pid,seed,mode,repr(exc),flush=True)
                write_json(a.output/'report.partial.json',report)
                print('TRAJECTORY',pid,seed,mode,'elapsed',round(time.time()-started),flush=True)
        if a.oracle_regression:
            seed=report['seeds'][0]
            control,_,_=docking(den,oracle_graph,seed=seed,steps=a.steps,device=device,noise_scale=0.,save=a.output/f'regression_{pid}.pt')
            result=run_trajectory(den,runtime,factory,seed=seed,steps=a.steps,start=1.,mode='oracle',oracle_bundle=bundle,oracle_edges=fixture['oracle_edges'])
            difference=float(np.abs(control.numpy()-result['positions'][-1]).max())
            report['regression'].append(dict(id=pid,max_coordinate_difference_A=difference))
            if difference>1e-4:raise AssertionError('Native adapter no longer matches official sampler')
    report['elapsed_seconds']=time.time()-started;write_json(a.output/'report.json',report)


if __name__=='__main__':main()
