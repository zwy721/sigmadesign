#!/usr/bin/env python3
"""Train an independent connection module on non-CASF PDBbind; CASF validation."""
import argparse
import hashlib
import json
import os
import time
from pathlib import Path

import bootstrap
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset
from scipy.spatial.transform import Rotation

from connection_predictor import PortConnectionPredictor, candidates, targets
from run_validation import write_json
from validation import digest
from vocab_chemistry import VocabLibrary, explicit_oov


class FeatureDataset(Dataset):
    def __init__(self, root, ids, augment):
        self.root, self.ids, self.augment, self.library = root, ids, augment, None

    def __len__(self): return len(self.ids)

    def __getitem__(self, index):
        if self.library is None: self.library = VocabLibrary()
        pid = self.ids[index]
        try:
            r = torch.load(self.root / f'{pid}.pt', weights_only=False)
            labels = r['labels'].tolist()
            T, R = r['T0'].numpy().copy(), r['R0'].numpy().copy()
            if self.augment:
                seed = int(hashlib.sha256(pid.encode()).hexdigest()[:8], 16)
                rng = np.random.default_rng(seed)
                sigma = rng.choice([0., .2, .5])
                T += rng.normal(size=T.shape) * sigma
                R = Rotation.from_rotvec(rng.normal(size=T.shape) * sigma * .25).as_matrix() @ R
            x = candidates(self.library, labels, T, R, oov=explicit_oov(r))
            y = targets(x, r)
            return dict(id=pid, **x, **y)
        except Exception as exc:
            return dict(id=pid, error=repr(exc))


def collate(items): return items


def initialize_worker(_): torch.set_num_threads(1)


def feature_cache(root, split, output, workers):
    ids = json.loads((root / f'{split}_ids.json').read_text())
    path = output / f'{split}_features.pt'
    if path.exists():
        data = torch.load(path, weights_only=False)
        if data['ids_sha256'] != digest(root / f'{split}_ids.json'):
            raise ValueError('Cached feature split changed')
        return data
    data = dict(types=[], x=[], y=[], stereo=[], ids=[], candidates=[], ptr=[0], true_bonds=[], failures=[],
                ids_sha256=digest(root / f'{split}_ids.json'), augmentation=split == 'train')
    dataset = FeatureDataset(root / 'records', ids, split == 'train')
    loader = DataLoader(dataset, batch_size=16, num_workers=workers, collate_fn=collate,
                        worker_init_fn=initialize_worker, persistent_workers=workers > 0)
    for batch in loader:
        for row in batch:
            if 'error' in row:
                data['failures'].append(row); continue
            for key in ('types', 'x', 'y', 'stereo', 'candidates'): data[key].append(row[key])
            data['ids'].append(row['id'])
            data['true_bonds'].append(row['true_bonds'])
            data['ptr'].append(data['ptr'][-1] + len(row['x']))
        if len(data['ids']) % 256 < 16:
            print('CACHE', split, len(data['ids']), '/', len(ids), 'rows', data['ptr'][-1], flush=True)
    for key in ('types', 'x', 'y', 'stereo', 'candidates'):
        data[key] = torch.cat(data[key])
    data['x'] = data['x'].half()
    data['true_bonds'] = torch.tensor(data['true_bonds'])
    torch.save(data, path)
    return data


@torch.inference_mode()
def evaluate(model, data, device, batch):
    model.eval()
    total_loss, count, tp, predicted = 0., 0, 0, 0
    for start in range(0, len(data['y']), batch):
        sl = slice(start, start + batch)
        logits, _ = model(data['types'][sl].to(device), data['x'][sl].to(device))
        y = data['y'][sl].to(device).long()
        total_loss += float(F.cross_entropy(logits, y, reduction='sum'))
        count += len(y)
        prob = logits.softmax(-1)
        p, order = prob[:, 1:].max(-1)
        order += 1
        active = (p >= .65) & (p > prob[:, 0])
        tp += int((active & (order == y) & (y > 0)).sum())
        predicted += int(active.sum())
    actual = int(data['true_bonds'].sum())
    precision, recall = tp / max(1, predicted), tp / max(1, actual)
    return dict(loss=total_loss / max(1, count), candidate_recall=float((data['y'] > 0).sum()) / max(1, actual),
                precision=precision, recall=recall, f1=2 * precision * recall / max(1e-8, precision + recall),
                true_bonds=actual, correct_port_bonds=tp, predicted_port_bonds=predicted)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, default=bootstrap.PROJECT / 'results/stage3_training')
    p.add_argument('--cache-root', type=Path, default=bootstrap.RECORDS.parent)
    p.add_argument('--device', default='cuda:2')
    p.add_argument('--epochs', type=int, default=5)
    p.add_argument('--batch-rows', type=int, default=32768)
    p.add_argument('--workers', type=int, default=6)
    p.add_argument('--resume', type=Path)
    a = p.parse_args()
    a.output = a.output.resolve(); a.output.mkdir(parents=True, exist_ok=True)
    if (a.output / 'latest.pt').exists() and not a.resume: p.error('Use --resume for an existing run')
    torch.set_num_threads(2)
    torch.manual_seed(20261101)
    train = feature_cache(a.cache_root, 'train', a.output, a.workers)
    val = feature_cache(a.cache_root, 'val', a.output, a.workers)
    if set(train['ids']) & set(val['ids']): raise AssertionError('CASF leaked into connection training')
    write_json(a.output / 'dataset_audit.json', dict(train_molecules=len(train['ids']), val_molecules=len(val['ids']),
               train_rows=len(train['y']), val_rows=len(val['y']), train_failures=train['failures'],
               val_failures=val['failures'], split_intersection=0, template_sha256=digest(bootstrap.WORKSPACE/'geom_m12/assets/templates.json')))
    device = torch.device(a.device)
    if device.type == 'cuda': torch.cuda.set_device(device)
    model = PortConnectionPredictor().to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=.002, weight_decay=.0001)
    counts = torch.bincount(train['y'].long(), minlength=3).float()
    weights = (counts.max() / counts.clamp_min(1)).sqrt().clamp(max=30).to(device)
    start, best, history = 0, -1., []
    if a.resume:
        saved = torch.load(a.resume, map_location='cpu', weights_only=False)
        if saved['train_ids_sha256'] != train['ids_sha256']: raise ValueError('Resume dataset differs')
        model.load_state_dict(saved['model'], strict=True); opt.load_state_dict(saved['optimizer'])
        start, best, history = saved['epoch'], saved['best_f1'], saved['history']
    # Port features fit in A100 memory: one transfer avoids per-batch host stalls.
    types, numeric, y, stereo = (train[k].to(device) for k in ('types', 'x', 'y', 'stereo'))
    started = time.time()
    for epoch in range(start, a.epochs):
        model.train()
        generator = torch.Generator(device=device).manual_seed(20261101 + epoch)
        order = torch.randperm(len(y), device=device, generator=generator)
        accumulated, total = 0., 0
        for offset in range(0, len(order), a.batch_rows):
            index = order[offset:offset + a.batch_rows]
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=device.type == 'cuda'):
                logits, stereologits = model(types[index], numeric[index])
                loss = F.cross_entropy(logits, y[index].long(), weight=weights)
                double = y[index] == 2
                if double.any(): loss = loss + .2 * F.cross_entropy(stereologits[double], stereo[index][double].long())
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 5.); opt.step()
            accumulated += float(loss.detach()) * len(index); total += len(index)
        metrics = evaluate(model, val, device, a.batch_rows)
        row = dict(epoch=epoch + 1, train_loss=accumulated/max(1,total), val=metrics,
                   elapsed_seconds=time.time()-started)
        history.append(row); print(json.dumps(row), flush=True)
        improved = metrics['f1'] > best
        best = max(best, metrics['f1'])
        saved = dict(model=model.state_dict(), optimizer=opt.state_dict(), epoch=epoch+1, best_f1=best,
                     history=history, architecture='PortConnectionPredictor-v1',
                     train_ids_sha256=train['ids_sha256'], val_ids_sha256=val['ids_sha256'],
                     source_sha256=digest(bootstrap.PROJECT/'connection_predictor.py'),
                     scope='Independent connection module; original SigmaDock backbone untouched')
        torch.save(saved, a.output/'latest.pt')
        if improved: torch.save(saved, a.output/'best.pt')
        write_json(a.output/'history.json', history)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.5))
    axes[0].plot([r['epoch'] for r in history], [r['train_loss'] for r in history], label='Train weighted loss')
    axes[0].plot([r['epoch'] for r in history], [r['val']['loss'] for r in history], label='CASF loss')
    axes[0].set(xlabel='Epoch', ylabel='Loss'); axes[0].legend()
    axes[1].plot([r['epoch'] for r in history], [r['val']['f1'] for r in history], label='CASF exact-port bond F1')
    axes[1].set(xlabel='Epoch', ylabel='F1'); axes[1].legend()
    fig.tight_layout(); fig.savefig(a.output/'training_curves.png', dpi=160); plt.close(fig)
    write_json(a.output/'status.json', dict(status='complete', epoch=a.epochs, best_f1=best,
               train_molecules=len(train['ids']), val_molecules=len(val['ids']), backbone_trained=False))


if __name__ == '__main__': main()
