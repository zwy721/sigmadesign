"""Shared legal chemistry and atom-count-aware evaluation for staged prediction."""
import copy
import math

import numpy as np
import torch
from rdkit import Chem, DataStructs
from rdkit.Chem import rdFingerprintGenerator, rdFMCS

from vocab_chemistry import ChemistryRejected, assemble_slots, canonical


def rigid_fit(source, target, preferred=None):
    source, target = np.asarray(source), np.asarray(target)
    center0, center1 = source.mean(0), target.mean(0)
    a, b = source - center0, target - center1
    h = a.T @ b
    if preferred is not None: h += 1e-8 * np.asarray(preferred).T
    u, _, vt = np.linalg.svd(h)
    correction = np.eye(3); correction[-1, -1] = np.linalg.det(vt.T @ u.T)
    rotation = vt.T @ correction @ u.T
    translation = center1 - center0 @ rotation.T
    error = float(np.sqrt(np.mean(np.sum((source @ rotation.T + translation - target) ** 2, axis=-1))))
    return translation, rotation, error


def remap_oracle_adjacency(library, old_labels, new_labels, relations, T, R, *, oov=None, beam_size=128):
    """Keep true slot adjacency/order; changed identities get geometry-based ports.

    No target atom indices/coordinates are used to bind new template ports.
    """
    parts = [library.template(int(t), (oov or [None] * len(new_labels))[i]) for i, t in enumerate(new_labels)]
    positions = [xyz @ np.asarray(R[i]).T + T[i] for i, (_, xyz) in enumerate(parts)]
    beams = [(0., [], {})]
    for relation in relations:
        i, j, order = relation['i'], relation['j'], relation['order']
        sites = []
        for slot, endpoint in ((i, 'a'), (j, 'b')):
            options = library.sites(int(new_labels[slot]), (oov or [None] * len(new_labels))[slot])
            options = [s for s in options if order in s['carbon_stub_sanitize_validated_orders']]
            if int(old_labels[slot]) == int(new_labels[slot]):
                options = [s for s in options if s['anchor_core'] == relation[endpoint]]
            sites.append(options)
        alternatives = []
        for a in sites[0]:
            for b in sites[1]:
                ai, bj = a['anchor_core'], b['anchor_core']
                distance = float(np.linalg.norm(positions[i][ai] - positions[j][bj]))
                ideal = 1.5 if order == 1 else 1.3
                alternatives.append((abs(distance - ideal), ai, bj, a, b))
        next_beams = []
        for score, selected, used in beams:
            for penalty, ai, bj, a, b in sorted(alternatives, key=lambda x: x[:3])[:16]:
                if used.get((i, ai), 0) + order > a['capacity_bond_order_units']: continue
                if used.get((j, bj), 0) + order > b['capacity_bond_order_units']: continue
                current = dict(used)
                for key in ((i, ai), (j, bj)): current[key] = current.get(key, 0) + order
                c = dict(relation, a=ai, b=bj)
                c['port_binding'] = 'same_identity_oracle_port' if (old_labels[i] == new_labels[i] and old_labels[j] == new_labels[j]) else 'new_identity_geometric_port'
                next_beams.append((score + penalty, selected + [c], current))
        beams = sorted(next_beams, key=lambda x: x[0])[:beam_size]
        if not beams: raise ChemistryRejected('Predicted identities cannot support the supplied slot adjacency/order')
    for score, selected, _ in beams:
        try:
            assembled = assemble_slots(library, new_labels, selected, oov=oov)
            return selected, assembled, score
        except ChemistryRejected:
            pass
    raise ChemistryRejected('All identity-to-port bindings failed complete chemical validation')


def molecule_metrics(molecule, target, predicted_xyz=None):
    """Full RMSD only for isomorphic chemistry; no cross-identity index shortcut."""
    molecule, target = Chem.RemoveHs(Chem.Mol(molecule)), Chem.RemoveHs(Chem.Mol(target))
    Chem.AssignStereochemistry(molecule, cleanIt=True, force=True)
    Chem.AssignStereochemistry(target, cleanIt=True, force=True)
    fingerprint = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=2048)
    exact = canonical(molecule) == canonical(target)
    result = dict(heavy_atoms=molecule.GetNumAtoms(), target_heavy_atoms=target.GetNumAtoms(),
                  constitution_exact=canonical(molecule, False) == canonical(target, False), stereo_chemical_exact=exact,
                  tanimoto=float(DataStructs.TanimotoSimilarity(fingerprint.GetFingerprint(molecule), fingerprint.GetFingerprint(target))),
                  full_ligand_rmsd_A=None,
                  rmsd_policy='Full receptor-frame heavy-atom RMSD only for identical isomeric chemistry; no alignment; symmetry mappings considered')
    mcs = rdFMCS.FindMCS([molecule, target], timeout=2, ringMatchesRingOnly=True, completeRingsOnly=True)
    result.update(mcs_atoms=int(mcs.numAtoms), mcs_timed_out=bool(mcs.canceled),
                  mcs_generated_coverage=mcs.numAtoms / max(1, molecule.GetNumAtoms()),
                  mcs_target_coverage=mcs.numAtoms / max(1, target.GetNumAtoms()))
    if predicted_xyz is not None and exact:
        matches = molecule.GetSubstructMatches(target, useChirality=True, uniquify=False, maxMatches=1024)
        target_xyz = np.asarray(target.GetConformer().GetPositions())
        pred = np.asarray(predicted_xyz)
        if matches:
            result['full_ligand_rmsd_A'] = min(float(np.sqrt(np.mean(np.sum((pred[list(m)] - target_xyz) ** 2, axis=-1)))) for m in matches)
    return result


def pose_geometry(molecule, xyz, connections, pocket=None):
    xyz=np.asarray(xyz,dtype=float);n=len(xyz)
    adjacency=np.zeros((n,n),dtype=bool)
    periodic=Chem.GetPeriodicTable()
    errors=[];lengths=[]
    for bond in molecule.GetBonds():
        i,j=bond.GetBeginAtomIdx(),bond.GetEndAtomIdx()
        adjacency[i,j]=adjacency[j,i]=True
    for connection in connections:
        i,j=connection['begin'],connection['end']
        distance=float(np.linalg.norm(xyz[i]-xyz[j]))
        radius=periodic.GetRcovalent(molecule.GetAtomWithIdx(i).GetAtomicNum())+periodic.GetRcovalent(molecule.GetAtomWithIdx(j).GetAtomicNum())
        order=molecule.GetBondBetweenAtoms(i,j).GetBondTypeAsDouble()
        ideal=radius*(1. if order==1 else .9 if order==2 else .85)
        lengths.append(distance);errors.append(abs(distance-ideal))
    excluded=adjacency|((adjacency.astype(np.int32)@adjacency.astype(np.int32))>0)|np.eye(n,dtype=bool)
    distances=np.linalg.norm(xyz[:,None]-xyz[None],axis=-1)
    clash=np.triu((distances<1.2)&~excluded,k=1)
    result=dict(interfragment_bonds=len(lengths),interfragment_length_mean_A=float(np.mean(lengths)) if lengths else None,
                interfragment_length_max_A=max(lengths,default=None),bond_error_over_0_5A=sum(x>.5 for x in errors),
                ligand_nonbonded_clashes_under_1_2A=int(clash.sum()))
    if pocket is not None:
        points=pocket.GetConformer().GetPositions()
        points=points[[a.GetIdx() for a in pocket.GetAtoms() if a.GetAtomicNum()>1]]
        minimum=np.linalg.norm(xyz[:,None]-points[None],axis=-1).min(-1)
        result['ligand_atoms_clashing_pocket_under_1_2A']=int((minimum<1.2).sum())
    return result
