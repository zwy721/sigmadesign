#!/usr/bin/env python3
"""JSON-lines classifier process, isolated from the official docking interpreter."""
import argparse
import contextlib
import json
import os
import shutil
import sys
from pathlib import Path

PROJECT=Path(__file__).resolve().parent
LEGACY=PROJECT.parent/'core497_joint_experiments_20261019/training3684'


def resize_slot_metadata(entry,n):
    """Reset every slot-sized supervision/augmentation field before inference."""
    import torch
    entry.update(wrong_type_mask=torch.zeros(n,dtype=torch.bool),
                 type_supervision_mask=torch.zeros(n,dtype=torch.bool),
                 atom_counts=torch.full((n,),2,dtype=torch.long),
                 local_xyz=[torch.zeros(2,3) for _ in range(n)],
                 geometry_training=False,pose_supervision=False)
    entry.pop('geometry_condition',None)
    return entry


def match_geom_features(entry,empty_pg):
    """Use the feature/readout branch actually trained by the GEOM checkpoint.

    Centre only the supplied current poses, never reference/target coordinates.
    The pocket remains external docking context, outside this legacy classifier.
    """
    import torch
    entry.update(source='geom',pg=empty_pg,origin=torch.zeros(3),
                 Tt=entry['Tt']-entry['Tt'].mean(0),pose_supervision=False)
    return entry


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--checkpoint',type=Path,default=LEGACY/'runs/geom_ipa3684_100ep_20261029_cuda01234_bs372_fast/best_loss.pt')
    p.add_argument('--assets',type=Path,required=True)
    p.add_argument('--device',default='cuda:3')
    p.add_argument('--feature-mode',choices=['geom_matched','pdb_original'],default='geom_matched')
    p.add_argument('--use-connection-prior',action='store_true',help='Opt-in diagnostic; packed GEOM did not train this prior channel')
    a=p.parse_args()
    import torch
    torch.set_num_threads(2)
    saved=torch.load(a.checkpoint,weights_only=False,map_location='cpu');cfg=saved['config']
    cfg['joint_options']['connection_graph']='none';cfg['train']['packed_geom']=False;cfg['train']['prepared_geom']=False
    a.assets.mkdir(parents=True,exist_ok=True);config_path=a.assets/'classifier_config.json'
    config_path.write_text(json.dumps(cfg));os.environ['CUTOFF_TRAIN_CONFIG']=str(config_path.resolve())
    sys.path=[str(LEGACY)]+[x for x in sys.path if Path(x or '.').resolve()!=PROJECT]
    with contextlib.redirect_stdout(sys.stderr):
        import runtime
        for name in ('mapping.json','templates.json','properties.json'):
            if not (a.assets/name).exists():shutil.copy2(runtime.ASSETS/name,a.assets/name)
        if not (a.assets/'diffusion_cache').exists():shutil.copytree(runtime.ASSETS/'diffusion_cache',a.assets/'diffusion_cache')
        runtime.ASSETS=a.assets
        from data import PoseDataset,input_graph
        from geom_data import initialize
        from model3684 import ConnectionIPA3684
        model=ConnectionIPA3684(a.device);model.load_state_dict(saved['model'],strict=True);model.eval()
        for parameter in model.parameters():parameter.requires_grad_(False)
        ds=PoseDataset('val',forced_mode='all_mask',forced_t=.02)
    print(json.dumps(dict(ready=True)),flush=True)
    for line in sys.stdin:
        try:
            request=json.loads(line)
            if request.get('close'):break
            with contextlib.redirect_stdout(sys.stderr):
                entry=ds[ds.ids.index(request['id'])]
                n=len(request['T']);origin=entry['origin']
                preserve_oov=bool(request.get('preserve_oov',False)) and n==len(entry['labels'])
                tokens=torch.full((n,),cfg['MASK'],dtype=torch.long)
                templates=[None]*n
                if preserve_oov:
                    for i,label in enumerate(entry['labels']):
                        if label<0:tokens[i]=-1;templates[i]=entry['oov_templates'][i]
                entry.update(tokens=tokens,labels=tokens.clone(),Tt=torch.tensor(request['T'],dtype=torch.float32)-origin,
                             Rt=torch.tensor(request['R'],dtype=torch.float32),t=float(request['t']),
                             oov_templates=templates,source='pdbbind',target_xyz=[torch.zeros(2,3) for _ in range(n)],
                             edges=torch.zeros(n,n,dtype=torch.long),anchors=torch.full((n,n,2),-100,dtype=torch.long),
                             stereo=torch.zeros(n,n,dtype=torch.long),C0=torch.zeros(n,3),Q0=torch.eye(3).repeat(n,1,1),
                             T0=torch.zeros(n,3),R0=torch.eye(3).repeat(n,1,1),fit=torch.zeros(n),
                             dof=torch.zeros(n,dtype=torch.long),axis=torch.zeros(n,3),pose_mask=torch.ones(n,dtype=torch.bool))
                resize_slot_metadata(entry,n)
                prior=torch.zeros(n,n,3);prior[...,0]=1
                for c in request.get('connections',[]):
                    i,j,order=c['i'],c['j'],c['order'];prior[i,j]=prior[j,i]=torch.nn.functional.one_hot(torch.tensor(order),3).float()
                entry['connection_prior']=prior
                if a.feature_mode=='geom_matched':match_geom_features(entry,initialize()['pg'])
                if a.feature_mode=='geom_matched' and not a.use_connection_prior:entry.pop('connection_prior',None)
                entry['graph']=input_graph(entry)
                if (tokens>=0).any() and not (tokens[tokens>=0]==cfg['MASK']).all():raise AssertionError('Oracle identity leaked')
                with torch.inference_mode():output=model._run([entry])[0]['logits'].softmax(-1).cpu()
                values,indices=output.topk(5,-1)
            print(json.dumps(dict(types=indices[:,0].tolist(),confidence=values[:,0].tolist(),feature_mode=a.feature_mode,
                                  connection_prior_used='connection_prior' in entry,
                                  top5=indices.tolist(),top5_probability=values.tolist())),flush=True)
        except Exception as exc:
            import traceback
            print(traceback.format_exc(),file=sys.stderr,flush=True)
            print(json.dumps(dict(error=repr(exc))),flush=True)


if __name__=='__main__':main()
