#!/usr/bin/env python3
"""Matched-budget ordinary / skeleton-plus-port beam experiment.

Generation and target-free ranking finish before diagnostic truth is read.
Explicit oracle diagnostics never inject a candidate into either sample pool.
"""
import argparse
from dataclasses import asdict,replace
import hashlib
import json
import os
from pathlib import Path
import time
import traceback

import bootstrap
import numpy as np
import torch

from collect_topology_candidates import evaluation_labels,BASE
from evaluate_robust_connections import edge_set
from evaluate_topology_search import diverse_hypotheses
from hierarchical_topology import SearchConfig,adjacency_key,option_groups,port_beam,hierarchical_search
from oracle_graph import assemble
from prepare_hierarchical_experiment import ROOT
from run_connection_trajectories import save_result
from run_validation import load_official,seed_all,write_json
from topology_diversity import skeleton_key,complete_key
from topology_reranker import extract_features,analytical_scores
from trajectory_connections import ConnectionRuntime,GraphFactory,load_connection,run_trajectory
from validation import digest
from vocab_chemistry import VocabLibrary,canonical


def colored_adjacency(labels,edges):
    return skeleton_key(labels,[dict(i=e['i'],j=e['j'],order=1) for e in edges])


def coverage(candidates,fixture):
    truth=fixture['oracle_edges'];target=canonical(fixture['target_mol'],False)
    return dict(labelled_skeleton=any(adjacency_key(c['connections'])==adjacency_key(truth) for c in candidates),
        colored_skeleton=any(colored_adjacency(fixture['labels'],c['connections'])==colored_adjacency(fixture['labels'],truth) for c in candidates),
        exact_connections=any(edge_set(c['connections'])==edge_set(truth) for c in candidates),
        constitution=any(c['constitution']==target for c in candidates))


def oracle_diagnostics(runtime,prediction,search,ordinary,fixture,config):
    """DIAGNOSTIC ONLY: true adjacency is supplied solely to a separate beam."""
    truth=fixture['oracle_edges'];groups=option_groups(runtime,prediction)
    true_pairs=adjacency_key(truth);required=edge_set(truth)
    support={tuple((e[k] for k in ('i','j','a','b','order'))) for vv in groups.values() for e in vv}
    limited={tuple((e[k] for k in ('i','j','a','b','order'))) for vv in groups.values() for e in vv[:config.pair_options]}
    before=time.time();forced,stats=port_beam(runtime,true_pairs,groups,config=config,limit=128)
    wide,wide_stats=port_beam(runtime,true_pairs,groups,config=replace(config,port_width=256,per_skeleton=128),limit=128)
    def table(cc):return {str(k):dict(count=len(cc[:k]),**coverage(cc[:k],fixture)) for k in [1,4,8,16,64,128]}
    skeleton_coverage=dict(labelled_skeleton=any(tuple(s['pairs'])==true_pairs for s in search['skeletons']),
        colored_skeleton=any(colored_adjacency(runtime.labels,[dict(i=i,j=j,order=1) for i,j in s['pairs']])==colored_adjacency(runtime.labels,truth) for s in search['skeletons']))
    pool=search['pool']
    return dict(diagnostic_only=True,true_topology_injected_into_generation=False,
        required_connections=len(required),true_connections_in_frozen_candidate_support=len(required&support),
        true_connections_in_truncated_pair_options=len(required&limited),
        true_skeleton_in_stage1=skeleton_coverage,
        true_skeleton_port_beam=table(forced),true_skeleton_wide_port_beam=table(wide),
        true_skeleton_port_statistics=stats,true_skeleton_wide_statistics=wide_stats,
        ordinary_initial={str(k):coverage(ordinary[:k],fixture) for k in [1,4,8]},
        hierarchical_initial={str(k):coverage(search['candidates'][:k],fixture) for k in [1,4,8]},
        hierarchical_all_internal_candidates=dict(count=len(pool),**coverage(pool,fixture)),
        diagnostic_seconds=time.time()-before)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--config',type=Path)
    p.add_argument('--ids',required=True);p.add_argument('--seeds',required=True)
    p.add_argument('--role',choices=['train','calibration','holdout'],required=True)
    p.add_argument('--stage',choices=['diagnose','sample'],default='sample');p.add_argument('--device',default='cuda:6')
    p.add_argument('--resume',action='store_true');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(2);os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    torch.use_deterministic_algorithms(True);torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    config=SearchConfig(**json.loads(a.config.read_text())) if a.config else SearchConfig()
    cohorts=json.loads((a.root/'cohorts.json').read_text());source=Path(cohorts['source_root'])
    ids=a.ids.split(',');role_key='casf_holdout' if a.role=='holdout' else a.role
    if not set(ids)<=set(cohorts[role_key]):raise ValueError('IDs outside chemistry-disjoint split')
    if a.role=='holdout' and (not a.config or not (a.root/'search_lock.json').exists()):raise ValueError('Holdout requires development-frozen search config')
    if a.role=='holdout':
        lock=json.loads((a.root/'search_lock.json').read_text())
        if lock['config']!=asdict(config):raise ValueError('Holdout search differs from locked config')
    sources=['hierarchical_topology.py','run_hierarchical_experiment.py','trajectory_connections.py','vocab_chemistry.py','topology_reranker.py','evaluate_topology_search.py']
    contract=dict(config=asdict(config),role=a.role,stage=a.stage,seeds=list(map(int,a.seeds.split(','))),ids=ids,
        source_sha256={n:digest(bootstrap.PROJECT/n) for n in sources},connection_checkpoint_sha256=digest(BASE),
        official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),cohorts_sha256=digest(a.root/'cohorts.json'))
    if a.role=='holdout' and contract['source_sha256']!=lock['source_sha256']:raise ValueError('Holdout source differs from development lock')
    protocol=a.output/'protocol.json'
    if protocol.exists():
        if not a.resume or json.loads(protocol.read_text())!=contract:raise ValueError('Existing run contract differs; choose new output')
    write_json(protocol,contract)
    den=load_official(bootstrap.CHECKPOINT,a.output,device);lib=VocabLibrary();checkpoint=load_connection(BASE,device)
    report=dict(contract=contract,groups=[],failures=[],weights_updated=False,reranker_used=False,truth_repair=False)
    started=time.time()
    for pid in ids:
        fixture_path=source/f'inputs/{pid}/fixture.pt'
        if digest(fixture_path)!=cohorts['source_fixture_sha256'][pid]:raise ValueError('Fixture changed')
        fixture=torch.load(fixture_path,weights_only=False)
        if bool(fixture['audit']['casf'])!=(a.role=='holdout'):raise ValueError('Source split mismatch')
        runtime=ConnectionRuntime(lib,checkpoint,fixture['labels'],fixture['oov'],device,policy='wide',head='full')
        factory=GraphFactory(lib,fixture['labels'],fixture['oov'],fixture['context'])
        for seed in contract['seeds']:
            folder=a.output/f'{pid}_{seed}';folder.mkdir(exist_ok=True)
            if a.resume and (folder/'group.json').exists():
                report['groups'].append(json.loads((folder/'group.json').read_text()));continue
            seed_all(seed);C,Q=den.diffuser.sample_ref(len(fixture['labels']),device)
            T=C.cpu().numpy()*2.7+np.asarray(fixture['context']['pocket_com']).reshape(3)
            prediction=runtime.predict(T,Q.cpu().numpy(),.9)
            before=time.time();ordinary,considered=diverse_hypotheses(runtime,prediction,8);ordinary_seconds=time.time()-before
            before=time.time();search=hierarchical_search(runtime,prediction,k=8,config=config);hierarchical_seconds=time.time()-before
            # Immutable generation artifact is written before touching truth.
            write_json(folder/'generation.json',dict(ordinary=ordinary,hierarchical=search,
                ordinary_seconds=ordinary_seconds,hierarchical_seconds=hierarchical_seconds,truth_used=False))
            torch.save(dict(T=T,R=Q.cpu().numpy(),t=.9,pool=prediction['pool'],meta=prediction['meta'],p=prediction['p'],sp=prediction['sp']),folder/'initial_prediction.pt')
            methods=dict(ordinary=ordinary,hierarchical=search['candidates']);candidates={};method_keys={}
            for method,cc in methods.items():
                method_keys[method]=[]
                for c in cc:
                    key=hashlib.sha256(json.dumps(complete_key(c['connections'])).encode()).hexdigest()[:16]
                    method_keys[method].append(key);candidates[key]=c
            rows=[];labels=[]
            if a.stage=='sample':
                for key,c in candidates.items():
                    dest=folder/key;dest.mkdir(exist_ok=True);before=time.time()
                    if a.resume and (dest/'candidate.json').exists() and (dest/'labels.json').exists():
                        rows.append(json.loads((dest/'candidate.json').read_text()));labels.append(dict(key=key,**json.loads((dest/'labels.json').read_text())));continue
                    try:
                        result=run_trajectory(den,runtime,factory,seed=seed,steps=25,mode='closed',initial_edges=c['connections'])
                        features=extract_features(runtime,spec=result['spec'],connections=result['connections'],frames=result['frames'],positions=result['positions'],pocket=fixture['context']['pocket'])
                        row=dict(key=key,success=True,features=features,scores=analytical_scores(features),initial_connections=c['connections'],
                            final_connections=result['connections'],constitution=canonical(assemble(result['spec']),False),
                            final_skeleton=colored_adjacency(runtime.labels,result['connections']),revisions=result['revisions'],
                            seconds=time.time()-before,backbone_evaluations=24)
                        save_result(dest,result,fixture);write_json(dest/'candidate.json',row)
                        label=evaluation_labels(fixture,result);write_json(dest/'labels.json',label);labels.append(dict(key=key,**label))
                    except Exception as exc:
                        if isinstance(exc,torch.OutOfMemoryError):raise
                        (dest/'error.txt').write_text(traceback.format_exc());row=dict(key=key,success=False,error=repr(exc),seconds=time.time()-before)
                        write_json(dest/'candidate.json',row);report['failures'].append(dict(id=pid,seed=seed,**row))
                    rows.append(row);print('SAMPLE',pid,seed,key,row['success'],'elapsed',round(time.time()-started),flush=True)
            # Separate truth-only diagnosis AFTER all ordinary generation/ranking.
            diagnostic=oracle_diagnostics(runtime,prediction,search,ordinary,fixture,config)
            write_json(folder/'oracle_diagnostic.json',diagnostic);write_json(folder/'labels.json',labels)
            group=dict(id=pid,seed=seed,role=a.role,slots=len(runtime.labels),methods=method_keys,candidates=rows,
                oracle_diagnostic=diagnostic,search_seconds=dict(ordinary=ordinary_seconds,hierarchical=hierarchical_seconds),
                ordinary_port_graphs_considered=considered,labels_path=str((folder/'labels.json').resolve()),
                generation_path=str((folder/'generation.json').resolve()),enrichment=[])
            write_json(folder/'group.json',group);report['groups'].append(group);write_json(a.output/'report.partial.json',report)
            print('GROUP',a.stage,pid,seed,'search_seconds',round(hierarchical_seconds,3),'pool',len(search['pool']),'elapsed',round(time.time()-started),flush=True)
    report['elapsed_seconds']=time.time()-started;write_json(a.output/'report.json',report)


if __name__=='__main__':main()
