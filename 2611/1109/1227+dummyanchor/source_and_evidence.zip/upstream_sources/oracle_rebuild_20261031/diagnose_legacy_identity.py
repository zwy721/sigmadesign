#!/usr/bin/env python3
"""Isolated checkpoint audit and paired train/CASF inference ablations."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

PROJECT = Path(__file__).resolve().parent
WORK = PROJECT.parent
LEGACY = WORK / 'core497_joint_experiments_20261019/training3684'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--checkpoint', type=Path, default=LEGACY/'runs/geom_ipa3684_100ep_20261029_cuda01234_bs372_fast/best_loss.pt')
    p.add_argument('--device', default='cpu')
    p.add_argument('--train-limit', type=int, default=64)
    p.add_argument('--val-limit', type=int, default=0)
    p.add_argument('--times', default='0,.2,.6,.9')
    p.add_argument('--branches', default='pdb_original,geom_matched,geom_oracle_adjacency')
    p.add_argument('--geom-limit', type=int, default=64)
    p.add_argument('--threads', type=int, default=2)
    p.add_argument('--true-centers', action='store_true',help='Controlled identity study: perturb R, restore true fragment centres')
    p.add_argument('--resume-report',action='store_true',help='Skip completed condition rows after an interrupted audit')
    a = p.parse_args()
    import torch
    torch.set_num_threads(a.threads)
    if a.device.startswith('cuda'):
        torch.cuda.set_device(torch.device(a.device))
        torch.cuda.set_per_process_memory_fraction(.15, torch.device(a.device))
    from prediction_metrics import identity_metrics, ranked_row
    a.output.mkdir(parents=True, exist_ok=True)
    saved = torch.load(a.checkpoint, map_location='cpu', weights_only=False)
    cfg = copy.deepcopy(saved['config'])
    cfg['joint_options']['connection_graph'] = 'none'
    cfg['train'].update(packed_geom=False, prepared_geom=False)
    config_path = a.output/'config.json'
    config_path.write_text(json.dumps(cfg))
    os.environ['CUTOFF_TRAIN_CONFIG'] = str(config_path.resolve())
    sys.path = [str(LEGACY)] + [x for x in sys.path if Path(x or '.').resolve() != PROJECT]
    import runtime
    assets = a.output/'assets'; assets.mkdir(exist_ok=True)
    for name in ('mapping.json', 'templates.json', 'properties.json','train_ids.json','dev_ids.json'):
        shutil.copy2(runtime.ASSETS/name, assets/name)
    shutil.copytree(runtime.ASSETS/'diffusion_cache', assets/'diffusion_cache', dirs_exist_ok=True)
    runtime.ASSETS = assets
    from data import PoseDataset, input_graph
    from geom_data import initialize, seed_cpu, GeomDataset
    from model3684 import ConnectionIPA3684
    ctx = initialize()
    model = ConnectionIPA3684(a.device).eval()
    model.load_state_dict(saved['model'], strict=True)
    for v in model.parameters(): v.requires_grad_(False)
    properties = json.loads((assets/'properties.json').read_text())
    frequency = [r['train_occurrences'] for r in properties]
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    observed = {name: sha(assets/name) for name in ('mapping.json', 'templates.json', 'properties.json')}
    expected = saved['provenance']['assets_sha256']
    assert all(expected[k] == v for k, v in observed.items()), 'Checkpoint vocabulary changed'
    report = dict(checkpoint=str(a.checkpoint), checkpoint_sha256=sha(a.checkpoint), progress=saved['progress'],
        asset_hash_match=True, asset_sha256=observed, K=cfg['K'], MASK=cfg['MASK'],
        input_audit=dict(mask_atoms=4, masked_atom_features='zeroed; learned MASK roles',
            mask_chemical_bonds='removed before native network', oov='supplied chemistry, excluded from identity metrics',
            train_masks=dict(all_mask=.4, partial=.5, known=.1), train_t_range=[.02,.98],
            source_switch='PDB uses CoreAttention cross-attention; GEOM uses LigandAttention, no pocket',
            packed_path='GEOM packed feedback does not accept connection_prior; config probability alone does not enable it'),
        true_centers_restored=a.true_centers, levels={}, failures=[])
    times = list(map(float,a.times.split(',')))
    branches = a.branches.split(',')
    if (a.output/'report.json').exists():
        if not a.resume_report:raise ValueError('Existing audit requires --resume-report')
        old=json.loads((a.output/'report.json').read_text())
        if old['checkpoint_sha256']!=report['checkpoint_sha256'] or old.get('true_centers_restored',False)!=a.true_centers:
            raise ValueError('Resume audit protocol differs')
        report=old
        report['true_centers_restored']=a.true_centers
    started = time.time()
    for split, limit in [('train',a.train_limit),('val',a.val_limit)]:
        ds = PoseDataset(split, forced_mode='all_mask', forced_t=.02)
        ds.ids = sorted(ds.ids, key=lambda pid: hashlib.sha256(('identity-diagnostic:'+pid).encode()).hexdigest())
        if limit: ds.ids = ds.ids[:limit]
        for t in times:
            for branch in branches:
                key=f'{split}/{t}/{branch}'
                if key in report['levels']:continue
                rows=[]
                for index, pid in enumerate(ds.ids):
                    try:
                        entry = ds[index]
                        entry.pop('geometry_condition',None)
                        entry['pose_supervision']=False;entry['geometry_training']=False
                        seed_cpu(runtime.stable('paired-identity-noise',pid,t))
                        n=len(entry['tokens'])
                        if t == 0:
                            T,R=entry['T0'].clone(),entry['R0'].clone()
                        else:
                            # Match cached native rigid-state forward diffusion exactly.
                            from native_common import canonical_state
                            noisy=ctx['diff'].forward_marginal(entry['C0'],entry['Q0'],torch.full((n,),t))
                            T,R=canonical_state(noisy['T_t']*2.7,noisy['R_t'],entry['refR'],entry['offset'])
                        if a.true_centers:T=entry['T0'].clone()
                        entry.update(Tt=T,Rt=R,t=max(.02,t))
                        if branch != 'pdb_original':
                            entry.update(source='geom',pg=ctx['pg'],origin=torch.zeros(3),Tt=T-T.mean(0))
                            entry['graph']=input_graph(entry)
                        if branch.endswith('oracle_adjacency') or branch=='pdb_original':
                            entry['connection_prior']=torch.nn.functional.one_hot(entry['edges'],3).float()
                        with torch.inference_mode(): prediction=model._run([entry])[0]
                        rows.append(ranked_row(pid,entry['labels'].tolist(),prediction['logits']))
                    except Exception as exc:
                        import traceback
                        report['failures'].append(dict(split=split,t=t,branch=branch,id=pid,error=repr(exc),traceback=traceback.format_exc()))
                    if (index+1)%32==0:print('PROGRESS',split,t,branch,index+1,'seconds',round(time.time()-started),flush=True)
                key=f'{split}/{t}/{branch}'
                report['levels'][key]=dict(rows=rows,metrics=identity_metrics(rows,frequency))
                runtime.write_json(a.output/'report.json',report)
                print('METRICS',key,report['levels'][key]['metrics'],flush=True)
    for split in ['train','dev']:
        if a.geom_limit <= 0: break
        for t in times:
            key=f'geom_{split}/{max(.02,t)}/training_matched'
            if key in report['levels']:continue
            # Same loader, masks, molecular frame and noise as GEOM training.
            ds=GeomDataset(split,limit=a.geom_limit,forced_mode='all_mask',forced_t=max(.02,t))
            rows=[]
            for index,pid in enumerate(ds.ids):
                e=ds[index]
                if t==0:
                    # GEOM from_record doesn't expose clean T; use marginal .02 as a labelled low-noise control.
                    pass
                with torch.inference_mode():pred=model._run([e])[0]
                rows.append(ranked_row(pid,e['labels'].tolist(),pred['logits']))
            key=f'geom_{split}/{max(.02,t)}/training_matched'
            report['levels'][key]=dict(rows=rows,metrics=identity_metrics(rows,frequency))
            runtime.write_json(a.output/'report.json',report)
            print('METRICS',key,report['levels'][key]['metrics'],flush=True)
    report['elapsed_seconds']=time.time()-started
    report['status']='complete'
    runtime.write_json(a.output/'report.json',report)


if __name__=='__main__': main()
