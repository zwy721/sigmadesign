#!/usr/bin/env python3
"""Different 3684 partitions: actual template chemistry, geometry and docking."""
import argparse
import copy
import json
import os
import time
import traceback
from pathlib import Path

import bootstrap
import numpy as np
import torch
from rdkit import Chem

from oracle_graph import assemble, rebuild
from run_validation import docking, load_official, seed_all, write_json
from serialization import save_graph
from validation import digest, inventory
from vocab_chemistry import (VocabLibrary, assemble_slots, atom_correspondence, canonical,
                            embedded_reference, explicit_oov, oracle_chiral, oracle_cip, spec_from_slots, true_connections)

DEFAULT_IDS = '1a30,3b1m,3mss,4agn,4m0y,5tmn'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', type=Path, default=bootstrap.PROJECT / 'results/acceptance')
    p.add_argument('--output', type=Path, default=bootstrap.PROJECT / 'results/stage1')
    p.add_argument('--ids', default=DEFAULT_IDS)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--seeds', default='0,1,2')
    p.add_argument('--steps', type=int, default=25)
    p.add_argument('--graphs-only', action='store_true')
    a = p.parse_args()
    a.output = a.output.resolve()
    if (a.output / 'report.json').exists():
        p.error('Choose a new output folder')
    a.output.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    device = torch.device(a.device)
    if device.type == 'cuda': torch.cuda.set_device(device)
    lib = VocabLibrary()
    baseline_report = json.loads((a.baseline / 'report.json').read_text())
    baseline_rows = {r['id']: r for r in baseline_report['rows']}
    manifest = dict(stage=1, ids=a.ids.split(','), seeds=list(map(int, a.seeds.split(','))),
                    steps=a.steps, checkpoint_sha256=digest(bootstrap.CHECKPOINT),
                    template_sha256=digest(lib.assets / 'templates.json'),
                    source_sha256={name: digest(bootstrap.PROJECT / name) for name in
                                   ('vocab_chemistry.py', 'run_stage1.py', 'oracle_graph.py')},
                    protocol='Fixed true 3684 identities and connections. Actual H-capped template assembly. '
                             'Two unbound references: shared official inference xyz, independent RDKit reference. '
                             'Different partitions are evaluated by chemistry, geometry and pose, not graph equality.')
    result = dict(manifest=manifest, rows=[], failures=[], accepted=False, stage='running')
    den = None if a.graphs_only else load_official(bootstrap.CHECKPOINT, a.output, device)
    for pid in manifest['ids']:
        out = a.output / pid
        out.mkdir(exist_ok=True)
        try:
            original_graph = torch.load(a.baseline / pid / 'official_graph.pt', weights_only=False)
            context = torch.load(a.baseline / pid / 'pocket_context.pt', weights_only=False)
            torch.save(context, out / 'pocket_context.pt')
            original = original_graph.mol_info['original']
            record = torch.load(bootstrap.RECORDS / f'{pid}.pt', weights_only=False)
            labels, oov, connections = record['labels'].tolist(), explicit_oov(record), true_connections(record)
            mapping = atom_correspondence(record, original)
            cip = oracle_cip(record, original, mapping)
            chiral = oracle_chiral(record, original, mapping)
            raw_mol, groups, cuts = assemble_slots(lib, labels, connections, oov=oov)
            raw_stereo_equal = canonical(raw_mol) == canonical(original)
            mol, groups, cuts = assemble_slots(lib, labels, connections, oov=oov, cip=cip, chiral=chiral)
            if canonical(mol) != canonical(original):
                raise AssertionError(f'3684 assembly differs in chemistry: {canonical(mol)} vs {canonical(original)}')
            target = torch.as_tensor(original.GetConformer().GetPositions()[mapping], dtype=torch.float64)
            # Replay current training template poses ONLY as a geometry audit.
            # These coordinates are never used in either docking reference.
            replay = []
            for i, label in enumerate(labels):
                _, xyz = lib.template(label, oov[i])
                replay.append(xyz @ record['R0'][i].numpy().T + record['T0'][i].numpy()
                              + np.asarray(record['graph']['case']['origin']))
            replay = torch.as_tensor(np.concatenate(replay))
            geometry_rmsd = float(((replay - target).square().sum(-1).mean()).sqrt())
            official_fragmented = original_graph.mol_info['fragmented']
            shared_xyz = official_fragmented.GetConformer().GetPositions()[mapping]
            shared = Chem.Mol(mol)
            for k, point in enumerate(shared_xyz): shared.GetConformer().SetAtomPosition(k, point)
            independent = embedded_reference(mol, seed=0)
            row = dict(id=pid, true_labels=labels, oov_slots=sum(x < 0 for x in labels),
                       official_fragments=int(original_graph.mol_info['num_fragments']),
                       vocab_fragments=len(labels), same_partition=baseline_rows[pid]['partition3684']['same_partition'],
                       constitution_equal=canonical(raw_mol, False) == canonical(original, False),
                       stereo_equal_without_attachment_context=raw_stereo_equal,
                       stereo_equal_with_explicit_cip=True, explicit_cip_conditions=cip,
                       explicit_chiral_conditions=chiral,
                       template_pose_replay_rmsd_A=geometry_rmsd,
                       new_atom_to_original=mapping, references={}, docking=[])
            write_json(out / 'conditions.json', dict(labels=labels, connections=connections, cip=cip, chiral=chiral))
            for refname, reference in [('shared_official_reference', shared), ('independent_library_reference', independent)]:
                spec = spec_from_slots(reference, groups, cuts, labels, refname)
                write_json(out / f'{refname}.json', spec)
                restored = assemble(json.loads((out / f'{refname}.json').read_text()))
                coordinate_error = float(np.max(np.abs(restored.GetConformer().GetPositions()
                                                       - reference.GetConformer().GetPositions())))
                if coordinate_error != 0:
                    raise AssertionError('Chemical graph export changed reference atom coordinates')
                graph = rebuild(spec, **context)
                save_graph(graph, out / f'{refname}_graph.pt')
                row['references'][refname] = dict(graph=inventory(graph), atom_coordinate_roundtrip_max_A=coordinate_error)
                for seed in ([] if a.graphs_only else manifest['seeds']):
                    pred, _, stats = docking(den, graph, seed=seed, steps=a.steps, device=device,
                                             noise_scale=0., save=out / f'{refname}_seed{seed}.pt')
                    stats['rmsd_A'] = float(((pred.double() - target).square().sum(-1).mean()).sqrt())
                    row['docking'].append(dict(reference=refname, seed=seed, **stats))
                    print(pid, refname, seed, 'RMSD', stats['rmsd_A'], flush=True)
            result['rows'].append(row)
            print(pid, 'CHEMISTRY OK', 'stereo context needed', not raw_stereo_equal,
                  'template pose replay RMSD', geometry_rmsd, flush=True)
        except Exception as exc:
            result['failures'].append(dict(id=pid, error=repr(exc), traceback=traceback.format_exc()))
            print('FAILED', pid, traceback.format_exc(), flush=True)
        finally:
            write_json(a.output / 'report.json', result)
    summary = {}
    for kind in ['official_baseline', 'shared_official_reference', 'independent_library_reference']:
        vals = ([s['official']['rmsd_A'] for pid in manifest['ids'] for s in baseline_rows[pid]['docking']
                 if s['seed'] in manifest['seeds']] if kind == 'official_baseline' else
                [s['rmsd_A'] for r in result['rows'] for s in r['docking'] if s['reference'] == kind])
        if vals:
            summary[kind] = dict(n=len(vals), mean_A=float(np.mean(vals)), median_A=float(np.median(vals)),
                                 under2_fraction=float(np.mean(np.asarray(vals) < 2)))
    result.update(summary=summary, accepted=len(result['rows']) == len(manifest['ids']) and not result['failures'],
                  stage='graphs_complete' if a.graphs_only else 'docking_complete')
    write_json(a.output / 'report.json', result)
    print('ACCEPTED', result['accepted'], 'SUMMARY', summary, flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
