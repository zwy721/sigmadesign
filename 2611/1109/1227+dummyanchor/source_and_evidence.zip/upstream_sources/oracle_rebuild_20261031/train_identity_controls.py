#!/usr/bin/env python3
"""Independent all-MASK identity experiments with oracle centres/adjacency.

Three separately trained heads share frame features and architecture width:
direct classification, chemical-template retrieval, iterative soft identity
correction. This never imports, updates or calls the official docking backbone.
"""
import argparse
import json
import math
from pathlib import Path
import time

import bootstrap
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from rdkit import Chem
from rdkit.Chem import rdFingerprintGenerator, Descriptors, rdMolDescriptors

from prediction_data import compact_cache,identity_features,make_diffuser,perturb,LEVELS,stable
from prediction_metrics import identity_metrics,ranked_row
from run_validation import write_json
from validation import digest
from vocab_chemistry import VocabLibrary


def chemistry_descriptors(lib):
    """Candidate library chemistry, shared by every input; no target lookup."""
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=256)
    rows=[]
    for label in range(len(lib.ids)):
        m,xyz=lib.template(label);prop=lib.properties[label]
        fp=gen.GetFingerprintAsNumPy(m).astype(np.float32)
        atoms=list(m.GetAtoms());eig=np.linalg.eigvalsh((xyz-xyz.mean(0)).T@(xyz-xyz.mean(0))/len(xyz))
        scalar=[m.GetNumAtoms()/44,Descriptors.MolWt(m)/600,prop['formal_charge']/3,
                rdMolDescriptors.CalcNumRings(m)/6,len(prop['candidate_sites'])/20,
                sum(s['capacity_bond_order_units'] for s in prop['candidate_sites'])/40,
                sum(a.GetIsAromatic() for a in atoms)/44]
        scalar += [sum(a.GetAtomicNum()==z for a in atoms)/20 for z in (6,7,8,9,15,16,17,35,53)]
        rows.append(np.concatenate([fp,scalar,np.sqrt(eig.clip(0))/5]))
    return torch.tensor(np.asarray(rows),dtype=torch.float32)


class IdentityHead(nn.Module):
    def __init__(self,features,descriptor,kind,prior):
        super().__init__();self.kind=kind
        self.encoder=nn.Sequential(nn.LayerNorm(features),nn.Linear(features,256),nn.SiLU(),nn.Linear(256,128),nn.SiLU())
        if kind=='retrieval':
            self.register_buffer('descriptors',descriptor)
            self.template_encoder=nn.Sequential(nn.Linear(descriptor.shape[-1],128),nn.SiLU(),nn.Linear(128,128))
            self.query=nn.Linear(128,128);self.scale=nn.Parameter(torch.tensor(math.log(10.)))
            self.bias=nn.Parameter(prior.clone())
        else:
            self.readout=nn.Linear(128,3684)
            with torch.no_grad():self.readout.bias.copy_(prior)
        if kind=='iterative':
            self.type_embedding=nn.Embedding(3684,32)
            self.correct=nn.Sequential(nn.Linear(128+64,128),nn.SiLU(),nn.Linear(128,128))
            self.norm=nn.LayerNorm(128)

    def logits(self,h):
        if self.kind=='retrieval':
            query=F.normalize(self.query(h),dim=-1)
            key=F.normalize(self.template_encoder(self.descriptors),dim=-1)
            return self.scale.exp().clamp(max=50)*query@key.T+self.bias
        return self.readout(h)

    def forward(self,x,adjacency,iterations=2):
        h=self.encoder(x);initial=self.logits(h);logits=initial
        if self.kind=='iterative':
            for _ in range(iterations):
                p=logits.softmax(-1)
                own=p@self.type_embedding.weight
                neighbour=adjacency@own/adjacency.sum(-1,keepdim=True).clamp_min(1)
                h=self.norm(h+.1*self.correct(torch.cat([h,own,neighbour],-1)))
                logits=self.logits(h)
        return logits,initial


def feature_dataset(rows,diffuser,*,augment=False):
    features,labels,ptr=[],[],[0];adj=[]
    for r in rows:
        # Controlled study always keeps true centres; only R is noised.
        views=[('clean',0)] if not augment else [('clean',0),('low',0),('medium',0),('high',0)]
        for level,seed in views:
            t=LEVELS[level];T,R=perturb(r,diffuser,t,seed,true_centers=True)
            x=identity_features(T,R,r['edges'].numpy(),t)
            features.append(x);labels.append(r['labels']);adj.append(r['edges'].float().clamp_max(1))
            ptr.append(ptr[-1]+len(x))
    return dict(x=torch.cat(features),labels=torch.cat(labels),ptr=ptr,adj=adj)


def batches(data,indices,batch,device):
    for offset in range(0,len(indices),batch):
        selected=indices[offset:offset+batch]
        xx=[];yy=[];aa=[]
        for k in selected:
            sl=slice(data['ptr'][k],data['ptr'][k+1]);xx.append(data['x'][sl]);yy.append(data['labels'][sl]);aa.append(data['adj'][k])
        yield torch.cat(xx).to(device),torch.cat(yy).to(device),torch.block_diag(*aa).to(device)


@torch.inference_mode()
def evaluate(model,rows,diffuser,lib,device,batch=64):
    model.eval();report={}
    frequency=[p['train_occurrences'] for p in lib.properties]
    for level,t in LEVELS.items():
        predicted=[];initial=[];loss=total=0
        # Same inputs and seeds for all three methods.
        views=[]
        for r in rows:
            T,R=perturb(r,diffuser,t,1,true_centers=True)
            views.append(dict(id=r['id'],labels=r['labels'],x=identity_features(T,R,r['edges'].numpy(),t),adj=r['edges'].float().clamp_max(1)))
        for start in range(0,len(views),batch):
            part=views[start:start+batch];sizes=[len(r['labels']) for r in part]
            x=torch.cat([r['x'] for r in part]).to(device);y=torch.cat([r['labels'] for r in part]).to(device)
            a=torch.block_diag(*[r['adj'] for r in part]).to(device)
            logits,first=model(x,a);known=y>=0
            if known.any():loss+=float(F.cross_entropy(logits[known],y[known],reduction='sum'));total+=int(known.sum())
            for r,out,raw in zip(part,logits.split(sizes),first.split(sizes)):
                predicted.append(ranked_row(r['id'],r['labels'].tolist(),out))
                initial.append(ranked_row(r['id'],r['labels'].tolist(),raw))
        report[level]=dict(metrics=identity_metrics(predicted,frequency),rows=predicted,
                           initial_metrics=identity_metrics(initial,frequency),loss=loss/max(1,total))
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--cache',type=Path,required=True)
    p.add_argument('--device',default='cpu');p.add_argument('--epochs',type=int,default=12)
    p.add_argument('--methods',default='direct,retrieval,iterative');p.add_argument('--batch-molecules',type=int,default=64)
    p.add_argument('--threads',type=int,default=4);p.add_argument('--workers',type=int,default=4)
    p.add_argument('--resume',action='store_true');p.add_argument('--build-cache-only',action='store_true')
    a=p.parse_args()
    if a.epochs<1 or a.batch_molecules<1:p.error('Epochs and batch size must be positive')
    if not set(a.methods.split(','))<={'direct','retrieval','iterative'}:p.error('Unknown identity method')
    a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(a.threads)
    data=compact_cache(a.cache,a.workers)
    if data['failures']:raise RuntimeError(f"Dataset failures: {data['failures'][:3]}")
    if a.build_cache_only:return
    lib=VocabLibrary();diff=make_diffuser(a.output);descriptor=chemistry_descriptors(lib)
    featurepath=a.cache/'identity_features_true_centers.pt'
    if featurepath.exists():train=torch.load(featurepath,weights_only=False)
    else:train=feature_dataset(data['train'],diff,augment=True);torch.save(train,featurepath)
    count=torch.bincount(train['labels'][train['labels']>=0],minlength=3684).float()
    prior=((count+1)/(count.sum()+3684)).log()
    # Neither class priors nor descriptors use validation labels.
    write_json(a.output/'protocol.json',dict(architecture='Independent frame/adjacency identity heads; official backbone frozen',
        train_molecules=len(data['train']),val_molecules=len(data['val']),train_views=4,
        controls='True centres, true slot adjacency/bond order, supplied N. All identities MASK, including OOV slots; '
                 'no atom-count/port/atom features or native target geometry as inputs. OOV excluded from type CE/metrics.',
        noise='Native VP/IGSO3 marginal followed by restoring true fragment centres; only orientation is noised.',
        seeds=dict(train_noise=0,val_noise=1),epochs=a.epochs,split_sha256=data['split_sha256'],
        template_sha256=digest(lib.assets/'templates.json'),mapping_sha256=digest(lib.assets/'mapping.json')))
    device=torch.device(a.device)
    if device.type=='cuda':
        torch.cuda.set_device(device);torch.cuda.set_per_process_memory_fraction(.15,device)
    descriptor=descriptor.to(device);prior=prior.to(device)
    train_probe=sorted(data['train'],key=lambda r:stable('identity-train-probe',r['id']))[:512]
    summary=json.loads((a.output/'summary.json').read_text()) if (a.output/'summary.json').exists() else {}
    for kind in a.methods.split(','):
        torch.manual_seed(731)
        out=a.output/kind;out.mkdir(exist_ok=True)
        model=IdentityHead(train['x'].shape[-1],descriptor,kind,prior).to(device)
        opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
        history=[];start=0;best=-1
        if (out/'latest.pt').exists():
            if not a.resume:raise ValueError('Existing experiment requires --resume')
            s=torch.load(out/'latest.pt',map_location=device,weights_only=False)
            if s['split_sha256']!=data['split_sha256'] or s['kind']!=kind or s['feature_dim']!=train['x'].shape[-1]:
                raise ValueError('Resume dataset, architecture or input features differ')
            model.load_state_dict(s['model'],strict=True);opt.load_state_dict(s['optimizer'])
            start=s['epoch'];history=s['history'];best=s['best']
        began=time.time()
        for epoch in range(start,a.epochs):
            model.train();rng=np.random.default_rng(731+epoch);order=rng.permutation(len(train['adj'])).tolist()
            accumulated=slots=0
            for x,y,adj in batches(train,order,a.batch_molecules,device):
                known=y>=0
                if not known.any():continue
                opt.zero_grad(set_to_none=True);logits,initial=model(x,adj)
                loss=F.cross_entropy(logits[known],y[known])
                if kind=='iterative':loss=loss+.3*F.cross_entropy(initial[known],y[known])
                loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
                accumulated+=float(loss.detach())*int(known.sum());slots+=int(known.sum())
            # Validation chooses the best independent identity checkpoint, never backbone updates.
            val=evaluate(model,data['val'],diff,lib,device)
            score=val['clean']['metrics']['topk_accuracy']['1'];improved=score>best;best=max(best,score)
            row=dict(epoch=epoch+1,train_loss=accumulated/max(1,slots),val={level:v['metrics'] for level,v in val.items()},
                     elapsed_seconds=time.time()-began)
            history.append(row);print('IDENTITY',kind,json.dumps(row),flush=True)
            saved=dict(model=model.state_dict(),optimizer=opt.state_dict(),epoch=epoch+1,history=history,best=best,
                kind=kind,feature_dim=train['x'].shape[-1],descriptor=descriptor.cpu(),prior=prior.cpu(),
                split_sha256=data['split_sha256'],source_sha256=digest(Path(__file__)))
            torch.save(saved,out/'latest.pt')
            if improved:torch.save(saved,out/'best.pt');write_json(out/'best_val.json',val)
            write_json(out/'history.json',history)
        saved=torch.load(out/'best.pt',map_location=device,weights_only=False);model.load_state_dict(saved['model'])
        val=evaluate(model,data['val'],diff,lib,device)
        probe=evaluate(model,train_probe,diff,lib,device)
        report=dict(kind=kind,best_epoch=saved['epoch'],train_probe=probe,val=val,
                    description='Independent controlled identity experiment; does not change docking or default joint sampler')
        write_json(out/'report.json',report)
        summary[kind]=dict(best_epoch=saved['epoch'],val={k:v['metrics'] for k,v in val.items()},
                          train_probe={k:v['metrics'] for k,v in probe.items()})
        write_json(a.output/'summary.json',summary)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(1,2,figsize=(10,3.5))
    for kind in summary:
        history=json.loads((a.output/kind/'history.json').read_text())
        ax[0].plot([r['epoch'] for r in history],[r['train_loss'] for r in history],label=kind)
        ax[1].plot([r['epoch'] for r in history],[r['val']['clean']['topk_accuracy']['1'] for r in history],label=kind)
    ax[0].set(xlabel='Epoch',ylabel='Training loss');ax[1].set(xlabel='Epoch',ylabel='CASF Top-1 (oracle centres/adjacency)')
    for axis in ax:axis.legend()
    fig.tight_layout();fig.savefig(a.output/'identity_curves.png',dpi=160);plt.close(fig)
    write_json(a.output/'status.json',dict(status='complete',methods=a.methods.split(','),epochs=a.epochs,backbone_trained=False))


if __name__=='__main__':main()
