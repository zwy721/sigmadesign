"""Shared identity metrics with explicit OOV and molecule denominators."""
import numpy as np


def identity_metrics(rows, frequencies, ks=(1, 5, 10, 20)):
    groups = {name: dict(slots=0, hits={str(k): 0 for k in ks})
              for name in ('rare_1_100', 'medium_101_1000', 'frequent_gt1000')}
    total = 0
    hits = {str(k): 0 for k in ks}
    complete_known = complete_in_vocab = in_vocab_molecules = eligible = oov = 0
    for row in rows:
        labels, ranks = row['labels'], row['topk']
        correct = []
        for label, ranked in zip(labels, ranks):
            if label < 0:
                oov += 1
                continue
            total += 1
            count = frequencies[label]
            group = groups['rare_1_100' if count <= 100 else 'medium_101_1000' if count <= 1000 else 'frequent_gt1000']
            group['slots'] += 1
            for k in ks:
                hit = int(label in ranked[:k])
                hits[str(k)] += hit
                group['hits'][str(k)] += hit
            correct.append(label == ranked[0])
        if correct:
            eligible += 1
            complete_known += int(all(correct))
            if min(labels) >= 0:
                in_vocab_molecules += 1
                complete_in_vocab += int(all(correct))
    for group in groups.values():
        group['topk_accuracy'] = {k: n / max(1, group['slots']) for k, n in group.pop('hits').items()}
    return dict(molecules=len(rows), known_slots=total, oov_slots_excluded=oov,
                topk_accuracy={k: n / max(1, total) for k, n in hits.items()},
                molecules_with_known_slots=eligible, all_known_slots_correct=complete_known,
                all_known_slots_accuracy=complete_known / max(1, eligible),
                fully_in_vocab_molecules=in_vocab_molecules, complete_in_vocab_correct=complete_in_vocab,
                complete_in_vocab_accuracy=complete_in_vocab / max(1, in_vocab_molecules), frequency_groups=groups)


def ranked_row(pid, labels, logits, k=20):
    import torch
    logits = logits.detach().float().cpu()
    return dict(id=pid, labels=list(map(int, labels)), topk=logits.topk(min(k, logits.shape[-1]), -1).indices.tolist())
