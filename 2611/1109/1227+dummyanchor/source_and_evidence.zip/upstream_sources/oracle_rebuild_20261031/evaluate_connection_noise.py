#!/usr/bin/env python3
"""Noise-stratified held-out connection validation; no docking or truth repair."""
import argparse
import json
from pathlib import Path
import time

import bootstrap
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader

from connection_predictor import PortConnectionPredictor,candidates,targets,proposals,legal_decode
from prediction_data import LEVELS,make_diffuser,perturb,list_collate,worker_init
from run_validation import write_json
from validation import digest
from vocab_chemistry import VocabLibrary,explicit_oov,true_connections,assemble_slots,canonical

CONNECTION_LEVELS=dict(LEVELS,near_0_02=.02,near_0_05=.05,near_0_1=.1)


class NoiseDataset(Dataset):
    def __init__(self,ids,levels,seeds,output,topk):
        self.keys=[(pid,name,seed) for name in levels for seed in seeds for pid in ids]
        self.output,self.topk=output,topk;self.lib=self.diff=None
    def __len__(self):return len(self.keys)
    def __getitem__(self,index):
        if self.lib is None:self.lib=VocabLibrary();self.diff=make_diffuser(self.output)
        pid,level,seed=self.keys[index]
        try:
            r=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
            labels=r['labels'].tolist();oov=explicit_oov(r)
            T,R=perturb(r,self.diff,CONNECTION_LEVELS[level],seed)
            x=candidates(self.lib,labels,T,R,oov=oov,topk=self.topk)
            truth=true_connections(r); target=targets(x,r)
            actual={(c['i'],c['j'],c['a'],c['b'],c['order']) for c in truth}
            oracle,_,_=assemble_slots(self.lib,labels,truth,oov=oov)
            return dict(id=pid,level=level,seed=seed,labels=labels,slots=len(labels),oov=oov,features=x,actual=actual,
                candidate_hits=int((target['y']>0).sum()),oracle_smiles=canonical(oracle,False),
                translation_rms_A=float(np.sqrt(np.square(T-r['T0'].numpy()).sum(-1).mean())),
                rotation_mean_deg=float(np.rad2deg(np.arccos(np.clip((np.einsum('nij,nij->n',R,r['R0'].numpy())-1)/2,-1,1))).mean()))
        except Exception as exc:
            import traceback
            return dict(id=pid,level=level,seed=seed,error=repr(exc),traceback=traceback.format_exc())


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--checkpoint',type=Path,default=bootstrap.PROJECT/'results/stage3_training/best.pt')
    p.add_argument('--device',default='cpu');p.add_argument('--workers',type=int,default=4)
    p.add_argument('--seeds',default='0,1,2');p.add_argument('--levels',default='clean,low,medium,high')
    p.add_argument('--topk',type=int,default=8);p.add_argument('--limit',type=int,default=0)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    # Prepare once in the parent; workers only read this private cache.
    make_diffuser(a.output)
    ids=json.loads((bootstrap.RECORDS.parent/'val_ids.json').read_text());ids=ids[:a.limit] if a.limit else ids
    ds=NoiseDataset(ids,a.levels.split(','),list(map(int,a.seeds.split(','))),a.output,a.topk)
    model=PortConnectionPredictor().to(a.device).eval()
    saved=torch.load(a.checkpoint,map_location='cpu',weights_only=False);model.load_state_dict(saved['model'],strict=True)
    lib=VocabLibrary();report=dict(checkpoint_sha256=digest(a.checkpoint),epoch=saved['epoch'],
        protocol='Oracle types; cached native C/Q forward marginal; VP translation and IGSO3 rotation. '
                 'No true edges/ports in candidates or decoding; no forced spanning tree. Threshold .65.',
        levels={k:CONNECTION_LEVELS[k] for k in a.levels.split(',')},topk_per_slot_pair=a.topk,rows=[],failures=[],summary={})
    started=time.time()
    for batch in DataLoader(ds,batch_size=8,num_workers=a.workers,collate_fn=list_collate,worker_init_fn=worker_init):
        for r in batch:
            if 'error' in r:report['failures'].append(r);continue
            proposed,pool=proposals(model,r.pop('features'),torch.device(a.device))
            decision,assembled=legal_decode(lib,r['labels'],proposed,oov=r.pop('oov'))
            guessed={(c['i'],c['j'],c['a'],c['b'],c['order']) for c in decision['connections']}
            actual=r.pop('actual');oracle=r.pop('oracle_smiles');r.pop('labels')
            r.update(true_bonds=len(actual),predicted_bonds=len(guessed),tp=len(actual&guessed),
                     exact_ports=actual==guessed,legal=assembled is not None,
                     constitution_exact=assembled is not None and canonical(assembled[0],False)==oracle)
            report['rows'].append(r)
        if len(report['rows'])%128<8:
            print('CONNECTION NOISE',len(report['rows']),'/',len(ds),'seconds',round(time.time()-started),flush=True)
            write_json(a.output/'report.partial.json',report)
    for level in a.levels.split(','):
        rows=[r for r in report['rows'] if r['level']==level]
        tp=sum(r['tp'] for r in rows);pred=sum(r['predicted_bonds'] for r in rows);true=sum(r['true_bonds'] for r in rows)
        precision,recall=tp/max(1,pred),tp/max(1,true)
        report['summary'][level]=dict(molecule_seed_runs=len(rows),molecules=len(set(r['id'] for r in rows)),
            tp=tp,predicted=pred,true=true,precision=precision,recall=recall,f1=2*tp/max(1,pred+true),
            candidate_coverage=sum(r['candidate_hits'] for r in rows)/max(1,true),
            complete_legal=sum(r['legal'] for r in rows)/max(1,len(rows)),
            full_port_graph_exact=sum(r['exact_ports'] for r in rows)/max(1,len(rows)),
            constitution_exact=sum(r['constitution_exact'] for r in rows)/max(1,len(rows)),
            translation_rms_A=float(np.mean([r['translation_rms_A'] for r in rows])),
            rotation_mean_deg=float(np.mean([r['rotation_mean_deg'] for r in rows])))
        multi=[r for r in rows if r['slots']>1]
        mt=sum(r['tp'] for r in multi);mp=sum(r['predicted_bonds'] for r in multi);ma=sum(r['true_bonds'] for r in multi)
        report['summary'][level]['multi_fragment_only']=dict(runs=len(multi),f1=2*mt/max(1,mp+ma),
            complete_legal=sum(r['legal'] for r in multi)/max(1,len(multi)),
            full_port_graph_exact=sum(r['exact_ports'] for r in multi)/max(1,len(multi)),
            constitution_exact=sum(r['constitution_exact'] for r in multi)/max(1,len(multi)))
    report['elapsed_seconds']=time.time()-started;write_json(a.output/'report.json',report)
    print(json.dumps(report['summary'],indent=2),flush=True)


if __name__=='__main__':main()
