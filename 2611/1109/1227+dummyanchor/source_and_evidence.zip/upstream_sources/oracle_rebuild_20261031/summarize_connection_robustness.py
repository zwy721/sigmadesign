#!/usr/bin/env python3
"""Build standalone figures, the connection report and frozen-input manifest."""
import argparse
import csv
from datetime import datetime,timezone
import json
from pathlib import Path

import bootstrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from evaluate_robust_connections import aggregate
from run_validation import write_json
from validation import digest


def pct(x):return f'{100*x:.2f}%'


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=bootstrap.PROJECT/'results/connection_robust_20261101')
    a=p.parse_args();root=a.root
    report=json.loads((root/'validation_ports/report.json').read_text());summary=report['summary']
    history=json.loads((root/'training_v2/history.json').read_text())
    protocol=json.loads((root/'training_v2/protocol.json').read_text())
    noise=json.loads((root/'training_v2/noise_protocol.json').read_text())
    audit=json.loads((root/'cache/audit.json').read_text())
    pilot_dir='alternation_native'
    pilot=json.loads((root/pilot_dir/'report.json').read_text())
    ablation=json.loads((root/'candidate_ablation/report.json').read_text())
    plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25,'figure.dpi':160})
    fig,ax=plt.subplots(figsize=(8,4))
    ax.plot([r['epoch'] for r in history],[r['train_loss'] for r in history],color='#0077bb',lw=1.6)
    ax.axvline(report['epoch'],color='#cc3311',ls='--',label=f"Selected epoch {report['epoch']}")
    ax.set(xlabel='Epoch',ylabel='Training loss',title='Time-conditioned connection head: full training loss')
    ax.legend();fig.tight_layout();fig.savefig(root/'training_loss.png');fig.savefig(root/'training_loss.pdf');plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4))
    for t in ['0.0','0.05','0.1','0.2','0.6','0.9']:
        rows=[r for r in history if 'val' in r]
        ax.plot([r['epoch'] for r in rows],[100*r['val'][t]['f1'] for r in rows],label=f't={t}')
    ax.set(xlabel='Epoch',ylabel='Raw candidate F1 (%)',title='Checkpoint selection only: noise seed 100')
    ax.legend(ncol=3);fig.tight_layout();fig.savefig(root/'selection_f1.png');plt.close(fig)
    grid=report['grid'];names={'original':'Original','full_noise':'Full-noise retrained','staged':'Staged (defer at high noise)'}
    colors={'original':'#666666','full_noise':'#cc3311','staged':'#0077bb'}
    fig,axes=plt.subplots(2,2,figsize=(11,7.5))
    for key,path,title in [('f1',None,'Exact port + bond-order F1'),('complete_legal',None,'Complete legal chemical graph'),
            ('full_ports_exact','multi_fragment','All connections exact (multi-fragment only)'),('candidate_coverage',None,'True bonds covered by candidate pool')]:
        ax=axes.flat[list(['f1','complete_legal','full_ports_exact','candidate_coverage']).index(key)]
        for method in names:
            yy=[100*(summary[method][str(t)][path][key] if path else summary[method][str(t)][key]) for t in grid]
            ax.plot(grid,yy,marker='o',markersize=3.5,label=names[method],color=colors[method],ls='--' if method=='staged' else '-')
        ax.set(xlabel='Diffusion time t',ylabel='Percent',title=title,ylim=(-2,103))
    axes.flat[0].legend(fontsize=8);fig.suptitle('271 CASF molecules, independent noise seeds 201 / 202 / 203')
    fig.tight_layout();fig.savefig(root/'noise_comparison.png');fig.savefig(root/'noise_comparison.pdf');plt.close(fig)
    with (root/'metrics.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=['method','t','port_f1','port_bond_f1','complete_legal_all','complete_legal_multi','exact_connections_multi','constitution_exact_multi','candidate_coverage'])
        writer.writeheader()
        for method in names:
            for t in grid:
                m=summary[method][str(t)];multi=m['multi_fragment']
                writer.writerow(dict(method=method,t=t,port_f1=m['port_f1'],port_bond_f1=m['f1'],complete_legal_all=m['complete_legal'],
                    complete_legal_multi=multi['complete_legal'],exact_connections_multi=multi['full_ports_exact'],
                    constitution_exact_multi=multi['constitution_exact'],candidate_coverage=m['candidate_coverage']))
    byseed={method:{str(t):[aggregate([r for r in report['rows'] if r['method']==method and r['t']==t and r['seed']==seed])
               for seed in report['seeds']] for t in grid} for method in names}
    write_json(root/'metrics_by_seed.json',byseed)
    pilot_summary={}
    for mode in ('fixed_identity','alternating_identity'):
        rows=[r for r in pilot['rows'] if r['mode']==mode];ok=[r for r in rows if r['success']]
        event_paths=[root/f"{pilot_dir}/{r['id']}_{r['seed']}_{mode}/events.json" for r in ok]
        events=[e for path in event_paths for e in json.loads(path.read_text())]
        accepted=[e for e in events if e['accepted']]
        audits=[json.loads((root/f"{pilot_dir}/{r['id']}_{r['seed']}_{mode}/trajectory_audit.json").read_text()) for r in ok]
        rms=[r['full_ligand_rmsd_A'] for r in ok if r['full_ligand_rmsd_A'] is not None]
        pilot_summary[mode]=dict(attempts=len(rows),completed=len(ok),failures=len(rows)-len(ok),
            low_noise_committed=sum(r['low_noise_committed'] for r in ok),
            final_constitution_exact=sum(r['constitution_exact'] for r in ok),
            low_proposal_exact=sum(r['low_proposal_exact'] for r in ok),
            low_proposal_f1=2*sum(r['low_proposal_tp'] for r in ok)/max(1,sum(r['low_proposal_predicted']+r['true_bonds'] for r in ok)),
            graph_revisions=sum(r['revisions'] for r in ok),
            identity_updates_proposed=sum(len(e['identity_updates']) for e in events),
            identity_updates_accepted=sum(len(e['identity_updates']) for e in accepted),
            known_identity_accuracy=sum(r['identities_correct'] for r in ok)/max(1,sum(r['known_slots'] for r in ok)),
            audited_forwards=sum(len(x['forwards']) for x in audits),
            audited_geometry_calls=sum(len(x['geometry']) for x in audits),
            all_dynamic_checks_passed=all(x['all_dynamic_recomputations_equal'] for x in audits),
            max_pose_transfer_fit_A=max([v for e in accepted for v in e.get('pose_transfer_fit_rmsd_A',[])],default=0.),
            isomeric_rmsd_evaluable=len(rms),isomeric_rmsd_median_A=float(np.median(rms)) if rms else None)
    write_json(root/'alternation_summary.json',pilot_summary)
    old=json.loads((bootstrap.PROJECT/'PREDICTION_MANIFEST.json').read_text())
    changed=[k for k,h in old['official_source_sha256'].items() if digest(bootstrap.OFFICIAL/k)!=h]
    if changed:raise RuntimeError(f'Frozen official source changed: {changed}')
    if digest(bootstrap.CHECKPOINT)!=old['official_checkpoint_sha256']:raise RuntimeError('Official weights changed')
    identity_path=bootstrap.PROJECT/'results/prediction_diagnostics/identity_controls/iterative/best.pt'
    if digest(identity_path)!=old['checkpoints']['iterative']:raise RuntimeError('Retained identity head changed')
    adapters=('oracle_graph.py','joint_sampler.py','connection_predictor.py','predict_identity_control.py','vocab_chemistry.py')
    if any(digest(bootstrap.PROJECT/k)!=old['scripts'][k] for k in adapters):raise RuntimeError('Frozen adapter changed')
    source_current={name:digest(bootstrap.PROJECT/name) for name in protocol['source_sha256']}
    if source_current!=protocol['source_sha256']:raise RuntimeError('Final training sources differ from protocol')
    if digest(bootstrap.PROJECT/'results/stage3_training/best.pt')!=protocol['legacy_sha256']:raise RuntimeError('Legacy connection weights changed')
    relative=root.relative_to(bootstrap.PROJECT).as_posix()
    lines=['# 连接预测噪声鲁棒性专项结果（2026-11-01）','',
        '时间条件连接头已完成 100 轮训练，第 96 轮为最佳检查点。只训练独立连接模块，官方 SigmaDock 主干和已训练的迭代身份纠错模型均保持冻结。',
        '', '## 数据与实验边界','',
        '- 训练：17,420 个 PDBbind 分子；验证：缓存中可用的 271 个 CASF 分子，其中 255 个多片段、16 个单片段。训练/验证 ID 交集为 0。这里不是全部原始 CASF 条目的覆盖声明。',
        '- 给定真实片段身份和 N；OOV 仅提供该片段的化学模板。输入候选端口来自模板完整枚举，不插入真实端口或连接。',
        '- 先用官方 `SE3Diffuser.forward_marginal(C0,Q0,t)` 生成观测，再转换到模板坐标系。目标位姿只用于加噪和事后评价，不直接传给连接头；t=0 是明确的 clean 对照。',
        '- 从官方权重读取完整噪声参数：VP β=0.1→20；IGSO3 logarithmic，σ=0.1→1.5，num_sigma=1000、num_omega=2000、L=1000。此前报告的 256/1024 网格结果保留为历史记录，本报告三组均在同一官方 1000/2000 网格上重新配对。',
        '- 选模及阈值：噪声 seed=100；最终测试：201/202/203。是同一 CASF 分子的独立噪声复核，并非额外独立分子测试集。',
        '- F1 按槽位对、两端原子端口及键级全部匹配计 TP；另列仅端口 F1。断连/非法图保留在分母，不强行补树。完整图正确率逐个分子要求所有连接完全一致，另给多片段分母以排除单片段抬高。',
        '', '## 三组方案','',
        '1. 原头：原检查点、每对槽位 Top-8/16 Å，阈值 0.65。',
        '2. 全噪声头：冻结旧头并训练时间条件残差；给定身份 embedding、候选端口化学和当前几何、分子身份袋统计及 t。低噪声 Top-8/16 Å，高噪声 Top-64/32 Å；按 seed=100 固定阈值。',
        '3. 分阶段：t>0.05 保留 Top-64 允许键级的候选，完全不提交连接；t≤0.05 使用冻结的原头，并受前期候选池约束。该保守对照保证保留原低噪声路径，但没有采用新头的低噪声提升。高噪声的提交 F1=0 是有意延迟，不代表候选覆盖率为 0。',
        '', '分阶段候选池基准按 t 递减观察同一随机数耦合的 forward marginal。低噪声观测由加噪器提供，不能将该表当作模型自主逆扩散成功率；真实多步采样另列下文。',
        '', '## 独立种子连接结果','',
        '每个 t、每组均为 271×3=813 次分子评估；多片段分母为 255×3=765。t=0 没有随机噪声，三次结果完全相同，有效独立分子数仍为 271。',
        '', '| t | 原头端口/键级 F1 | 新头端口 F1 | 新头端口/键级 F1 | 原头合法完整图 | 新头合法完整图 | 原头多片段全连接正确 | 新头多片段全连接正确 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for t in grid:
        b=summary['original'][str(t)];m=summary['full_noise'][str(t)]
        lines.append('| '+str(t)+' | '+' | '.join(map(pct,[b['f1'],m['port_f1'],m['f1'],b['complete_legal'],m['complete_legal'],b['multi_fragment']['full_ports_exact'],m['multi_fragment']['full_ports_exact']]))+' |')
    lines+=['', '低噪声 t=0/0.02/0.05 的 F1 均高于原头，全部通过预设的 -2 个百分点保护门槛。t=0.02 合法完整图比例从 69.74% 到 68.27%，下降 1.48 个百分点；完整连接正确率反而由 53.99% 提升到 61.31%。合法图与正确图必须分别看待。',
        '', '| t | 分阶段候选覆盖率 | 分阶段端口/键级 F1 | 分阶段合法完整图 | 分阶段多片段全连接正确 |',
        '| --- | ---: | ---: | ---: | ---: |']
    for t in grid:
        m=summary['staged'][str(t)]
        lines.append(f"| {t} | {pct(m['candidate_coverage'])} | {pct(m['f1'])} | {pct(m['complete_legal'])} | {pct(m['multi_fragment']['full_ports_exact'])} |")
    lines+=['', '高噪声保留的候选覆盖率约 99.9%，但该池仍含大量错误假设。分阶段高噪声合法图比例 5.90% 全部来自无需连接的单片段，多片段已提交合法图为 0。新头 t=0.9 的合法完整图达到 42.56%，多片段完整连接正确率仅 9.41%；因此“能组装”不能代替“连接正确”。',
        '', f"补充配对对照固定原权重与 0.65 阈值，仅改用新头相同的候选池。t=0.2/0.9 的 F1 分别为 {pct(ablation['summary']['0.2']['f1'])}/{pct(ablation['summary']['0.9']['f1'])}，全噪声重训练头为 {pct(summary['full_noise']['0.2']['f1'])}/{pct(summary['full_noise']['0.9']['f1'])}。因此提高覆盖率本身不足以解释新头提升；此对照未重新校准旧头阈值。",
        '', '## 训练及曲线','',
        f"训练 loss：{history[0]['train_loss']:.4f} → {history[-1]['train_loss']:.4f}。100 轮优化循环耗时约 {history[-1]['elapsed_seconds']:.1f} 秒，已排除一次性候选编译、数据载入和初始化。候选缓存是向量化的小型连接任务；此耗时不代表官方位姿主干完整训练耗时。",
        '', f'![训练 loss]({relative}/training_loss.png)', '',f'![连接噪声结果]({relative}/noise_comparison.png)',
        '', '## 身份—连接交替与动态化学图重建','',
        f"在原先 12 个受体、独立 seed={'/'.join(map(str,pilot['seeds']))} 上，分别运行“给定身份”和“允许迭代身份纠错”两条路径。每条 36 次尝试，25 时间点、24 次原主干去噪更新，t=0.9→0.005，平移/旋转从官方 stationary prior 初始化。全程没有真实连接、端口或目标位姿输入。",
        '', '启动时官方主干需要完整合法图，因此从高噪声预测候选中选择满足容量约束的连接假设，明确标记为未提交候选；这项候选搜索只用于采样启动，不用于上方连接正确率评估。高噪声保留候选，低噪声才尝试确认。身份/连接更改被接受时，重新生成真实化学图、原子/虚拟节点及边，并将当前物理位姿转移过去。',
        '', '已修复启动阶段不恰当的模板形状投影：孤立片段模板与完整分子的 RDKit 参考构象可能含不同环构象。旧开发运行在 72 次中有 12 次因此被 0.5 Å 保护检查拒绝；启动时本来不存在旧物理状态，现改回官方 native 随机刚体初始化。后续真实图修订继续保留 0.5 Å 位姿转移保护。旧诊断在 alternation/，修复后的独立种子结果在 alternation_native/。',
        '', '| 路径 | 完成/尝试 | 低噪声确认图 | 最终分子构造正确 | 低噪声提案全连接正确 | 接受图重建 | 提议/接受身份改动 | 审计主干调用 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for mode,m in pilot_summary.items():
        lines.append(f"| {mode} | {m['completed']}/{m['attempts']} | {m['low_noise_committed']}/{m['attempts']} | {m['final_constitution_exact']}/{m['attempts']} | {m['low_proposal_exact']}/{m['attempts']} | {m['graph_revisions']} | {m['identity_updates_proposed']}/{m['identity_updates_accepted']} | {m['audited_forwards']} |")
    lines+=['', '这项小样本检查用于发现采样分布与 forward-noise 评估之间的差距，不能与上表的已知低噪声观测等同。身份纠错头曾在真中心/真邻接条件下训练；在本试验只给当前预测邻接，不使用真邻接。高噪声错误化学假设可能把轨迹引入错误拓扑，这仍是主要剩余问题。',
        '', f"两条路径最终已知片段身份保持正确率分别为 {pct(pilot_summary['fixed_identity']['known_identity_accuracy'])} 和 {pct(pilot_summary['alternating_identity']['known_identity_accuracy'])}。初始身份已给定正确，因此这是身份更新是否破坏正确输入的检查，不是从错误身份恢复的准确率。",
        '', '逐步审计检查动态近邻边、当前距离、方向、边界相对距离及每次图版本内静态化学边；接受重建时另检查物理位姿转移。所有完成轨迹的审计均通过。工程回归另覆盖实际改变原子数与连接后的重建，不能仅凭本试验中身份提案数宣称身份纠错已经解决。',
        '', '## 决定与限制','',
        '- 保留此次新连接头用于后续连接预测；低噪声继续使用新头值得验证，当前分阶段对照的原头低噪声路径较保守。暂不启动完整联合训练，也不覆盖原版采样默认入口。',
        '- 下一步优先在当前预测图和主干真实逆扩散轨迹上构建训练样本，改善训练/采样分布差距；保留多个拓扑假设，采用重评分后再确认，避免过早把错误拓扑固定给预训练主干。',
        '- 片段身份和 N 仍是给定条件；高噪声下仅由片段身份、端口和随机姿态无法唯一推断原分子连接，本结果不等价于盲生成质量或 Vina 评分改善。',
        '- 原始 SigmaDock 源码、EMA 权重、旧连接权重和迭代身份权重未改。本地官方检出保留 10 月 30 日已有的 PoseBusters/错误透传兼容补丁；本轮没有修改主干。',
        '', f'[最佳连接头]({relative}/training_v2/best.pt) · [完整指标 CSV]({relative}/metrics.csv) · [逐样本报告]({relative}/validation_ports/report.json) · [多步采样报告]({relative}/{pilot_dir}/report.json) · [训练参数]({relative}/training_v2/protocol.json) · [复现说明](CONNECTION_ROBUST.md)', '']
    (bootstrap.PROJECT/'CONNECTION_ROBUST_RESULTS.md').write_text('\n'.join(lines))
    stage=bootstrap.PROJECT/'STAGED_RESULTS.md';text=stage.read_text();marker='\n## 2026-11-01：连接噪声鲁棒性专项'
    if marker in text:text=text.split(marker)[0]
    stage.write_text(text+marker+'\n\n已按最新 prompt 完成独立连接头的全噪声重训练与三组独立种子验证。官方主干、迭代身份头冻结，未启动完整联合训练。\n\n'+
        't=0/0.05/0.2/0.9 的端口/键级 F1：原头 94.63/66.03/9.42/1.55%，新头 97.18/79.96/39.18/25.51%。clean 多片段完整连接正确率由 73.33% 提升到 86.27%；t=0.9 仍仅 9.41%。\n\n'+
        '独立种子测试为 271 可用 CASF×3 seeds；另完成 12 受体×3 新种子×2 路径的真实多步预测图采样检查。详细分母、失败、候选/提交区别与剩余问题见 [连接预测专项报告](CONNECTION_ROBUST_RESULTS.md)，复现命令见 [CONNECTION_ROBUST.md](CONNECTION_ROBUST.md)。\n')
    tests=(root/'tests.log').read_text();test_line=next(x for x in tests.splitlines() if x.startswith('Ran '))
    manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),prompt_sha256=digest(bootstrap.WORKSPACE/'prompt.md'),
        official_source_files_checked=len(old['official_source_sha256']),official_source_changed=changed,
        official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),existing_compatibility_patches=old['existing_official_compatibility_patches'],
        iterative_identity_sha256=digest(identity_path),legacy_connection_sha256=digest(bootstrap.PROJECT/'results/stage3_training/best.pt'),
        new_connection_sha256=digest(root/'training_v2/best.pt'),train_source_matches_checkpoint=True,
        scripts={path.name:digest(path) for path in bootstrap.PROJECT.glob('*connection*.py')},
        entrypoint_sha256=digest(bootstrap.PROJECT/'stages.sh'),
        tests_sha256={str(path.relative_to(bootstrap.PROJECT)):digest(path) for path in (bootstrap.PROJECT/'tests').glob('test_*.py')},
        frozen_adapters_checked=list(adapters),pilot_sampling_source_sha256=digest(root/pilot_dir/'sampling_source.py'),
        tests=test_line,test_success='\nOK\n' in tests,selection_seed=100,test_seeds=report['seeds'],pilot_seeds=pilot['seeds'],
        noise_protocol=noise,cache_audit=audit,pilot_summary=pilot_summary,backbone_trained=False,joint_training_started=False,
        reports={str(path.relative_to(root)):digest(path) for path in [root/'validation_ports/report.json',root/'candidate_ablation/report.json',root/pilot_dir/'report.json',root/'training_v2/history.json',root/'metrics.csv']})
    write_json(bootstrap.PROJECT/'CONNECTION_ROBUST_MANIFEST.json',manifest)
    print(json.dumps(dict(checkpoint_epoch=report['epoch'],pilot=pilot_summary,tests=test_line),indent=2))


if __name__=='__main__':main()
