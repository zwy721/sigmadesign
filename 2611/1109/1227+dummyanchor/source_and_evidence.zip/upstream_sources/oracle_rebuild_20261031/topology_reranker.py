"""Independent target-free topology features and pairwise scoring network."""
from pathlib import Path

import numpy as np
import torch
from torch import nn
from rdkit import Chem
from rdkit.Chem import Descriptors,Lipinski,rdMolDescriptors,Crippen

from oracle_graph import assemble
from pipeline_utils import pose_geometry
from trajectory_connections import edge_key

SCHEMA='topology-reranker-features-v1'


def _stats(result,prefix,values):
    values=np.asarray(values,dtype=float)
    if not values.size:values=np.zeros(1)
    for name,value in [('mean',values.mean()),('std',values.std()),('min',values.min()),('max',values.max()),('q25',np.quantile(values,.25)),('median',np.median(values))]:
        result[f'{prefix}_{name}']=float(value)


def extract_features(runtime,*,spec,connections,frames,positions,pocket):
    """No truth topology, target pose, candidate origin, ID or label argument.

    Frames/positions must be the GENERATED trajectory. The pocket is the given
    receptor. All chemistry descriptors refer to the candidate itself.
    """
    xyz=np.asarray(positions[-1],dtype=float);positions=np.asarray(positions,dtype=float)
    if xyz.ndim!=2 or xyz.shape[1]!=3 or not np.isfinite(positions).all():raise ValueError('Invalid generated coordinates')
    mol=assemble(spec);n=mol.GetNumAtoms()
    if len(xyz)!=n:raise ValueError('Candidate atom/coordinate mismatch')
    if len(frames)!=len(positions):raise ValueError('Frame/trajectory length mismatch')
    result={};periodic=Chem.GetPeriodicTable();geometry=pose_geometry(mol,xyz,spec['connections'],pocket)
    result.update(heavy_atoms=float(n),slots=float(len(runtime.labels)),interfragment_edges=float(len(connections)),
        molecular_weight=Descriptors.MolWt(mol),logp=Crippen.MolLogP(mol),tpsa=rdMolDescriptors.CalcTPSA(mol),
        hbd=float(Lipinski.NumHDonors(mol)),hba=float(Lipinski.NumHAcceptors(mol)),
        rotatable_bonds=float(Lipinski.NumRotatableBonds(mol)),rings=float(rdMolDescriptors.CalcNumRings(mol)),
        aromatic_rings=float(rdMolDescriptors.CalcNumAromaticRings(mol)),
        charge=float(sum(a.GetFormalCharge() for a in mol.GetAtoms())),
        abs_charge=float(sum(abs(a.GetFormalCharge()) for a in mol.GetAtoms())),
        hetero_fraction=sum(a.GetAtomicNum() not in (1,6) for a in mol.GetAtoms())/max(1,n),
        aromatic_fraction=sum(a.GetIsAromatic() for a in mol.GetAtoms())/max(1,n),
        fraction_csp3=float(rdMolDescriptors.CalcFractionCSP3(mol)))
    # Attachment-dependent motifs are candidate chemistry, not supplied labels.
    for name,smarts in [('amide','[CX3](=O)[NX3]'),('ester','[CX3](=O)[OX2][#6]'),('ether','[#6][OX2][#6]'),
                       ('urea','[NX3][CX3](=O)[NX3]'),('sulfonamide','S(=O)(=O)N')]:
        result[f'motif_{name}']=float(len(mol.GetSubstructMatches(Chem.MolFromSmarts(smarts))))
    degree=np.zeros(len(runtime.labels),dtype=float)
    for e in connections:degree[e['i']]+=1;degree[e['j']]+=1
    _stats(result,'fragment_degree',degree);result['leaf_fraction']=float(np.mean(degree==1))
    errors=[]
    for c in spec['connections']:
        i,j=c['begin'],c['end'];order=mol.GetBondBetweenAtoms(i,j).GetBondTypeAsDouble()
        radius=periodic.GetRcovalent(mol.GetAtomWithIdx(i).GetAtomicNum())+periodic.GetRcovalent(mol.GetAtomWithIdx(j).GetAtomicNum())
        ideal=radius*(1. if order==1 else .9 if order==2 else .85)
        errors.append(abs(float(np.linalg.norm(xyz[i]-xyz[j]))-ideal))
    _stats(result,'bond_error',errors)
    result['bad_bond_fraction']=geometry['bond_error_over_0_5A']/max(1,len(connections))
    result['ligand_clash_fraction']=geometry['ligand_nonbonded_clashes_under_1_2A']/max(1,n)
    points=pocket.GetConformer().GetPositions()
    atoms=[a for a in pocket.GetAtoms() if a.GetAtomicNum()>1]
    points=points[[a.GetIdx() for a in atoms]]
    distances=np.linalg.norm(xyz[:,None]-points[None],axis=-1);minimum=distances.min(-1)
    _stats(result,'pocket_nearest',minimum)
    for threshold in (1.2,2.,2.5,3.5,4.5,6.):
        result[f'pocket_fraction_{threshold:g}A']=float(np.mean(minimum<threshold))
    result['pocket_contact_fraction']=float(np.mean((minimum>=2.)&(minimum<4.5)))
    result['pocket_contact_pairs']=float(((distances>=2.)&(distances<4.5)).sum()/max(1,n))
    result['pocket_com_distance']=float(np.linalg.norm(xyz.mean(0)-points.mean(0)))
    lz=np.array([a.GetAtomicNum() for a in mol.GetAtoms()]);pz=np.array([a.GetAtomicNum() for a in atoms])
    polar=np.isin(lz,[7,8,16])[:,None]&np.isin(pz,[7,8,16])[None]
    hydrophobic=(lz==6)[:,None]&(pz==6)[None]
    result['polar_contacts']=float((polar&(distances>=2.2)&(distances<3.8)).sum()/max(1,n))
    result['carbon_contacts']=float((hydrophobic&(distances>=3.)&(distances<4.5)).sum()/max(1,n))
    lr=np.array([periodic.GetRvdw(int(z)) for z in lz]);pr=np.array([periodic.GetRvdw(int(z)) for z in pz])
    overlap=np.maximum(.8*(lr[:,None]+pr[None])-distances,0.)
    result['vdw_overlap_mean']=float(overlap.sum()/max(1,n));result['vdw_overlap_max']=float(overlap.max())
    centred=xyz-xyz.mean(0);eig=np.linalg.eigvalsh(centred.T@centred/max(1,n))
    result['radius_gyration']=float(np.sqrt(np.mean((centred**2).sum(-1))))
    result['asphericity']=float((eig[-1]-.5*(eig[0]+eig[1]))/max(1e-8,eig.sum()))
    last=positions[-min(5,len(positions)):]
    _stats(result,'late_step_motion',np.sqrt(np.mean(np.sum(np.diff(last,axis=0)**2,-1),axis=-1)))
    result['trajectory_com_shift']=float(np.linalg.norm(positions[-1].mean(0)-positions[0].mean(0)))
    _stats(result,'template_fit',frames[-1]['fit'])
    likelihood=[]
    for i in sorted(set([0,len(frames)//3,2*len(frames)//3,len(frames)-1])):
        frame=frames[i];pred=runtime.predict(frame['T'],frame['R'],frame['t'],head='full',policy='wide')
        pool={edge_key(e):e for e in pred['pool']}
        odds=[pool.get(edge_key(e),{}).get('log_odds',-20.) for e in connections]
        probs=[pool.get(edge_key(e),{}).get('confidence',1e-8) for e in connections]
        mean=float(np.mean(odds)) if odds else 0.;likelihood.append(mean)
        if i==len(frames)-1:
            _stats(result,'connection_log_odds',odds);_stats(result,'connection_probability',probs)
            result['missing_connection_fraction']=sum(edge_key(e) not in pool for e in connections)/max(1,len(connections))
            p=pred['p'];entropy=-(p*np.log(np.maximum(p,1e-8))).sum(-1) if len(p) else np.zeros(1)
            _stats(result,'pool_entropy',entropy)
    result['likelihood_gain']=float(likelihood[-1]-likelihood[0]);result['likelihood_min']=float(min(likelihood))
    result['likelihood_path_mean']=float(np.mean(likelihood))
    if not all(np.isfinite(v) for v in result.values()):raise FloatingPointError('Nonfinite reranker feature')
    return result


def analytical_scores(features):
    connection=features['connection_log_odds_mean']
    geometry=-.5*features['bond_error_mean']-2*features['ligand_clash_fraction']-2*features['pocket_fraction_1.2A']
    pocket=geometry+.5*features['pocket_contact_fraction']+.1*features['polar_contacts']+.05*features['carbon_contacts']-.1*features['vdw_overlap_mean']
    return dict(heuristic=connection+geometry,connection=connection,geometry=geometry,pocket=pocket)


class TopologyReranker(nn.Module):
    def __init__(self,dimension,hidden=32):
        super().__init__()
        self.network=nn.Sequential(nn.Linear(dimension,hidden),nn.SiLU(),nn.Linear(hidden,1))
    def forward(self,x):return self.network(x).squeeze(-1)


def load_reranker(path,device='cpu'):
    saved=torch.load(Path(path),map_location='cpu',weights_only=False)
    if saved['schema']!=SCHEMA:raise ValueError('Reranker feature schema differs')
    model=TopologyReranker(len(saved['feature_names']),saved['hidden']).to(device).eval()
    model.load_state_dict(saved['model'],strict=True);model.requires_grad_(False)
    return model,saved


@torch.inference_mode()
def score_candidates(model,saved,features,device='cpu'):
    names=saved['feature_names']
    if any(set(row)!=set(names) for row in features):raise ValueError('Unexpected/missing reranker feature')
    x=torch.tensor([[row[k] for k in names] for row in features],device=device,dtype=torch.float32)
    mean=saved['mean'].to(device);scale=saved['scale'].to(device)
    return model(((x-mean)/scale).clamp(-10,10)).cpu().tolist()
