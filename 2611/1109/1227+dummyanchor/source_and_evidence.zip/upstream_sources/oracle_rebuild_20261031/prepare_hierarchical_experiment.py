"""Freeze development/test chemistry disjointness for hierarchical search."""
import argparse
import json
from pathlib import Path
import shutil

import bootstrap
import torch
from rdkit import Chem

from prepare_reranker_experiment import ROOT as PREVIOUS
from run_validation import write_json
from validation import digest
from vocab_chemistry import canonical

ROOT=bootstrap.PROJECT/'results/connection_hierarchical_20261101'


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args()
    a.root.mkdir(parents=True,exist_ok=True);old=json.loads((PREVIOUS/'cohorts.json').read_text())
    if not (a.root/'prompt_used.md').exists():shutil.copyfile(bootstrap.WORKSPACE/'prompt.md',a.root/'prompt_used.md')
    audit=json.loads((PREVIOUS/'all_casf_chemical_overlap_audit.json').read_text())
    if audit['casf_read_failures']:raise ValueError('Incomplete CASF chemistry audit')
    excluded=set(audit['excluded_ids']);seen={};cohorts={};duplicates=[];source_hashes={}
    for role in ['train','calibration','casf_holdout']:
        cohorts[role]=[]
        for pid in old[role]:
            if pid in excluded:continue
            source=PREVIOUS/f'inputs/{pid}/fixture.pt';fixture=torch.load(source,weights_only=False)
            mol=Chem.RemoveHs(Chem.Mol(fixture['target_mol']));mol.RemoveAllConformers();key=canonical(mol,False)
            if role!='casf_holdout' and key in seen:
                duplicates.append(dict(excluded=pid,role=role,same_as=seen[key]));continue
            if role=='casf_holdout' and key in seen:raise ValueError('Full-constitution development/test overlap')
            if role!='casf_holdout':seen[key]=pid
            cohorts[role].append(pid);source_hashes[pid]=digest(source)
    cohorts.update(test_seeds=[1801,1802,1803],development_seed=1702,historical_test_already_examined=True,
        split='Exact canonical constitution after hydrogen/stereo removal; all CASF duplicates excluded from non-CASF development; no new training in this phase',
        excluded_casf_duplicates=sorted(excluded),excluded_development_duplicates=duplicates,
        source_root=str(PREVIOUS),source_fixture_sha256=source_hashes,
        all_casf_chemical_audit_sha256=digest(PREVIOUS/'all_casf_chemical_overlap_audit.json'))
    write_json(a.root/'cohorts.json',cohorts);print(json.dumps(cohorts,indent=2))


if __name__=='__main__':main()
