"""Explicit Oracle identity registry, independent of any whole-ligand fixture."""
import copy

from oracle_graph import OracleContractError, assemble, rebuild


def split_templates(spec, library=None):
    """Factor chemistry into reusable identity templates and a ligand instance.

    The instance contains identity IDs, atom/bond order bindings, reference xyz,
    ports and true cross-fragment connections. Atom and internal bond chemistry
    are read only from the independent library when resolving an instance.
    """
    assemble(spec)  # Validate before exporting any registry entry.
    if library is None:
        library = dict(schema='sigmadock-oracle-library-v1', templates={})
    library = copy.deepcopy(library)
    if library['schema'] != 'sigmadock-oracle-library-v1':
        raise OracleContractError('Unknown template library schema')
    instance = {k: copy.deepcopy(v) for k, v in spec.items() if k not in ('schema', 'fragments')}
    instance['schema'] = 'sigmadock-oracle-instance-v1'
    instance['fragments'] = []
    for f in spec['fragments']:
        ids = f['atom_ids']
        local = {k: i for i, k in enumerate(ids)}
        bonds = []
        for b in f['bonds']:
            bond = {k: copy.deepcopy(v) for k, v in b.items() if k != 'order'}
            bond.update(begin=local[b['begin']], end=local[b['end']],
                        stereo_atoms=[local.get(k, 'external') for k in b['stereo_atoms']])
            bonds.append(bond)
        template = dict(atoms=copy.deepcopy(f['atoms']), bonds=bonds)
        previous = library['templates'].get(f['identity'])
        if previous is not None and previous != template:
            raise OracleContractError(f'Identity collision for {f["identity"]}')
        library['templates'][f['identity']] = template
        binding = {k: copy.deepcopy(v) for k, v in f.items() if k not in ('atoms', 'bonds')}
        binding['internal_bond_order'] = [b['order'] for b in f['bonds']]
        binding['stereo_atom_bindings'] = [b['stereo_atoms'] for b in f['bonds']]
        instance['fragments'].append(binding)
    return instance, library


def resolve(instance, library):
    if instance.get('schema') != 'sigmadock-oracle-instance-v1':
        raise OracleContractError('Unknown instance schema')
    if library.get('schema') != 'sigmadock-oracle-library-v1':
        raise OracleContractError('Unknown template library schema')
    spec = {k: copy.deepcopy(v) for k, v in instance.items() if k not in ('schema', 'fragments')}
    spec['schema'] = 'sigmadock-oracle-chemistry-v1'
    spec['fragments'] = []
    for f in instance['fragments']:
        if f['identity'] not in library['templates']:
            raise OracleContractError(f'Unresolved explicit fragment identity: {f["identity"]}')
        tpl = library['templates'][f['identity']]
        ids = f['atom_ids']
        if len(ids) != len(tpl['atoms']) or len(tpl['bonds']) != len(f['internal_bond_order']):
            raise OracleContractError('Template and instance order bindings differ')
        if len(f['stereo_atom_bindings']) != len(tpl['bonds']):
            raise OracleContractError('Invalid stereo context bindings')
        fragment = {k: copy.deepcopy(v) for k, v in f.items()
                    if k not in ('internal_bond_order', 'stereo_atom_bindings')}
        fragment['atoms'] = copy.deepcopy(tpl['atoms'])
        fragment['bonds'] = []
        for b, order, stereo in zip(tpl['bonds'], f['internal_bond_order'], f['stereo_atom_bindings']):
            if len(stereo) != len(b['stereo_atoms']):
                raise OracleContractError('Template stereo and instance stereo differ')
            for loc, atom in zip(b['stereo_atoms'], stereo):
                if loc == 'external':
                    if atom in ids:
                        raise OracleContractError('External stereo context points into the same identity')
                elif ids[loc] != atom:
                    raise OracleContractError('Internal stereo context changed the identity')
            bond = copy.deepcopy(b)
            bond.update(order=order, begin=ids[b['begin']], end=ids[b['end']], stereo_atoms=copy.deepcopy(stereo))
            fragment['bonds'].append(bond)
        spec['fragments'].append(fragment)
    assemble(spec)
    return spec


def rebuild_from_library(instance, library, **pocket_context):
    return rebuild(resolve(instance, library), **pocket_context)
