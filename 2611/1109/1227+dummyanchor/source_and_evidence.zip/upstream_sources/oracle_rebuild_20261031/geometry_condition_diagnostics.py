"""Diagnostic-only pose-conditioned connection and joint-port evaluation.

This module is not imported by normal generation. Search input is only supplied
fragment chemistry, current rigid poses and a fixed common diffusion time.
Truth is consumed after search, or by the explicitly conditioned Oracle beam.
"""
from dataclasses import replace

import numpy as np

from evaluate_robust_connections import edge_set
from hierarchical_topology import SearchConfig,adjacency_key,option_groups,port_beam,hierarchical_search
from pipeline_utils import rigid_fit
from run_hierarchical_experiment import colored_adjacency
from trajectory_connections import edge_key
from vocab_chemistry import canonical

K_VALUES=(1,4,8,32,128)


def diagnostic_pose(library,labels,oov,target_xyz,*,diagnostic_only=False):
    if not diagnostic_only:raise ValueError('Target rigid poses are diagnostic only')
    xyz=np.asarray(target_xyz,dtype=float);offset=0;T=[];R=[];fit=[];reconstructed=[]
    for i,label in enumerate(labels):
        _,template=library.template(label,oov[i]);part=xyz[offset:offset+len(template)];offset+=len(template)
        if len(part)!=len(template):raise ValueError('Target/template atom count mismatch')
        trans,rot,error=rigid_fit(template,part);T.append(trans);R.append(rot);fit.append(error)
        reconstructed.append(template@rot.T+trans)
    if offset!=len(xyz):raise ValueError('Unused target atoms')
    return dict(T=np.asarray(T),R=np.asarray(R),fit=np.asarray(fit),reconstructed=np.concatenate(reconstructed))


def choose_generated(group):
    """Same pre-existing default ordinary K=8 scorer; never reads labels."""
    by_key={c['key']:c for c in group['candidates']}
    keys=[key for key in group['methods']['ordinary'][:8] if by_key[key]['success']]
    if not keys:raise ValueError('No successful current-default generated candidate')
    return max(keys,key=lambda key:by_key[key]['scores']['heuristic'])


def rank_metrics(candidates,truth,target_constitution):
    """Ranks within a bounded returned pool; a missing answer is censored."""
    exact=[i+1 for i,c in enumerate(candidates) if edge_set(c['connections'])==edge_set(truth)]
    constitution=[i+1 for i,c in enumerate(candidates) if c['constitution']==target_constitution]
    return dict(candidates=len(candidates),distinct_constitutions=len({c['constitution'] for c in candidates}),
        first_exact_connections_rank=min(exact,default=None),first_correct_constitution_rank=min(constitution,default=None),
        topk={str(k):dict(actual_candidates=min(k,len(candidates)),exact_connections=any(rank<=k for rank in exact),
            constitution=any(rank<=k for rank in constitution)) for k in K_VALUES})


def edge_ranks(prediction,truth):
    """Evaluate each true port/order against all scored options for its pair."""
    groups={};lookup={}
    for c in prediction['pool']:
        key=edge_key(c);lookup[key]=c;groups.setdefault((c['i'],c['j']),[]).append(c)
    rows=[]
    for e in truth:
        key=edge_key(e);options=sorted(groups.get((e['i'],e['j']),[]),key=lambda c:(-c['log_odds'],edge_key(c)))
        rank=next((i+1 for i,c in enumerate(options) if edge_key(c)==key),None);row=lookup.get(key)
        rows.append(dict(connection=list(key),rank=rank,options=len(options),
            probability=row['confidence'] if row else None,log_odds=row['log_odds'] if row else None,
            best_log_odds=options[0]['log_odds'] if options else None))
    return rows


def pose_quality(runtime,T,R,xyz,fit,fixture):
    target=np.asarray(fixture['target_xyz']);actual=np.asarray(xyz);errors=[];offset=np.cumsum([0]+[
        len(runtime.lib.template(label,runtime.oov[i])[1]) for i,label in enumerate(runtime.labels)])
    predicted=[runtime.lib.template(label,runtime.oov[i])[1]@R[i].T+T[i] for i,label in enumerate(runtime.labels)]
    projected=np.concatenate(predicted)
    for e in fixture['oracle_edges']:
        a,b=offset[e['i']]+e['a'],offset[e['j']]+e['b']
        errors.append(dict(connection=list(edge_key(e)),distance_A=float(np.linalg.norm(projected[a]-projected[b])),
            target_distance_A=float(np.linalg.norm(target[a]-target[b]))))
    return dict(slot_atom_rmsd_A=float(np.sqrt(np.mean(np.sum((actual-target)**2,-1)))),
        rigid_template_projection_rmsd_A=float(np.sqrt(np.mean(np.sum((projected-target)**2,-1)))),
        template_fit_max_A=float(max(fit,default=0.)),template_fit_mean_A=float(np.mean(fit)),
        true_bond_distances=errors,
        true_bond_distance_error_mean_A=float(np.mean([abs(e['distance_A']-e['target_distance_A']) for e in errors])) if errors else 0.)


def evaluate_condition(runtime,*,T,R,t,fixture,diagnostic_only=False):
    if not diagnostic_only:raise ValueError('Geometry ablation requires explicit diagnostic-only mode')
    T=np.asarray(T,dtype=float);R=np.asarray(R,dtype=float)
    if T.shape!=(len(runtime.labels),3) or R.shape!=(len(runtime.labels),3,3):raise ValueError('Invalid rigid pose shapes')
    if not np.isfinite(T).all() or not np.isfinite(R).all() or not 0<=t<=1:raise ValueError('Nonfinite pose/time')
    # Same unchanged normal search, same head/policy/time for all conditions.
    config=SearchConfig();prediction=runtime.predict(T,R,float(t),policy='wide',head='full')
    search=hierarchical_search(runtime,prediction,k=128,config=config)
    # Only AFTER unconditional search do diagnostic truth labels enter.
    truth=fixture['oracle_edges'];target=canonical(fixture['target_mol'],False)
    required=edge_set(truth);groups=option_groups(runtime,prediction)
    conditioned,stats=port_beam(runtime,adjacency_key(truth),groups,
        config=replace(config,port_width=256,per_skeleton=128),limit=128)
    support={edge_key(e) for vv in groups.values() for e in vv}
    truncated={edge_key(e) for vv in groups.values() for e in vv[:config.pair_options]}
    skeletons=[tuple(s['pairs']) for s in search['skeletons']];true_skeleton=adjacency_key(truth)
    true_color=colored_adjacency(runtime.labels,truth)
    colored=[colored_adjacency(runtime.labels,[dict(i=i,j=j,order=1) for i,j in pairs]) for pairs in skeletons]
    skeleton_rank=next((i+1 for i,pairs in enumerate(skeletons) if pairs==true_skeleton),None)
    color_rank=next((i+1 for i,color in enumerate(colored) if color==true_color),None)
    return dict(t=float(t),head='full',policy='wide',diagnostic_only=True,normal_generation_repaired=False,
        search_config=search['config'],conditional_port_width=256,conditional_limit=128,
        stage1=dict(candidates=len(skeletons),first_true_labelled_skeleton_rank=skeleton_rank,
            first_true_colored_skeleton_rank=color_rank),
        support=dict(required_edges=len(required),available_edges=len(required&support),pair_top64_edges=len(required&truncated)),
        true_edge_ranks=edge_ranks(prediction,truth),
        unconditional=rank_metrics(search['candidates'],truth,target),
        conditional_true_skeleton=rank_metrics(conditioned,truth,target),conditional_statistics=stats,
        internal_pool=rank_metrics(sorted(search['pool'],key=lambda c:-c['score']),truth,target),
        raw_head=dict(complete_legal=prediction['assembled'] is not None,
            exact_connections=edge_set(prediction['decision']['connections'])==required),
        candidates=dict(unconditional=search['candidates'],conditional_true_skeleton=conditioned),
        prediction=dict(meta=prediction['meta'].tolist(),p=prediction['p'].tolist(),sp=prediction['sp'].tolist()))
