#!/usr/bin/env python3
"""Summarize the four stage experiments without mixing their denominators."""
import json
import re
from pathlib import Path

import bootstrap
from run_validation import write_json
from validation import digest


def main():
    project=bootstrap.PROJECT;root=project/'results'
    s1=json.loads((root/'stage1/report.json').read_text())
    s2=json.loads((root/'stage2/report.json').read_text())
    s3=json.loads((root/'stage3/report.json').read_text())
    training=json.loads((root/'stage3_training/history.json').read_text())
    best=max(training,key=lambda x:x['val']['f1'])
    s4=json.loads((root/'stage4/report.json').read_text())
    stress=json.loads((root/'stage4_identity_updates/report.json').read_text())
    n6=json.loads((root/'stage4_customN6_v2/report.json').read_text())
    frozen=json.loads((root/'acceptance/report.json').read_text())['manifest']
    unchanged=all(digest(bootstrap.SOURCE/'sigmadock'/p)==h for p,h in frozen['source_sha256'].items())
    unchanged&=digest(bootstrap.CHECKPOINT)==frozen['checkpoint_sha256']
    if not unchanged:raise AssertionError('Official source/checkpoint changed')
    testlog=(root/'staged_tests.log').read_text()
    if '\nOK\n' not in testlog:raise AssertionError('Final tests did not pass')
    tests=int(re.findall(r'Ran (\d+) tests',testlog)[-1])
    lines=['# 四阶段扩展结果','',
        '前四节保留早先实验记录；最新预测修复与改进见文末专项结果及 [PREDICTION_RESULTS.md](PREDICTION_RESULTS.md)。','',
        '已完成真实 3684 模板兼容性、身份预测接口、独立连接模块训练、交替重建采样原型。'
        '原始 SigmaDock 源码与 EMA 权重哈希保持不变。原训练工程未改动。','',
        '## 阶段 1：六个切分不同的样本','',
        '六个样本均从实际 3684 封端模板和真实连接恢复完整化学分子并成功运行官方 docking；'
        '不同切分不要求图相等。4/6 个样本需要显式补充连接后形成的原子立体条件。'
        '原训练模板在真实位姿下重放的 RMSD 为 '
        f'{min(r["template_pose_replay_rmsd_A"] for r in s1["rows"]):.3f}–'
        f'{max(r["template_pose_replay_rmsd_A"] for r in s1["rows"]):.3f} Å。','',
        '| 组别 | 轨迹数 | 平均 RMSD (Å) | 中位 RMSD (Å) | RMSD <2 Å |',
        '| --- | ---: | ---: | ---: | ---: |']
    names={'official_baseline':'官方原切分基线','shared_official_reference':'3684 切分，共享官方参考构象',
           'independent_library_reference':'3684 切分，独立模板化学参考构象'}
    for key,label in names.items():
        m=s1['summary'][key]
        lines.append(f'| {label} | {m["n"]} | {m["mean_A"]:.4f} | {m["median_A"]:.4f} | {m["under2_fraction"]:.2%} |')
    lines+=['','固定原子对应重原子 RMSD，不对齐、不做对称性修正。每组 6 个配体 × 3 个种子。'
            '共享参考时结果接近；独立参考下 <2 Å 比例下降，不能仅凭均值相近声称性能完全相同。','',
            '## 阶段 2：全遮蔽身份预测','',
            f'- 12 个样本中有 {s2["identity_summary"]["known_slots"]} 个词表内槽位；'
            f'Top-1={s2["identity_summary"]["top1_accuracy"]:.2%}，Top-5={s2["identity_summary"]["top5_accuracy"]:.2%}。',
            f'- 预测身份有 {s2["summary"]["legal_predicted_molecules"]}/12 能完成合法化学组装及 docking；'
            '无法组装的样本在 backbone 前拒绝，保留在总分母中。',
            f'- 完整立体化学结构一致为 {s2["summary"]["predicted_chemical_exact"]}/12；'
            '该一致样本是保留显式 OOV 化学的 1r5y，不能算作词表内身份恢复成功。',
            '- 身份改变时使用新模板和新端口绑定。原子数或化学结构不同的输出不计算原索引 RMSD；'
            '报告 Tanimoto、MCS 覆盖率及合法率。','',
            '该轮身份模块是主要瓶颈，当时尚未重新训练；后续预测专项结果见本文末尾。身份 embedding 未写入官方 backbone。','',
            '## 阶段 3：连接预测训练及验证','',
            '- 17,420 个非 CASF 记录训练，271 个可用 CASF 缓存验证，交集为零。'
            '这是现有可用缓存范围，没有重新补齐原始 CASF 全集。',
            f'- 训练 5 轮，最佳为第 {best["epoch"]} 轮；约束筛选前端口/键级 F1={best["val"]["f1"]:.2%}。',
            f'- 原始候选覆盖率={best["val"]["candidate_recall"]:.2%}；训练扰动为近真实低噪声位姿。','',
            '| 约束筛选后的指标 | 结果 |','| --- | ---: |']
    m=s3['summary']
    for label,value in [('端口/键级 Precision',f'{m["precision"]:.2%}'),('端口/键级 Recall',f'{m["recall"]:.2%}'),
                        ('端口/键级 F1',f'{m["f1"]:.2%}'),('完整合法化学图',f'{m["complete_legal"]}/271 ({m["complete_legal"]/271:.2%})'),
                        ('整分子化学连接结构一致',f'{m["constitution_exact"]}/271 ({m["constitution_exact"]/271:.2%})'),
                        ('完整端口/键级集合一致',f'{m["exact_connections"]}/271')]:
        lines.append(f'| {label} | {value} |')
    lines+=['','49 个不完整或不合法预测留作候选，没有补入真实边。合法样本的化学连接结构一致率与端口索引指标分别报告。'
            '这些 F1 不包含新增手性中心正确率，也不是高噪声全程生成的成功率。','',
            '[训练 loss 与 F1 曲线](results/stage3_training/training_curves.png) · '
            '[最佳连接头](results/stage3_training/best.pt) · [训练历史](results/stage3_training/history.json)','',
            '## 阶段 4：动态重建原型','',
            '两个口袋、四种条件共 8 条完整 25 时间点采样均完成；固定图对照与原始官方 sampler 的最终坐标差为 0。'
            '主实验接受了 8 次连接/化学图更新，默认身份阈值下没有接受身份替换。','',
            '额外用身份阈值 0 进行结构更新压力测试，两条轨迹接受了 7 次真实身份替换，原子数随之改变；'
            '重建后重新计算了参考几何、刚体状态及动态边。该阈值仅验证实现，不代表推荐质量设置。'
            '另完成自定义 N=6 的采样，未使用原始槽位数。','',
            '| 实验 | 口袋 | 最终重原子数 | 接受的图更新 | 身份更新 | 跨片段键长异常数 | 配体内碰撞对数 |',
            '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for experiment,data in [('主实验',s4),('身份替换压力测试',stress),('用户指定 N=6',n6)]:
        for row in data['rows']:
            geometry=row.get('geometry_quality',{})
            changed=sum(e.get('accepted',False) and e.get('proposed_labels')!=e['old_labels'] for e in row['events'])
            lines.append(f'| {experiment}/{row["profile"]} | {row["id"]} | {row["quality"]["heavy_atoms"]} | '
                         f'{row["revisions"]} | {changed} | {geometry.get("bond_error_over_0_5A","NA")} | '
                         f'{geometry.get("ligand_nonbonded_clashes_under_1_2A","NA")} |')
    lines+=['','键长异常定义为与按元素共价半径估计的键长偏差 >0.5 Å，碰撞阈值为 1.2 Å（排除 1–2/1–3 邻接）。'
            '这些只是几何诊断，不能替代力场能量、Vina 或实验结合能力。输出 SDF 未额外用 Vina 优化。',
            '', '去除 Oracle 后仍有键长异常；少量闭环演示不能证明生成质量已经收敛。'
            '本轮结果支持继续改进身份模型、扩展连接模型的位姿噪声范围，并开展更大规模生成评估。','',
            '## 文件与复现','',
            '- 调用方式、条件说明和限制见 [STAGED.md](STAGED.md)。',
            '- 阶段报告： [stage1](results/stage1/report.json)、[stage2](results/stage2/report.json)、'
            '[stage3](results/stage3/report.json)、[stage4](results/stage4/report.json)。',
            '- 身份替换压力测试：[报告](results/stage4_identity_updates/report.json)；'
            '不同 N：[报告](results/stage4_customN6_v2/report.json)。',
            '- 每条第四阶段轨迹目录均保存 `molecule.sdf`、`coordinates.pt`、`final_chemistry.json`。',
            f'- {tests} 项测试通过，覆盖真实词表、立体条件、信息隔离、非法图、备选键级及位姿转移。',
            '- 原始官方源码与检查点哈希均保持不变；完整源码清单见 `STAGED_MANIFEST.json`。','']
    if (project/'PREDICTION_RESULTS.md').exists():
        lines+=['','以上为早先四阶段原型记录，最新预测诊断与改进如下。','',
                (project/'PREDICTION_RESULTS.md').read_text()]
    (project/'STAGED_RESULTS.md').write_text('\n'.join(lines))
    write_json(project/'STAGED_MANIFEST.json',dict(
        official_source_and_checkpoint_unchanged=unchanged,official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),
        scripts={str(p.relative_to(project)):digest(p) for p in sorted(project.glob('*.py'))},
        results={name:digest(root/name/'report.json') for name in ('stage1','stage2','stage3','stage4','stage4_identity_updates','stage4_customN6_v2')},
        tests=tests,scope='Four-stage research implementation and finite validation; no claim of converged de novo quality'))
    print(project/'STAGED_RESULTS.md')


if __name__=='__main__':main()
