#!/usr/bin/env python3
"""Auditable report for topology coverage, no-truth ranking and holdout tests."""
import argparse
import csv
from datetime import datetime,timezone
import json
from pathlib import Path

import bootstrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch

from prepare_reranker_experiment import ROOT
from run_validation import write_json
from validation import digest


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    a=p.parse_args();root=a.root
    evaluation=json.loads((root/'evaluation_disjoint/report.json').read_text());summary=evaluation['summary']
    receiver_only=json.loads((root/'evaluation_final/report.json').read_text())
    chemistry_audit=json.loads((root/'all_casf_chemical_overlap_audit.json').read_text())
    historical=json.loads((root/'historical_ranking_analysis.json').read_text())
    cohorts=json.loads((root/'cohorts.json').read_text());history=json.loads((root/'fitting_disjoint/history.json').read_text())
    status=json.loads((root/'fitting_disjoint/status.json').read_text());protocol=json.loads((root/'fitting_disjoint/protocol.json').read_text())
    regression=json.loads((root/'oracle_regression/report.json').read_text())
    collections=[json.loads(p.read_text()) for role in ['train','calibration','holdout'] for p in root.glob(f'{role}_*/report.json')]
    counts={}
    for role in ['train','calibration','holdout']:
        groups=[g for r in collections for g in r['groups'] if g['role']==role]
        covered=generated=0;positives=0
        for g in groups:
            labels={r['key']:r for r in json.loads(Path(g['labels_path']).read_text())}
            generated_keys=set(sum(g['methods'].values(),[]))
            generated+=any(labels[k]['constitution_correct'] for k in generated_keys if k in labels)
            covered+=any(r['constitution_correct'] for r in labels.values());positives+=sum(r['constitution_correct'] for r in labels.values())
        counts[role]=dict(groups=len(groups),molecules=len({g['id'] for g in groups}),
            attempted_candidates=sum(len(g['candidates']) for g in groups),successful_candidates=sum(c['success'] for g in groups for c in g['candidates']),
            generated_pool_positive_groups=generated,all_available_candidates_positive_groups=covered,positive_candidates=positives)
    counts['fitted']=dict(train_molecules=protocol['train_molecules'],train_candidates=protocol['train_candidates'],
        calibration_molecules=protocol['calibration_molecules'],calibration_candidates=protocol['calibration_candidates'],
        excluded_ids=protocol['excluded_ids'])
    write_json(root/'dataset_summary.json',counts)
    rows=evaluation['rows']
    fields=['search','K','scorer','runs','candidate_coverage','strict_candidate_coverage','colored_skeleton_coverage','labelled_adjacency_coverage','constitution_correct','connections_correct','chemical_valid','geometry_abnormal','pocket_clash','mean_completed_candidates','mean_distinct_skeletons','mean_backbone_evaluations','median_sampling_seconds','median_shared_search_seconds']
    with (root/'holdout_metrics.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for search,kk in summary.items():
            for k,mm in kk.items():
                for method,metrics in mm.items():writer.writerow(dict(search=search,K=k,scorer=method,**metrics))
    lookup={(r['id'],r['seed'],r['search'],r['K'],r['scorer']):r for r in rows}
    changes=[]
    for row in rows:
        if row['scorer']!='reranker':continue
        old=lookup[row['id'],row['seed'],row['search'],row['K'],'heuristic']
        kind='coverage_missing' if not row['candidate_coverage'] else 'reranker_rescue' if row['constitution_correct'] and not old['constitution_correct'] else 'reranker_regression' if old['constitution_correct'] and not row['constitution_correct'] else 'both_correct' if row['constitution_correct'] else 'ranking_remaining'
        changes.append(dict(id=row['id'],seed=row['seed'],search=row['search'],K=row['K'],kind=kind,heuristic_selected=old['selected'],reranker_selected=row['selected']))
    write_json(root/'ranking_case_changes.json',changes)
    plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25,'figure.dpi':160})
    fig,axes=plt.subplots(1,3,figsize=(15,4))
    for method in ['heuristic','connection','geometry','pocket','oracle']:
        axes[0].plot([1,4,8],[historical['summary'][str(k)][method]['constitution_correct'] for k in [1,4,8]],marker='o',label=method)
    axes[0].plot([1,4,8],[evaluation['historical_reranker'][str(k)]['constitution_correct'] for k in [1,4,8]],marker='o',label='reranker')
    axes[0].set(title='Historical CASF: ranking failure diagnosis',xlabel='K',ylabel='Correct constitution / 36',xticks=[1,4,8],ylim=(0,36));axes[0].legend(fontsize=8)
    for search,color in [('ordinary','#0077bb'),('diverse','#cc3311')]:
        axes[1].plot([1,4,8],[summary[search][str(k)]['heuristic']['candidate_coverage'] for k in [1,4,8]],color=color,marker='o',label=search)
    axes[1].set(title='NEW CASF receptors: candidate coverage',xlabel='K',ylabel='Groups containing correct constitution / 36',xticks=[1,4,8],ylim=(0,36));axes[1].legend()
    for search,color in [('ordinary','#0077bb'),('diverse','#cc3311')]:
        axes[2].plot([1,4,8],[summary[search][str(k)]['heuristic']['colored_skeleton_coverage'] for k in [1,4,8]],color=color,marker='o',label=search)
    axes[2].set(title='NEW CASF: colored skeleton coverage',xlabel='K',ylabel='Groups containing correct skeleton / 36',xticks=[1,4,8],ylim=(0,36));axes[2].legend()
    fig.tight_layout();fig.savefig(root/'coverage_and_ranking.png');fig.savefig(root/'coverage_and_ranking.pdf');plt.close(fig)
    methods=['heuristic','connection','geometry','pocket','reranker','oracle']
    columns=[(s,k) for s in ['ordinary','diverse'] for k in [1,4,8]]
    matrix=np.array([[summary[s][str(k)][m]['constitution_correct'] for s,k in columns] for m in methods])
    fig,ax=plt.subplots(figsize=(9,5));im=ax.imshow(matrix,vmin=0,vmax=36,cmap='Blues',aspect='auto')
    ax.set_xticks(range(6),[f'{s}\nK={k}' for s,k in columns]);ax.set_yticks(range(6),methods)
    ax.set(title='Independent CASF: correct constitution / 36 (Oracle is an upper bound)')
    for i in range(6):
        for j in range(6):ax.text(j,i,f'{matrix[i,j]}/36',ha='center',va='center',color='white' if matrix[i,j]>20 else 'black')
    ax.grid(False);fig.colorbar(im,ax=ax);fig.tight_layout();fig.savefig(root/'scoring_comparison.png');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(13,4))
    for search,color in [('ordinary','#0077bb'),('diverse','#cc3311')]:
        for method,ls in [('heuristic','--'),('reranker','-')]:
            for ax,field,title in zip(axes[:2],['constitution_correct','connections_correct'],['Constitution exact','All connections exact']):
                ax.plot([1,4,8],[summary[search][str(k)][method][field] for k in [1,4,8]],marker='o',color=color,ls=ls,label=f'{search}/{method}')
                ax.set(title=title,xlabel='K',ylabel='Correct / 36',xticks=[1,4,8],ylim=(0,36))
        axes[2].plot([1,4,8],[summary[search][str(k)]['reranker']['mean_backbone_evaluations'] for k in [1,4,8]],marker='o',color=color,label=search)
    axes[0].legend(fontsize=7);axes[2].set(title='Sampling cost',xlabel='K',ylabel='Mean backbone evaluations',xticks=[1,4,8],ylim=(0,None));axes[2].legend()
    fig.tight_layout();fig.savefig(root/'reranker_holdout.png');fig.savefig(root/'reranker_holdout.pdf');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4));epochs=[r['epoch'] for r in history]
    axes[0].plot(epochs,[r['train_loss'] for r in history],label='train loss')
    axes[0].plot(epochs,[r['calibration_pair_loss'] for r in history],label='non-CASF calibration pair loss')
    axes[0].axvline(status['best_epoch'],color='#cc3311',ls='--',label=f"Selected {status['best_epoch']}")
    axes[0].set(title='Independent reranker training',xlabel='Epoch',ylabel='Loss');axes[0].legend(fontsize=8)
    axes[1].plot(epochs,[r['calibration']['accuracy']*100 for r in history],label='full correctness')
    axes[1].plot(epochs,[r['calibration']['selected_connection_f1']*100 for r in history],label='selected partial edge F1')
    axes[1].set(title='Non-CASF calibration (sparse positive pools)',xlabel='Epoch',ylabel='Percent',ylim=(0,100));axes[1].legend(fontsize=8)
    fig.tight_layout();fig.savefig(root/'reranker_loss.png');plt.close(fig)
    prefix=root.relative_to(bootstrap.PROJECT).as_posix()
    lines=['# 拓扑候选覆盖与无真值排序专项（2026-11-01）','',
        '本轮冻结官方 SigmaDock、身份模型和原时间条件连接头，仅训练独立 Topology Reranker。完成旧候选排序诊断、非 CASF 多拓扑轨迹监督、完整连接去重/骨架多样性搜索，以及新 CASF 受体的独立比较。','',
        '严格化学去重后的新测试中，排序器构造正确数为 0/36，尚无可采用的排序提升。多样性搜索提高了正确连接骨架覆盖，但未提高完整分子构造覆盖；本轮主要定位了端口组合覆盖与监督数据稀缺的问题。','',
        '## 现有候选的排序失败','',
        '沿用上一轮 12 个 CASF 受体×3 seed 的 baseline 候选，不重新采样；比较分数时特征计算不读取真实拓扑或目标位姿。真实标签只用于事后正确率与 Oracle 排序上界。','',
        '| K | 当前启发式 | 连接概率 | 纯几何 | 几何＋口袋接触 | 新排序器开发复核 | Oracle 排序上界 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for k in [1,4,8]:
        h=historical['summary'][str(k)];learn=evaluation['historical_reranker'][str(k)]['constitution_correct']
        values=[h[m]['constitution_correct'] for m in ['heuristic','connection','geometry','pocket']]+[learn,h['oracle']['constitution_correct']]
        lines.append(f'| {k} | '+' | '.join(f'{v}/36' for v in values)+' |')
    lines+=['',f"原启发式复现最大误差 {historical['max_historical_heuristic_reproduction_error']:.3g}。K=8 有 15/36 个池含正确构造，启发式选中 8/36，7 次属于排序损失；其余 21 次属于覆盖损失，排序器无法创造缺失候选。旧受体用于开发诊断，不能当作新的独立测试集。",
        '', '## 数据隔离与排序器训练','',
        f"采集：{counts['train']['molecules']} 个非 CASF 训练分子、{counts['train']['successful_candidates']} 个成功候选；另采集 {counts['calibration']['molecules']} 个校准分子、{counts['calibration']['successful_candidates']} 个候选。按槽位数 2–4/5–8/9–12 分层固定选择。训练每组最多普通/多样性 Top-4 并集，校准最多 Top-8 并集。",
        '', f"化学重合审计后，最终参数训练使用 {protocol['train_molecules']} 个分子、{protocol['train_candidates']} 个候选；校准使用 {protocol['calibration_molecules']} 个分子、{protocol['calibration_candidates']} 个候选。统一剔除了与全部 271 个可用 CASF 配体构造完全重复的 {', '.join(protocol['excluded_ids'])}。该规则只读取二维化学图，不按测试评分结果筛选，模型结构、学习率、种子和选模规则均保持不变。原受体 ID 拆分版本保留为对照。",
        '', '仅训练集额外加入已知真实连接构造的候选，使用同样的模板组装、随机起点和冻结主干采样；该候选若采样后被错误更新，其标签按实际最终结构重新计算。候选来源不是评分特征。校准和 CASF 均没有真拓扑候选注入或图修复。',
        '', f"初始 12 分子校准池只有 {counts['calibration']['generated_pool_positive_groups']}/{counts['calibration']['groups']} 组含正确构造，不能凭稀少的完整正确率声称可靠收敛。初次按完整正确率/MRR 选模出现轮次平局，后在读取新 CASF 结果前加入部分连接 F1 和分级验证排序损失作平局指标。化学去重后按相同设置重新拟合，最终 epoch={status['best_epoch']}；模型和数据修正理由均保存。",
        '', f"模型为 {protocol['hidden']} 隐层的独立 MLP，输入 {len(protocol['feature_names'])} 个目标无关特征，使用分组均衡的成对排序损失和辅助正确/错误分类。输入归一化只拟合训练集。训练的可学习参数不包括原主干、身份头或连接头。",
        '', '特征包括候选化学描述符/局部官能团、连接度、当前预测连接概率、键长与碰撞、极性/碳接触、口袋接近程度、生成轨迹稳定性和模板拟合误差。口袋分数是接触几何代理，不是 Vina 能量或实验亲和力。真实边、真实端口、目标坐标、RMSD、分子 ID/seed、候选来源、正确标签都不进入评分器。',
        '', f'![排序器 loss]({prefix}/reranker_loss.png)',
        '', '## 完整连接去重与骨架多样性','',
        '普通搜索严格复用上一轮：有容量约束的树搜索，考察最多 64 个端口图并按分子构造去重。新搜索先按完整连接键（槽位、两端口、键级、双键立体标记）去重，再增加槽位对排除和固定随机种子的骨架扰动；采用标准化连接分数与骨架新颖度的 MMR 选择，预先固定 diversity_weight=1.5。',
        '', '两组 K=1 的初始候选完全一致；K=4/8 为各自嵌套前缀，不复制不足的候选。所有评分方式在完全相同的已生成候选上比较。相同输入完整连接只采样一次，避免把重复采样当作搜索收益。骨架标色使用冻结片段类别；OOV 统一类别可能合并不同未知片段的标色签名，但槽位对新颖度及完整连接键仍保留其位置区别。',
        '', '## 新 CASF 受体的独立验证','',
        '受体 ID：`'+', '.join(cohorts['casf_holdout'])+'`。这 12 个受体不在前面 12 个开发受体中，也不在非 CASF 训练/校准集合中；每个初始 seed=1801/1802/1803，共 36 组。固定真实片段身份和 N，未更新身份。候选由冻结原连接头＋原阈值产生。初版模型在读取新测试标签前冻结；发现化学重合后按统一数据规则重训，未据测试分数调参。下表为修正后的复算结果。',
        '', '| 搜索 | K | 正确骨架覆盖 | 正确构造池覆盖 | 启发式构造正确 | Reranker 构造正确 | Reranker 全连接正确 | 选中结构合法 | 几何异常 | 平均骨架数 | 平均 NFE | 采样中位耗时 s |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for search in ['ordinary','diverse']:
        for k in [1,4,8]:
            r=summary[search][str(k)]['reranker'];h=summary[search][str(k)]['heuristic']
            lines.append(f"| {search} | {k} | {r['colored_skeleton_coverage']}/36 | {r['candidate_coverage']}/36 | {h['constitution_correct']}/36 | {r['constitution_correct']}/36 | {r['connections_correct']}/36 | {r['chemical_valid']}/36 | {r['geometry_abnormal']}/36 | {r['mean_distinct_skeletons']:.2f} | {r['mean_backbone_evaluations']:.1f} | {r['median_sampling_seconds']:.2f} |")
    lines+=['','完整连接正确要求给定槽位对应下的所有端口和键级一致；分子构造正确忽略立体化学且容许化学图同构。两者都不代表所有立体异构信息恢复，也不表示正确结合位姿。正确骨架覆盖仅比较片段类别标色树，忽略原子端口。几何异常沿用任一片段间键误差>0.5 Å 或配体非键合距离<1.2 Å；失败也计异常。合法率仅表示可组装、可采样。','',
        f'![覆盖与排序]({prefix}/coverage_and_ranking.png)', '',f'![独立验证各评分方式]({prefix}/scoring_comparison.png)', '',f'![排序器与搜索对照]({prefix}/reranker_holdout.png)',
        '', '所有评分方式详表如下。Oracle 排序仅在现有候选内读取真实标签挑选上界，没有额外生成真候选；它不属于无真值推理结果。','',
        '| 搜索 | K | 启发式 | 连接概率 | 几何 | 几何＋口袋 | Reranker | Oracle 上界 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for search in ['ordinary','diverse']:
        for k in [1,4,8]:
            vals=[summary[search][str(k)][m]['constitution_correct'] for m in methods]
            lines.append(f'| {search} | {k} | '+' | '.join(f'{v}/36' for v in vals)+' |')
    lines+=['', '## 树约束的适用范围','',
        '当前非环断键切分数据的片段图为 N−1 条边的树，继续执行该约束和端口容量检查。分子内部、单个片段内部的环正常保留；但本搜索不能生成新的跨片段闭环。未来若需要跨片段成环，必须引入允许环的连接搜索与环感知骨架编码，重新评估覆盖率，不能直接外推本报告结果。',
        '', '## 成本、回归与采用','',
        '表中耗时为同一方法候选的采样及特征提取耗时之和，不含两种搜索共享的候选枚举；共享枚举耗时另列 CSV。每个成功候选 24 次原主干调用，NFE 比共享服务器的 wall time 更适合比较预算。原分子/受体范围仍有限，非 CASF 校准正例覆盖尤其低，不能仅凭训练 loss 判断推广能力。',
        '', '原官方采样器回归和只读 Oracle/shadow 路径再次检查；真实拓扑只用于这些明确诊断和训练监督，不修补普通/多样性 CASF 生成。排序器特征的标签隔离、全局坐标变换不变性、骨架置换不变性和 CASF 训练拒绝均有测试。',
        '', f"原版采样器回归：{len(regression['regression'])} 个固定样本的最大坐标差均为 0 Å；Oracle/shadow 最大坐标差为 {max(r.get('oracle_shadow_max_coordinate_difference_A',0.) for r in regression['rows']):g} Å。测试记录：{next(x for x in (root/'tests.log').read_text().splitlines() if x.startswith('Ran '))}，结果 OK。",
        '', f'[独立测试 CSV]({prefix}/holdout_metrics.csv) · [逐案例得失]({prefix}/ranking_case_changes.json) · [排序模型]({prefix}/fitting_disjoint/best.pt) · [候选特征列表/训练参数]({prefix}/fitting_disjoint/protocol.json) · [化学重合审计]({prefix}/all_casf_chemical_overlap_audit.json) · [复现及推理接口](TOPOLOGY_RERANKER.md)', '']
    lines+=['', '## 数据修正后的结论','',
        f"仅按受体 ID 拆分时，普通 K=8 的排序器曾选中 {receiver_only['summary']['ordinary']['8']['reranker']['constitution_correct']}/36。审计发现其中配体构造与训练集重复；统一剔除全部 CASF 构造重复后，同一固定候选池的最终结果为 {summary['ordinary']['8']['reranker']['constitution_correct']}/36，不能把原结果当作新配体泛化提升。去重同时改变了归一化与校准选模，不能把差异单独归因于一个训练样本。",
        '', f"普通 K=8 的正确标色骨架覆盖为 {summary['ordinary']['8']['oracle']['colored_skeleton_coverage']}/36，骨架多样性搜索为 {summary['diverse']['8']['oracle']['colored_skeleton_coverage']}/36；但两者正确分子构造均只覆盖 {summary['ordinary']['8']['oracle']['candidate_coverage']}/36。改变连接骨架没有解决端口/原子连接位置的组合缺失，排序器也无法修复候选池中不存在的构造。",
        '', f"真连接组装检查的构造不一致样本为 {chemistry_audit['true_topology_roundtrip_mismatches']}。因此本轮缺失不是库中完全无法表示真实构造，而是固定预算的候选生成没有把它选入池。下一步应优先联合考虑骨架与每个骨架下的端口分配，并扩大有正确候选的独立校准数据；本轮不替换原连接头，也不将新排序器设为默认。",
        '', '受体 ID 独立和分子构造独立是两种定义。本轮严格去重只针对新排序器的训练/校准集；冻结的历史 GEOM/PDBbind 连接头及官方预训练模型并未重训，也未重新全面审计其历史化学重合。12 个受体×3 seed 不是 36 个独立受体，当前结果不支持宣称通用生成质量提升。','']
    (bootstrap.PROJECT/'TOPOLOGY_RERANKER_RESULTS.md').write_text('\n'.join(lines))
    old=json.loads((bootstrap.PROJECT/'PREDICTION_MANIFEST.json').read_text());changes=[n for n,h in old['official_source_sha256'].items() if digest(bootstrap.OFFICIAL/n)!=h]
    if changes or digest(bootstrap.CHECKPOINT)!=old['official_checkpoint_sha256']:raise RuntimeError('Official model changed')
    connection=bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt'
    previous=json.loads((bootstrap.PROJECT/'CONNECTION_ROBUST_MANIFEST.json').read_text())
    if digest(connection)!=previous['new_connection_sha256']:raise RuntimeError('Frozen connection head changed')
    identity=bootstrap.PROJECT/'results/prediction_diagnostics/identity_controls/iterative/best.pt'
    if digest(identity)!=old['checkpoints']['iterative']:raise RuntimeError('Identity model changed')
    lock=json.loads((root/'final_model_lock.json').read_text())
    if digest(root/'fitting_disjoint/best.pt')!=lock['checkpoint_sha256']:raise RuntimeError('Locked reranker changed')
    if digest(root/'all_casf_chemical_overlap_audit.json')!=lock['exclusion_audit_sha256']:raise RuntimeError('Locked exclusion audit changed')
    audits=[json.loads(p.read_text()) for p in root.glob('*_*/*/*/audit.json')]
    if not all(r['all_dynamic_recomputations_equal'] for r in audits):raise RuntimeError('Dynamic graph audit failed')
    tests=(root/'tests.log').read_text();test_line=next(x for x in tests.splitlines() if x.startswith('Ran '))
    manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),prompt_sha256=digest(bootstrap.WORKSPACE/'prompt.md'),
        official_source_changed=changes,official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),connection_checkpoint_sha256=digest(connection),identity_checkpoint_sha256=digest(identity),
        reranker_checkpoint_sha256=digest(root/'fitting_disjoint/best.pt'),model_lock=lock,
        chemical_exclusion_audit=chemistry_audit,
        oracle_regression=regression['regression'],oracle_shadow_max_difference_A=max(r.get('oracle_shadow_max_coordinate_difference_A',0.) for r in regression['rows']),
        completed_candidate_audits=len(audits),audited_backbone_forwards=sum(len(r['forwards']) for r in audits),
        cohorts=cohorts,datasets=counts,tests=test_line,test_success='\nOK\n' in tests,
        scripts={n:digest(bootstrap.PROJECT/n) for n in ['topology_reranker.py','topology_diversity.py','collect_topology_candidates.py','train_topology_reranker.py','evaluate_topology_reranking.py','score_topology_candidates.py','audit_reranker_chemistry.py','summarize_topology_reranker.py']},
        results={str(p.relative_to(root)):digest(p) for p in [root/'evaluation_disjoint/report.json',root/'historical_ranking_analysis.json',root/'holdout_metrics.csv',root/'fitting_disjoint/protocol.json']})
    write_json(bootstrap.PROJECT/'TOPOLOGY_RERANKER_MANIFEST.json',manifest)
    stage=bootstrap.PROJECT/'STAGED_RESULTS.md';marker='\n## 2026-11-01：候选覆盖与独立拓扑排序器'
    stage.write_text(stage.read_text().split(marker)[0]+marker+'\n\n已完成旧候选排序诊断、非 CASF 独立排序器和新 CASF 受体的普通/骨架多样性 Top-K 比较。详细结果见 [专项报告](TOPOLOGY_RERANKER_RESULTS.md)，接口见 [TOPOLOGY_RERANKER.md](TOPOLOGY_RERANKER.md)。\n')
    print(json.dumps(dict(training=status,datasets=counts,holdout=summary,tests=test_line),indent=2))


if __name__=='__main__':main()
