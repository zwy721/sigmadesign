#!/usr/bin/env python3
"""Deterministic chemistry-only split audit; no pose or model score is used."""
import argparse
import json

import bootstrap
import torch
from rdkit import Chem

from prepare_reranker_experiment import ROOT
from prepare_trajectory_inputs import SOURCE
from run_validation import write_json
from vocab_chemistry import VocabLibrary,canonical,assemble_slots


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=type(ROOT),default=ROOT)
    a=p.parse_args();cohorts=json.loads((a.root/'cohorts.json').read_text())
    sources={r['pdb_id']:r for r in map(json.loads,SOURCE.open())}
    casf_ids=json.loads((bootstrap.RECORDS.parent/'val_ids.json').read_text());chemistry={};failures=[]
    for pid in casf_ids:
        mol=Chem.SDMolSupplier(sources[pid]['sdf_path'],removeHs=True)[0]
        if mol is None:failures.append(pid);continue
        mol.RemoveAllConformers();chemistry.setdefault(canonical(mol,False),[]).append(pid)
    lib=VocabLibrary();overlap={};mismatches=[]
    for role in ['train','calibration','casf_holdout']:
        overlap[role]=[]
        for pid in cohorts[role]:
            fixture=torch.load(a.root/f'inputs/{pid}/fixture.pt',weights_only=False)
            key=canonical(Chem.RemoveHs(Chem.Mol(fixture['target_mol'])),False)
            if role!='casf_holdout' and key in chemistry:overlap[role].append(dict(id=pid,matching_casf_ids=chemistry[key]))
            mol,_,_=assemble_slots(lib,fixture['labels'],fixture['oracle_edges'],oov=fixture['oov'])
            if canonical(mol,False)!=canonical(fixture['target_mol'],False):mismatches.append(pid)
    write_json(a.root/'all_casf_chemical_overlap_audit.json',dict(
        definition='Exact canonical constitution after hydrogen removal and stereo removal; compare against all 271 available CASF ligand graphs; no pose/score used.',
        casf_molecules=len(casf_ids),casf_read_failures=failures,overlaps=overlap,
        excluded_ids=[r['id'] for role in ['train','calibration'] for r in overlap[role]],true_topology_roundtrip_mismatches=mismatches))


if __name__=='__main__':main()
