#!/usr/bin/env python3
"""Generate a readable, evidence-linked acceptance report from one completed run."""
import argparse
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--report', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    report = a.report.resolve()
    data = json.loads(report.read_text())
    if data['stage'] != 'paired_docking_complete' or not data['accepted']:
        p.error('A completed, accepted full docking run is required')
    manifest = data['manifest']
    rows = data['rows']
    pairs = [d for r in rows for d in r['docking']]
    matched = [r['id'] for r in rows if r['partition3684']['usable_as_same_graph']]
    mismatched = [r['id'] for r in rows if not r['partition3684']['usable_as_same_graph']]
    geometric_updates = sum(len(d[k]['audit']['updates']) for d in pairs for k in ('official', 'reconstructed'))
    network_calls = sum(len(d[k]['audit']['forwards']) for d in pairs for k in ('official', 'reconstructed'))
    max_delta = max(d['max_trajectory_difference_A'] for d in pairs)
    all_hashes = all(d['per_step_hashes_identical'] for d in pairs)
    lines = ['# Oracle 化学图重建验收结果', '',
        f'已完成 {len(rows)} 个 CASF 配体 × {len(manifest["seeds"])} 个种子 '
        f'× 官方/重建两组，共 {len(pairs) * 2} 条完整采样轨迹。', '',
        f'- 图一致性：{sum(r["graph_exact"] for r in rows)}/{len(rows)} 样本逐项精确一致。',
        f'- 全轨迹坐标最大差异：{max_delta:.9g} Å；所有逐步输入/输出/几何哈希相同：{all_hashes}。',
        f'- 共审计 {geometric_updates} 次图更新、{network_calls} 次网络前向；每步动态边、距离和方向检查通过。',
        f'- 与 3684 缓存切分及真实连接一致：{", ".join(matched)}。',
        f'- 单独记录、排除出 3684 同图结论：{", ".join(mismatched)}。', '',
        '| 验收集合 | 模型输入 | 轨迹数 | 平均 RMSD (Å) | 中位 RMSD (Å) | RMSD <2 Å |',
        '| --- | --- | ---: | ---: | ---: | ---: |']
    for cohort, label in [('official_partition', '官方切分全部样本'),
                          ('matching_3684_partition', '3684 切分/连接相同子集')]:
        for key, name in [('official', '官方直接建图'), ('reconstructed', 'Oracle 化学重建')]:
            s = data['summary'].get(f'{cohort}/{key}')
            if s:
                lines.append(f'| {label} | {name} | {s["n"]} | {s["mean_A"]:.4f} | '
                             f'{s["median_A"]:.4f} | {s["under2_fraction"]:.2%} |')
    lines += ['', '固定原子对应的重原子 RMSD，受体坐标框架，不做对齐或对称性修正；'
              '不是 best-of-seeds，所有指定种子都计入统计。两组使用同一个官方 EMA 权重。', '',
              '## 逐配体结果', '',
              '| CASF | 官方/3684 片段数 | 3684 切分及连接相同 | 官方平均 RMSD (Å) | 重建平均 RMSD (Å) |',
              '| --- | ---: | --- | ---: | ---: |']
    for r in rows:
        d = r['partition3684']
        official = sum(x['official']['rmsd_A'] for x in r['docking']) / len(r['docking'])
        restored = sum(x['reconstructed']['rmsd_A'] for x in r['docking']) / len(r['docking'])
        n = len(d['vocab3684_atom_groups'])
        link = (report.parent / r['id'] / 'partition3684.json').as_posix()
        lines.append(f'| [{r["id"]}]({link}) | {r["graph"]["fragments"]}/{n} | '
                     f'{"是" if d["usable_as_same_graph"] else "否"} | {official:.4f} | {restored:.4f} |')
    lines += ['', '## 实现中定位的问题', '',
        '仅补上跨片段边不能恢复官方输入。需要先恢复完整化学分子，保留原子和键顺序，再让官方流程重新处理切分、'
        '原子价态/度数、锚点、dummy、虚拟节点及约束结构。', '',
        'CASF 回归测试进一步发现：官方构象生成和 canonical 切分会影响手性标签的清理与重排。'
        '直接复制 SDF 标签，或者提前设置 RDKit 的 _StereochemDone 感知缓存，都会改变输入特征。'
        '新模块捕获官方切分前参考模板，并保留官方化学感知过程，随后按真实连接切分。', '',
        '独立身份库入口见 `template_library.py` 和 `build_from_library.py`：实例只携带身份编号、'
        '真实连接及几何/顺序绑定，原子和片段内部化学键从独立 Oracle 模板库查询。'
        '额外的 `library_validation.json` 要求查库恢复的完整化学输入及图与本轮 docking 输入精确一致。'
        '这是显式 Oracle 身份库，尚不等于旧 3684 编号到全部化学上下文的无损映射。', '',
        '图文件使用保留所有 RDKit 属性的序列化方式，避免丢失 `fragmentation_mapping`。'
        '`serialization_validation.json` 记录所有已验收输入张量保持不变、读回后完整图与元数据一致。', '',
        '## 可复现配置与边界', '',
        f'- 官方源码提交：`{manifest["official_commit"]}`。',
        f'- 权重 SHA256：`{manifest["checkpoint_sha256"]}`。',
        f'- docking 种子：`{manifest["seeds"]}`；图种子：`{manifest["graph_seed"]}`。',
        f'- 采样：{manifest["steps"]} 个时间点，{manifest["steps"] - 1} 次 Euler 更新；'
        'EDM、rho=3、t_min=0.005，使用原始官方 sampler；启用确定性运算、关闭 TF32。',
        '- 为严格比较，5 Å 口袋筛选的扰动、坐标抖动和随机旋转均关闭；'
        '因此这些绝对 RMSD 不应直接与早先采用口袋随机扰动的运行比较。',
        '- 参考构象由官方 RDKit 流程生成；晶体配体坐标仅用于口袋定义、原子对应和最终评价。',
        '- 本轮证明显式 Oracle 化学模板可以保留官方 docking 输出。没有证明全部 3684 编号能无损还原官方片段，'
        '也没有测试身份/连接预测误差、拓扑变化或 de novo 生成。',
        '- 未启动训练、身份预测或下一阶段动态生成。', '',
        f'完整逐步审计和输入/代码/权重哈希见 [report.json]({report.as_posix()})。', '']
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text('\n'.join(lines))
    print(a.output)


if __name__ == '__main__':
    main()
