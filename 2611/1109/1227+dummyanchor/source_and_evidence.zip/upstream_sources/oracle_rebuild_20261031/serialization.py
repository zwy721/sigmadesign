"""Preserve RDKit fragment mapping and stereo metadata in graph artifacts."""
from pathlib import Path

import bootstrap  # noqa: F401
import torch
from rdkit import Chem


def save_graph(graph, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    previous = Chem.GetDefaultPickleProperties()
    try:
        Chem.SetDefaultPickleProperties(Chem.PropertyPickleOptions.AllProps)
        torch.save(graph, path)
    finally:
        Chem.SetDefaultPickleProperties(previous)
