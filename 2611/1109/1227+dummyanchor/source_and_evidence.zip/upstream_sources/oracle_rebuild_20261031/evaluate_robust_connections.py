#!/usr/bin/env python3
"""Paired old/full-noise/staged validation with held-out diffusion seeds."""
import argparse
import json
from pathlib import Path
import time

import bootstrap
import numpy as np
import torch

from connection_predictor import PortConnectionPredictor
from robust_connection_data import build_cache,pack_records,noisy_frames,candidate_features,make_official_diffuser
from robust_connection_model import TimeConnectionPredictor,predict_probabilities,legal_decode_fast
from run_validation import write_json
from train_robust_connections import GRID
from validation import digest
from vocab_chemistry import VocabLibrary,explicit_oov,assemble_slots,canonical


def hydrate_oov(rows):
    for row in rows:
        if (row['chem']['labels']<0).any():
            r=torch.load(bootstrap.RECORDS/f"{row['id']}.pt",weights_only=False)
            row['oov']=explicit_oov(r)
        else:row['oov']=[None]*len(row['chem']['labels'])


def metadata(packed,features):
    chem=packed['chem'];ix=features['indices'];a,b=chem['pairs'][ix].T
    molecule=chem['pair_mol'][ix]
    offset=torch.cat([chem['n'].new_zeros(1),chem['n'].cumsum(0)[:-1]]).long()
    s=chem['slot'];atom=chem['atom']
    meta=torch.stack([s[a]-offset[molecule],s[b]-offset[molecule],atom[a],atom[b]],-1)
    return meta.cpu().numpy(),molecule.cpu().numpy()


def truth(row):
    c=row['chem'];active=torch.where(row['target']['y']>0)[0];a,b=c['pairs'][active].long().T;s=c['slot'];atom=c['atom']
    return [dict(i=int(s[aa]),j=int(s[bb]),a=int(atom[aa]),b=int(atom[bb]),order=int(row['target']['y'][k]),
                 stereo=int(row['target']['stereo'][k])) for aa,bb,k in zip(a,b,active)]


def edge_set(edges):return {(c['i'],c['j'],c['a'],c['b'],c['order']) for c in edges}


def retained_keys(row,meta):
    c=row['chem'];allowed={(int(s),int(a)):set(i+1 for i,v in enumerate(order) if v)
        for s,a,order in zip(c['slot'],c['atom'],c['allowed'])}
    return {(int(i),int(j),int(a),int(b),o) for i,j,a,b in meta for o in (1,2)
            if o in allowed.get((int(i),int(a)),set()) and o in allowed.get((int(j),int(b)),set())}


def metric_row(lib,row,meta,prob,sp,threshold,*,candidate_pool=None,commit=True):
    actual=edge_set(truth(row));candidate_keys=retained_keys(row,meta)
    if not commit:
        return dict(id=row['id'],slots=len(row['chem']['labels']),true_bonds=row['target']['true_bonds'],predicted=0,tp=0,
            port_tp=0,
            candidate_hits=len(actual&candidate_keys),candidate_pairs=len(meta),retained_hypotheses=len(candidate_keys),
            complete_legal=len(row['chem']['labels'])==1,full_ports_exact=not actual,
            constitution_exact=not actual,committed=False,connections=[])
    if candidate_pool is not None:
        keep=np.array([any((int(i),int(j),int(a),int(b),o) in candidate_pool for o in (1,2)) for i,j,a,b in meta],dtype=bool)
        meta,prob,sp=meta[keep],prob[keep],sp[keep]
    decision,assembled=legal_decode_fast(lib,row,meta,prob,sp,threshold)
    predicted=edge_set(decision['connections'])
    exact_chem=False
    if assembled is not None:
        target,_,_=assemble_slots(lib,row['chem']['labels'].tolist(),truth(row),oov=row['oov'])
        exact_chem=canonical(assembled[0],False)==canonical(target,False)
    return dict(id=row['id'],slots=len(row['chem']['labels']),true_bonds=row['target']['true_bonds'],
        predicted=len(predicted),tp=len(actual&predicted),candidate_hits=len(actual&candidate_keys),
        port_tp=len({x[:4] for x in actual}&{x[:4] for x in predicted}),
        candidate_pairs=len(meta),complete_legal=assembled is not None,full_ports_exact=actual==predicted,
        constitution_exact=exact_chem,committed=True,connections=decision['connections'])


def aggregate(rows):
    tp=sum(r['tp'] for r in rows);pred=sum(r['predicted'] for r in rows);actual=sum(r['true_bonds'] for r in rows)
    port_tp=sum(r.get('port_tp',r['tp']) for r in rows)
    multi=[r for r in rows if r['slots']>1]
    return dict(molecule_seed_runs=len(rows),molecules=len({r['id'] for r in rows}),precision=tp/max(1,pred),
        recall=tp/max(1,actual),f1=2*tp/max(1,pred+actual),tp=tp,predicted=pred,true_bonds=actual,
        port_precision=port_tp/max(1,pred),port_recall=port_tp/max(1,actual),port_f1=2*port_tp/max(1,pred+actual),
        bond_order_accuracy_given_correct_ports=tp/max(1,port_tp),
        candidate_coverage=sum(r['candidate_hits'] for r in rows)/max(1,actual),
        complete_legal=sum(r['complete_legal'] for r in rows)/max(1,len(rows)),
        full_ports_exact=sum(r['full_ports_exact'] for r in rows)/max(1,len(rows)),
        constitution_exact=sum(r['constitution_exact'] for r in rows)/max(1,len(rows)),
        multi_fragment=dict(runs=len(multi),complete_legal=sum(r['complete_legal'] for r in multi)/max(1,len(multi)),
            full_ports_exact=sum(r['full_ports_exact'] for r in multi)/max(1,len(multi)),
            constitution_exact=sum(r['constitution_exact'] for r in multi)/max(1,len(multi))))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--cache',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--device',default='cuda:1')
    p.add_argument('--seeds',default='201,202,203');p.add_argument('--grid',default=','.join(map(str,GRID)))
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    dataset=build_cache(a.cache)['val'];rows=dataset['rows'];hydrate_oov(rows)
    packed=pack_records(rows,device);lib=VocabLibrary();diff=make_official_diffuser(a.output,device)
    saved=torch.load(a.checkpoint,map_location='cpu',weights_only=False)
    if saved['contract']!=dataset['contract']:raise ValueError('Model/template/split contract differs')
    full=TimeConnectionPredictor(saved['legacy_state']).to(device).eval();full.load_state_dict(saved['model'],strict=True)
    old=PortConnectionPredictor().to(device).eval();old.load_state_dict(saved['legacy_state'],strict=True)
    selected=next(r for r in saved['history'] if r['epoch']==saved['epoch'])
    thresholds=selected['thresholds'];grid=list(map(float,a.grid.split(',')))
    interpolate=lambda t:float(np.interp(t,sorted(map(float,thresholds)),[thresholds[str(x)] for x in sorted(map(float,thresholds))]))
    report=dict(checkpoint_sha256=digest(a.checkpoint),epoch=saved['epoch'],seeds=list(map(int,a.seeds.split(','))),
        threshold_selection_seed=100,thresholds=thresholds,grid=grid,rows=[],failures=[],summary={},
        inputs='True supplied fragment identities and N; template chemistry plus noisy Tt/Rt and time. No truth edges/ports/clean pose features.',
        staged='At t>.05 retain legal-order top64 candidates without committing edges. At t<=.05 use frozen original low-noise expert '
               'and only current candidates retained in the earlier high-noise pool. Incomplete graphs never enter docking.',
        sequence_caveat='The staged candidate-memory benchmark observes coupled FORWARD marginals at decreasing t; '
                        'lower-noise poses are supplied observations, not an autonomous learned reverse trajectory.')
    started=time.time()
    for seed in report['seeds']:
        pool={r['id']:set() for r in rows}
        for t in sorted(grid,reverse=True):
            tt=torch.full((len(rows),),t,device=device);T,R=noisy_frames(packed,diff,tt,seed=seed)
            f=candidate_features(packed['chem'],T,R,tt,adaptive=True,half=False)
            prob,sp=predict_probabilities(full,packed,f);meta,molecule=metadata(packed,f)
            fold=candidate_features(packed['chem'],T,R,tt,topk=8,cutoff=16,half=False)
            op,os=predict_probabilities(old,packed,fold,legacy=True);ometa,omolecule=metadata(packed,fold)
            prob,sp,op,os=(x.numpy() for x in (prob,sp,op,os))
            for m,row in enumerate(rows):
                ix=molecule==m;oi=omolecule==m
                base=metric_row(lib,row,ometa[oi],op[oi],os[oi],.65)
                retrained=metric_row(lib,row,meta[ix],prob[ix],sp[ix],interpolate(t))
                if t>.05:
                    pool[row['id']].update(retained_keys(row,meta[ix]))
                    staged=metric_row(lib,row,meta[ix],prob[ix],sp[ix],interpolate(t),commit=False)
                else:
                    # No high-noise observations if a custom grid contains low t only.
                    memory=pool[row['id']] or None
                    staged=metric_row(lib,row,ometa[oi],op[oi],os[oi],.65,candidate_pool=memory)
                for method,r in [('original',base),('full_noise',retrained),('staged',staged)]:
                    report['rows'].append(dict(method=method,t=t,seed=seed,**r))
            print('EVAL',seed,t,'elapsed',round(time.time()-started),flush=True)
        write_json(a.output/'report.partial.json',report)
    for method in ('original','full_noise','staged'):
        report['summary'][method]={str(t):aggregate([r for r in report['rows'] if r['method']==method and r['t']==t]) for t in grid}
    report['elapsed_seconds']=time.time()-started
    report['low_noise_guard']={str(t):report['summary']['full_noise'][str(t)]['f1']>=report['summary']['original'][str(t)]['f1']-.02
                               for t in grid if t<=.05}
    write_json(a.output/'report.json',report);print(json.dumps(report['summary'],indent=2),flush=True)


if __name__=='__main__':main()
