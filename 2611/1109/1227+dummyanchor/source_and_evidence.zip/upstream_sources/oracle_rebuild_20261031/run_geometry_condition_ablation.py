#!/usr/bin/env python3
"""DIAGNOSTIC ONLY: true / Oracle-denoised / current-generated pose ablation."""
import argparse
import json
import os
from pathlib import Path
import shutil
import time

import bootstrap
import numpy as np
import torch

from collect_topology_candidates import BASE
from geometry_condition_diagnostics import diagnostic_pose,choose_generated,evaluate_condition,pose_quality
from prepare_hierarchical_experiment import ROOT as PREVIOUS
from run_connection_trajectories import save_result
from run_validation import load_official,write_json
from trajectory_connections import ConnectionRuntime,GraphFactory,load_connection,run_trajectory
from validation import digest
from vocab_chemistry import VocabLibrary

ROOT=bootstrap.PROJECT/'results/connection_geometry_ablation_20261102'


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--ids',required=True);p.add_argument('--seeds',default='1801,1802,1803')
    p.add_argument('--device',default='cuda:6');p.add_argument('--resume',action='store_true')
    p.add_argument('--diagnostic-only',action='store_true',required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8');torch.use_deterministic_algorithms(True)
    torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    cohorts=json.loads((PREVIOUS/'cohorts.json').read_text());source=Path(cohorts['source_root'])
    ids=a.ids.split(',');seeds=list(map(int,a.seeds.split(',')))
    if not set(ids)<=set(cohorts['casf_holdout']) or not set(seeds)<=set(cohorts['test_seeds']):raise ValueError('Use fixed CASF pairs for the ablation')
    sources=['geometry_condition_diagnostics.py','run_geometry_condition_ablation.py','hierarchical_topology.py',
        'trajectory_connections.py','vocab_chemistry.py','robust_connection_data.py','robust_connection_model.py']
    contract=dict(created_for='Geometry-condition diagnosis only; truth pose/topology forbidden in ordinary generation',
        ids=ids,seeds=seeds,common_time=.005,steps=25,source_sha256={n:digest(bootstrap.PROJECT/n) for n in sources},
        connection_checkpoint_sha256=digest(BASE),official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),
        previous_search_lock_sha256=digest(PREVIOUS/'search_lock.json'),previous_cohorts_sha256=digest(PREVIOUS/'cohorts.json'),
        training_started=False,beam_width_increased=False,
        time_control='Every pose is re-scored with the same full connection head at t=0.005; time is not inferred from pose source.')
    if (a.output/'protocol.json').exists():
        if not a.resume or json.loads((a.output/'protocol.json').read_text())!=contract:raise ValueError('Existing ablation source/contract differs')
    write_json(a.output/'protocol.json',contract)
    if not (a.root/'prompt_used.md').exists():shutil.copyfile(bootstrap.WORKSPACE/'prompt.md',a.root/'prompt_used.md')
    den=load_official(bootstrap.CHECKPOINT,a.output,device);lib=VocabLibrary();checkpoint=load_connection(BASE,device)
    report=dict(contract=contract,groups=[],failures=[],diagnostic_only=True,ordinary_generation_changed=False)
    started=time.time()
    for pid in ids:
        fixture_path=source/f'inputs/{pid}/fixture.pt'
        if digest(fixture_path)!=cohorts['source_fixture_sha256'][pid]:raise ValueError('Fixture changed')
        fixture=torch.load(fixture_path,weights_only=False);graph_path=source/f'inputs/{pid}/oracle_graph.pt'
        graph=torch.load(graph_path,weights_only=False)
        runtime=ConnectionRuntime(lib,checkpoint,fixture['labels'],fixture['oov'],device,policy='wide',head='full')
        factory=GraphFactory(lib,fixture['labels'],fixture['oov'],fixture['context'])
        true_folder=a.output/f'{pid}_true_pose';true_folder.mkdir(exist_ok=True)
        if a.resume and (true_folder/'metrics.json').exists():true_metrics=json.loads((true_folder/'metrics.json').read_text())
        else:
            pose=diagnostic_pose(lib,fixture['labels'],fixture['oov'],fixture['target_xyz'],diagnostic_only=True)
            before=time.time();true_metrics=evaluate_condition(runtime,T=pose['T'],R=pose['R'],t=.005,fixture=fixture,diagnostic_only=True)
            true_metrics['geometry']=pose_quality(runtime,pose['T'],pose['R'],fixture['target_xyz'],pose['fit'],fixture)
            true_metrics['seconds']=time.time()-before;write_json(true_folder/'metrics.json',true_metrics)
            np.savez_compressed(true_folder/'pose.npz',T=pose['T'],R=pose['R'],fit=pose['fit'],xyz=fixture['target_xyz'])
        for seed in seeds:
            folder=a.output/f'{pid}_{seed}';folder.mkdir(exist_ok=True)
            if a.resume and (folder/'group.json').exists():report['groups'].append(json.loads((folder/'group.json').read_text()));continue
            paths=list(PREVIOUS.glob(f'holdout_*/{pid}_{seed}/group.json'))
            if len(paths)!=1:raise ValueError('Missing/duplicated prior generated pair')
            previous_group=json.loads(paths[0].read_text());key=choose_generated(previous_group)
            generated_path=paths[0].parent/key/'trajectory.pt';generated=torch.load(generated_path,weights_only=False)
            gen_frame=generated['frames'][-1]
            before=time.time();oracle=run_trajectory(den,runtime,factory,seed=seed,steps=25,mode='oracle',
                oracle_bundle=(graph,fixture['groups'],fixture['spec']),oracle_edges=fixture['oracle_edges'])
            save_result(folder/'oracle_trajectory',oracle,fixture);frame=oracle['frames'][-1]
            if not np.isclose(frame['t'],.005,atol=1e-7) or not np.isclose(gen_frame['t'],.005,atol=1e-7):raise ValueError('Unmatched denoising endpoint')
            conditions={'true_pose':true_metrics}
            for name,f,positions in [('oracle_denoised',frame,oracle['positions'][-1]),('generated_pose',gen_frame,generated['positions'][-1])]:
                before_search=time.time();metrics=evaluate_condition(runtime,T=f['T'],R=f['R'],t=.005,fixture=fixture,diagnostic_only=True)
                metrics['geometry']=pose_quality(runtime,np.asarray(f['T']),np.asarray(f['R']),positions,f['fit'],fixture)
                metrics['seconds']=time.time()-before_search;write_json(folder/f'{name}.json',metrics);conditions[name]=metrics
                np.savez_compressed(folder/f'{name}_pose.npz',T=f['T'],R=f['R'],fit=f['fit'],xyz=positions)
            compact={name:{k:v for k,v in metrics.items() if k not in ('candidates','prediction')} for name,metrics in conditions.items()}
            group=dict(id=pid,seed=seed,conditions=compact,seconds=time.time()-before,
                true_pose_shared_across_seeds=True,true_pose_path=str((true_folder/'metrics.json').resolve()),
                generated_candidate=key,generated_selection='Frozen ordinary Top-8 previous heuristic; no target labels',
                generated_trajectory=str(generated_path),generated_trajectory_sha256=digest(generated_path),
                previous_group_sha256=digest(paths[0]),oracle_graph_sha256=digest(graph_path),fixture_sha256=digest(fixture_path),
                oracle_backbone_evaluations=len(oracle['audit']['forwards']),diagnostic_only=True)
            write_json(folder/'group.json',group);report['groups'].append(group);write_json(a.output/'report.partial.json',report)
            print('ABLATION',pid,seed,'elapsed',round(time.time()-started),flush=True)
    report['elapsed_seconds']=time.time()-started;write_json(a.output/'report.json',report)


if __name__=='__main__':main()
