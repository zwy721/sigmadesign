#!/usr/bin/env python3
"""Run an independent identity head on supplied frames/adjacency (no dataset lookup)."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from prediction_data import identity_features
from train_identity_controls import IdentityHead
from validation import digest
from vocab_chemistry import VocabLibrary


def load_head(checkpoint,device='cpu'):
    checkpoint=Path(checkpoint)
    saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
    lib=VocabLibrary()
    protocol=json.loads((checkpoint.parent.parent/'protocol.json').read_text())
    if protocol['mapping_sha256']!=digest(lib.assets/'mapping.json'):
        raise ValueError('Identity model vocabulary order differs')
    if protocol['template_sha256']!=digest(lib.assets/'templates.json'):
        raise ValueError('Identity model template library differs')
    model=IdentityHead(saved['feature_dim'],saved['descriptor'],saved['kind'],saved['prior']).to(device).eval()
    model.load_state_dict(saved['model'],strict=True)
    return model,lib,saved


def predict(model,request,device='cpu',topk=20):
    T=np.asarray(request['T'],dtype=np.float32);R=np.asarray(request['R'],dtype=np.float32)
    A=np.asarray(request['adjacency']);t=float(request.get('t',0))
    n=len(T)
    if n<1 or T.shape!=(n,3) or R.shape!=(n,3,3) or A.shape!=(n,n):raise ValueError('Invalid frame/adjacency shapes')
    if not np.isfinite(T).all() or not np.isfinite(R).all():raise ValueError('Nonfinite frames')
    if not np.allclose(R@R.transpose(0,2,1),np.eye(3),atol=1e-4) or not np.allclose(np.linalg.det(R),1,atol=1e-4):
        raise ValueError('R must contain proper rotations')
    if not np.isin(A,[0,1,2]).all() or not np.array_equal(A,A.T) or np.diag(A).any():raise ValueError('Invalid adjacency')
    if not 0<=t<=1:raise ValueError('Invalid diffusion time')
    features=identity_features(T,R,A,t).to(device)
    with torch.inference_mode():
        logits,initial=model(features,torch.tensor(A.clip(max=1),dtype=torch.float32,device=device))
        values,indices=logits.softmax(-1).topk(min(topk,3684),-1)
    return dict(kind=model.kind,slots=n,topk=indices.cpu().tolist(),probability=values.cpu().tolist(),
                initial_top1=initial.argmax(-1).cpu().tolist(),condition='Supplied rigid frames and adjacency; no identity or dataset fields read')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--device',default='cpu');a=p.parse_args();torch.set_num_threads(2)
    model,lib,saved=load_head(a.checkpoint,a.device)
    result=predict(model,json.loads(a.input.read_text()),a.device)
    result['core_ids']=[[lib.ids[i] for i in row] for row in result['topk']]
    a.output.write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
