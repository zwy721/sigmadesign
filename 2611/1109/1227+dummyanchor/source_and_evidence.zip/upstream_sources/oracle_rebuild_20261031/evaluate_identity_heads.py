#!/usr/bin/env python3
"""Full PDBbind training-set metrics and fresh-noise CASF identity evaluation."""
import argparse
import json
from pathlib import Path

import bootstrap
import torch

from prediction_data import compact_cache,make_diffuser,LEVELS
from prediction_metrics import identity_metrics,ranked_row
from predict_identity_control import load_head,predict
from train_identity_controls import batches,evaluate
from run_validation import write_json


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True)
    p.add_argument('--cache',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--threads',type=int,default=4);a=p.parse_args();torch.set_num_threads(a.threads)
    data=compact_cache(a.cache);train=torch.load(a.cache/'identity_features_true_centers.pt',weights_only=False)
    diff=make_diffuser(a.run);result=dict(protocol='All 17,420 training molecules, cached training noise seed 0; '
        'all 271 CASF validation molecules with unseen orientation-noise seeds 2, 3, 4. '
        'True centres/adjacency/N remain oracle. CASF noise seed 1 was used for checkpoint selection.',methods={})
    for kind in ('direct','retrieval','iterative'):
        model,lib,saved=load_head(a.run/kind/'best.pt');freq=[p['train_occurrences'] for p in lib.properties]
        training={}
        with torch.inference_mode():
            for level_offset,level in enumerate(LEVELS):
                indices=list(range(level_offset,len(train['adj']),4));rows=[];molecule_index=0
                for x,y,adj in batches(train,indices,64,torch.device('cpu')):
                    logits,_=model(x,adj)
                    sizes=[len(r['labels']) for r in data['train'][molecule_index:molecule_index+64]]
                    for r,out in zip(data['train'][molecule_index:molecule_index+64],logits.split(sizes)):
                        rows.append(ranked_row(r['id'],r['labels'].tolist(),out))
                    molecule_index+=len(sizes)
                assert molecule_index==len(data['train'])
                training[level]=identity_metrics(rows,freq)
                print('FULL TRAIN',kind,level,training[level]['topk_accuracy'],flush=True)
        # evaluate() has a fixed seed=1 for selection; construct pre-noised rotations
        # as clean reference Q0 for fresh-seed comparisons by a dedicated view loop.
        from prediction_data import perturb,identity_features
        validation={}
        for level,t in LEVELS.items():
            all_rows=[];seeds=[2] if level=='clean' else [2,3,4]
            for seed in seeds:
                part=[]
                for r in data['val']:
                    T,R=perturb(r,diff,t,seed,true_centers=True)
                    part.append((r,identity_features(T,R,r['edges'].numpy(),t)))
                with torch.inference_mode():
                    for start in range(0,len(part),64):
                        batch=part[start:start+64]
                        logits,_=model(torch.cat([x for _,x in batch]),torch.block_diag(*[r['edges'].float().clamp_max(1) for r,_ in batch]))
                        for (r,_),out in zip(batch,logits.split([len(r['labels']) for r,_ in batch])):
                            row=ranked_row(r['id'],r['labels'].tolist(),out);row['seed']=seed;all_rows.append(row)
            validation[level]=dict(seeds=seeds,unique_molecules=len(data['val']),
                metrics=identity_metrics(all_rows,freq),rows=all_rows)
            print('FRESH CASF',kind,level,validation[level]['metrics']['topk_accuracy'],flush=True)
        result['methods'][kind]=dict(best_epoch=saved['epoch'],full_training=training,fresh_noise_val=validation)
        write_json(a.output,result)
    # Exercise the public, dataset-free API using an explicit supplied-condition JSON.
    r=next(r for r in data['val'] if r['id']=='1a30')
    request=dict(T=r['T0'].tolist(),R=r['R0'].tolist(),adjacency=r['edges'].tolist(),t=0)
    write_json(a.output.parent/'identity_example_input.json',request)
    for kind in result['methods']:
        model,lib,_=load_head(a.run/kind/'best.pt')
        output=predict(model,request)
        assert len(output['topk'])==len(request['T'])
        write_json(a.output.parent/f'identity_example_{kind}.json',output)


if __name__=='__main__':main()
