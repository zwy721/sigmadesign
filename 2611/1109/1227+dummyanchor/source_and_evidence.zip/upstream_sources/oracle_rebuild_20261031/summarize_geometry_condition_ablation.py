#!/usr/bin/env python3
"""Summarize matched-time geometry ablations without altering any model/search."""
import argparse
import copy
import csv
from datetime import datetime,timezone
import json
from pathlib import Path

import bootstrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch

from geometry_condition_diagnostics import K_VALUES
from pipeline_utils import rigid_fit
from prepare_hierarchical_experiment import ROOT as PREVIOUS
from run_geometry_condition_ablation import ROOT
from run_validation import write_json
from validation import digest

CONDITIONS=['true_pose','oracle_denoised','generated_pose']
NAMES={'true_pose':'真实片段位姿','oracle_denoised':'正确拓扑去噪位姿','generated_pose':'当前生成位姿'}
ENGLISH={'true_pose':'Crystal rigid poses','oracle_denoised':'Correct-topology denoised','generated_pose':'Predicted-topology generated'}
COLORS={'true_pose':'#228833','oracle_denoised':'#0077bb','generated_pose':'#cc3311'}


def aggregate(rows):
    n=len(rows);edges=[e for r in rows for e in r['metrics']['true_edge_ranks']];result=dict(runs=n,
        stage1_skeleton_coverage=sum(r['metrics']['stage1']['first_true_labelled_skeleton_rank'] is not None for r in rows),
        stage1_colored_skeleton_coverage=sum(r['metrics']['stage1']['first_true_colored_skeleton_rank'] is not None for r in rows),
        stage1_skeleton_top1=sum(r['metrics']['stage1']['first_true_labelled_skeleton_rank']==1 for r in rows),
        all_true_edges_supported=sum(r['metrics']['support']['available_edges']==r['metrics']['support']['required_edges'] for r in rows),
        all_true_edges_in_pair_top64=sum(r['metrics']['support']['pair_top64_edges']==r['metrics']['support']['required_edges'] for r in rows),
        raw_head_exact_connections=sum(r['metrics']['raw_head']['exact_connections'] for r in rows),
        edges=len(edges),true_edge_top1=sum(e['rank']==1 for e in edges),
        all_true_edges_top1=sum(all(e['rank']==1 for e in r['metrics']['true_edge_ranks']) for r in rows),
        edge_topk={str(k):sum(e['rank'] is not None and e['rank']<=k for e in edges) for k in K_VALUES})
    for family in ['unconditional','conditional_true_skeleton']:
        rr=[r['metrics'][family] for r in rows];ranks=[r['first_correct_constitution_rank'] for r in rr];exact=[r['first_exact_connections_rank'] for r in rr]
        hits=[v for v in ranks if v is not None]
        result[family]=dict(topk={str(k):dict(constitution=sum(r['topk'][str(k)]['constitution'] for r in rr),
            exact_connections=sum(r['topk'][str(k)]['exact_connections'] for r in rr),
            mean_actual_candidates=float(np.mean([r['topk'][str(k)]['actual_candidates'] for r in rr]))) for k in K_VALUES},
            found_constitution=len(hits),not_returned=n-len(hits),median_rank_among_constitution_hits=float(np.median(hits)) if hits else None,
            constitution_mrr=float(np.mean([1/v if v is not None else 0. for v in ranks])),
            exact_connections_mrr=float(np.mean([1/v if v is not None else 0. for v in exact])))
    for field in ['slot_atom_rmsd_A','internal_shape_rmsd_A','rigid_template_projection_rmsd_A','template_fit_max_A','true_bond_distance_error_mean_A']:
        values=[r['metrics']['geometry'][field] for r in rows]
        result[field]=dict(median=float(np.median(values)),max=float(max(values)))
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args();root=a.root
    cohorts=json.loads((PREVIOUS/'cohorts.json').read_text());reports=[(p,json.loads(p.read_text())) for p in sorted(root.glob('ablation_*/report.json'))]
    groups=[(p,g) for p,report in reports for g in report['groups']]
    expected={(pid,s) for pid in cohorts['casf_holdout'] for s in cohorts['test_seeds']}
    if {(g['id'],g['seed']) for _,g in groups}!=expected or len(groups)!=len(expected):raise ValueError('Missing/duplicated ablation pairs')
    if any(report['failures'] or not report['diagnostic_only'] or report['ordinary_generation_changed'] for _,report in reports):raise ValueError('Ablation failure or production alteration')
    for _,report in reports:
        for name,h in report['contract']['source_sha256'].items():
            if digest(bootstrap.PROJECT/name)!=h:raise ValueError(f'Ablation source changed: {name}')
        if report['contract']['common_time']!=.005 or report['contract']['training_started'] or report['contract']['beam_width_increased']:raise ValueError('Changed time/training/beam protocol')
    rows=[];paired_rows=[];seen_true={};fixtures={}
    for path,group in groups:
        pid=group['id'];seed=group['seed'];folder=path.parent/f'{pid}_{seed}'
        if pid not in fixtures:fixtures[pid]=torch.load(Path(cohorts['source_root'])/f'inputs/{pid}/fixture.pt',weights_only=False)
        target=fixtures[pid]['target_xyz']
        for condition in CONDITIONS:
            metrics=copy.deepcopy(group['conditions'][condition])
            if metrics['t']!=.005 or metrics['head']!='full' or metrics['policy']!='wide':raise ValueError('Unmatched connection time/head')
            if metrics['conditional_port_width']!=256 or metrics['search_config']!=reports[0][1]['groups'][0]['conditions'][condition]['search_config']:raise ValueError('Unmatched search widths')
            if condition=='true_pose':xyz=target
            else:xyz=np.load(folder/f'{condition}_pose.npz')['xyz']
            # Metric only: remove whole-ligand rigid motion, never sent to model.
            _,_,shape=rigid_fit(xyz,target);metrics['geometry']['internal_shape_rmsd_A']=float(shape)
            row=dict(id=pid,seed=seed,condition=condition,metrics=metrics);paired_rows.append(row)
            if condition=='true_pose':
                if pid in seen_true:
                    if metrics!=seen_true[pid]['metrics']:raise ValueError('Crystal poses unexpectedly differ across seeds')
                    continue
                seen_true[pid]=row
            rows.append(row)
    summary={condition:aggregate([r for r in rows if r['condition']==condition]) for condition in CONDITIONS}
    paired_summary={condition:aggregate([r for r in paired_rows if r['condition']==condition]) for condition in CONDITIONS}
    by_pair={(r['id'],r['seed'],r['condition']):r['metrics'] for r in paired_rows};transitions={}
    for condition in ['oracle_denoised','generated_pose']:
        transitions[condition]={}
        for family in ['unconditional','conditional_true_skeleton']:
            transitions[condition][family]={}
            for k in K_VALUES:
                pairs=[(by_pair[pid,seed,'true_pose'][family]['topk'][str(k)]['constitution'],by_pair[pid,seed,condition][family]['topk'][str(k)]['constitution']) for pid,seed in sorted(expected)]
                transitions[condition][family][str(k)]=dict(true_pose_correct_other_wrong=sum(a and not b for a,b in pairs),both_correct=sum(a and b for a,b in pairs),
                    both_wrong=sum(not a and not b for a,b in pairs),true_pose_wrong_other_correct=sum(not a and b for a,b in pairs))
    diagnosis=dict(summary=summary,paired_summary=paired_summary,paired_transitions=transitions,rows=rows,
        rank_policy='Exact rank within returned bounded pools only; missing ranks are censored, MRR=0. Crystal rows are unique per ligand.',
        time=.005,normal_generation_changed=False,training_started=False,search_width_increased=False)
    write_json(root/'analysis.json',diagnosis)
    csv_rows=[]
    for r in rows:
        metrics=r['metrics']
        for family in ['unconditional','conditional_true_skeleton']:
            for k in K_VALUES:csv_rows.append(dict(id=r['id'],seed=r['seed'],condition=r['condition'],scope=family,K=k,
                **metrics[family]['topk'][str(k)],first_correct_constitution_rank=metrics[family]['first_correct_constitution_rank'],
                first_exact_connections_rank=metrics[family]['first_exact_connections_rank'],
                true_skeleton_rank=metrics['stage1']['first_true_labelled_skeleton_rank'],
                **{key:metrics['geometry'][key] for key in ['slot_atom_rmsd_A','internal_shape_rmsd_A','true_bond_distance_error_mean_A','template_fit_max_A']}))
    with (root/'per_case_metrics.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(csv_rows[0]));writer.writeheader();writer.writerows(csv_rows)
    with (root/'true_edge_ranks.csv').open('w') as f:
        er=[dict(id=r['id'],seed=r['seed'],condition=r['condition'],**e) for r in rows for e in r['metrics']['true_edge_ranks']]
        writer=csv.DictWriter(f,fieldnames=list(er[0]));writer.writeheader();writer.writerows(er)
    plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25,'figure.dpi':160})
    fig,axes=plt.subplots(2,2,figsize=(12,8))
    for condition in CONDITIONS:
        s=summary[condition]
        for i,family in enumerate(['unconditional','conditional_true_skeleton']):
            for j,field in enumerate(['constitution','exact_connections']):
                ax=axes[i,j];ax.plot(K_VALUES,[100*s[family]['topk'][str(k)][field]/s['runs'] for k in K_VALUES],marker='o',color=COLORS[condition],label=ENGLISH[condition])
                ax.set_xscale('log',base=2);ax.set_xticks(K_VALUES,[str(k) for k in K_VALUES]);ax.set(xlabel='K (existing bounded pool)',ylabel='Coverage %',ylim=(0,105))
                ax.set_title(('Unconditional skeleton + ports' if i==0 else 'DIAGNOSTIC: true skeleton supplied')+'\n'+('Constitution' if j==0 else 'All labelled connections'))
    axes[0,0].legend(fontsize=8);fig.tight_layout();fig.savefig(root/'geometry_coverage.png');fig.savefig(root/'geometry_coverage.pdf');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,4.5));bin_names=['1','2–4','5–8','9–32','33–128','Not returned'];bin_colors=['#228833','#66ccee','#4477aa','#aa4499','#ddaa33','#bbbbbb']
    for ax,family in zip(axes,['unconditional','conditional_true_skeleton']):
        bottoms=np.zeros(3)
        for b,label in enumerate(bin_names):
            heights=[]
            for condition in CONDITIONS:
                rr=[r['metrics'][family]['first_correct_constitution_rank'] for r in rows if r['condition']==condition]
                def bucket(v):return 5 if v is None else 0 if v==1 else 1 if v<=4 else 2 if v<=8 else 3 if v<=32 else 4
                heights.append(100*sum(bucket(v)==b for v in rr)/len(rr))
            ax.bar(range(3),heights,bottom=bottoms,color=bin_colors[b],label=label);bottoms+=np.asarray(heights)
        ax.set_xticks(range(3),['Crystal','Oracle denoised','Generated']);ax.set(ylabel='Fraction %',ylim=(0,100),title='Unconditional rank' if family=='unconditional' else 'True-skeleton port combination rank')
    axes[1].legend(fontsize=8,bbox_to_anchor=(1.02,1),loc='upper left');fig.tight_layout();fig.savefig(root/'geometry_rank_distribution.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for condition in CONDITIONS:
        rr=[r for r in rows if r['condition']==condition]
        x=[r['metrics']['geometry']['true_bond_distance_error_mean_A'] for r in rr]
        y=[1/r['metrics']['conditional_true_skeleton']['first_correct_constitution_rank'] if r['metrics']['conditional_true_skeleton']['first_correct_constitution_rank'] is not None else 0. for r in rr]
        axes[0].scatter(x,y,color=COLORS[condition],label=ENGLISH[condition],alpha=.65)
        axes[1].scatter([r['metrics']['geometry']['internal_shape_rmsd_A'] for r in rr],y,color=COLORS[condition],alpha=.65)
    axes[0].set(xlabel='Mean error of true bond distances (A)',ylabel='Reciprocal constitution rank; missing=0',ylim=(-.03,1.03));axes[0].legend(fontsize=7)
    axes[1].set(xlabel='Whole-ligand rigid-aligned shape RMSD (A)',ylabel='Reciprocal constitution rank; missing=0',ylim=(-.03,1.03))
    fig.tight_layout();fig.savefig(root/'geometry_error_vs_rank.png');plt.close(fig)
    # Verify frozen pretrained artifacts and all fresh Oracle denoising steps.
    old=json.loads((bootstrap.PROJECT/'PREDICTION_MANIFEST.json').read_text());changed=[n for n,h in old['official_source_sha256'].items() if digest(bootstrap.OFFICIAL/n)!=h]
    if changed or digest(bootstrap.CHECKPOINT)!=old['official_checkpoint_sha256']:raise RuntimeError('Official backbone changed')
    robust=json.loads((bootstrap.PROJECT/'CONNECTION_ROBUST_MANIFEST.json').read_text());connection=bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt'
    identity=bootstrap.PROJECT/'results/prediction_diagnostics/identity_controls/iterative/best.pt'
    if digest(connection)!=robust['new_connection_sha256'] or digest(identity)!=old['checkpoints']['iterative']:raise RuntimeError('Frozen prediction heads changed')
    lock=json.loads((PREVIOUS/'search_lock.json').read_text())
    for name,h in lock['source_sha256'].items():
        if digest(bootstrap.PROJECT/name)!=h:raise RuntimeError('Search or ordinary sampler changed')
    audits=[json.loads(p.read_text()) for p in root.glob('ablation_*/*/oracle_trajectory/audit.json')]
    if len(audits)!=36 or not all(x['all_dynamic_recomputations_equal'] and len(x['forwards'])==24 for x in audits):raise RuntimeError('Oracle geometry audit failed')
    regression=json.loads((root/'oracle_regression/report.json').read_text())
    if regression['failures'] or any(r['max_coordinate_difference_A']!=0 for r in regression['regression']):raise RuntimeError('Official regression failed')
    shadow=max(r.get('oracle_shadow_max_coordinate_difference_A',0.) for r in regression['rows'])
    if shadow!=0:raise RuntimeError('Shadow observation changed coordinates')
    tests=(root/'tests.log').read_text();test_line=next(x for x in tests.splitlines() if x.startswith('Ran '))
    if '\nOK\n' not in tests:raise RuntimeError('Tests failed')
    prefix=root.relative_to(bootstrap.PROJECT).as_posix();t=summary['true_pose'];o=summary['oracle_denoised'];g=summary['generated_pose']
    headline=f"真实几何下，{t['unconditional']['topk']['1']['exact_connections']}/{t['runs']} 个配体的完整连接为 Top-1，{t['true_edge_top1']}/{t['edges']} 条真实连接为各槽位对第一选择；正确拓扑去噪后，无条件 Top-8 构造覆盖 {o['unconditional']['topk']['8']['constitution']}/{o['runs']}；当前生成几何下为 {g['unconditional']['topk']['8']['constitution']}/{g['runs']}。"
    lines=['# 连接预测几何条件消融（2026-11-02）','',headline,'',
        '本轮证据支持当前生成位姿的相对几何是主要瓶颈。在固定真实身份、N、当前模板和树约束下，连接头获得真实几何后可以恢复本组全部端口连接。正确拓扑去噪几何大幅保留该能力；预测拓扑生成的几何使端口组合排序显著恶化。该结论仅限本组固定 CASF 诊断，不能外推为所有配体或未知身份生成均已解决。','',
        '## 三种条件与时间控制','',
        '三组使用同一冻结 full 时间条件连接头，统一在 t=0.005、wide top64/32 Å 支持策略下重算候选和分数。真实几何组不是 t=0、其它组 t>0 的比较。身份、N、模板、原子顺序、口袋和搜索配置均一致。','',
        '真实片段位姿：按给定槽位/局部原子对应，将当前刚体模板拟合到晶体坐标。连接头只读取拟合后的 T/R，并继续使用同一模板内部几何；因此这不是直接替换逐原子特征。正确拓扑去噪位姿：原官方 SigmaDock、正确完整化学图、相同初始种子、25 个状态/24 次去噪，真实连接固定，仅用于诊断。当前生成位姿：复用上一轮默认普通 Top-8 在旧启发式下选中的最终轨迹，不按真值重新选择。','',
        '真实骨架条件端口搜索是独立 Oracle 诊断，不向无条件候选池补入真骨架、真端口或真构造。正常生成流程未修改，也没有重新训练任何模型。','',
        '## 样本与搜索预算','',
        '`'+', '.join(cohorts['casf_holdout'])+'`，种子 1801/1802/1803，共 36 个受体/seed 配对。真实几何与 seed 无关，主表只统计 12 个唯一配体；另外两组各 36 次。`analysis.json` 另存真实几何重复到 36 对后的配对汇总与得失，重复不代表增加了独立样本。CASF 是已使用过的固定诊断集，不是新盲测。','',
        '骨架 beam=128、最多 24 骨架；常规端口 beam=64、每对最多 64 联合选项、每骨架最多 16 完整立体构造。Top-32/128 只从同一既有内部池继续读取候选，不增大 beam 或增加候选去噪。给定真骨架的条件诊断沿用上轮已经存在的 port_width=256、最多 128 个构造，三组完全相同。','',
        '排名为有限返回池内首个正确答案的位置；缺失记为“未返回”，不伪称精确的全空间排名或简单的 >128。无条件池按原分数＋骨架新颖度选择并按构造去重；条件端口池按联合模型分数排序、按完整立体化学去重。两种池的定义不同，分别报告。','',
        '## 骨架和端口局部排名','',
        '| 几何条件 | 样本数 | 真骨架 Top-1 | 真骨架 Top-24 | 全部真端口/键级在支持中 | 真实边局部 Top-1 | 原始连接头直接全连接正确 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for condition in CONDITIONS:
        s=summary[condition];n=s['runs'];lines.append(f"| {NAMES[condition]} | {n} | {s['stage1_skeleton_top1']}/{n} | {s['stage1_skeleton_coverage']}/{n} | {s['all_true_edges_supported']}/{n} | {s['true_edge_top1']}/{s['edges']} | {s['raw_head_exact_connections']}/{n} |")
    for family,title in [('unconditional','无条件骨架＋联合端口搜索'),('conditional_true_skeleton','给定真实骨架的条件端口诊断')]:
        lines+=['','## '+title,'',
            '| 几何条件 | 构造 Top-1 | Top-4 | Top-8 | Top-32 | Top-128 |','| --- | ---: | ---: | ---: | ---: | ---: |']
        for condition in CONDITIONS:
            s=summary[condition];n=s['runs'];lines.append('| '+NAMES[condition]+' | '+' | '.join(f"{s[family]['topk'][str(k)]['constitution']}/{n}" for k in K_VALUES)+' |')
        lines+=['','| 几何条件 | 严格全连接 Top-1 | Top-4 | Top-8 | Top-32 | Top-128 |','| --- | ---: | ---: | ---: | ---: | ---: |']
        for condition in CONDITIONS:
            s=summary[condition];n=s['runs'];lines.append('| '+NAMES[condition]+' | '+' | '.join(f"{s[family]['topk'][str(k)]['exact_connections']}/{n}" for k in K_VALUES)+' |')
    lines+=['','构造正确忽略立体、允许化学图同构。严格全连接正确要求给定槽位对应下全部原子端口和键级一致，不代表全部四面体立体中心恢复。骨架忽略键级和端口；表中为严格槽位骨架，完整 JSON 同时保留片段类别标色骨架指标。','',
        f'![三组 Top-K 覆盖]({prefix}/geometry_coverage.png)','',
        '## 完整端口组合排名','',
        '| 几何条件 | 无条件构造命中中位排名 | 无条件未返回 | 条件端口构造命中中位排名 | 条件端口未返回 | 条件端口 MRR |','| --- | ---: | ---: | ---: | ---: | ---: |']
    for condition in CONDITIONS:
        s=summary[condition];free=s['unconditional'];port=s['conditional_true_skeleton'];n=s['runs']
        lines.append(f"| {NAMES[condition]} | {free['median_rank_among_constitution_hits']} | {free['not_returned']}/{n} | {port['median_rank_among_constitution_hits']} | {port['not_returned']}/{n} | {port['constitution_mrr']:.4f} |")
    lines+=['','中位排名只包含返回池中命中的样本，必须与未返回率一起阅读；MRR 对未返回记 0。逐条真实边在对应槽位对的全部已评分端口/键级中的排名、分数与概率保存在 `true_edge_ranks.csv`，完整组合排名保存在逐例 CSV。','',
        f'![排名分布]({prefix}/geometry_rank_distribution.png)','',
        '## 相对几何误差与解释','',
        '| 几何条件 | 口袋坐标系 RMSD 中位 Å | 去整体刚体运动后的形状 RMSD 中位 Å | 真实键长误差中位 Å | 模板拟合误差最大 Å |','| --- | ---: | ---: | ---: | ---: |']
    for condition in CONDITIONS:
        s=summary[condition];lines.append(f"| {NAMES[condition]} | {s['slot_atom_rmsd_A']['median']:.4f} | {s['internal_shape_rmsd_A']['median']:.4f} | {s['true_bond_distance_error_mean_A']['median']:.4f} | {s['template_fit_max_A']['max']:.4f} |")
    lines+=['','口袋坐标系 RMSD 使用固定槽位/局部原子对应，既包含整体位姿偏差也包含内部形状偏差。形状 RMSD 只在事后评价中去除整个分子的平移和旋转，不用于连接预测。真实键长误差来自连接头实际使用的模板投影坐标，比较真实连接两端的距离；不受整个配体平移/旋转影响。','',
        f"真实几何组送入连接头的模板投影 RMSD 中位数为 {t['rigid_template_projection_rmsd_A']['median']:.4f} Å、最大 {t['rigid_template_projection_rmsd_A']['max']:.4f} Å；单片段最大拟合误差为 {t['template_fit_max_A']['max']:.4f} Å。表中真实组原始坐标 RMSD=0 不等于将精确晶体原子坐标直接传入网络。",'',
        f'![几何误差与组合排名]({prefix}/geometry_error_vs_rank.png)','',
        f"在同一 36 配对中，真实几何条件端口 Top-8 正确、Oracle 去噪几何错误的为 {transitions['oracle_denoised']['conditional_true_skeleton']['8']['true_pose_correct_other_wrong']} 对；换成当前生成几何后为 {transitions['generated_pose']['conditional_true_skeleton']['8']['true_pose_correct_other_wrong']} 对。真实几何下端口支持、局部第一选择、原始头直接解码和联合搜索均能通过，说明本组失败的主要来源是错误拓扑/生成轨迹没有提供足够好的片段相对几何，而不是这组已知身份在正确几何下普遍不可区分。",
        '', '正确拓扑是几何生成过程中的干预条件，其优越性不能当作正常生成性能。正确拓扑仍可能得到较差整体对接位置；应结合内部形状与真实键长误差理解连接恢复。错误拓扑对几何的作用和几何对连接评分的作用形成耦合，本轮不能把这一耦合单独分解为某一个训练损失或单个特征的因果贡献。',
        '', '后续优先检查连接未知时的初始相对几何、错误拓扑造成的几何自强化，以及何时允许连接更新；本轮不扩大 beam、不训练 Reranker、不启动新的大规模训练。',
        '', '## 回归与可复现性','',
        f"原官方源代码和权重、身份头和连接头哈希均未改变；正常搜索代码与上一轮参数锁一致。36 条正确拓扑 Oracle 轨迹共 {sum(len(x['forwards']) for x in audits)} 次主干调用，动态边/距离/方向重算审计全部通过。原官方采样器两例回归坐标差均为 0 Å，Oracle/shadow 最大差为 {shadow:g} Å。{test_line}，结果 OK。",
        '', f'[完整分析 JSON]({prefix}/analysis.json) · [逐例组合排名与覆盖]({prefix}/per_case_metrics.csv) · [逐真实边排名]({prefix}/true_edge_ranks.csv) · [诊断脚本及复现](GEOMETRY_CONDITION_ABLATION.md)','']
    (bootstrap.PROJECT/'GEOMETRY_CONDITION_ABLATION_RESULTS.md').write_text('\n'.join(lines))
    manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),prompt_sha256=digest(root/'prompt_used.md'),
        official_source_changed=changed,official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),connection_checkpoint_sha256=digest(connection),identity_checkpoint_sha256=digest(identity),
        search_source_unchanged=True,normal_generation_changed=False,training_started=False,beam_width_increased=False,
        unique_receptors=len(cohorts['casf_holdout']),paired_seeds=len(expected),conditions_summary=summary,oracle_forwards=sum(len(x['forwards']) for x in audits),
        official_regression=regression['regression'],oracle_shadow_coordinate_difference_A=shadow,tests=test_line,test_success=True,
        scripts={name:digest(bootstrap.PROJECT/name) for name in ['geometry_condition_diagnostics.py','run_geometry_condition_ablation.py','summarize_geometry_condition_ablation.py']},
        results={name:digest(root/name) for name in ['analysis.json','per_case_metrics.csv','true_edge_ranks.csv']},
        protocols={str(p.relative_to(root)):digest(p) for p in root.glob('ablation_*/protocol.json')})
    write_json(bootstrap.PROJECT/'GEOMETRY_CONDITION_ABLATION_MANIFEST.json',manifest)
    stage=bootstrap.PROJECT/'STAGED_RESULTS.md';marker='\n## 2026-11-02：连接预测几何条件消融'
    stage.write_text(stage.read_text().split(marker)[0]+marker+'\n\n'+headline+'\n\n[专项报告](GEOMETRY_CONDITION_ABLATION_RESULTS.md) · [诊断接口](GEOMETRY_CONDITION_ABLATION.md)。\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
