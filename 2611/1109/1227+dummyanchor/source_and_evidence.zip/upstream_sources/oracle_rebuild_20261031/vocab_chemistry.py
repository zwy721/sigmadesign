"""Actual 3684 H-capped templates -> validated complete ligand chemistry.

All inter-fragment bonds are chemical bonds before official graph construction.
No geometric or chemical edge is patched into the SigmaDock network graph.
"""
import copy
import json
from collections import Counter
from pathlib import Path

import bootstrap
import numpy as np
from rdkit import Chem
from scipy.optimize import linear_sum_assignment

from oracle_graph import OracleContractError, export_oracle
from sigmadock.chem.ligalign import ConformerOptimizer


class ChemistryRejected(OracleContractError):
    pass


class VocabLibrary:
    def __init__(self, assets=None):
        self.assets = Path(assets or bootstrap.WORKSPACE / 'geom_m12/assets')
        self.mapping = json.loads((self.assets / 'mapping.json').read_text())
        self.ids = self.mapping['class_to_core_id']
        self.templates = json.loads((self.assets / 'templates.json').read_text())
        self.properties = json.loads((self.assets / 'properties.json').read_text())

    def template(self, label, explicit=None):
        if label < 0:
            if explicit is None:
                raise ChemistryRejected('OOV identity requires an explicit chemical template')
            template = explicit
        else:
            if not 0 <= label < len(self.ids):
                raise ChemistryRejected('MASK or unknown identity cannot enter the docking backbone')
            template = self.templates[self.ids[label]]
        mol = Chem.MolFromMolBlock(template['molblock'], removeHs=False)
        if mol is None:
            raise ChemistryRejected('Invalid template molblock')
        if mol.GetNumAtoms() != len(template['heavy_indices']) or any(a.GetAtomicNum() <= 1 for a in mol.GetAtoms()):
            raise ChemistryRejected('This interface requires heavy-only H-capped cores')
        xyz = np.asarray(template['coordinates'], dtype=float)[template['heavy_indices']]
        if xyz.shape != (mol.GetNumAtoms(), 3) or not np.isfinite(xyz).all():
            raise ChemistryRejected('Invalid template geometry')
        for k, point in enumerate(xyz):
            mol.GetConformer().SetAtomPosition(k, point)
        return mol, xyz.copy()

    def sites(self, label, explicit=None):
        if label >= 0:
            return copy.deepcopy(self.properties[label]['candidate_sites'])
        mol, _ = self.template(label, explicit)
        return [dict(anchor_core=a.GetIdx(), capacity_bond_order_units=int(a.GetTotalNumHs()),
                     carbon_stub_sanitize_validated_orders=[o for o in (1, 2) if a.GetTotalNumHs() >= o])
                for a in mol.GetAtoms() if a.GetTotalNumHs() > 0]


def explicit_oov(record):
    case = record['graph']['case']
    mol = Chem.MolFromMolBlock(case['native_molblock'], removeHs=False)
    mapping = []
    parts = Chem.GetMolFrags(mol, asMols=True, sanitizeFrags=True, fragsMolAtomMapping=mapping)
    lookup = {tuple(ids): part for ids, part in zip(mapping, parts)}
    result = []
    for i, label in enumerate(record['labels'].tolist()):
        if label >= 0:
            result.append(None)
            continue
        part = lookup[tuple(case['native_groups'][i])]
        xyz = np.asarray(case['fragments'][i]['template_local'])
        result.append(dict(molblock=Chem.MolToMolBlock(part), coordinates=xyz.tolist(),
                           heavy_indices=list(range(len(xyz)))))
    return result


def true_connections(record):
    edges = []
    for i in range(len(record['labels'])):
        for j in range(i + 1, len(record['labels'])):
            order = int(record['edges'][i, j])
            if order:
                a, b = map(int, record['anchors'][i, j].tolist())
                edges.append(dict(i=i, j=j, a=a, b=b, order=order,
                                  stereo=max(0, int(record['stereo'][i, j]))))
    return edges


def assemble_slots(library, labels, connections, *, oov=None, cip=None, chiral=None):
    """Replace capped H atoms with true bonds; validate ports, valence and graph.

    Optional CIP conditions are explicit Oracle atom-stereo conditions, not
    inferred from crystal coordinates. A capped identity can lose a stereocenter
    that is created only after attachment, so this information is kept separate.
    """
    labels = list(map(int, labels))
    if not labels:
        raise ChemistryRejected('No fragment slots')
    oov = oov or [None] * len(labels)
    parts, sizes, offsets = [], [], []
    total = 0
    for i, label in enumerate(labels):
        mol, _ = library.template(label, oov[i])
        sizes.append(mol.GetNumAtoms())
        for a in mol.GetAtoms():
            a.SetIntProp('_oracle_slot', i)
            a.SetIntProp('_oracle_local', a.GetIdx())
        mol = Chem.AddHs(mol, addCoords=True)
        parts.append(mol)
        offsets.append(total)
        total += mol.GetNumAtoms()
    used, pairs = Counter(), set()
    for c in connections:
        i, j, a, b, order = (int(c[k]) for k in ('i', 'j', 'a', 'b', 'order'))
        if not (0 <= i < len(labels) and 0 <= j < len(labels)) or i == j:
            raise ChemistryRejected('Invalid inter-fragment slot pair')
        if not (0 <= a < sizes[i] and 0 <= b < sizes[j]) or order not in (1, 2):
            raise ChemistryRejected('Invalid port or unsupported bond order')
        key = tuple(sorted(((i, a), (j, b))))
        if key in pairs:
            raise ChemistryRejected('Duplicate chemical connection')
        pairs.add(key)
        for slot, atom in ((i, a), (j, b)):
            sites = {int(s['anchor_core']): s for s in library.sites(labels[slot], oov[slot])}
            if atom not in sites or order not in sites[atom]['carbon_stub_sanitize_validated_orders']:
                raise ChemistryRejected('Connection uses a chemically unavailable port/order')
            used[slot, atom] += order
            if used[slot, atom] > sites[atom]['capacity_bond_order_units']:
                raise ChemistryRejected('Shared attachment hydrogen/valence capacity exceeded')
    combined = parts[0]
    for part in parts[1:]:
        combined = Chem.CombineMols(combined, part)
    rw = Chem.RWMol(combined)
    remove = []
    for (slot, anchor), amount in used.items():
        atom = rw.GetAtomWithIdx(offsets[slot] + anchor)
        hydrogens = [a.GetIdx() for a in atom.GetNeighbors() if a.GetAtomicNum() == 1]
        if len(hydrogens) < amount:
            raise ChemistryRejected('Insufficient H-substitution capacity')
        remove.extend(hydrogens[:amount])
    for c in connections:
        rw.AddBond(offsets[c['i']] + c['a'], offsets[c['j']] + c['b'],
                   Chem.BondType.SINGLE if c['order'] == 1 else Chem.BondType.DOUBLE)
    for k in sorted(remove, reverse=True):
        rw.RemoveAtom(k)
    try:
        mol = rw.GetMol()
        Chem.SanitizeMol(mol)
        mol = Chem.RemoveHs(mol)
        if len(Chem.GetMolFrags(mol)) != 1:
            raise ChemistryRejected('Incomplete/disconnected graph retained as candidates; docking prohibited')
        groups = [[] for _ in labels]
        indices = {}
        for atom in mol.GetAtoms():
            slot, local = atom.GetIntProp('_oracle_slot'), atom.GetIntProp('_oracle_local')
            groups[slot].append(atom.GetIdx())
            indices[slot, local] = atom.GetIdx()
        if [len(g) for g in groups] != sizes:
            raise ChemistryRejected('Assembly lost real atoms')
        cuts = []
        for c in connections:
            a, b = indices[c['i'], c['a']], indices[c['j'], c['b']]
            bond = mol.GetBondBetweenAtoms(a, b)
            cuts.append(bond.GetIdx())
            if c['order'] == 2 and c.get('stereo', 0) in (1, 2):
                na = [v.GetIdx() for v in mol.GetAtomWithIdx(a).GetNeighbors() if v.GetIdx() != b]
                nb = [v.GetIdx() for v in mol.GetAtomWithIdx(b).GetNeighbors() if v.GetIdx() != a]
                if not na or not nb:
                    raise ChemistryRejected('E/Z specified on a non-stereogenic double bond')
                bond.SetStereoAtoms(na[0], nb[0])
                bond.SetStereo(Chem.BondStereo.STEREOE if c['stereo'] == 1 else Chem.BondStereo.STEREOZ)
        # AssignStereochemistry(cleanIt=True) reconstructs double-bond stereo
        # from neighbouring bond directions. Without them an explicit predicted
        # E/Z condition is silently cleared before reference generation.
        Chem.SetDoubleBondNeighborDirections(mol)
        Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
        # Set all related centers together. Ring/pseudoasymmetric centers can
        # depend on each other and may have a chiral tag without a standalone CIP.
        for condition in chiral or []:
            atom = mol.GetAtomWithIdx(indices[condition['slot'], condition['atom']])
            expected = [indices[s, a] for s, a in condition['neighbors']]
            current = [a.GetIdx() for a in atom.GetNeighbors()]
            if set(expected) != set(current):
                raise ChemistryRejected('Chiral Oracle context no longer matches this chemical identity')
            permutation = [expected.index(k) for k in current]
            inversions = sum(permutation[i] > permutation[j] for i in range(len(permutation))
                             for j in range(i + 1, len(permutation)))
            atom.SetChiralTag(Chem.ChiralType.values[condition['tag']])
            if inversions % 2: atom.InvertChirality()
        Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
        for condition in cip or []:
            atom = mol.GetAtomWithIdx(indices[condition['slot'], condition['atom']])
            if atom.HasProp('_CIPCode') and atom.GetProp('_CIPCode') == condition['CIP']:
                continue
            atom.SetChiralTag(Chem.ChiralType.CHI_TETRAHEDRAL_CW)
            Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
            if not atom.HasProp('_CIPCode'):
                raise ChemistryRejected('CIP Oracle condition is not a stereogenic atom')
            if atom.GetProp('_CIPCode') != condition['CIP']:
                atom.InvertChirality()
                Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
            if atom.GetProp('_CIPCode') != condition['CIP']:
                raise ChemistryRejected('Could not satisfy explicit CIP condition')
        return mol, groups, cuts
    except ChemistryRejected:
        raise
    except (ValueError, RuntimeError) as exc:
        raise ChemistryRejected(f'Invalid assembled chemistry: {exc}') from exc


def atom_correspondence(record, original):
    """Oracle evaluation-only correspondence, retaining TEMPLATE local order."""
    heavy = [a.GetIdx() for a in original.GetAtoms() if a.GetAtomicNum() > 1]
    xyz = original.GetConformer().GetPositions()[heavy]
    case = record['graph']['case']
    cached = Chem.MolFromMolBlock(case['native_molblock'], removeHs=False)
    source_z = np.array([cached.GetAtomWithIdx(k).GetAtomicNum() for k in case['heavy_global']])
    target_z = np.array([original.GetAtomWithIdx(k).GetAtomicNum() for k in heavy])
    source_xyz = np.concatenate([np.asarray(x) for x in record['target_xyz']]) + np.asarray(case['origin'])
    if xyz.shape != source_xyz.shape:
        raise ChemistryRejected('Oracle atom counts differ')
    distance = np.linalg.norm(source_xyz[:, None] - xyz[None], axis=-1)
    distance[source_z[:, None] != target_z[None]] = 1e9
    rows, cols = linear_sum_assignment(distance)
    if distance[rows, cols].max() > 1e-3:
        raise ChemistryRejected('Could not map cached chemical atoms to the source ligand')
    return [heavy[int(j)] for j in cols]


def oracle_cip(record, original, mapping):
    original = Chem.Mol(original)
    Chem.AssignStereochemistry(original, cleanIt=True, force=True)
    conditions, offset = [], 0
    for i, points in enumerate(record['target_xyz']):
        for a in range(len(points)):
            atom = original.GetAtomWithIdx(mapping[offset + a])
            if atom.HasProp('_CIPCode'):
                conditions.append(dict(slot=i, atom=a, CIP=atom.GetProp('_CIPCode')))
        offset += len(points)
    return conditions


def oracle_chiral(record, original, mapping):
    original = Chem.Mol(original)
    Chem.AssignStereochemistry(original, cleanIt=True, force=True)
    inverse, offset = {}, 0
    for i, points in enumerate(record['target_xyz']):
        for a in range(len(points)): inverse[mapping[offset + a]] = [i, a]
        offset += len(points)
    result = []
    for atom in original.GetAtoms():
        if int(atom.GetChiralTag()) in (1, 2):
            i, a = inverse[atom.GetIdx()]
            result.append(dict(slot=i, atom=a, tag=int(atom.GetChiralTag()),
                               neighbors=[inverse[n.GetIdx()] for n in atom.GetNeighbors()]))
    return result


def canonical(mol, stereo=True):
    mol = Chem.Mol(mol)
    Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
    if not stereo:
        Chem.RemoveStereochemistry(mol)
    return Chem.MolToSmiles(mol, isomericSmiles=stereo)


def embedded_reference(mol, seed=0):
    # Official conformer generator discards all coordinates before ETKDG/MMFF.
    return ConformerOptimizer(Chem.Mol(mol), seed=seed)._generate_conformer()


def spec_from_slots(mol, groups, cuts, labels, source):
    return export_oracle(mol, groups, cuts, labels=labels, reference_source=source)
