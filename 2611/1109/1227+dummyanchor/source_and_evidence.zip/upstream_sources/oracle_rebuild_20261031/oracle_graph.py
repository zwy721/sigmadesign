"""Lossless Oracle chemistry -> original SigmaDock input graph.

The JSON contract contains explicit per-fragment atoms, internal bonds, reference
coordinates, and inter-fragment bonds. It contains neither precomputed network
features nor a whole-ligand molblock. A 3684 integer alone is deliberately not a
lossless identity for OOVs, stereochemistry, or attachment-dependent valence.
"""
import copy
import hashlib
import json
from types import FunctionType

import bootstrap  # noqa: F401
import numpy as np
from rdkit import Chem

from sigmadock.chem.fragmentation import fragment_molecule, fragment_on_bonds_with_mapping, get_fragment_map
from sigmadock.data import SigmaDataset


class OracleContractError(ValueError):
    pass


def _atom_record(atom):
    return dict(z=atom.GetAtomicNum(), charge=atom.GetFormalCharge(),
                isotope=atom.GetIsotope(), chiral_tag=int(atom.GetChiralTag()),
                explicit_hs=atom.GetNumExplicitHs(), no_implicit=atom.GetNoImplicit(),
                aromatic=atom.GetIsAromatic(), radicals=atom.GetNumRadicalElectrons(),
                atom_map=atom.GetAtomMapNum())


def _bond_record(bond):
    return dict(order=bond.GetIdx(), begin=bond.GetBeginAtomIdx(), end=bond.GetEndAtomIdx(),
                bond_type=int(bond.GetBondType()), aromatic=bond.GetIsAromatic(),
                conjugated=bond.GetIsConjugated(), direction=int(bond.GetBondDir()),
                stereo=int(bond.GetStereo()), stereo_atoms=list(bond.GetStereoAtoms()))


def _identity(atoms, bonds, ids):
    local = {k: i for i, k in enumerate(ids)}
    normalized = []
    for b in bonds:
        normalized.append({k: v for k, v in b.items() if k not in ('order', 'begin', 'end', 'stereo_atoms')}
                          | dict(begin=local[b['begin']], end=local[b['end']],
                                 stereo_atoms=[local.get(k, 'external') for k in b['stereo_atoms']]))
    # Ordered identity: the local atom order is part of the port/template contract.
    value = json.dumps(dict(atoms=atoms, bonds=normalized), sort_keys=True).encode()
    return 'oracle:' + hashlib.sha256(value).hexdigest()[:24]


def export_oracle(mol, groups, cut_order, *, labels=None, reference_source='explicit reference'):
    """Extract a lossless Oracle fixture; rebuild() never receives this source mol.

    groups are original atom indices, excluding added dummies. cut_order is the
    exact ordered list of bond indices selected by the official fragmenter.
    """
    if mol.GetNumConformers() != 1:
        raise OracleContractError('Exactly one reference conformer is required')
    if mol.GetStereoGroups():
        raise OracleContractError('Enhanced stereo groups are not supported by this Oracle schema')
    n = mol.GetNumAtoms()
    groups = [list(map(int, g)) for g in groups]
    flat = [k for g in groups for k in g]
    if not groups or any(not g for g in groups) or sorted(flat) != list(range(n)):
        raise OracleContractError('Fragments must partition all original atoms exactly once')
    slots = {k: i for i, g in enumerate(groups) for k in g}
    xyz = mol.GetConformer().GetPositions()
    intra = [[] for _ in groups]
    connections = []
    for bond in mol.GetBonds():
        record = _bond_record(bond)
        a, b = record['begin'], record['end']
        if slots[a] == slots[b]:
            intra[slots[a]].append(record)
        else:
            connections.append(record | dict(slots=[slots[a], slots[b]]))
    if set(cut_order) != {b['order'] for b in connections} or len(set(cut_order)) != len(cut_order):
        raise OracleContractError('Declared cut bonds differ from inter-fragment chemical bonds')
    fragments = []
    for i, ids in enumerate(groups):
        atoms = [_atom_record(mol.GetAtomWithIdx(k)) for k in ids]
        ports = sorted({b[k] for b in connections for k in ('begin', 'end') if b[k] in ids})
        fragments.append(dict(slot=i, identity=_identity(atoms, intra[i], ids), atom_ids=ids,
                              atoms=atoms, bonds=intra[i], coordinates=xyz[ids].tolist(),
                              ports=ports, vocab3684=None if labels is None else int(labels[i])))
    return dict(schema='sigmadock-oracle-chemistry-v1', reference_source=reference_source,
                fragments=fragments, connections=connections, cut_order=list(map(int, cut_order)))


def oracle_from_official(graph, reference):
    """Oracle fixture with official inference (RDKit) geometry, never bound xyz."""
    original = graph.mol_info['original']
    fragmented = graph.mol_info['fragmented']
    n = original.GetNumAtoms()
    if [a.GetAtomicNum() for a in fragmented.GetAtoms()][:n] != [a.GetAtomicNum() for a in original.GetAtoms()]:
        raise OracleContractError('Official fragmentation did not retain original atom order')
    # Capture the actual unfragmented inference molecule. Copying tags from the
    # original SDF is insufficient: official AddHs/RemoveHs cleans stereo tags,
    # while FragmentOnBonds can flip tetrahedral tags as neighbors are reordered.
    mol = Chem.Mol(reference)
    if mol.GetNumAtoms() != n or not np.array_equal(mol.GetConformer().GetPositions(),
                                                    fragmented.GetConformer().GetPositions()[:n]):
        raise OracleContractError('Reference is not the exact official pre-fragmentation conformer')
    groups = [[k for k in group if k < n] for group in Chem.GetMolFrags(fragmented)]
    cuts = []
    for b in get_fragment_map(fragmented)['torsional_bonds']:
        bond = mol.GetBondBetweenAtoms(*b['bond'])
        if bond is None:
            raise OracleContractError('Official cut bond missing from chemical molecule')
        cuts.append(bond.GetIdx())
    return export_oracle(mol, groups, cuts, reference_source='official RDKit sampled inference conformer')


def assemble(spec):
    """Recreate chemically sanitized ligand with exact original atom/bond order."""
    if spec.get('schema') != 'sigmadock-oracle-chemistry-v1':
        raise OracleContractError('Unsupported Oracle schema')
    fragments = spec['fragments']
    if not fragments or [f['slot'] for f in fragments] != list(range(len(fragments))):
        raise OracleContractError('Fragment slots must be consecutive and nonempty')
    ids = [k for f in fragments for k in f['atom_ids']]
    if sorted(ids) != list(range(len(ids))) or not ids:
        raise OracleContractError('Atom indices must be a permutation of 0..N-1')
    n = len(ids)
    atom_records = {}
    xyz = np.empty((n, 3), dtype=float)
    slots = {}
    for f in fragments:
        group = f['atom_ids']
        if not group or len(f['atoms']) != len(group):
            raise OracleContractError('Atom and identity lengths differ')
        coords = np.asarray(f['coordinates'], dtype=float)
        if coords.shape != (len(group), 3) or not np.isfinite(coords).all():
            raise OracleContractError('Nonfinite or incorrectly shaped reference geometry')
        if _identity(f['atoms'], f['bonds'], group) != f['identity']:
            raise OracleContractError('Fragment identity does not match its chemical template')
        if not set(f['ports']).issubset(group):
            raise OracleContractError('Port outside fragment')
        xyz[group] = coords
        for k, a in zip(group, f['atoms']):
            atom_records[k] = a
            slots[k] = f['slot']
    rw = Chem.RWMol()
    for k in range(n):
        a = atom_records[k]
        if a['z'] <= 0:
            raise OracleContractError('Identity templates must contain real atoms, not dummies')
        atom = Chem.Atom(int(a['z']))
        atom.SetFormalCharge(a['charge'])
        atom.SetIsotope(a['isotope'])
        atom.SetChiralTag(Chem.ChiralType.values[a['chiral_tag']])
        atom.SetNumExplicitHs(a['explicit_hs'])
        atom.SetNoImplicit(a['no_implicit'])
        atom.SetIsAromatic(a['aromatic'])
        atom.SetNumRadicalElectrons(a['radicals'])
        atom.SetAtomMapNum(a['atom_map'])
        rw.AddAtom(atom)
    bonds = []
    for f in fragments:
        for b in f['bonds']:
            if not {b['begin'], b['end']}.issubset(f['atom_ids']):
                raise OracleContractError('An internal bond leaves its identity template')
            bonds.append(b)
    for b in spec['connections']:
        a, z = b['begin'], b['end']
        if a not in slots or z not in slots or slots[a] == slots[z]:
            raise OracleContractError('Connection must join atoms in two different fragments')
        if b['slots'] != [slots[a], slots[z]]:
            raise OracleContractError('Connection slot/atom mapping differs')
        if any(k not in fragments[slots[k]]['ports'] for k in (a, z)):
            raise OracleContractError('Connection uses an undeclared attachment port')
        bonds.append(b)
    bonds.sort(key=lambda b: b['order'])
    if [b['order'] for b in bonds] != list(range(len(bonds))):
        raise OracleContractError('Missing or duplicate bond order index')
    cuts = spec['cut_order']
    if len(cuts) != len(set(cuts)) or set(cuts) != {b['order'] for b in spec['connections']}:
        raise OracleContractError('Connections and explicit cut order differ')
    try:
        for b in bonds:
            rw.AddBond(b['begin'], b['end'], Chem.BondType.values[b['bond_type']])
            bond = rw.GetBondWithIdx(b['order'])
            bond.SetIsAromatic(b['aromatic'])
            bond.SetIsConjugated(b['conjugated'])
            bond.SetBondDir(Chem.BondDir.values[b['direction']])
        for b in bonds:
            bond = rw.GetBondWithIdx(b['order'])
            if b['stereo_atoms']:
                if len(b['stereo_atoms']) != 2:
                    raise OracleContractError('Invalid stereo atom tuple')
                bond.SetStereoAtoms(*b['stereo_atoms'])
            bond.SetStereo(Chem.BondStereo.values[b['stereo']])
        mol = rw.GetMol()
        Chem.SanitizeMol(mol)
        # Leave perception to the official fragmenter. Premature stereo assignment
        # sets RDKit's _StereochemDone cache and prevents its normal cleanup of
        # non-stereogenic SDF tags, changing the official chiral feature column.
        if len(Chem.GetMolFrags(mol)) != 1:
            raise OracleContractError('Oracle docking requires a connected chemical molecule')
        conf = Chem.Conformer(n)
        for k in range(n):
            conf.SetAtomPosition(k, xyz[k])
        mol.AddConformer(conf)
        return mol
    except OracleContractError:
        raise
    except Exception as exc:
        raise OracleContractError(f'Invalid assembled chemistry: {exc}') from exc


class _ExplicitOracleDataset(SigmaDataset):
    """Run the original Dataset code with supplied chemistry/pocket and cuts.

    A private function binding changes only fragment selection, preserving the
    exact official annotation implementation. No module globals are patched;
    concurrent official datasets continue to use their original fragmenter.
    """
    def __init__(self, spec, pocket, pocket_com, pdb_path, ligand_path):
        # In-memory datafront protocol: these paths are provenance only. Unlike
        # ExplicitPairsFront this does not require a whole-ligand SDF on disk.
        super().__init__([(ligand_path, pdb_path, None)],
                         pb_check=False, get_mol_info=True, alignment_tries=0,
                         sample_conformer=False, skip_bounds_check=True, force_retry=False,
                         pocket_com_noise=0., pocket_distance_noise=0.,
                         prot_coordinate_distance_noise=0., lig_coordinate_distance_noise=0.,
                         random_rotation=False, fragmentation_strategy='canonical')
        self.spec = copy.deepcopy(spec)
        self.assembled = assemble(spec)
        self.pocket = Chem.Mol(pocket)
        self.com = np.asarray(pocket_com, dtype=np.float32).reshape(3).copy()
        if not np.isfinite(self.com).all():
            raise OracleContractError('Nonfinite pocket center')

    def parse_complex(self, sdf, pdb, ref_sdf=None):
        return Chem.Mol(self.pocket), Chem.Mol(self.assembled), self.com.copy(), None

    def fragment_and_annotate(self, mol, idx):
        def explicit_fragmenter(molecule, **kwargs):
            molecule = Chem.Mol(molecule)
            # Selection also performs chemistry perception (notably canonical
            # FindMolChiralCenters cleanup for <12 torsions). Keep those official
            # side effects, then apply the GIVEN cuts rather than the sampled cuts.
            # This deliberately favors compatibility over preprocessing speed.
            fragment_molecule(molecule, **kwargs)
            return fragment_on_bonds_with_mapping(molecule, self.spec['cut_order'],
                                                   ignore_conjugated=kwargs['ignore_conjugated'])
        official = SigmaDataset.fragment_and_annotate
        globals_copy = dict(official.__globals__, fragment_molecule=explicit_fragmenter)
        bound = FunctionType(official.__code__, globals_copy, official.__name__,
                             official.__defaults__, official.__closure__)
        result = bound(self, mol, idx)
        fragmented = result[0]
        n = mol.GetNumAtoms()
        actual = {frozenset(k for k in g if k < n) for g in Chem.GetMolFrags(fragmented)}
        declared = {frozenset(f['atom_ids']) for f in self.spec['fragments']}
        if actual != declared:
            raise OracleContractError('Official explicit cutting changed the declared atom partition')
        return result


def rebuild(spec, *, pocket, pocket_com, pdb_path, ligand_path):
    """Build all chemistry features, dummy/virtual structure and reference geometry.

    pocket must be the official RDKit pocket (including residue metadata), not a
    cached custom receptor graph. Paths are provenance and protein embedding keys.
    """
    return _ExplicitOracleDataset(spec, pocket, pocket_com, pdb_path, ligand_path)[0]
