"""Template-only port candidates, separate targets, official marginal noise."""
import argparse
import json
from pathlib import Path
import shutil
import sys

import bootstrap
import numpy as np
import torch
from rdkit import Chem
from torch.utils.data import Dataset,DataLoader

from prediction_data import list_collate,worker_init
from run_validation import write_json
from validation import digest
from vocab_chemistry import VocabLibrary,explicit_oov,true_connections

SCHEMA=1


def make_official_diffuser(output,device='cpu'):
    """Read the frozen official checkpoint's exact VP/IGSO3 discretization."""
    from sigmadock.diff.se3_diffuser import SE3Diffuser
    import sigmadock
    import sigmadock.oracle
    sys.modules['alphadock']=sigmadock;sys.modules['alphadock.oracle']=sigmadock.oracle
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    raw=torch.load(bootstrap.CHECKPOINT,map_location='cpu',weights_only=False)
    config=raw['hyper_parameters']['denoiser_config']
    params={k:config[k] for k in ('min_beta','max_beta','schedule','min_sigma','max_sigma','num_sigma','num_omega','use_cached_score','L')}
    cache=output/'diffusion_cache'
    if not cache.exists():shutil.copytree(bootstrap.CACHE,cache)
    diffuser=SE3Diffuser(**params,cache_path=cache)
    diffuser._so3_diffuser.set_device(torch.device(device))
    write_json(output/'noise_protocol.json',dict(checkpoint_sha256=digest(bootstrap.CHECKPOINT),parameters=params,
        flow='Unmodified official SE3Diffuser.forward_marginal on native C0/Q0, then canonical Tt/Rt; no target pose features'))
    return diffuser


def compile_chemistry(library,labels,oov=None):
    """Only given identities/templates; every permissible port pair is enumerated."""
    oov=oov or [None]*len(labels)
    xyz=[];direction=[];numeric=[];radii=[];slots=[];atoms=[];allowed=[]
    periodic=Chem.GetPeriodicTable()
    for i,label in enumerate(labels):
        mol,local=library.template(int(label),oov[i])
        for site in library.sites(int(label),oov[i]):
            a=int(site['anchor_core']);atom=mol.GetAtomWithIdx(a);neighbours=[n.GetIdx() for n in atom.GetNeighbors()]
            delta=local[a]-local[neighbours] if neighbours else np.zeros((1,3))
            outward=(delta/np.linalg.norm(delta,axis=-1,keepdims=True).clip(1e-8)).sum(0)
            outward/=max(1e-8,np.linalg.norm(outward))
            xyz.append(local[a]);direction.append(outward)
            numeric.append([atom.GetAtomicNum()/54,atom.GetFormalCharge()/3,site['capacity_bond_order_units']/4,
                            atom.GetIsAromatic(),atom.IsInRing(),atom.GetDegree()/4,mol.GetNumAtoms()/44])
            radii.append(periodic.GetRcovalent(atom.GetAtomicNum()));slots.append(i);atoms.append(a)
            allowed.append([k in site['carbon_stub_sanitize_validated_orders'] for k in (1,2)])
    slots=np.asarray(slots,dtype=np.int64)
    a,b=np.where(slots[:,None]<slots[None,:])
    return dict(labels=torch.tensor(labels,dtype=torch.long),xyz=torch.tensor(np.asarray(xyz).reshape(-1,3),dtype=torch.float32),
        direction=torch.tensor(np.asarray(direction).reshape(-1,3),dtype=torch.float32),
        numeric=torch.tensor(np.asarray(numeric).reshape(-1,7),dtype=torch.float32),radius=torch.tensor(radii,dtype=torch.float32),
        slot=torch.tensor(slots),atom=torch.tensor(atoms,dtype=torch.long),
        allowed=torch.tensor(allowed,dtype=torch.bool).reshape(-1,2),
        pairs=torch.tensor(np.stack([a,b],-1),dtype=torch.int32))


def compile_targets(chemistry,record):
    # No target is consulted while enumerating ports, pairs, legality or features.
    a,b=chemistry['pairs'].long().T;s=chemistry['slot'];atom=chemistry['atom']
    i,j=s[a],s[b]
    y=record['edges'][i,j].clone().to(torch.int8)
    matches=(record['anchors'][i,j,0]==atom[a])&(record['anchors'][i,j,1]==atom[b])
    y[~matches]=0
    stereo=record['stereo'][i,j].clamp_min(0).to(torch.int8)
    count=len(true_connections(record))
    return dict(y=y,stereo=stereo,true_bonds=count,enumerated_positive=int((y>0).sum()))


class CompileDataset(Dataset):
    def __init__(self,ids):self.ids=ids;self.library=None
    def __len__(self):return len(self.ids)
    def __getitem__(self,index):
        if self.library is None:self.library=VocabLibrary()
        pid=self.ids[index]
        try:
            r=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
            chem=compile_chemistry(self.library,r['labels'].tolist(),explicit_oov(r))
            target=compile_targets(chem,r)
            noise={k:r[k].clone() for k in ('T0','R0','C0','Q0','refR','offset')}
            return dict(id=pid,chem=chem,target=target,noise=noise,split=r['audit']['split'])
        except Exception as exc:
            import traceback
            return dict(id=pid,error=repr(exc),traceback=traceback.format_exc())


def contract():
    assets=bootstrap.WORKSPACE/'geom_m12/assets'
    return dict(schema=SCHEMA,assets={k:digest(assets/k) for k in ('templates.json','mapping.json','properties.json')},
        splits={s:digest(bootstrap.RECORDS.parent/f'{s}_ids.json') for s in ('train','val')})


def build_cache(output,workers=8):
    output=Path(output);output.mkdir(parents=True,exist_ok=True);expected=contract()
    datasets={}
    for split in ('train','val'):
        path=output/f'{split}.pt'
        if path.exists():
            data=torch.load(path,weights_only=False)
            if data['contract']!=expected:raise ValueError('Connection cache provenance differs')
            datasets[split]=data;continue
        ids=json.loads((bootstrap.RECORDS.parent/f'{split}_ids.json').read_text())
        rows=[];failures=[]
        loader=DataLoader(CompileDataset(ids),batch_size=16,num_workers=workers,collate_fn=list_collate,worker_init_fn=worker_init)
        for batch in loader:
            for row in batch:
                if 'error' in row:failures.append(row)
                else:
                    assert row['split']==split
                    rows.append(row)
            if len(rows)%512<16:print('COMPILE',split,len(rows),'/',len(ids),flush=True)
        if failures:write_json(output/f'{split}_failures.json',failures);raise RuntimeError(f'{split}: {len(failures)} failed records')
        missing=[r['id'] for r in rows if r['target']['true_bonds']!=r['target']['enumerated_positive']]
        # Explicitly expose any unavailable true port, rather than injecting it as a candidate.
        data=dict(contract=expected,rows=rows,failures=failures,missing_target_ports=missing)
        torch.save(data,path);datasets[split]=data
    assert not {r['id'] for r in datasets['train']['rows']} & {r['id'] for r in datasets['val']['rows']}
    write_json(output/'audit.json',dict(contract=expected,split_intersection=0,
        datasets={s:dict(molecules=len(d['rows']),port_pairs=sum(len(r['chem']['pairs']) for r in d['rows']),
                         true_bonds=sum(r['target']['true_bonds'] for r in d['rows']),
                         enumerated_positive=sum(r['target']['enumerated_positive'] for r in d['rows']),
                         missing_target_ports=d['missing_target_ports']) for s,d in datasets.items()}))
    return datasets


def pack_records(rows,device):
    """Pack molecular boundaries explicitly. No pair can cross a molecule."""
    keys=('labels','xyz','direction','numeric','radius','slot','atom','allowed','pairs')
    chem={k:[] for k in keys};noise={k:[] for k in ('T0','R0','C0','Q0','refR','offset')}
    y=[];stereo=[];port_mol=[];slot_mol=[];pair_mol=[];groups=[]
    ps=ss=gs=0;ptr=[0]
    for m,row in enumerate(rows):
        c=row['chem'];ns=len(c['labels']);np_=len(c['slot']);nr=len(c['pairs'])
        for k in keys:
            value=c[k]
            if k=='slot':value=value+ss
            if k=='pairs':value=value.long()+ps
            chem[k].append(value)
        for k in noise:noise[k].append(row['noise'][k])
        for container,key in ((y,'y'),(stereo,'stereo')):container.append(row['target'][key])
        slot_mol.append(torch.full((ns,),m,dtype=torch.long));port_mol.append(torch.full((np_,),m,dtype=torch.long))
        pair_mol.append(torch.full((nr,),m,dtype=torch.long))
        a,b=c['pairs'].long().T
        groups.append(c['slot'][a]*ns+c['slot'][b]+gs)
        ps+=np_;ss+=ns;gs+=ns*ns;ptr.append(ptr[-1]+nr)
    chem={k:torch.cat(v).to(device) for k,v in chem.items()}
    chem.update(slot_mol=torch.cat(slot_mol).to(device),port_mol=torch.cat(port_mol).to(device),
                pair_mol=torch.cat(pair_mol).to(device),group=torch.cat(groups).to(device),
                n=torch.tensor([len(r['chem']['labels']) for r in rows],device=device,dtype=torch.float32))
    return dict(chem=chem,noise={k:torch.cat(v).to(device) for k,v in noise.items()},
                y=torch.cat(y).to(device),stereo=torch.cat(stereo).to(device),ptr=ptr,rows=rows)


def noisy_frames(packed,diffuser,molecule_t,*,seed):
    """Only this augmentation provider reads reference/target rigid states."""
    device=packed['chem']['labels'].device
    torch.manual_seed(seed)
    if device.type=='cuda':torch.cuda.manual_seed_all(seed)
    noise=packed['noise'];t=molecule_t[packed['chem']['slot_mol']]
    result=diffuser.forward_marginal(noise['C0'],noise['Q0'],t.clamp_min(.00001))
    Q=result['R_t'];R=Q@noise['refR']
    T=result['T_t']*2.7-torch.einsum('nij,nj->ni',Q,noise['offset'])
    clean=t==0
    return torch.where(clean[:,None],noise['T0'],T),torch.where(clean[:,None,None],noise['R0'],R)


def port_geometry(chem,T,R):
    s=chem['slot'];rr=R[s]
    pos=torch.einsum('nij,nj->ni',rr,chem['xyz'])+T[s]
    direction=torch.einsum('nij,nj->ni',rr,chem['direction'])
    return pos,direction


def candidate_features(chem,T,R,t,*,topk=64,cutoff=32.,chunk=524288,adaptive=False,half=True):
    """Pure noisy-input function: no target edges, ports or reference poses."""
    if not len(chem['pairs']):
        return dict(x=T.new_zeros((0,35)),indices=torch.zeros(0,device=T.device,dtype=torch.long),t=T.new_zeros(0))
    position,direction=port_geometry(chem,T,R)
    xx=[];score=[];valid=[]
    for start in range(0,len(chem['pairs']),chunk):
        pair=chem['pairs'][start:start+chunk];a,b=pair.T
        delta=position[b]-position[a];distance=delta.norm(dim=-1);unit=delta/distance.clamp_min(1e-8)[:,None]
        cos=torch.stack([(direction[a]*unit).sum(-1),-(direction[b]*unit).sum(-1),-(direction[a]*direction[b]).sum(-1)],-1)
        radius=chem['radius'][a]+chem['radius'][b]
        rbf=torch.exp(-((distance[:,None]-torch.linspace(0,8,16,device=T.device))/.75).square())
        num=chem['numeric']
        x=torch.cat([num[a]+num[b],(num[a]-num[b]).abs(),rbf,cos,(distance-radius)[:,None],(distance-.9*radius)[:,None]],-1)
        xx.append(x.half() if half else x);score.append((distance-radius).abs()-.1*cos[:,:2].sum(-1))
        slots=chem['slot'];centredistance=(T[slots[a]]-T[slots[b]]).norm(dim=-1)
        tm=t[chem['pair_mol'][start:start+len(pair)]]
        limit=torch.where(tm<=.05,16.,cutoff) if adaptive else cutoff
        valid.append(centredistance<=limit)
    x=torch.cat(xx);score=torch.cat(score);valid=torch.cat(valid)
    order=score.argsort(stable=True);order=order[chem['group'][order].argsort(stable=True)]
    group=chem['group'][order];index=torch.arange(len(order),device=T.device)
    boundary=torch.cat([torch.ones(1,device=T.device,dtype=torch.bool),group[1:]!=group[:-1]])
    begin=torch.where(boundary,index,0).cummax(0).values;rank=index-begin
    k=torch.where(t[chem['pair_mol'][order]]<=.05,8,topk) if adaptive else topk
    keep=rank<k
    chosen=order[keep&valid[order]]
    return dict(x=x[chosen],indices=chosen,t=t[chem['pair_mol'][chosen]])


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--workers',type=int,default=8)
    a=p.parse_args();torch.set_num_threads(2);build_cache(a.output,a.workers)


if __name__=='__main__':main()
