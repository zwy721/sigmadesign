#!/usr/bin/env python3
"""Nested K=1/4/8 legal topology search without oracle generation repair."""
import argparse
import json
import os
from pathlib import Path
import time
import traceback

import bootstrap
import numpy as np
import torch
from rdkit import Chem

from evaluate_robust_connections import edge_set
from oracle_graph import assemble
from pipeline_utils import pose_geometry
from run_connection_trajectories import Observer,save_result
from run_validation import load_official,seed_all,write_json
from trajectory_connections import ConnectionRuntime,GraphFactory,load_connection,legal_topologies,run_trajectory,edge_key
from validation import digest
from vocab_chemistry import VocabLibrary,assemble_slots,canonical


def diverse_hypotheses(runtime,prediction,k=8):
    candidates=legal_topologies(runtime,prediction,k=64,max_search=256)
    result=[];seen=set()
    for c in candidates:
        mol,_,_=assemble_slots(runtime.lib,runtime.labels,c['connections'],oov=runtime.oov)
        key=canonical(mol,False)
        if key in seen:continue
        seen.add(key);result.append(dict(c,constitution=key))
        if len(result)==k:break
    return result,len(candidates)


def rank_trajectory(runtime,frame,xyz,spec,connections,pocket):
    """Only model likelihood and generated geometry. No truth/RMSD argument."""
    prediction=runtime.predict(frame['T'],frame['R'],frame['t'])
    scores={edge_key(c):c['log_odds'] for c in prediction['pool']}
    likelihood=float(np.mean([scores.get(edge_key(c),-20.) for c in connections])) if connections else 0.
    molecule=assemble(spec);geom=pose_geometry(molecule,xyz,spec['connections'],pocket)
    periodic=Chem.GetPeriodicTable();errors=[]
    for connection in spec['connections']:
        i,j=connection['begin'],connection['end'];order=molecule.GetBondBetweenAtoms(i,j).GetBondTypeAsDouble()
        radius=periodic.GetRcovalent(molecule.GetAtomWithIdx(i).GetAtomicNum())+periodic.GetRcovalent(molecule.GetAtomWithIdx(j).GetAtomicNum())
        ideal=radius*(1. if order==1 else .9 if order==2 else .85)
        errors.append(abs(float(np.linalg.norm(xyz[i]-xyz[j]))-ideal))
    mean_error=float(np.mean(errors)) if errors else 0.
    ligand_clashes=geom['ligand_nonbonded_clashes_under_1_2A']/max(1,len(xyz))
    protein_clashes=geom.get('ligand_atoms_clashing_pocket_under_1_2A',0)/max(1,len(xyz))
    score=likelihood-.5*mean_error-2*ligand_clashes-2*protein_clashes
    return dict(score=score,connection_log_odds_mean=likelihood,bond_error_mean_A=mean_error,geometry=geom)


def centroids(xyz,sizes):
    offset=np.cumsum([0]+sizes)
    return np.asarray([xyz[offset[i]:offset[i+1]].mean(0) for i in range(len(sizes))])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=bootstrap.PROJECT/'results/connection_trajectory_20261101')
    p.add_argument('--output',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--adapted',type=Path,required=True);p.add_argument('--ids',required=True)
    p.add_argument('--seeds',default='801,802,803');p.add_argument('--device',default='cuda:0');p.add_argument('--steps',type=int,default=25)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8');torch.use_deterministic_algorithms(True)
    torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    den=load_official(bootstrap.CHECKPOINT,a.output,device);lib=VocabLibrary()
    checkpoints={name:load_connection(path,device) for name,path in [('baseline',a.baseline),('adapted',a.adapted)]}
    report=dict(rows=[],branches=[],failures=[],seeds=list(map(int,a.seeds.split(','))),K=[1,4,8],steps=a.steps,
        checkpoints={name:digest(path) for name,path in [('baseline',a.baseline),('adapted',a.adapted)]},
        source_sha256={n:digest(bootstrap.PROJECT/n) for n in ['trajectory_connections.py','evaluate_topology_search.py']},
        policy='Full time-conditioned head, top64/32A at all times, low-t legal updates, fixed supplied identities/N.',
        ranking='Mean final predicted connection log-odds - .5*mean covalent-radius bond error(A) - 2*ligand-clash fraction - 2*protein-clash fraction. No target geometry, truth topology or Vina used.',
        search='Bounded constrained-tree exclusion search over up to 64 port graphs; deduplicate constitutional chemistry, keep first 8. Nested prefixes, K=1 current first hypothesis. Not exact exhaustive k-best.',
        oracle_repair=False,identity_updates=False,truth_for_metrics_only=True)
    began=time.time()
    for pid in a.ids.split(','):
        fixture=torch.load(a.root/f'inputs/{pid}/fixture.pt',weights_only=False)
        if not fixture['audit']['casf']:raise ValueError('CASF validation expected')
        truth=edge_set(fixture['oracle_edges'])
        sizes=[len(lib.template(t,fixture['oov'][i])[1]) for i,t in enumerate(fixture['labels'])]
        for name,checkpoint in checkpoints.items():
            runtime=ConnectionRuntime(lib,checkpoint,fixture['labels'],fixture['oov'],device,policy='wide',head='full')
            factory=GraphFactory(lib,fixture['labels'],fixture['oov'],fixture['context'])
            for seed in report['seeds']:
                seed_all(seed);C,Q=den.diffuser.sample_ref(len(fixture['labels']),device)
                T=C.cpu().numpy()*2.7+np.asarray(fixture['context']['pocket_com']).reshape(3)
                prediction=runtime.predict(T,Q.cpu().numpy(),.9)
                search_start=time.time();hypotheses,considered=diverse_hypotheses(runtime,prediction,8);search_seconds=time.time()-search_start
                branches=[];initial_centres=[];final_centres=[]
                for b,hypothesis in enumerate(hypotheses):
                    folder=a.output/f'{pid}_{name}_{seed}_branch{b}'
                    branch_started=time.time()
                    try:
                        result=run_trajectory(den,runtime,factory,seed=seed,steps=a.steps,mode='closed',
                            initial_edges=hypothesis['connections'],observer=Observer(fixture,runtime))
                        save_result(folder,result,fixture)
                        ranking=rank_trajectory(runtime,result['frames'][-1],result['positions'][-1],result['spec'],result['connections'],fixture['context']['pocket'])
                        row=dict(id=pid,model=name,seed=seed,branch=b,success=True,seconds=result['seconds'],
                            initial_topology_exact=edge_set(hypothesis['connections'])==truth,
                            final_topology_exact=edge_set(result['connections'])==truth,
                            final_constitution_exact=result['metrics'][-1]['current_constitution_exact'],
                            initial_constitution=hypothesis['constitution'],final_constitution=canonical(assemble(result['spec']),False),
                            final_slot_atom_rmsd_A=result['metrics'][-1]['slot_atom_rmsd_A'],
                            initial_connections=hypothesis['connections'],final_connections=result['connections'],
                            revisions=result['revisions'],rank=ranking)
                        initial_centres.append(centroids(result['positions'][0],sizes));final_centres.append(centroids(result['positions'][-1],sizes))
                    except Exception as exc:
                        if isinstance(exc,torch.OutOfMemoryError):raise
                        folder.mkdir(parents=True,exist_ok=True);(folder/'error.txt').write_text(traceback.format_exc())
                        row=dict(id=pid,model=name,seed=seed,branch=b,success=False,error=repr(exc),seconds=time.time()-branch_started)
                        report['failures'].append(row)
                        initial_centres.append(None);final_centres.append(None)
                    branches.append(row);report['branches'].append(row)
                    print('SEARCH',pid,name,seed,b,row['success'],'elapsed',round(time.time()-began),flush=True)
                for k in (1,4,8):
                    prefix=branches[:k];ok=[r for r in prefix if r['success']]
                    chosen=max(ok,key=lambda r:r['rank']['score']) if ok else None
                    keys={tuple(sorted(edge_set(r['final_connections']))) for r in ok}
                    def drift(values):
                        keep=[values[r['branch']] for r in ok]
                        distances=[float(np.sqrt(np.mean(np.sum((keep[i]-keep[j])**2,-1)))) for i in range(len(keep)) for j in range(i+1,len(keep))]
                        return dict(mean_A=float(np.mean(distances)) if distances else 0.,max_A=max(distances,default=0.))
                    report['rows'].append(dict(id=pid,model=name,seed=seed,K=k,available_hypotheses=len(hypotheses),
                        attempted=len(prefix),completed=len(ok),chemical_valid=bool(ok),selected_branch=chosen['branch'] if chosen else None,
                        selected_topology_exact=chosen['final_topology_exact'] if chosen else False,
                        selected_constitution_exact=chosen['final_constitution_exact'] if chosen else False,
                        selected_rank=chosen['rank'] if chosen else None,
                        selected_slot_atom_rmsd_A=chosen['final_slot_atom_rmsd_A'] if chosen else None,
                        final_topology_pool_contains_truth=any(r['final_topology_exact'] for r in ok),
                        initial_topology_pool_contains_truth=any(r['initial_topology_exact'] for r in ok),
                        distinct_final_topologies=len(keys),initial_pose_drift=drift(initial_centres),final_pose_drift=drift(final_centres),
                        distinct_final_constitutions=len({r['final_constitution'] for r in ok}),port_graphs_considered=considered,
                        seconds=sum(r.get('seconds',0.) for r in prefix)+search_seconds,
                        backbone_evaluations=len(ok)*(a.steps-1),
                        cost_caveat='Wall time amortizes graph cache; all K prefixes charged same K=8 candidate enumeration. NFE is exact for completed branches.'))
                write_json(a.output/'report.partial.json',report)
    report['elapsed_seconds']=time.time()-began;write_json(a.output/'report.json',report)


if __name__=='__main__':main()
