#!/usr/bin/env python3
"""Frozen-backbone pilot with predicted chemical graphs and current-pose updates.

The sampler receives supplied initial identities/N/OOV templates and a pocket.
Target edges, ports and crystal coordinates are read only after sampling for
metrics. A connected bootstrap hypothesis is explicitly NOT a confident graph.
"""
import argparse
import json
from pathlib import Path
import time

import bootstrap
import numpy as np
import torch
from rdkit import Chem

from connection_predictor import candidates,proposals
from evaluate_robust_connections import metadata,edge_set
from joint_sampler import NativeState,chemical_graph,legal_hypothesis,topology_key
from pipeline_utils import molecule_metrics
from predict_identity_control import load_head,predict
from robust_connection_data import compile_chemistry
from robust_connection_model import TimeConnectionPredictor,predict_probabilities,legal_decode_fast
from run_validation import load_official,seed_all,write_json
from validation import SamplingAudit,digest
from vocab_chemistry import VocabLibrary,ChemistryRejected,assemble_slots,explicit_oov,true_connections


def inference_candidates(lib,model,labels,oov,T,R,t,device,retained=None):
    """No dataset or reference-pose argument is accepted by this input builder."""
    from robust_connection_data import candidate_features
    c=compile_chemistry(lib,labels,oov);n=len(labels)
    chem={k:v.to(device) for k,v in c.items()};chem['pairs']=chem['pairs'].long()
    a,b=chem['pairs'].T
    chem.update(slot_mol=torch.zeros(n,dtype=torch.long,device=device),
        port_mol=torch.zeros(len(c['slot']),dtype=torch.long,device=device),
        pair_mol=torch.zeros(len(a),dtype=torch.long,device=device),
        group=chem['slot'][a]*n+chem['slot'][b],n=torch.tensor([n],device=device,dtype=torch.float32))
    packed=dict(chem=chem)
    # At t<=.05 the staged strategy uses the untouched original expert.
    f=candidate_features(chem,torch.tensor(T,device=device,dtype=torch.float32),
        torch.tensor(R,device=device,dtype=torch.float32),torch.tensor([t],device=device),adaptive=True,half=False)
    p,sp=predict_probabilities(model if t>.05 else model.legacy,packed,f,legacy=t<=.05)
    meta,_=metadata(packed,f)
    if retained is not None:
        keep=np.array([any((int(i),int(j),int(a),int(b),o) in retained for o in (1,2)) for i,j,a,b in meta],dtype=bool)
        meta,p,sp=meta[keep],p[keep],sp[keep]
    row=dict(chem=c,oov=oov)
    decision,assembled=legal_decode_fast(lib,row,meta,p.numpy(),sp.numpy(),.65)
    pool=[]
    for k,(i,j,a,b) in enumerate(meta):
        for order in (1,2):
            confidence=float(p[k,order]);none=float(p[k,0])
            pool.append(dict(i=int(i),j=int(j),a=int(a),b=int(b),order=order,
                stereo=int(sp[k].argmax()) if order==2 else 0,confidence=confidence,
                log_odds=float(np.log(max(confidence,1e-8))-np.log(max(none,1e-8)))))
    return decision,assembled,pool


def sample(den,lib,model,identity,*,labels,oov,context,device,seed,steps,alternate,threshold=.8):
    """Only predicted topology enters identity inference or the official network."""
    labels=list(labels);seed_all(seed);n=len(labels)
    C,Q=den.diffuser.sample_ref(n,device)
    T=C.cpu().numpy()*2.7+np.asarray(context['pocket_com']).reshape(3)
    R=Q.cpu().numpy();events=[]
    decision,assembled,pool=inference_candidates(lib,model,labels,oov,T,R,.9,device)
    retained={(c['i'],c['j'],c['a'],c['b'],c['order']) for c in pool}
    if assembled is None:
        connections,_=legal_hypothesis(lib,labels,pool,oov)
        graph_role='uncommitted_connected_candidate'
    else:connections=decision['connections'];graph_role='high_noise_prediction_candidate'
    graph,groups,spec=chemical_graph(lib,labels,connections,context,oov,seed=seed)
    with torch.inference_mode(),SamplingAudit(den) as audit:
        # There is no previous physical state to transfer at bootstrap. The
        # assembled reference can have a different ring conformation from an
        # isolated library template. Use the ORIGINAL native stationary start
        # rather than projecting library shapes into that reference or rejecting
        # an otherwise valid graph. Subsequent graph revisions still transfer
        # the actual physical state and enforce the 0.5 A shape guard.
        seed_all(seed)
        state=NativeState(den,graph,groups,device)
        grid=(.9**(1/3)+torch.arange(steps,device=device)/(steps-1)*(.005**(1/3)-.9**(1/3)))**3
        key=topology_key(labels,connections);revisions=0;last_proposal=[]
        for step,tensor_t in enumerate(grid[:-1]):
            t=float(tensor_t)
            if step%4==0 or t<=.05:
                current_T,current_R,fit=state.slot_frames(lib,labels,oov)
                next_labels=list(labels)
                event=dict(step=step,t=t,fit_rmsd_A=fit,accepted=False,identity_updates=[])
                if alternate and t<=.05:
                    adjacency=np.zeros((n,n),dtype=int)
                    for edge in connections:adjacency[edge['i'],edge['j']]=adjacency[edge['j'],edge['i']]=edge['order']
                    response=predict(identity,dict(T=current_T.tolist(),R=current_R.tolist(),adjacency=adjacency.tolist(),t=t),device)
                    for i,(ids,prob) in enumerate(zip(response['topk'],response['probability'])):
                        if labels[i]>=0 and prob[0]>=threshold and ids[0]!=labels[i]:
                            # Keep molecular slots suitable for the frozen rigid-body contract.
                            template,_=lib.template(ids[0])
                            if template.GetNumHeavyAtoms()>=2 and lib.sites(ids[0]):
                                next_labels[i]=ids[0]
                                event['identity_updates'].append(dict(slot=i,old=labels[i],new=ids[0],confidence=prob[0]))
                memory=retained if t<=.05 and next_labels==labels else None
                decision,assembled,pool=inference_candidates(lib,model,next_labels,oov,current_T,current_R,t,device,retained=memory)
                event.update(candidate_hypotheses=len(pool),proposal_status=decision['status'])
                if t>.05:
                    # Never commit high-noise connection estimates.
                    retained.update((c['i'],c['j'],c['a'],c['b'],c['order']) for c in pool)
                    event['reason']='defer_connections_until_low_noise'
                else:
                    last_proposal=decision['connections']
                    if assembled is None:event['reason']='incomplete_proposal_retain_last_legal_candidate'
                    else:
                        next_connections=decision['connections'];next_key=topology_key(next_labels,next_connections)
                        if next_key==key:
                            graph_role='low_noise_committed_prediction';event['reason']='same_legal_chemistry'
                        else:
                            try:
                                new_graph,new_groups,new_spec=chemical_graph(lib,next_labels,next_connections,context,oov,seed=seed)
                                actual=state.physical();desired=[]
                                for i,label in enumerate(next_labels):
                                    previous=actual[state.pn+np.asarray(state.groups[i])]
                                    if label==labels[i]:desired.append(previous.copy())
                                    else:
                                        _,local=lib.template(label,oov[i])
                                        desired.append((local-local.mean(0))@current_R[i].T+previous.mean(0))
                                replacement=NativeState(den,new_graph,new_groups,device,desired=desired,preferred=current_R)
                                event['pose_transfer_fit_rmsd_A']=replacement.transfer_errors
                                if max(replacement.transfer_errors,default=0)>.5:raise ChemistryRejected('Rebuild shape transfer exceeds 0.5 A')
                                audit.static_hash=None
                                state,graph,groups,spec=replacement,new_graph,new_groups,new_spec
                                labels,connections,key=next_labels,next_connections,next_key
                                if event['identity_updates']:
                                    retained={(c['i'],c['j'],c['a'],c['b'],c['order']) for c in pool}
                                revisions+=1;graph_role='low_noise_committed_prediction'
                                event.update(accepted=True,revision=revisions)
                            except (ChemistryRejected,ValueError,RuntimeError) as exc:
                                if isinstance(exc,torch.OutOfMemoryError):raise
                                event['reason']=repr(exc)
                events.append(event)
            state.step(tensor_t,grid[step]-grid[step+1])
        state.batch=den._update_batch(state.batch,state.pos0,state.pos)
        xyz=state.physical()[state.pn:state.pn+sum(map(len,state.groups))]
    return dict(labels=labels,connections=connections,spec=spec,xyz=xyz,events=events,revisions=revisions,
        graph_role=graph_role,last_low_noise_proposal=last_proposal,audit=audit.report())


def proposal_identities(result):
    """Rejected identity proposals also change the meaning of their port indices."""
    labels=list(result['labels'])
    for event in reversed(result['events']):
        if event['t']<=.05:
            for change in event['identity_updates']:labels[change['slot']]=change['new']
            break
    return labels


def rescore_saved(output):
    report=json.loads((output/'report.json').read_text());records={}
    for row in report['rows']:
        if not row['success']:continue
        pid=row['id'];folder=output/f"{pid}_{row['seed']}_{row['mode']}"
        result=json.loads((folder/'sample.json').read_text())
        result['events']=json.loads((folder/'events.json').read_text())
        proposed_labels=proposal_identities(result);result.pop('events')
        result['last_low_noise_proposal_labels']=proposed_labels
        if pid not in records:records[pid]=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
        record=records[pid];supplied=record['labels'].tolist()
        actual=edge_set(true_connections(record));proposed=edge_set(result['last_low_noise_proposal'])
        comparable={e for e in proposed if proposed_labels[e[0]]==supplied[e[0]] and proposed_labels[e[1]]==supplied[e[1]]}
        row['low_proposal_tp']=len(actual&comparable)
        row['low_proposal_exact']=actual==proposed and supplied==proposed_labels
        write_json(folder/'sample.json',result)
    report['metrics_rescored']='Cross-identity port indices compared only when both proposed endpoint identities match supplied identities. Sampling artifacts and trajectories unchanged.'
    report['metrics_source_sha256']=digest(Path(__file__))
    write_json(output/'report.json',report)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--identity-checkpoint',type=Path,default=bootstrap.PROJECT/'results/prediction_diagnostics/identity_controls/iterative/best.pt')
    p.add_argument('--ids',default='1a30,1r5y,2j7h,2wvt,3b1m,3f3e,3mss,3ryj,4agn,4f9w,4m0y,5tmn')
    p.add_argument('--seeds',default='301,302,303');p.add_argument('--steps',type=int,default=25)
    p.add_argument('--device',default='cuda:2');p.add_argument('--rescore-only',action='store_true')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    if a.rescore_only:rescore_saved(a.output);return
    torch.set_num_threads(2);device=torch.device(a.device);torch.cuda.set_device(device)
    den=load_official(bootstrap.CHECKPOINT,a.output,device);lib=VocabLibrary()
    saved=torch.load(a.checkpoint,map_location='cpu',weights_only=False)
    model=TimeConnectionPredictor(saved['legacy_state']).to(device).eval();model.load_state_dict(saved['model'],strict=True)
    identity,_,_=load_head(a.identity_checkpoint,device)
    report=dict(checkpoint_sha256=digest(a.checkpoint),identity_sha256=digest(a.identity_checkpoint),
        official_checkpoint_sha256=digest(bootstrap.CHECKPOINT),steps=a.steps,time_range=[.9,.005],
        inputs='Supplied initial identities/N/OOV templates, pocket, stationary random T/R. No true edges, true ports or crystal pose.',
        initialization='Bootstrap topology proposed using random template frames; original native stationary C/Q initializes the assembled reference. '
            'No template-to-reference shape projection at bootstrap; actual-pose transfer and 0.5 A guard apply to subsequent graph revisions.',
        pilot_caveat='Small engineering pilot. Initial identities are supplied; iterative identity model was trained on true centres/adjacency. '
            'High-noise connected bootstrap is an UNCOMMITTED predicted candidate, never counted as successful reconstruction.',
        seeds=list(map(int,a.seeds.split(','))),rows=[],failures=[])
    began=time.time()
    for pid in a.ids.split(','):
        record=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
        context=torch.load(bootstrap.PROJECT/f'results/acceptance/{pid}/pocket_context.pt',weights_only=False)
        target=torch.load(bootstrap.PROJECT/f'results/acceptance/{pid}/official_graph.pt',weights_only=False).mol_info['original']
        for seed in report['seeds']:
            for mode in ('fixed_identity','alternating_identity'):
                out=a.output/f'{pid}_{seed}_{mode}';out.mkdir(exist_ok=True)
                try:
                    result=sample(den,lib,model,identity,labels=record['labels'].tolist(),oov=explicit_oov(record),
                        context=context,device=device,seed=seed,steps=a.steps,alternate=mode=='alternating_identity')
                    result['last_low_noise_proposal_labels']=proposal_identities(result)
                    mol,_,_=assemble_slots(lib,result['labels'],result['connections'],oov=explicit_oov(record))
                    conf=mol.GetConformer()
                    for i,point in enumerate(result['xyz']):conf.SetAtomPosition(i,point.tolist())
                    with Chem.SDWriter(str(out/'sample.sdf')) as writer:writer.write(mol)
                    np.save(out/'heavy_xyz_A.npy',result.pop('xyz'))
                    write_json(out/'trajectory_audit.json',result.pop('audit'));write_json(out/'events.json',result.pop('events'))
                    xyz=np.load(out/'heavy_xyz_A.npy');metrics=molecule_metrics(mol,target,xyz)
                    actual=edge_set(true_connections(record));proposed=edge_set(result['last_low_noise_proposal'])
                    supplied=record['labels'].tolist()
                    proposed_labels=result['last_low_noise_proposal_labels']
                    comparable={e for e in proposed if proposed_labels[e[0]]==supplied[e[0]] and proposed_labels[e[1]]==supplied[e[1]]}
                    row=dict(id=pid,seed=seed,mode=mode,success=True,revisions=result['revisions'],
                        low_noise_committed=result['graph_role']=='low_noise_committed_prediction',graph_role=result['graph_role'],
                        identities_correct=sum(x==y for x,y in zip(result['labels'],record['labels'].tolist()) if y>=0),
                        known_slots=int((record['labels']>=0).sum()),
                        low_proposal_tp=len(actual&comparable),low_proposal_predicted=len(proposed),true_bonds=len(actual),
                        low_proposal_exact=actual==proposed and supplied==proposed_labels,**metrics)
                    write_json(out/'sample.json',result)
                except (ChemistryRejected,ValueError,RuntimeError) as exc:
                    if isinstance(exc,torch.OutOfMemoryError):raise
                    import traceback
                    (out/'error.txt').write_text(traceback.format_exc())
                    row=dict(id=pid,seed=seed,mode=mode,success=False,error=repr(exc))
                    report['failures'].append(row)
                report['rows'].append(row);write_json(a.output/'report.partial.json',report)
                print('PILOT',pid,seed,mode,row['success'],'elapsed',round(time.time()-began),flush=True)
    report['elapsed_seconds']=time.time()-began
    write_json(a.output/'report.json',report)


if __name__=='__main__':main()
