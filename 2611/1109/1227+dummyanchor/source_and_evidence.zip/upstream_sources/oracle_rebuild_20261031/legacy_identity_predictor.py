#!/usr/bin/env python3
"""Isolated read-only legacy classifier worker; NEVER the docking backbone."""
import argparse
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
WORK = PROJECT.parent
LEGACY = WORK / 'core497_joint_experiments_20261019/training3684'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint', type=Path, default=LEGACY / 'runs/geom_ipa3684_100ep_20261029_cuda01234_bs372_fast/best_loss.pt')
    p.add_argument('--ids', default='1a30,3b1m,3mss,4agn,4m0y,5tmn')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--device', default='cuda:1')
    p.add_argument('--feature-mode', choices=['geom_matched','pdb_original'], default='geom_matched')
    a = p.parse_args()
    import torch
    import numpy as np
    from identity_server import match_geom_features
    a.output = a.output.resolve()
    a.output.parent.mkdir(parents=True, exist_ok=True)
    if a.output.exists(): p.error('Output exists')
    torch.set_num_threads(2)
    saved = torch.load(a.checkpoint, map_location='cpu', weights_only=False)
    cfg = saved['config']
    cfg['joint_options']['connection_graph'] = 'none'
    cfg['train']['packed_geom'] = False
    cfg['train']['prepared_geom'] = False
    config_path = a.output.with_suffix('.config.json')
    config_path.write_text(json.dumps(cfg, indent=2))
    os.environ['CUTOFF_TRAIN_CONFIG'] = str(config_path)
    # Keep this worker out of the new official-source Python interpreter.
    sys.path = [str(LEGACY)] + [x for x in sys.path if Path(x or '.').resolve() != PROJECT]
    import runtime
    assets = a.output.parent / 'classifier_assets'
    assets.mkdir(exist_ok=True)
    for name in ('mapping.json', 'templates.json', 'properties.json'):
        shutil.copy2(runtime.ASSETS / name, assets / name)
    shutil.copytree(runtime.ASSETS / 'diffusion_cache', assets / 'diffusion_cache', dirs_exist_ok=True)
    runtime.ASSETS = assets
    from data import PoseDataset,input_graph
    from geom_data import initialize
    from model3684 import ConnectionIPA3684
    model = ConnectionIPA3684(a.device)
    model.load_state_dict(saved['model'], strict=True)
    model.eval()
    for param in model.parameters(): param.requires_grad_(False)
    ds = PoseDataset('val', forced_t=.02, forced_mode='all_mask')
    report = dict(checkpoint=str(a.checkpoint.resolve()), checkpoint_sha256=hashlib.sha256(a.checkpoint.read_bytes()).hexdigest(),
                  checkpoint_progress=saved.get('progress'),feature_mode=a.feature_mode,
                  protocol='Known slot count, true fragment rigid positions/orientations and adjacency; '
                           'all in-vocabulary identities masked; explicit OOV chemistry retained. '
                           'Legacy network is classification-only in an isolated subprocess.', rows=[], failures=[])
    for pid in a.ids.split(','):
        try:
            ix = ds.ids.index(pid)
            entry = ds[ix]
            origin = entry['origin']
            entry.update(Tt=entry['T0'].clone(), Rt=entry['R0'].clone(), t=.02,
                         connection_prior=torch.nn.functional.one_hot(entry['edges'], num_classes=3).float())
            entry.pop('geometry_condition',None)
            if a.feature_mode=='geom_matched':
                match_geom_features(entry,initialize()['pg'])
                entry['graph']=input_graph(entry)
            known = entry['labels'] >= 0
            if not (entry['tokens'][known] == cfg['MASK']).all():
                raise AssertionError('True identity leaked into classifier tokens')
            if entry['graph']['case']['native_anchor_pairs']:
                raise AssertionError('True chemical graph leaked into MASK carrier')
            with torch.inference_mode():
                pred = model._run([entry])[0]
            probability = pred['logits'].softmax(-1).cpu()
            values, types = probability.topk(5, -1)
            labels = entry['labels'].tolist()
            guessed = types[:, 0].tolist()
            output_labels = [g if t >= 0 else -1 for t, g in zip(labels, guessed)]
            edge = pred['edge']
            row = dict(id=pid, true_labels=labels, predicted_labels=output_labels,
                       top5=types.tolist(), top5_probability=values.tolist(),
                       known_slots=int(known.sum()), correct=int(((types[:, 0] == entry['labels']) & known).sum()),
                       top5_correct=int((((types == entry['labels'][:, None]).any(-1)) & known).sum()),
                       oov_slots=int((~known).sum()), tokens=entry['tokens'].tolist(),
                       edge={k: (v.softmax(-1) if k != 'pairs' else v).cpu().tolist() for k, v in edge.items()},
                       input_condition=dict(identity='MASK for every known slot', positions='oracle',
                                            adjacency='oracle', oov='supplied explicit atoms'))
            report['rows'].append(row)
            print(pid, 'type correct', row['correct'], '/', row['known_slots'], flush=True)
        except Exception as exc:
            import traceback
            report['failures'].append(dict(id=pid, error=repr(exc), traceback=traceback.format_exc()))
            print('FAILED', pid, traceback.format_exc(), flush=True)
        a.output.write_text(json.dumps(report, indent=2) + '\n')
    total = sum(r['known_slots'] for r in report['rows'])
    report['summary'] = dict(known_slots=total, top1_accuracy=sum(r['correct'] for r in report['rows']) / max(1, total),
                            top5_accuracy=sum(r['top5_correct'] for r in report['rows']) / max(1, total))
    a.output.write_text(json.dumps(report, indent=2) + '\n')
    return 0 if not report['failures'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
