#!/usr/bin/env python3
"""Prepare disjoint non-CASF trajectory cohorts and immutable oracle fixtures."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

import bootstrap
import numpy as np
import torch
from sigmadock.data import SigmaDataset
from sigmadock.datafronts import ExplicitPairsFront

from joint_sampler import chemical_graph
from run_validation import write_json
from serialization import save_graph
from validation import digest
from vocab_chemistry import VocabLibrary,explicit_oov,true_connections,atom_correspondence,oracle_cip,oracle_chiral

ROOT=bootstrap.PROJECT/'results/connection_trajectory_20261101'
SOURCE=Path('/data/zhouwanyao/cutoff_geom3684_pdbbind_20261024/pdbbind/pdbbind_manifest.jsonl')


def select_cohorts(output,train_size=96,cal_size=24):
    sources={r['pdb_id']:r for r in map(json.loads,SOURCE.open())}
    cache=torch.load(bootstrap.PROJECT/'results/connection_robust_20261101/cache/train.pt',weights_only=False)
    val=set(json.loads((bootstrap.RECORDS.parent/'val_ids.json').read_text()))
    buckets=[[],[],[]]
    for row in cache['rows']:
        n=len(row['chem']['labels']);pid=row['id'];source=sources.get(pid)
        if not source or source['is_casf2016'] or pid in val or not 2<=n<=12:continue
        if not Path(source['sdf_path']).exists() or not Path(source['pocket_path']).exists():continue
        # Sum atom-count feature once per fragment; fallback uses portless atoms
        # only during fixture generation. This bound limits this pilot's cost.
        r=None
        bucket=0 if n<=4 else 1 if n<=8 else 2
        buckets[bucket].append(pid)
    for b in buckets:b.sort(key=lambda x:hashlib.sha256(('trajectory-v1:'+x).encode()).hexdigest())
    train=[];cal=[]
    for b in buckets:
        nt=train_size//3;nc=cal_size//3
        train+=b[:nt];cal+=b[nt:nt+nc]
    if len(train)!=train_size or len(cal)!=cal_size:raise ValueError('Cohort sizes must be multiples of three and available')
    assert not set(train)&set(cal) and not (set(train)|set(cal))&val
    result=dict(train=train,calibration=cal,casf_diagnostic='1a30,1r5y,2j7h,2wvt,3b1m,3f3e,3mss,3ryj,4agn,4f9w,4m0y,5tmn'.split(','),
        selection='Deterministic hash; 1/3 each with 2-4,5-8,9-12 slots; all supplied training split and non-CASF',
        source_manifest_sha256=digest(SOURCE),casf_intersection=0,train_calibration_intersection=0)
    write_json(output/'cohorts.json',result);return result,sources


def prepare_one(pid,output,sources,lib):
    folder=output/'inputs'/pid;folder.mkdir(parents=True,exist_ok=True)
    if (folder/'fixture.pt').exists():return
    record=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
    existing=bootstrap.PROJECT/f'results/acceptance/{pid}'
    if (existing/'pocket_context.pt').exists():
        context=torch.load(existing/'pocket_context.pt',weights_only=False)
        target=torch.load(existing/'official_graph.pt',weights_only=False).mol_info['original']
    else:
        source=sources[pid];source_sdf=Path(source['sdf_path']);source_pdb=Path(source['pocket_path'])
        if digest(source_sdf)!=source['source_sha256']:raise ValueError('Source ligand changed')
        # Official parsing infers the ligand residue identifier from the second
        # underscore-delimited filename token. Preserve its input convention.
        sdf=folder/f'{pid}_LIG_ligand.sdf';pdb=folder/f'{pid}_LIG_pocket.pdb'
        shutil.copyfile(source_sdf,sdf);shutil.copyfile(source_pdb,pdb)
        dataset=SigmaDataset(ExplicitPairsFront([(sdf,pdb,None)]),pb_check=False,get_mol_info=True,force_retry=False,
            pocket_com_noise=0.,pocket_distance_noise=0.,prot_coordinate_distance_noise=0.,random_rotation=False,
            pocket_distance_cutoff=5.,alignment_tries=0,sample_conformer=True,skip_bounds_check=True)
        pocket,target,com,_=dataset.parse_complex(sdf,pdb,None)
        context=dict(pocket=pocket,pocket_com=np.asarray(com),pdb_path=str(pdb),ligand_path=str(sdf))
    mapping=atom_correspondence(record,target)
    stereo=dict(cip=oracle_cip(record,target,mapping),chiral=oracle_chiral(record,target,mapping))
    labels=record['labels'].tolist();oov=explicit_oov(record);connections=true_connections(record)
    graph,groups,spec=chemical_graph(lib,labels,connections,context,oov,seed=0,**stereo)
    save_graph(graph,folder/'oracle_graph.pt')
    torch.save(dict(id=pid,labels=labels,oov=oov,context=context,oracle_edges=connections,groups=groups,spec=spec,
        target_xyz=np.concatenate([x.numpy() for x in record['target_xyz']])+np.asarray(record['graph']['case']['origin']),
        target_mol=target,source_record_sha256=digest(bootstrap.RECORDS/f'{pid}.pt'),audit=record['audit']),folder/'fixture.pt')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=ROOT)
    p.add_argument('--ids');p.add_argument('--train-size',type=int,default=96);p.add_argument('--calibration-size',type=int,default=24)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    cohorts,sources=select_cohorts(a.output,a.train_size,a.calibration_size)
    ids=a.ids.split(',') if a.ids else cohorts['casf_diagnostic']+cohorts['train']+cohorts['calibration']
    lib=VocabLibrary();failures=[]
    for i,pid in enumerate(ids):
        try:prepare_one(pid,a.output,sources,lib);print('PREPARE',i+1,len(ids),pid,flush=True)
        except Exception as exc:
            import traceback
            failures.append(dict(id=pid,error=repr(exc),traceback=traceback.format_exc()))
            write_json(a.output/'preparation_failures.json',failures);print('PREPARE_FAILED',pid,repr(exc),flush=True)
    write_json(a.output/'preparation.json',dict(requested=ids,failed=failures))
    write_json(a.output/'preparation_failures.json',failures)


if __name__=='__main__':main()
