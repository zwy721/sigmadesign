#!/usr/bin/env python3
"""Rescore existing CASF candidates; labels are isolated from feature building."""
import argparse
import json
import os
from pathlib import Path

import bootstrap
import numpy as np
import torch

from prepare_reranker_experiment import ROOT,PREVIOUS
from run_validation import write_json
from topology_reranker import extract_features,analytical_scores,SCHEMA
from trajectory_connections import ConnectionRuntime,load_connection
from validation import digest
from vocab_chemistry import VocabLibrary


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--device',default='cuda:6');a=p.parse_args();a.root.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(2);os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    torch.use_deterministic_algorithms(True);torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    checkpoint=load_connection(bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt',a.device)
    lib=VocabLibrary();runtime_by_id={};fixtures={};records=[];labels=[];differences=[]
    for report_path in sorted(PREVIOUS.glob('search_*/report.json')):
        report=json.loads(report_path.read_text())
        for b in report['branches']:
            if b['model']!='baseline' or not b['success']:continue
            pid=b['id']
            if pid not in fixtures:
                fixture=torch.load(PREVIOUS/f'inputs/{pid}/fixture.pt',weights_only=False);fixtures[pid]=fixture
                runtime_by_id[pid]=ConnectionRuntime(lib,checkpoint,fixture['labels'],fixture['oov'],a.device,policy='wide')
            folder=report_path.parent/f"{pid}_baseline_{b['seed']}_branch{b['branch']}"
            trajectory=torch.load(folder/'trajectory.pt',weights_only=False)
            spec=json.loads((folder/'chemistry.json').read_text())
            features=extract_features(runtime_by_id[pid],spec=spec,connections=b['final_connections'],
                frames=trajectory['frames'],positions=trajectory['positions'],pocket=fixtures[pid]['context']['pocket'])
            scores=analytical_scores(features);differences.append(abs(scores['heuristic']-b['rank']['score']))
            key=f"{pid}:{b['seed']}:{b['branch']}"
            records.append(dict(key=key,group=f"{pid}:{b['seed']}",id=pid,seed=b['seed'],branch=b['branch'],features=features,scores=scores))
            labels.append(dict(key=key,constitution_correct=b['final_constitution_exact'],connections_correct=b['final_topology_exact']))
        print('HISTORICAL_FEATURES',report_path.parent.name,len(records),flush=True)
    write_json(a.root/'historical_features.json',dict(schema=SCHEMA,records=records))
    write_json(a.root/'historical_labels.json',labels)
    truth={r['key']:r for r in labels};groups={}
    for r in records:groups.setdefault(r['group'],[]).append(r)
    summary={};failures=[]
    for k in (1,4,8):
        summary[str(k)]={}
        for method in ('heuristic','connection','geometry','pocket','oracle'):
            correct=strict=coverage=0
            for group,rr in groups.items():
                candidates=[r for r in rr if r['branch']<k]
                coverage+=any(truth[r['key']]['constitution_correct'] for r in candidates)
                chosen=max(candidates,key=lambda r:(truth[r['key']]['constitution_correct'] if method=='oracle' else r['scores'][method],-r['branch']))
                correct+=truth[chosen['key']]['constitution_correct'];strict+=truth[chosen['key']]['connections_correct']
                if k==8 and method=='heuristic' and not truth[chosen['key']]['constitution_correct']:
                    positives=[r for r in candidates if truth[r['key']]['constitution_correct']]
                    if positives:
                        best=max(positives,key=lambda r:r['scores']['heuristic'])
                        failures.append(dict(group=group,winner=chosen['key'],best_correct=best['key'],winner_scores=chosen['scores'],correct_scores=best['scores'],
                            feature_differences={f:chosen['features'][f]-best['features'][f] for f in chosen['features']}))
            summary[str(k)][method]=dict(runs=len(groups),constitution_correct=int(correct),connections_correct=int(strict),candidate_coverage=int(coverage),oracle_diagnostic_only=method=='oracle')
    report=dict(summary=summary,ranking_failures=failures,max_historical_heuristic_reproduction_error=max(differences),
        candidates=len(records),historical_casf_development_only=True,used_for_training=False,
        source_sha256={n:digest(bootstrap.PROJECT/n) for n in ['topology_reranker.py','analyze_topology_rank_failures.py']})
    write_json(a.root/'historical_ranking_analysis.json',report)
    if max(differences)>1e-4:raise AssertionError('Historical heuristic was not reproduced')
    print(json.dumps(summary,indent=2),flush=True)


if __name__=='__main__':main()
