"""Alternating identity/connection proposals and original SigmaDock SE(3) steps.

Only complete legal hypotheses enter the backbone. Rejected proposals retain
the last valid graph and are logged. Every accepted graph revision regenerates
reference geometry, masks and dynamic edges and transfers the physical pose.
"""
import copy
import json
import subprocess
from pathlib import Path

import bootstrap
import numpy as np
import torch
from torch_geometric.data import Batch

from connection_predictor import candidates, legal_decode, proposals
from oracle_graph import rebuild
from pipeline_utils import remap_oracle_adjacency, rigid_fit
from run_validation import seed_all
from sigmadock.oracle import HPARAMS
from validation import SamplingAudit
from vocab_chemistry import ChemistryRejected, assemble_slots, embedded_reference, spec_from_slots


class PredictorExecutionError(RuntimeError):
    pass


class IdentityClient:
    def __init__(self, output, device='cuda:3'):
        self.log=Path(output).open('w')
        self.process=subprocess.Popen([str(bootstrap.WORKSPACE/'.venv-cutoff-train/bin/python'),
            str(bootstrap.PROJECT/'identity_server.py'),'--device',device,'--assets',
            str(Path(output).parent/'identity_server_assets')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
            stderr=self.log,text=True,bufsize=1)
        line=self.process.stdout.readline()
        if not line or not json.loads(line).get('ready'):raise RuntimeError('Identity server failed to initialize')

    def predict(self,**request):
        self.process.stdin.write(json.dumps(request)+'\n');self.process.stdin.flush()
        line=self.process.stdout.readline()
        if not line:raise PredictorExecutionError('Identity server exited')
        try:response=json.loads(line)
        except json.JSONDecodeError as exc:raise PredictorExecutionError('Malformed identity server response') from exc
        if 'error' in response:raise PredictorExecutionError(response['error'])
        return response

    def close(self):
        if self.process.poll() is None:
            self.process.stdin.write('{"close":true}\n');self.process.stdin.flush()
            self.process.wait(timeout=30)
        self.log.close()


def legal_hypothesis(library,labels,pool,oov=None):
    """A low-confidence connected CANDIDATE, explicitly distinct from commitment.

    This optional search is used only for joint bootstrap; held-out connection
    evaluation never completes disconnected proposals with a spanning tree.
    """
    parent=list(range(len(labels)));used={};selected=[]
    def root(i):
        while parent[i]!=i:i=parent[i]
        return i
    for c in sorted(pool,key=lambda c:(-c['log_odds'],c['i'],c['j'],c['a'],c['b'])):
        i,j=c['i'],c['j']
        if root(i)==root(j):continue
        okay=True
        for slot,atom in ((i,c['a']),(j,c['b'])):
            sites={s['anchor_core']:s for s in library.sites(int(labels[slot]),(oov or [None]*len(labels))[slot])}
            if atom not in sites or c['order'] not in sites[atom]['carbon_stub_sanitize_validated_orders'] or used.get((slot,atom),0)+c['order']>sites[atom]['capacity_bond_order_units']:
                okay=False;break
        if not okay:continue
        selected.append(c);parent[root(i)]=root(j)
        for k in ((i,c['a']),(j,c['b'])):used[k]=used.get(k,0)+c['order']
        if len(selected)==len(labels)-1:break
    mol,groups,cuts=assemble_slots(library,labels,selected,oov=oov)
    return selected,(mol,groups,cuts)


class NativeState:
    def __init__(self,den,graph,groups,device,*,randomize=True,desired=None,preferred=None):
        self.graph=graph;self.groups=groups;self.den=den
        data=graph.clone();del data.mol_info
        self.batch=Batch.from_data_list([data]).to(device)
        self.pos0,self.T0,self.R0,self.num=den._get_initial_states(self.batch)
        self.pn=int((graph.frag_idx_map==-1).sum())
        self.transfer_errors=[]
        mass,_=den.get_fragment_mass_inertia(self.pos0,self.batch)
        if mass.min()<2:raise ChemistryRejected('Official rigid-body mass contract violated')
        if desired is None:
            self.C,self.Q=den.diffuser.sample_ref(int(self.num.sum()),device)
        else:
            ref=graph.ref_pos.cpu().numpy()
            C,Q=[],[]
            for i,g in enumerate(groups):
                src=ref[self.pn+np.asarray(g)]
                trans,rotation,error=rigid_fit(src,desired[i],None if preferred is None else preferred[i])
                self.transfer_errors.append(error)
                center=self.T0[i].cpu().numpy()*HPARAMS.general.dimensional_scale+graph.pocket_com.cpu().numpy().reshape(3)
                center=center@rotation.T+trans
                C.append((center-graph.pocket_com.cpu().numpy().reshape(3))/HPARAMS.general.dimensional_scale)
                Q.append(rotation@self.R0[i].cpu().numpy())
            self.C=torch.as_tensor(np.asarray(C),device=device,dtype=self.pos0.dtype)
            self.Q=torch.as_tensor(np.asarray(Q),device=device,dtype=self.pos0.dtype)
        self.pos=den._apply_transformations(self.pos0,self.batch,self.T0,self.R0,self.Q,self.C)

    def physical(self):
        return (self.pos.detach().cpu().numpy()*HPARAMS.general.dimensional_scale
                +self.graph.pocket_com.cpu().numpy().reshape(3))

    def slot_frames(self,library,labels,oov):
        xyz=self.physical();T,R,errors=[],[],[]
        for i,g in enumerate(self.groups):
            _,template=library.template(int(labels[i]),oov[i])
            translation,rotation,error=rigid_fit(template,xyz[self.pn+np.asarray(g)])
            T.append(translation);R.append(rotation);errors.append(error)
        return np.asarray(T),np.asarray(R),errors

    def step(self,t,dt):
        den=self.den
        self.batch=den._update_batch(self.batch,self.pos0,self.pos)
        forces,index=den._compute_forces(copy.deepcopy(self.batch),torch.as_tensor([t],device=self.pos.device))
        force,torque,mass,inertia=den._compute_fragment_dynamics(self.batch,self.Q,self.R0,self.C,forces,index)
        updates=den._predict_fragment_updates(force,torque,mass,inertia)
        scores=den._compute_scores(dict(T_t=self.C,R_t=self.Q),updates,t.repeat_interleave(int(self.num.sum())))
        C,Q=den.diffuser.reverse(self.C,self.Q,scores['pred_T_score'],scores['pred_R_score'],t,dt,noise_scale=0.)
        self.pos=den._apply_transformations(self.pos,self.batch,self.C,self.Q,Q,C)
        self.C,self.Q=C,Q
        if not torch.isfinite(self.pos).all():raise FloatingPointError('Nonfinite joint trajectory')


def chemical_graph(library,labels,connections,context,oov,seed=0,cip=None,chiral=None):
    mol,groups,cuts=assemble_slots(library,labels,connections,oov=oov,cip=cip,chiral=chiral)
    reference=embedded_reference(mol,seed=seed)
    spec=spec_from_slots(reference,groups,cuts,labels,'current legal chemistry; regenerated unbound reference')
    return rebuild(spec,**context),groups,spec


def topology_key(labels,connections):
    return (tuple(labels),tuple(sorted((c['i'],c['j'],c['a'],c['b'],c['order'],c.get('stereo',0)) for c in connections)))


def sample_joint(den,library,connection_model,identity_client,*,pid,record,context,profile,device,steps=25,seed=0,
                 stride=5,identity_threshold=.3,slots=None,oracle_chemical_stereo=None):
    profiles={'oracle':(True,True,True),'learned_connections':(True,False,True),
              'learned_identity':(False,True,True),'joint':(False,False,False)}
    identity_oracle,connection_oracle,center_oracle=profiles[profile]
    from vocab_chemistry import explicit_oov,true_connections
    original_labels=record['labels'].tolist();n=slots or len(original_labels)
    if n!=len(original_labels) and (identity_oracle or connection_oracle or center_oracle):
        raise ValueError('An Oracle profile requires its original slot count')
    seed_all(seed);rng=np.random.default_rng(seed)
    oov=explicit_oov(record) if identity_oracle else [None]*n
    if identity_oracle:labels=original_labels
    else:
        allowed=np.array([p['n_heavy']>=2 and (bool(p['candidate_sites']) or n==1) for p in library.properties])
        prior=np.array([p['train_occurrences'] for p in library.properties],dtype=float)*allowed
        prior/=prior.sum();labels=rng.choice(len(prior),size=n,p=prior).tolist()
    if center_oracle:
        feature_T=record['T0'].numpy()+np.asarray(record['graph']['case']['origin']);feature_R=record['R0'].numpy()
    else:
        C,Q=den.diffuser.sample_ref(n,device)
        feature_T=C.cpu().numpy()*HPARAMS.general.dimensional_scale+np.asarray(context['pocket_com']).reshape(3)
        feature_R=Q.cpu().numpy()
    events=[]
    if connection_oracle:
        truth=true_connections(record)
        if identity_oracle:connections=truth
        else:
            prediction=identity_client.predict(id=pid,T=feature_T.tolist(),R=feature_R.tolist(),t=1.,connections=truth)
            proposed=prediction['types']
            # Purely geometric port binding; original identity indices are withheld.
            connections,_,_=remap_oracle_adjacency(library,[-999]*n,proposed,truth,feature_T,feature_R,oov=oov)
            labels=proposed
        bootstrap_policy='oracle_slot_adjacency'
    else:
        x=candidates(library,labels,feature_T,feature_R,oov=oov,cutoff=32.)
        proposed,pool=proposals(connection_model,x,device)
        decision,assembled=legal_decode(library,labels,proposed,oov=oov)
        if assembled is None:
            connections,_=legal_hypothesis(library,labels,pool,oov)
            bootstrap_policy='legal_low_confidence_candidate_hypothesis'
        else:connections=decision['connections'];bootstrap_policy='complete_predicted_connections'
    stereo=oracle_chemical_stereo or {}
    graph,groups,spec=chemical_graph(library,labels,connections,context,oov,seed=seed,
        cip=stereo.get('cip') if profile=='oracle' else None,
        chiral=stereo.get('chiral') if profile=='oracle' else None)
    # Reset RNG here, matching the original sampler's stationary initialization.
    seed_all(seed)
    with torch.inference_mode(),SamplingAudit(den) as audit:
        state=NativeState(den,graph,groups,device)
        grid=(1.+torch.arange(steps,device=device)/(steps-1)*(.005**(1/3)-1.))**3
        initial=state.physical();key=topology_key(labels,connections);revisions=0
        for step,t in enumerate(grid[:-1]):
            if step>0 and step%stride==0 and profile!='oracle':
                current_T,current_R,fit=state.slot_frames(library,labels,oov)
                T,R=(feature_T,feature_R) if center_oracle else (current_T,current_R)
                next_labels=list(labels)
                event=dict(step=step,t=float(t),accepted=False,old_labels=list(labels),fit_rmsd_A=fit)
                try:
                    if not identity_oracle:
                        response=identity_client.predict(id=pid,T=T.tolist(),R=R.tolist(),t=float(t),connections=connections)
                        event['type_confidence']=response['confidence']
                        for i,(guess,confidence) in enumerate(zip(response['types'],response['confidence'])):
                            if confidence>=identity_threshold:next_labels[i]=guess
                    if connection_oracle:
                        next_connections,_,_=remap_oracle_adjacency(library,[-999]*n,next_labels,true_connections(record),T,R,oov=oov)
                        candidate_kind='oracle_adjacency_geometric_ports'
                    else:
                        x=candidates(library,next_labels,T,R,oov=oov,cutoff=32.)
                        proposed,pool=proposals(connection_model,x,device)
                        decision,assembled=legal_decode(library,next_labels,proposed,oov=oov)
                        if assembled is None:
                            next_connections,_=legal_hypothesis(library,next_labels,pool,oov)
                            candidate_kind='legal_uncommitted_hypothesis'
                        else:next_connections=decision['connections'];candidate_kind='complete_prediction'
                    next_key=topology_key(next_labels,next_connections)
                    event.update(proposed_labels=next_labels,candidate_kind=candidate_kind)
                    if next_key!=key:
                        new_graph,new_groups,new_spec=chemical_graph(library,next_labels,next_connections,context,oov,seed=seed)
                        desired=[]
                        previous_xyz=state.physical()
                        for i,label in enumerate(next_labels):
                            old_actual=previous_xyz[state.pn+np.asarray(state.groups[i])]
                            if label==labels[i]:
                                desired.append(old_actual.copy())
                            else:
                                _,xyz=library.template(label,oov[i])
                                desired.append((xyz-xyz.mean(0))@current_R[i].T+old_actual.mean(0))
                        replacement=NativeState(den,new_graph,new_groups,device,desired=desired,preferred=current_R)
                        event['pose_transfer_fit_rmsd_A']=replacement.transfer_errors
                        if max(replacement.transfer_errors,default=0)>.5:
                            raise ChemistryRejected('New reference is incompatible with the current physical fragment shapes (>0.5 A)')
                        # Static edges must be invariant WITHIN each graph revision.
                        audit.static_hash=None
                        state,graph,groups,spec=replacement,new_graph,new_groups,new_spec
                        labels,connections,key=next_labels,next_connections,next_key;revisions+=1
                        event.update(accepted=True,revision=revisions,real_atoms=sum(map(len,new_groups)))
                    else:event['reason']='proposal_matches_current_chemistry'
                except PredictorExecutionError:
                    # Software/service failures are not ordinary rejected chemical hypotheses.
                    raise
                except (ChemistryRejected,ValueError,RuntimeError) as exc:
                    if isinstance(exc,torch.OutOfMemoryError):raise
                    event['reason']=repr(exc);event['fallback']='retain_last_legal_graph'
                events.append(event)
            state.step(t,grid[step]-grid[step+1])
        # Last state update refreshes dynamic geometry even though no extra force is evaluated.
        state.batch=den._update_batch(state.batch,state.pos0,state.pos)
        xyz=state.physical()[state.pn:state.pn+sum(map(len,state.groups))]
    return dict(profile=profile,seed=seed,labels=labels,connections=connections,spec=spec,xyz=xyz,
                events=events,revisions=revisions,audit=audit.report(),bootstrap_policy=bootstrap_policy,
                conditioning=dict(identity=identity_oracle,connections=connection_oracle,centers=center_oracle,
                                  centers_usage='predictor_inputs_only',slot_count='oracle' if slots is None else 'user_supplied',
                                  oov='supplied_only_in_true_identity_profiles'),initial_xyz=initial)
