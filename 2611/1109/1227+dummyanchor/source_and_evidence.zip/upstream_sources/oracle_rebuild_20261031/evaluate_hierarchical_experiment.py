#!/usr/bin/env python3
"""Evaluate fixed candidate prefixes at exactly matched denoiser budgets."""
import argparse
import json
from pathlib import Path

import bootstrap
import numpy as np
import torch
from rdkit import Chem

from hierarchical_topology import adjacency_key
from prepare_hierarchical_experiment import ROOT
from run_hierarchical_experiment import colored_adjacency
from run_validation import write_json
from validation import digest


def matched_prefixes(methods,k):
    """Never pad/repeat candidates to claim a larger equal sampling budget."""
    size=min(k,*(len(v) for v in methods.values()))
    return {name:keys[:size] for name,keys in methods.items()}


def aggregate(rows):
    count_fields=['initial_colored_skeleton_coverage','initial_labelled_skeleton_coverage','initial_constitution_coverage',
        'final_colored_skeleton_coverage','final_labelled_skeleton_coverage','final_constitution_coverage',
        'final_exact_connections_coverage','constitution_correct','connections_correct','chemical_valid','geometry_abnormal',
        'pocket_clash','initial_correct_constitution_lost','final_pool_correct_but_ranked_wrong']
    return dict(runs=len(rows),**{key:sum(bool(r[key]) for r in rows) for key in count_fields},
        mean_selected_connection_f1=float(np.mean([r['selected_connection_f1'] for r in rows])),
        mean_actual_candidates=float(np.mean([r['attempted'] for r in rows])),
        mean_backbone_evaluations=float(np.mean([r['backbone_evaluations'] for r in rows])),
        mean_distinct_final_constitutions=float(np.mean([r['distinct_final_constitutions'] for r in rows])),
        median_sampling_seconds=float(np.median([r['sampling_seconds'] for r in rows])),
        median_search_seconds=float(np.median([r['search_seconds'] for r in rows])),
        median_sampling_plus_search_seconds=float(np.median([r['sampling_seconds']+r['search_seconds'] for r in rows])),
        unresolved_selected_double_centres=sum(r['unresolved_double_centres'] for r in rows),
        unresolved_selected_tetra_centres=sum(r['unresolved_tetra_centres'] for r in rows))


def aggregate_diagnostics(groups):
    result=dict(groups=len(groups),all_required_edges_in_support=sum(d['true_connections_in_frozen_candidate_support']==d['required_connections'] for d in groups),
        all_required_edges_in_pair_top64=sum(d['true_connections_in_truncated_pair_options']==d['required_connections'] for d in groups),
        stage1={key:sum(d['true_skeleton_in_stage1'][key] for d in groups) for key in ('labelled_skeleton','colored_skeleton')},
        internal_pool={key:sum(bool(d['hierarchical_all_internal_candidates'][key]) for d in groups) for key in ('labelled_skeleton','colored_skeleton','exact_connections','constitution')})
    for name in ['true_skeleton_port_beam','true_skeleton_wide_port_beam','ordinary_initial','hierarchical_initial']:
        result[name]={k:{metric:sum(d[name][k][metric] for d in groups) for metric in ('labelled_skeleton','colored_skeleton','exact_connections','constitution')} for k in groups[0][name]}
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args()
    cohorts=json.loads((a.root/'cohorts.json').read_text());lock=json.loads((a.root/'search_lock.json').read_text())
    reports=[(p,json.loads(p.read_text())) for p in sorted(a.root.glob('holdout_*/report.json'))]
    groups=[(path,group) for path,report in reports for group in report['groups']]
    expected={(pid,s) for pid in cohorts['casf_holdout'] for s in cohorts['test_seeds']}
    if {(g['id'],g['seed']) for _,g in groups}!=expected or len(groups)!=len(expected):raise ValueError('Missing/duplicated CASF groups')
    if any(r['contract']['config']!=lock['config'] or r['contract']['source_sha256']!=lock['source_sha256'] for _,r in reports):raise ValueError('Unlocked search configuration/source')
    result=dict(rows=[],per_case_diagnostics=[],oracle_diagnostic_only=True,ranking='Frozen previous heuristic, generated features only',
        source_sha256=digest(bootstrap.PROJECT/'evaluate_hierarchical_experiment.py'),search_lock_sha256=digest(a.root/'search_lock.json'),
        repeat_benchmark_not_new_blind_cohort=True,budget='Both methods use min(K, available ordinary, available hierarchical) unique starting hypotheses; NFE=24 per successful trajectory.')
    for path,group in groups:
        if group['role']!='holdout' or group['enrichment']:raise ValueError('Invalid CASF pool')
        candidates={c['key']:c for c in group['candidates']};generation=json.loads(Path(group['generation_path']).read_text())
        # Select BEFORE reading the independent target labels or true graph.
        chosen_by_task={}
        for k in [1,4,8]:
            for method,keys in matched_prefixes(group['methods'],k).items():
                ok=[key for key in keys if candidates[key]['success']]
                chosen_by_task[method,k]=max(ok,key=lambda key:candidates[key]['scores']['heuristic']) if ok else None
        labels={r['key']:r for r in json.loads(Path(group['labels_path']).read_text())}
        fixture=torch.load(Path(cohorts['source_root'])/f"inputs/{group['id']}/fixture.pt",weights_only=False)
        true_skeleton=colored_adjacency(fixture['labels'],fixture['oracle_edges']);true_pairs=adjacency_key(fixture['oracle_edges'])
        for k in [1,4,8]:
            prefixes=matched_prefixes(group['methods'],k)
            for method,keys in prefixes.items():
                ok=[key for key in keys if candidates[key]['success']];selected=chosen_by_task[method,k]
                label=labels[selected] if selected else {};row=candidates[selected] if selected else {};feat=row.get('features',{})
                initial=generation['ordinary'] if method=='ordinary' else generation['hierarchical']['candidates']
                initial=initial[:len(keys)];final_cov=any(labels[key]['constitution_correct'] for key in ok)
                initial_cov=bool(group['oracle_diagnostic'][('ordinary' if method=='ordinary' else 'hierarchical')+'_initial'][str(k)]['constitution'])
                # If availability were below nominal K, use actual selected prefix.
                if len(keys)!=min(k,len(group['methods'][method])):
                    from run_hierarchical_experiment import coverage
                    initial_cov=coverage(initial,fixture)['constitution']
                unresolved_double=unresolved_tetra=0
                if selected:
                    from oracle_graph import assemble
                    molecule=assemble(json.loads((Path(group['generation_path']).parent/selected/'chemistry.json').read_text()))
                    for info in Chem.FindPotentialStereo(molecule):
                        if info.specified!=Chem.StereoSpecified.Unspecified:continue
                        if info.type==Chem.StereoType.Bond_Double:unresolved_double+=1
                        if info.type==Chem.StereoType.Atom_Tetrahedral:unresolved_tetra+=1
                r=dict(id=group['id'],seed=group['seed'],method=method,K=k,attempted=len(keys),completed=len(ok),selected=selected,
                    initial_colored_skeleton_coverage=any(colored_adjacency(fixture['labels'],c['connections'])==true_skeleton for c in initial),
                    initial_labelled_skeleton_coverage=any(adjacency_key(c['connections'])==true_pairs for c in initial),
                    initial_constitution_coverage=initial_cov,
                    final_colored_skeleton_coverage=any(candidates[key]['final_skeleton']==true_skeleton for key in ok),
                    final_labelled_skeleton_coverage=any(adjacency_key(candidates[key]['final_connections'])==true_pairs for key in ok),
                    final_constitution_coverage=final_cov,final_exact_connections_coverage=any(labels[key]['connections_correct'] for key in ok),
                    constitution_correct=bool(label.get('constitution_correct')),connections_correct=bool(label.get('connections_correct')),
                    selected_connection_f1=float(label.get('connection_f1',0.)),chemical_valid=bool(selected),
                    geometry_abnormal=not selected or feat['bad_bond_fraction']>0 or feat['ligand_clash_fraction']>0,
                    pocket_clash=bool(selected and feat['pocket_fraction_1.2A']>0),
                    initial_correct_constitution_lost=initial_cov and not final_cov,final_pool_correct_but_ranked_wrong=final_cov and not label.get('constitution_correct'),
                    distinct_final_constitutions=len({candidates[key]['constitution'] for key in ok}),
                    sampling_seconds=sum(candidates[key]['seconds'] for key in keys),search_seconds=group['search_seconds'][method],
                    backbone_evaluations=sum(candidates[key].get('backbone_evaluations',0) for key in ok),
                    unresolved_double_centres=unresolved_double,unresolved_tetra_centres=unresolved_tetra)
                result['rows'].append(r)
            arow,brow=result['rows'][-2:]
            if arow['attempted']!=brow['attempted'] or arow['backbone_evaluations']!=brow['backbone_evaluations']:raise ValueError('Unmatched actual NFE; investigate failures before reporting')
        result['per_case_diagnostics'].append(dict(id=group['id'],seed=group['seed'],**group['oracle_diagnostic']))
    result['summary']={method:{str(k):aggregate([r for r in result['rows'] if r['method']==method and r['K']==k]) for k in [1,4,8]} for method in ['ordinary','hierarchical']}
    result['oracle_layered']=aggregate_diagnostics([g['oracle_diagnostic'] for _,g in groups])
    cal=json.loads((a.root/'calibration_diagnostic/report.json').read_text())['groups']
    result['calibration_oracle_layered']=aggregate_diagnostics([g['oracle_diagnostic'] for g in cal])
    write_json(a.root/'evaluation.json',result);print(json.dumps(dict(summary=result['summary'],oracle_layered=result['oracle_layered']),indent=2))


if __name__=='__main__':main()
