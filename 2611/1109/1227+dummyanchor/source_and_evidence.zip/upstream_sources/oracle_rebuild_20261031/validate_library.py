#!/usr/bin/env python3
"""Export Oracle registry and verify the identity-only entry on all accepted cases."""
import argparse
import json
from pathlib import Path

import bootstrap
import torch
from run_validation import write_json
from template_library import rebuild_from_library, resolve, split_templates
from validation import compare_graphs, digest


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--report', type=Path, required=True)
    a = p.parse_args()
    a.report = a.report.resolve()
    report = json.loads(a.report.read_text())
    if not report['accepted'] or report['stage'] != 'paired_docking_complete':
        p.error('First complete graph and docking acceptance')
    torch.set_num_threads(2)
    library = None
    folder = a.report.parent
    for row in report['rows']:
        path = folder / row['id']
        original = json.loads((path / 'oracle.json').read_text())
        instance, library = split_templates(original, library)
        write_json(path / 'oracle_instance.json', instance)
    write_json(folder / 'oracle_templates.json', library)
    library = json.loads((folder / 'oracle_templates.json').read_text())
    result = dict(accepted=False, parent_docking_report_sha256=digest(a.report),
                  module_sha256=digest(bootstrap.PROJECT / 'template_library.py'),
                  source_sha256={name: digest(bootstrap.PROJECT / name) for name in
                                 ('template_library.py', 'oracle_graph.py', 'serialization.py', 'validation.py')},
                  templates=len(library['templates']), rows=[],
                  scope='Oracle chemical identity registry, not a 3684 index-to-chemistry resolver')
    for row in report['rows']:
        path = folder / row['id']
        original = json.loads((path / 'oracle.json').read_text())
        instance = json.loads((path / 'oracle_instance.json').read_text())
        if any('atoms' in f or 'bonds' in f for f in instance['fragments']):
            raise AssertionError('Chemistry leaked into identity-only instance')
        if resolve(instance, library) != original:
            raise AssertionError('Registry resolution changed docking chemistry input')
        context = torch.load(path / 'pocket_context.pt', map_location='cpu', weights_only=False)
        graph = rebuild_from_library(instance, library, **context)
        official = torch.load(path / 'official_graph.pt', map_location='cpu', weights_only=False)
        checks = compare_graphs(official, graph)
        if not checks['exact']:
            raise AssertionError(f'{row["id"]}: registry graph differs from accepted official graph')
        result['rows'].append(dict(id=row['id'], chemistry_input_exact=True, graph_exact=True,
                                   instance_sha256=digest(path / 'oracle_instance.json')))
        print(row['id'], 'REGISTRY EXACT', flush=True)
    result['accepted'] = True
    write_json(folder / 'library_validation.json', result)
    print('ACCEPTED', len(result['rows']), 'cases', result['templates'], 'Oracle templates')


if __name__ == '__main__':
    main()
