"""Compact, target-separated inputs for controlled predictor experiments."""
import hashlib
import json
from pathlib import Path
import shutil

import bootstrap
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset


LEVELS = dict(clean=0., low=.2, medium=.6, high=.9)


def stable(*values):
    return int(hashlib.sha256('|'.join(map(str, values)).encode()).hexdigest()[:8], 16)


def make_diffuser(output):
    from sigmadock.diff.se3_diffuser import SE3Diffuser
    output = Path(output); cache = output/'diffusion_cache'
    if not cache.exists(): shutil.copytree(bootstrap.CACHE, cache)
    cfg = json.loads((bootstrap.WORKSPACE/'core497_joint_experiments_20261019/training3684/config.json').read_text())
    return SE3Diffuser(**cfg['diffusion'], cache_path=cache)


def perturb(record, diffuser, t, seed, *, true_centers=False):
    """Exact cached PDBbind native-state VP/IGSO3 marginal, then canonical frames."""
    T, R = record['T0'].clone(), record['R0'].clone()
    if not t: return T.numpy(), R.numpy()
    torch.manual_seed(stable('predictor-noise', record['id'], t, seed))
    np.random.seed(stable('predictor-noise-numpy', record['id'], t, seed))
    n = len(T)
    noise = diffuser.forward_marginal(record['C0'], record['Q0'], torch.full((n,), float(t)))
    Q = noise['R_t']
    R = Q @ record['refR']
    if not true_centers:
        T = noise['T_t'] * 2.7 - torch.einsum('nij,nj->ni', Q, record['offset'])
    return T.float().numpy(), R.float().numpy()


class CompactDataset(Dataset):
    def __init__(self, ids): self.ids = ids
    def __len__(self): return len(self.ids)
    def __getitem__(self, index):
        pid = self.ids[index]
        try:
            record = torch.load(bootstrap.RECORDS/f'{pid}.pt', weights_only=False)
            out = {k: record[k].clone() for k in ('labels','T0','R0','C0','Q0','refR','offset','edges')}
            out.update(id=pid, split=record['audit']['split'])
            return out
        except Exception as exc: return dict(id=pid, error=repr(exc))


def list_collate(x): return x
def worker_init(_): torch.set_num_threads(1)


def compact_cache(output, workers=4):
    output=Path(output); output.mkdir(parents=True, exist_ok=True); path=output/'compact.pt'
    hashes={split: hashlib.sha256((bootstrap.RECORDS.parent/f'{split}_ids.json').read_bytes()).hexdigest()
            for split in ('train','val')}
    if path.exists():
        data=torch.load(path,weights_only=False)
        if data['split_sha256'] != hashes: raise ValueError('Cached dataset splits changed')
        return data
    data=dict(split_sha256=hashes,failures=[])
    for split in ('train','val'):
        ids=json.loads((bootstrap.RECORDS.parent/f'{split}_ids.json').read_text())
        loader=DataLoader(CompactDataset(ids), batch_size=32, num_workers=workers,
                          collate_fn=list_collate, worker_init_fn=worker_init)
        rows=[]
        for batch in loader:
            for r in batch:
                if 'error' in r: data['failures'].append(r)
                else:
                    assert r['split']==split
                    rows.append(r)
            if len(rows)%1024<32: print('COMPACT',split,len(rows),flush=True)
        data[split]=rows
    assert not {r['id'] for r in data['train']} & {r['id'] for r in data['val']}
    torch.save(data,path)
    return data


def identity_features(T, R, adjacency, t):
    """All-MASK input: only supplied frames, slot count and controlled adjacency.

    No template atom count, ports, atom features, target labels or target local xyz.
    Ordered nearest-neighbour geometry is invariant to global rigid transforms.
    """
    T,R,A=np.asarray(T),np.asarray(R),np.asarray(adjacency)
    n=len(T); delta=T[None,:,:]-T[:,None,:]
    distance=np.linalg.norm(delta,axis=-1)
    local_a=np.einsum('nji,nkj->nki',R,delta)/10
    # [i,j] expressed in the neighbour's frame.
    local_b=-np.einsum('kji,nkj->nki',R,delta)/10
    relative=np.einsum('nji,kjl->nkil',R,R).reshape(n,n,9)
    rbf=np.exp(-((distance[...,None]-np.linspace(0,15,12))/1.25)**2)
    bond=np.eye(3)[A.astype(int)]
    pair=np.concatenate([local_a,local_b,relative,rbf,bond,distance[...,None]/10],-1).astype(np.float32)
    assert pair.shape[-1]==31
    node=[]
    for i in range(n):
        blocks=[]
        for ix in (np.where(A[i]>0)[0],np.array([j for j in range(n) if j!=i],dtype=int)):
            ix=ix[np.argsort(distance[i,ix],kind='stable')][:6]
            block=np.zeros((6,32),np.float32)
            block[:len(ix),:31]=pair[i,ix];block[:len(ix),31]=1
            blocks.append(block.ravel())
        counts=[(A[i]==1).sum()/6,(A[i]==2).sum()/6,A[i].sum()/6,n/32,t]
        hist=(rbf[i].sum(0)-rbf[i,i])/max(1,n-1)
        node.append(np.concatenate([counts,*blocks,hist]))
    return torch.tensor(np.asarray(node),dtype=torch.float32)
