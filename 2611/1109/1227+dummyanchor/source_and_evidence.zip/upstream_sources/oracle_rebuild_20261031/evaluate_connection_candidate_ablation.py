#!/usr/bin/env python3
"""Keep the original weights/threshold, change only the candidate pool."""
import argparse
from pathlib import Path
import time

import bootstrap
import torch

from connection_predictor import PortConnectionPredictor
from evaluate_robust_connections import hydrate_oov,metadata,metric_row,aggregate
from robust_connection_data import build_cache,pack_records,make_official_diffuser,noisy_frames,candidate_features
from robust_connection_model import predict_probabilities
from run_validation import write_json
from train_robust_connections import GRID
from validation import digest
from vocab_chemistry import VocabLibrary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--legacy',type=Path,default=bootstrap.PROJECT/'results/stage3_training/best.pt')
    p.add_argument('--device',default='cuda:1');p.add_argument('--seeds',default='201,202,203')
    a=p.parse_args();torch.set_num_threads(2);a.output.mkdir(parents=True,exist_ok=True)
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    rows=build_cache(a.cache)['val']['rows'];hydrate_oov(rows);packed=pack_records(rows,device)
    lib=VocabLibrary();diff=make_official_diffuser(a.output,device)
    model=PortConnectionPredictor().to(device).eval()
    model.load_state_dict(torch.load(a.legacy,map_location='cpu',weights_only=False)['model'],strict=True)
    report=dict(legacy_sha256=digest(a.legacy),seeds=list(map(int,a.seeds.split(','))),rows=[],summary={},
        policy='Frozen original head and threshold .65; same adaptive candidate pool as full-noise arm. No fitting or threshold tuning.')
    began=time.time()
    for seed in report['seeds']:
        for t in GRID:
            tt=torch.full((len(rows),),t,device=device);T,R=noisy_frames(packed,diff,tt,seed=seed)
            features=candidate_features(packed['chem'],T,R,tt,adaptive=True,half=False)
            prob,sp=predict_probabilities(model,packed,features,legacy=True);meta,molecule=metadata(packed,features)
            for m,row in enumerate(rows):
                ix=molecule==m
                report['rows'].append(dict(t=t,seed=seed,**metric_row(lib,row,meta[ix],prob[ix].numpy(),sp[ix].numpy(),.65)))
            print('ABLATION',seed,t,'elapsed',round(time.time()-began),flush=True)
    report['summary']={str(t):aggregate([r for r in report['rows'] if r['t']==t]) for t in GRID}
    report['elapsed_seconds']=time.time()-began;write_json(a.output/'report.json',report)


if __name__=='__main__':main()
