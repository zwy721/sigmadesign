#!/usr/bin/env python3
"""Refresh metadata serialization without changing any accepted graph tensor."""
import argparse
import json
from pathlib import Path

import bootstrap
import torch
from oracle_graph import oracle_from_official, rebuild
from run_validation import official_graph, write_json
from serialization import save_graph
from validation import GRAPH_FIELDS, compare_graphs, compare_values, digest


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--report', type=Path, required=True)
    a = p.parse_args()
    a.report = a.report.resolve()
    report = json.loads(a.report.read_text())
    if not report['accepted']:
        p.error('Accepted report required')
    torch.set_num_threads(2)
    result = dict(parent_report_sha256=digest(a.report), rows=[], accepted=False)
    for row in report['rows']:
        folder = a.report.parent / row['id']
        context = torch.load(folder / 'pocket_context.pt', weights_only=False)
        baseline, reference = official_graph(context['ligand_path'], context['pdb_path'], report['manifest']['graph_seed'])
        spec = json.loads((folder / 'oracle.json').read_text())
        if oracle_from_official(baseline, reference) != spec:
            raise AssertionError('Fresh official preprocessing changed the accepted Oracle input')
        restored = rebuild(spec, **context)
        for name, graph in [('official', baseline), ('reconstructed', restored)]:
            path = folder / f'{name}_graph.pt'
            saved = torch.load(path, weights_only=False)
            checks = [c for field in GRAPH_FIELDS for c in compare_values(graph[field], saved[field], field)]
            if not all(c['exact'] for c in checks):
                raise AssertionError(f'{row["id"]}: refresh would change an accepted graph tensor')
            save_graph(graph, path)
            loaded = torch.load(path, weights_only=False)
            if not compare_graphs(graph, loaded)['exact']:
                raise AssertionError('Graph serialization lost official fragment metadata')
        result['rows'].append(dict(id=row['id'], accepted_tensors_unchanged=True, metadata_roundtrip_exact=True))
        print(row['id'], 'SERIALIZATION EXACT', flush=True)
    result['accepted'] = True
    write_json(a.report.parent / 'serialization_validation.json', result)


if __name__ == '__main__':
    main()
