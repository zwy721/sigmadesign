#!/usr/bin/env python3
"""Full-noise time-conditioned connection training; all geometry is noisy input."""
import argparse
import json
from pathlib import Path
import time

import bootstrap
import numpy as np
import torch
from torch.nn import functional as F

from connection_predictor import PortConnectionPredictor
from robust_connection_data import build_cache,pack_records,noisy_frames,candidate_features,make_official_diffuser
from robust_connection_model import TimeConnectionPredictor,predict_probabilities
from run_validation import write_json
from validation import digest

GRID=[0.,.02,.05,.1,.2,.4,.6,.9]
THRESHOLDS=[.1,.2,.3,.4,.5,.65,.8]


def raw_metrics(prob,y,true_bonds,threshold):
    value,order=prob[:,1:].max(-1);order+=1
    active=(value>=threshold)&(value>prob[:,0])
    tp=int((active&(order==y)&(y>0)).sum());pred=int(active.sum())
    return dict(precision=tp/max(1,pred),recall=tp/max(1,true_bonds),f1=2*tp/max(1,pred+true_bonds),
                tp=tp,predicted=pred,true=true_bonds,threshold=threshold)


def validation_views(packed,diffuser,seed):
    device=packed['chem']['labels'].device;views={}
    for t in GRID:
        tt=torch.full((len(packed['rows']),),t,device=device)
        T,R=noisy_frames(packed,diffuser,tt,seed=seed)
        views[str(t)]=candidate_features(packed['chem'],T,R,tt,adaptive=True,half=False)
    return views


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--cache',type=Path,required=True)
    p.add_argument('--device',default='cuda:0');p.add_argument('--epochs',type=int,default=30)
    p.add_argument('--batch-rows',type=int,default=131072);p.add_argument('--workers',type=int,default=10)
    p.add_argument('--resume',type=Path);p.add_argument('--eval-every',type=int,default=2)
    p.add_argument('--legacy',type=Path,default=bootstrap.PROJECT/'results/stage3_training/best.pt')
    a=p.parse_args();torch.set_num_threads(2);a.output.mkdir(parents=True,exist_ok=True)
    if (a.output/'latest.pt').exists() and not a.resume:p.error('Existing run requires --resume')
    source_hashes={name:digest(bootstrap.PROJECT/name) for name in
        ('robust_connection_data.py','robust_connection_model.py','train_robust_connections.py')}
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    datasets=build_cache(a.cache,a.workers)
    train=pack_records(datasets['train']['rows'],device);val=pack_records(datasets['val']['rows'],device)
    diffuser=make_official_diffuser(a.output,device)
    saved=torch.load(a.legacy,map_location='cpu',weights_only=False)
    torch.manual_seed(20261101);model=TimeConnectionPredictor(saved['model']).to(device)
    opt=torch.optim.AdamW([v for v in model.parameters() if v.requires_grad],lr=.001,weight_decay=.0001)
    start=0;history=[];best=-1.;best_epoch=None
    if a.resume:
        old=torch.load(a.resume,map_location=device,weights_only=False)
        if old['contract']!=datasets['train']['contract']:raise ValueError('Resume data/library contract changed')
        if old['source_sha256']!=source_hashes:raise ValueError('Resume training source differs from the checkpoint')
        model.load_state_dict(old['model'],strict=True);opt.load_state_dict(old['optimizer'])
        start=old['epoch'];history=old['history'];best=old['best_score'];best_epoch=old['best_epoch']
    views=validation_views(val,diffuser,100)
    baseline=PortConnectionPredictor().to(device).eval();baseline.load_state_dict(saved['model'],strict=True)
    original={}
    for t in GRID:
        tt=torch.full((len(val['rows']),),t,device=device);T,R=noisy_frames(val,diffuser,tt,seed=100)
        f=candidate_features(val['chem'],T,R,tt,topk=8,cutoff=16,half=False)
        prob,_=predict_probabilities(baseline,val,f,legacy=True)
        original[str(t)]=raw_metrics(prob,val['y'][f['indices']].long().cpu(),sum(r['target']['true_bonds'] for r in val['rows']),.65)
    write_json(a.output/'baseline_selection_seed100.json',original)
    write_json(a.output/'protocol.json',dict(contract=datasets['train']['contract'],train_molecules=len(train['rows']),
        val_molecules=len(val['rows']),legacy_sha256=digest(a.legacy),epochs=a.epochs,device=str(device),
        candidate_policy='t<=.05: top8 / 16A, otherwise top64 / 32A; targets never inserted',
        time_sampling='25% clean, 25% U(0,.05), 50% U(.02,.9); new poses every epoch',
        inputs='Supplied identities and N, template chemistry/ports, noisy Tt/Rt and t only; no true edges/anchors/clean pose',
        selection_seed=100,test_seeds=[201,202,203],low_noise_protection='Low-t distillation and validation guard; staged arm retains original low-noise expert',
        precision='BF16 MLP, FP32 geometry',backbone_trained=False,source_sha256=source_hashes,
        optimizer=dict(name='AdamW',lr=.001,weight_decay=.0001,gradient_clip=5.),
        loss='sqrt-frequency weighted CE, equal molecule weighting, low-t KL weight .5, double-bond stereo CE weight .2',
        batch_rows=a.batch_rows))
    began=time.time()
    for epoch in range(start,a.epochs):
        epoch_start=time.time();model.train();torch.manual_seed(830000+epoch)
        u=torch.rand(len(train['rows']),device=device);v=torch.rand_like(u)
        times=torch.where(u<.25,torch.zeros_like(u),torch.where(u<.5,.0001+v*.0499,.02+v*.88))
        T,R=noisy_frames(train,diffuser,times,seed=910000+epoch)
        with torch.no_grad():features=candidate_features(train['chem'],T,R,times,adaptive=True)
        index=features['indices'];y=train['y'][index].long();stereo=train['stereo'][index].long()
        counts=torch.bincount(y,minlength=3).float();weights=(counts.max()/counts.clamp_min(1)).sqrt().clamp(max=30)
        order=torch.randperm(len(index),device=device)
        mol=train['chem']['pair_mol'][index]
        molecular_weight=torch.bincount(mol,minlength=len(train['rows'])).float().clamp_min(1).reciprocal()[mol]
        molecular_weight=molecular_weight/molecular_weight.mean()
        context=model.context(train['chem']).detach();total=loss_sum=0.
        for offset in range(0,len(order),a.batch_rows):
            selected=order[offset:offset+a.batch_rows];opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=='cuda'):
                logits,sl,base=model(train['chem'],features,context,selected,return_base=True)
                row_loss=F.cross_entropy(logits,y[selected],weight=weights,reduction='none')
                w=molecular_weight[selected]
                loss=(row_loss*w).sum()/(weights[y[selected]]*w).sum().clamp_min(1e-8)
                low=features['t'][selected]<=.05
                if low.any():
                    kl=F.kl_div(logits[low].float().log_softmax(-1),base[low].detach().float().softmax(-1),reduction='none').sum(-1)
                    loss=loss+.5*(kl*w[low]).sum()/w[low].sum().clamp_min(1e-8)
                double=y[selected]==2
                if double.any():loss=loss+.2*F.cross_entropy(sl[double],stereo[selected][double])
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
            loss_sum+=float(loss.detach())*len(selected);total+=len(selected)
        row=dict(epoch=epoch+1,train_loss=loss_sum/max(1,total),candidate_rows=len(index),
                 seconds=time.time()-epoch_start,elapsed_seconds=time.time()-began)
        improved=False
        if (epoch+1)%a.eval_every==0 or epoch==a.epochs-1:
            model.eval();metrics={};thresholds={}
            for t in GRID:
                f=views[str(t)];prob,_=predict_probabilities(model,val,f)
                target=val['y'][f['indices']].long().cpu();true=sum(r['target']['true_bonds'] for r in val['rows'])
                candidates=[raw_metrics(prob,target,true,z) for z in THRESHOLDS]
                m=max(candidates,key=lambda d:d['f1']);metrics[str(t)]=m;thresholds[str(t)]=m['threshold']
            guard=all(metrics[str(t)]['f1']>=original[str(t)]['f1']-.02 for t in (0.,.02,.05))
            score=float(np.mean([metrics[str(t)]['f1'] for t in (.05,.1,.2,.4,.6,.9)]))
            row.update(val=metrics,selection_score=score,low_noise_guard=guard,thresholds=thresholds)
            improved=guard and score>best
            if improved:best=score;best_epoch=epoch+1
        history.append(row)
        payload=dict(model=model.state_dict(),optimizer=opt.state_dict(),epoch=epoch+1,history=history,best_score=best,
            best_epoch=best_epoch,contract=datasets['train']['contract'],architecture='TimeConnectionPredictor-v1',
            legacy_state=saved['model'],source_sha256=source_hashes)
        torch.save(payload,a.output/'latest.pt')
        if improved:torch.save(payload,a.output/'best.pt')
        write_json(a.output/'history.json',history)
        write_json(a.output/'status.json',dict(status='running',epoch=epoch+1,target_epochs=a.epochs,best_epoch=best_epoch,
                   best_score=best,updated_row=row))
        print(json.dumps(row),flush=True)
    if best_epoch is None:raise RuntimeError('No checkpoint passed the low-noise preservation guard')
    write_json(a.output/'status.json',dict(status='complete',epoch=a.epochs,best_epoch=best_epoch,best_score=best,
               elapsed_seconds=time.time()-began,backbone_trained=False))


if __name__=='__main__':main()
