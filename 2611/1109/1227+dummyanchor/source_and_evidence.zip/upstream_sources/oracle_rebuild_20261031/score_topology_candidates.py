#!/usr/bin/env python3
"""Standalone reranker inference on an explicitly feature-only request."""
import argparse
import json
import math
from pathlib import Path

from topology_reranker import SCHEMA,load_reranker,score_candidates


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();request=json.loads(a.input.read_text())
    if set(request)!={'schema','candidates'} or request['schema']!=SCHEMA:raise ValueError('Expected schema and feature-only candidates')
    if any(set(r)!={'key','features'} for r in request['candidates']):raise ValueError('Candidate request may contain only key/features')
    if any(not math.isfinite(float(v)) for r in request['candidates'] for v in r['features'].values()):raise ValueError('Nonfinite candidate feature')
    model,saved=load_reranker(a.checkpoint)
    scores=score_candidates(model,saved,[r['features'] for r in request['candidates']]) if request['candidates'] else []
    ranked=sorted([dict(key=r['key'],score=s) for r,s in zip(request['candidates'],scores)],key=lambda r:-r['score'])
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(dict(schema=SCHEMA,ranked=ranked),indent=2)+'\n')


if __name__=='__main__':main()
