"""Time-conditioned connection residual; original low-noise expert is frozen."""
import torch
from torch import nn
from torch.nn import functional as F

from connection_predictor import PortConnectionPredictor


class TimeConnectionPredictor(nn.Module):
    def __init__(self,legacy_state):
        super().__init__()
        self.legacy=PortConnectionPredictor();self.legacy.load_state_dict(legacy_state,strict=True)
        self.legacy.requires_grad_(False)
        self.identity=nn.Embedding(3685,32)
        with torch.no_grad():self.identity.weight.copy_(self.legacy.identity.weight)
        self.atom=nn.Embedding(128,8)
        self.network=nn.Sequential(nn.LayerNorm(168),nn.Linear(168,256),nn.SiLU(),nn.Linear(256,128),nn.SiLU())
        self.bond=nn.Linear(128,3);self.stereo=nn.Linear(128,3)
        for layer in (self.bond,self.stereo):nn.init.zeros_(layer.weight);nn.init.zeros_(layer.bias)

    @staticmethod
    def gate(t):
        # Full-noise arm learns at every t; staged decoding retains the frozen
        # original expert at low noise as a distinct experimental strategy.
        return torch.ones_like(t)

    def context(self,chem):
        # Frozen chemistry bag, independent of graph topology and coordinates.
        label=chem['labels'].clone();label[label<0]=3684
        embedding=self.legacy.identity(label)
        result=embedding.new_zeros((len(chem['n']),32)).index_add(0,chem['slot_mol'],embedding)
        return result/chem['n'][:,None].clamp_min(1)

    def forward(self,chem,features,context,selection,return_base=False):
        ix=features['indices'][selection];x=features['x'][selection].float();t=features['t'][selection].float()
        a,b=chem['pairs'][ix].T;s=chem['slot'];labels=chem['labels']
        left=labels[s[a]].clone();right=labels[s[b]].clone();left[left<0]=3684;right[right<0]=3684
        types=torch.stack([left,right],-1)
        base,bstereo=self.legacy(types,x)
        l,r=self.identity(left),self.identity(right)
        pa,pb=self.atom(chem['atom'][a].clamp_max(127)),self.atom(chem['atom'][b].clamp_max(127))
        xa,xb=chem['xyz'][a]/5,chem['xyz'][b]/5
        time=t[:,None]*t.new_tensor([1.,2.,4.,8.,16.,32.])[None]
        temb=torch.cat([time.sin(),time.cos(),t[:,None],t[:,None].square()],-1)
        mol=chem['pair_mol'][ix]
        z=torch.cat([l+r,(l-r).abs(),x,pa+pb,(pa-pb).abs(),xa+xb,(xa-xb).abs(),
                     context[mol],chem['n'][mol,None]/32,temb],-1)
        h=self.network(z)
        gate=self.gate(t)[:,None]
        logits,stereo=base+gate*self.bond(h),bstereo+gate*self.stereo(h)
        return (logits,stereo,base) if return_base else (logits,stereo)


@torch.inference_mode()
def predict_probabilities(model,packed,features,batch=131072,legacy=False):
    if not len(features['indices']):return torch.zeros(0,3),torch.zeros(0,3)
    chem=packed['chem'];context=model.context(chem) if not legacy else None
    probs=[];stereos=[]
    for start in range(0,len(features['indices']),batch):
        sl=slice(start,start+batch)
        if legacy:
            a,b=chem['pairs'][features['indices'][sl]].T;s=chem['slot'];labels=chem['labels']
            types=torch.stack([labels[s[a]],labels[s[b]]],-1).clone();types[types<0]=3684
            logits,stereo=model(types,features['x'][sl].float())
        else:logits,stereo=model(chem,features,context,sl)
        probs.append(logits.float().softmax(-1).cpu());stereos.append(stereo.float().softmax(-1).cpu())
    return torch.cat(probs),torch.cat(stereos)


def legal_decode_fast(library,row,meta,probability,stereo,threshold):
    """Same greedy port/capacity policy as v1; no target access or tree forcing."""
    from vocab_chemistry import ChemistryRejected,assemble_slots
    import numpy as np
    c=row['chem'];labels=c['labels'].tolist()
    # Static port capacities/allowed orders come from supplied templates only.
    capacity={(int(s),int(a)):int(round(float(n[2])*4)) for s,a,n in zip(c['slot'],c['atom'],c['numeric'])}
    allowed={(int(s),int(a)):set(i+1 for i,v in enumerate(order) if v) for s,a,order in zip(c['slot'],c['atom'],c['allowed'])}
    p=np.asarray(probability);sp=np.asarray(stereo)
    if len(p):
        order=p[:,1:].argmax(-1)+1;confidence=p[np.arange(len(p)),order]
        active=(confidence>=threshold)&(confidence>p[:,0])
        entries=[]
        for k in np.where(active)[0]:
            i,j,a,b=map(int,meta[k]);o=int(order[k])
            entries.append(dict(i=i,j=j,a=a,b=b,order=o,stereo=int(sp[k].argmax()) if o==2 else 0,
                                confidence=float(confidence[k]),log_odds=float(np.log(max(confidence[k],1e-8))-np.log(max(p[k,0],1e-8)))))
    else:entries=[]
    used={};pairs=set();connections=[]
    for edge in sorted(entries,key=lambda e:(-e['log_odds'],e['i'],e['j'],e['a'],e['b'])):
        i,j,a,b,o=(edge[k] for k in ('i','j','a','b','order'))
        if (i,j) in pairs:continue
        if any(o not in allowed.get(key,set()) or used.get(key,0)+o>capacity.get(key,0) for key in ((i,a),(j,b))):continue
        connections.append(edge);pairs.add((i,j))
        for key in ((i,a),(j,b)):used[key]=used.get(key,0)+o
    # The explicit OOV chemistry is stored as supplied input by the caller.
    try:
        assembled=assemble_slots(library,labels,connections,oov=row.get('oov'))
        return dict(status='complete_legal',connections=connections),assembled
    except ChemistryRejected as exc:
        return dict(status='candidates_only',connections=connections,reason=str(exc)),None
