#!/usr/bin/env python3
"""Build a SigmaDock graph from identity IDs, true connections and a registry."""
import argparse
import json
from pathlib import Path

import bootstrap
import torch
from template_library import rebuild_from_library
from serialization import save_graph


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--instance', type=Path, required=True)
    p.add_argument('--library', type=Path, required=True)
    p.add_argument('--context', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists():
        p.error('Output exists; choose a new filename')
    context = torch.load(a.context, map_location='cpu', weights_only=False)
    if set(context) != {'pocket', 'pocket_com', 'pdb_path', 'ligand_path'}:
        p.error('Only receptor context is allowed')
    graph = rebuild_from_library(json.loads(a.instance.read_text()), json.loads(a.library.read_text()), **context)
    bootstrap.verify_imports()
    a.output.parent.mkdir(parents=True, exist_ok=True)
    save_graph(graph, a.output)
    print(f'Saved {graph.num_nodes} nodes, {graph.edge_index.shape[1]} edges to {a.output}')


if __name__ == '__main__':
    main()
