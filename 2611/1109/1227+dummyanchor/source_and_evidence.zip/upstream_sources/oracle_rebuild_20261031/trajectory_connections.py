"""Target-free fixed-identity topology inference and frozen native trajectories.

Truth is accepted ONLY by explicitly named diagnostic modes. Observers receive
states for metrics and return no updates. Ordinary closed-loop/search calls
reject oracle graph arguments.
"""
import heapq
import json
from pathlib import Path
import time

import bootstrap
import numpy as np
import torch

from evaluate_robust_connections import metadata,edge_set
from joint_sampler import NativeState,chemical_graph,topology_key
from oracle_graph import assemble
from robust_connection_data import compile_chemistry,candidate_features
from robust_connection_model import TimeConnectionPredictor,predict_probabilities,legal_decode_fast
from run_validation import seed_all
from validation import SamplingAudit
from vocab_chemistry import ChemistryRejected,assemble_slots


def edge_key(c):return (c['i'],c['j'],c['a'],c['b'],c['order'])


def is_fragment_tree(n,connections):
    """Non-ring cut bonds partition one molecule into a fragment tree."""
    if len(connections)!=n-1:return False
    parent=list(range(n))
    def root(i):
        while parent[i]!=i:i=parent[i]
        return i
    for c in connections:
        i,j=c['i'],c['j']
        if root(i)==root(j):return False
        parent[root(i)]=root(j)
    return True


class ConnectionRuntime:
    def __init__(self,lib,checkpoint,labels,oov,device,*,policy='adaptive',head='full'):
        self.lib,self.labels,self.oov,self.device=lib,list(labels),oov,torch.device(device)
        self.policy,self.head=policy,head
        self.cpu=compile_chemistry(lib,labels,oov);n=len(labels)
        self.chem={k:v.to(device) for k,v in self.cpu.items()};c=self.chem;c['pairs']=c['pairs'].long()
        a,b=c['pairs'].T
        c.update(n=torch.tensor([n],device=device,dtype=torch.float32),group=c['slot'][a]*n+c['slot'][b],
            slot_mol=torch.zeros(n,device=device,dtype=torch.long),
            port_mol=torch.zeros(len(c['slot']),device=device,dtype=torch.long),
            pair_mol=torch.zeros(len(a),device=device,dtype=torch.long))
        self.packed=dict(chem=c)
        self.model=checkpoint['runtime_model']
        self.thresholds=checkpoint['runtime_thresholds']
        self.capacity={(int(s),int(a)):int(round(float(x[2])*4)) for s,a,x in zip(self.cpu['slot'],self.cpu['atom'],self.cpu['numeric'])}
        self.allowed={(int(s),int(a)):set(i+1 for i,v in enumerate(vv) if v) for s,a,vv in zip(self.cpu['slot'],self.cpu['atom'],self.cpu['allowed'])}

    def threshold(self,t):
        grid=sorted(map(float,self.thresholds))
        return float(np.interp(t,grid,[self.thresholds[str(x)] for x in grid]))

    def predict(self,T,R,t,*,policy=None,head=None):
        policy=policy or self.policy;head=head or self.head;c=self.chem;device=self.device
        T=torch.as_tensor(T,device=device,dtype=torch.float32);R=torch.as_tensor(R,device=device,dtype=torch.float32)
        f=candidate_features(c,T,R,torch.tensor([t],device=device),topk=64,cutoff=32.,half=False)
        meta,_=metadata(self.packed,f)
        legacy=head=='legacy_staged' and t<=.05
        p,sp=predict_probabilities(self.model.legacy if legacy else self.model,self.packed,f,legacy=legacy)
        keep=np.ones(len(meta),dtype=bool)
        if policy=='adaptive' and t<=.05:
            rank={}
            for k,(i,j,a,b) in enumerate(meta):
                pair=(int(i),int(j));r=rank.get(pair,0);rank[pair]=r+1
                keep[k]=r<8 and float((T[i]-T[j]).norm())<=16
        elif policy not in ('wide','adaptive'):raise ValueError('Unknown candidate policy')
        meta=meta[keep];p=p[keep].numpy();sp=sp[keep].numpy()
        ix=f['indices'][torch.as_tensor(keep,device=device)]
        features=dict(x=f['x'][torch.as_tensor(keep,device=device)],indices=ix,
            t=f['t'][torch.as_tensor(keep,device=device)])
        threshold=.65 if legacy else self.threshold(t)
        decision,assembled=legal_decode_fast(self.lib,dict(chem=self.cpu,oov=self.oov),meta,p,sp,threshold)
        raw_complete=assembled is not None
        if assembled is not None and not is_fragment_tree(len(self.labels),decision['connections']):
            decision=dict(decision,status='outside_fragment_tree_contract');assembled=None
        pool=[]
        for k,(i,j,a,b) in enumerate(meta):
            i,j,a,b=map(int,(i,j,a,b))
            for order in self.allowed.get((i,a),set())&self.allowed.get((j,b),set()):
                confidence=float(p[k,order])
                pool.append(dict(i=i,j=j,a=a,b=b,order=order,stereo=int(sp[k].argmax()) if order==2 else 0,
                    confidence=confidence,log_odds=float(np.log(max(confidence,1e-8))-np.log(max(float(p[k,0]),1e-8)))))
        return dict(meta=meta,p=p,sp=sp,features=features,pool=pool,decision=decision,assembled=assembled,
                    head='legacy' if legacy else 'full',policy=policy,threshold=threshold,
                    raw_complete_chemical_graph=raw_complete)


def load_connection(checkpoint,device):
    saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
    model=TimeConnectionPredictor(saved['legacy_state']).to(device).eval()
    model.load_state_dict(saved['model'],strict=True);model.requires_grad_(False)
    if 'thresholds' in saved:thresholds=saved['thresholds']
    else:thresholds=next(r['thresholds'] for r in saved['history'] if r['epoch']==saved['epoch'])
    return dict(runtime_model=model,runtime_thresholds=thresholds,saved=saved)


def legal_topologies(runtime,prediction,k=8,max_search=192):
    """Deterministic constrained-tree deviations plus the raw legal proposal.

    No true edge count, topology, port or coordinate is available here. Trees
    provide a connected bootstrap prior; a valid non-tree raw proposal is also
    retained. This bounded search does not claim exact k-best enumeration.
    """
    n=len(runtime.labels)
    if n==1:return [dict(connections=[],score=0.,kind='single_fragment')]
    edges=sorted(prediction['pool'],key=lambda c:(-c['log_odds'],edge_key(c)))
    edge_by_key={edge_key(c):c for c in edges}
    result=[];seen=set();counter=0;heap=[];visited=set()
    def append(cs,kind):
        key=tuple(sorted(edge_key(c) for c in cs))
        if key in seen:return
        try:assemble_slots(runtime.lib,runtime.labels,cs,oov=runtime.oov)
        except ChemistryRejected:return
        seen.add(key);result.append(dict(connections=cs,score=float(sum(c['log_odds'] for c in cs)),kind=kind))
    if prediction['assembled'] is not None and is_fragment_tree(n,prediction['decision']['connections']):
        append(prediction['decision']['connections'],'complete_raw_prediction')
    def tree(forbidden):
        parent=list(range(n));used={};selected=[]
        def root(a):
            while parent[a]!=a:a=parent[a]
            return a
        for c in edges:
            key=edge_key(c)
            if key in forbidden:continue
            i,j,a,b,o=key
            if root(i)==root(j):continue
            if any(used.get(v,0)+o>runtime.capacity.get(v,0) for v in ((i,a),(j,b))):continue
            selected.append(c);parent[root(i)]=root(j)
            for v in ((i,a),(j,b)):used[v]=used.get(v,0)+o
            if len(selected)==n-1:break
        if len(selected)!=n-1:return None
        return selected
    def enqueue(forbidden):
        nonlocal counter
        if forbidden in visited:return
        visited.add(forbidden);cs=tree(forbidden)
        if cs is not None:
            heapq.heappush(heap,(-sum(c['log_odds'] for c in cs),counter,forbidden,cs));counter+=1
    enqueue(frozenset());attempts=0
    while heap and len(result)<k and attempts<max_search:
        _,_,forbidden,cs=heapq.heappop(heap);attempts+=1
        append(cs,'uncommitted_tree_hypothesis')
        for c in cs:enqueue(forbidden|{edge_key(c)})
    # K=1 is the same deterministic first hypothesis used by the closed loop.
    return result[:k]


class GraphFactory:
    def __init__(self,lib,labels,oov,context):
        self.lib,self.labels,self.oov,self.context=lib,list(labels),oov,context
        self.cache={}
    def get(self,connections):
        key=topology_key(self.labels,connections)
        if key not in self.cache:
            print('GRAPH_BUILD',len(self.labels),'slots',len(connections),'edges',flush=True)
            self.cache[key]=chemical_graph(self.lib,self.labels,connections,self.context,self.oov,seed=0)
        return self.cache[key]


def pose_transfer(den,state,bundle,device):
    graph,groups,spec=bundle;physical=state.physical()
    desired=[physical[state.pn+np.asarray(g)] for g in state.groups]
    replacement=NativeState(den,graph,groups,device,desired=desired)
    if max(replacement.transfer_errors,default=0)>.5:
        raise ChemistryRejected('Physical-state shape transfer exceeds 0.5 A')
    return replacement


def run_trajectory(den,runtime,factory,*,seed=0,steps=25,start=.9,mode='closed',
                   oracle_bundle=None,oracle_edges=None,initial_edges=None,observer=None,reset_steps=(8,16,20)):
    diagnostic=mode in ('oracle','shadow','diagnostic_reset')
    if mode not in ('oracle','shadow','closed','diagnostic_reset'):raise ValueError('Unknown trajectory mode')
    if not diagnostic and (oracle_bundle is not None or oracle_edges is not None):
        raise ValueError('Oracle data forbidden in ordinary generation')
    if diagnostic and (oracle_bundle is None or oracle_edges is None):raise ValueError('Explicit diagnostic oracle required')
    seed_all(seed);device=runtime.device;n=len(runtime.labels);started=time.time()
    if mode in ('oracle','shadow'):
        bundle=oracle_bundle;connections=list(oracle_edges);bootstrap_kind='diagnostic_true_topology'
    elif initial_edges is not None:
        connections=list(initial_edges);bundle=factory.get(connections);bootstrap_kind='predicted_search_hypothesis'
    else:
        C,Q=den.diffuser.sample_ref(n,device)
        T=C.cpu().numpy()*2.7+np.asarray(factory.context['pocket_com']).reshape(3)
        pred=runtime.predict(T,Q.cpu().numpy(),start)
        hypotheses=legal_topologies(runtime,pred,k=1)
        if not hypotheses:raise ChemistryRejected('No complete legal bootstrap hypothesis')
        connections=hypotheses[0]['connections'];bundle=factory.get(connections);bootstrap_kind=hypotheses[0]['kind']
    graph,groups,spec=bundle;events=[];frames=[];positions=[];metrics=[];revisions=0
    seed_all(seed)
    with torch.inference_mode(),SamplingAudit(den) as audit:
        state=NativeState(den,graph,groups,device)
        grid=(start**(1/3)+torch.arange(steps,device=device)/(steps-1)*(.005**(1/3)-start**(1/3)))**3
        for step,tensor_t in enumerate(grid):
            t=float(tensor_t);T,R,fit=state.slot_frames(runtime.lib,runtime.labels,runtime.oov)
            pred=runtime.predict(T,R,t)
            xyz=state.physical()[state.pn:state.pn+sum(map(len,state.groups))]
            frame=dict(step=step,t=t,T=T.astype(np.float32),R=R.astype(np.float32),fit=np.asarray(fit,dtype=np.float32),
                current_connections=connections)
            frames.append(frame);positions.append(xyz.copy())
            if observer is not None:metrics.append(observer(frame,xyz,pred,spec))
            if step==steps-1:break
            event=dict(step=step,t=t,accepted=False,kind='hold',connections_before=connections)
            next_bundle=None;next_connections=None
            if mode=='diagnostic_reset' and step in reset_steps:
                next_bundle,next_connections=oracle_bundle,list(oracle_edges)
                event['kind']='DIAGNOSTIC_TRUE_TOPOLOGY_RESET'
            elif mode in ('closed','diagnostic_reset') and step>0 and t<=.05:
                if pred['assembled'] is not None:
                    next_connections=pred['decision']['connections'];event['kind']='predicted_low_noise_update'
                    if topology_key(runtime.labels,next_connections)!=topology_key(runtime.labels,connections):
                        try:next_bundle=factory.get(next_connections)
                        except (ChemistryRejected,ValueError,RuntimeError) as exc:
                            if isinstance(exc,torch.OutOfMemoryError):raise
                            event['error']=repr(exc)
                else:event['kind']='incomplete_proposal_keep_last_legal_graph'
            if next_bundle is not None and topology_key(runtime.labels,next_connections)!=topology_key(runtime.labels,connections):
                try:
                    replacement=pose_transfer(den,state,next_bundle,device)
                    event['transfer_fit_A']=replacement.transfer_errors
                    state=replacement;graph,groups,spec=next_bundle;connections=next_connections
                    audit.static_hash=None;revisions+=1;event.update(accepted=True,revision=revisions)
                except (ChemistryRejected,ValueError,RuntimeError) as exc:
                    if isinstance(exc,torch.OutOfMemoryError):raise
                    event['error']=repr(exc)
            event['connections_after']=connections;events.append(event)
            state.step(tensor_t,grid[step]-grid[step+1])
        state.batch=den._update_batch(state.batch,state.pos0,state.pos)
    return dict(mode=mode,seed=seed,frames=frames,positions=np.asarray(positions),metrics=metrics,events=events,
        connections=connections,spec=spec,revisions=revisions,audit=audit.report(),bootstrap_kind=bootstrap_kind,
        seconds=time.time()-started,truth_used_for_generation=diagnostic)


def connection_metrics(prediction,truth):
    actual=edge_set(truth);proposed=edge_set(prediction['decision']['connections'])
    meta=prediction['meta'];p=prediction['p'];pool=prediction['pool']
    allkeys={edge_key(c) for c in pool};group={}
    for c in pool:group.setdefault((c['i'],c['j']),[]).append(c)
    coverage={}
    for k in (1,4,8,16,64):
        keys={edge_key(c) for values in group.values() for c in sorted(values,key=lambda c:-c['confidence'])[:k]}
        coverage[str(k)]=len(actual&keys)/max(1,len(actual))
    tp=len(actual&proposed)
    return dict(tp=tp,predicted=len(proposed),true_bonds=len(actual),f1=2*tp/max(1,len(actual)+len(proposed)),
        proposal_exact=actual==proposed,proposal_legal=prediction['assembled'] is not None,
        candidate_coverage=len(actual&allkeys)/max(1,len(actual)),scored_port_order_topk_coverage=coverage,
        head=prediction['head'],threshold=prediction['threshold'])
