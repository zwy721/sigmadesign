"""Target-free tree search that explores distinct inter-fragment skeletons."""
import numpy as np

from evaluate_topology_search import diverse_hypotheses
from trajectory_connections import legal_topologies,edge_key,is_fragment_tree
from vocab_chemistry import assemble_slots,ChemistryRejected,canonical


def complete_key(edges):
    return tuple(sorted((*edge_key(e),int(e.get('stereo',0))) for e in edges))


def skeleton_key(labels,edges):
    """Canonical colored unrooted-tree signature, independent of slot names."""
    adjacency=[[] for _ in labels]
    for e in edges:
        i,j,o=e['i'],e['j'],e['order'];adjacency[i].append((j,o));adjacency[j].append((i,o))
    def rooted(i,parent):
        children=sorted(f'{o}:{rooted(j,i)}' for j,o in adjacency[i] if j!=parent)
        return f'{labels[i]}('+','.join(children)+')'
    return min(rooted(i,-1) for i in range(len(labels)))


def topology_search(runtime,prediction,*,seed,k=8,diversity_weight=1.5):
    all_candidates=legal_topologies(runtime,prediction,k=64,max_search=256)
    ordinary=[];chem_seen=set()
    for c in all_candidates:
        mol,_,_=assemble_slots(runtime.lib,runtime.labels,c['connections'],oov=runtime.oov)
        key=canonical(mol,False)
        if key in chem_seen:continue
        chem_seen.add(key);ordinary.append(dict(c,constitution=key))
        if len(ordinary)==k:break
    considered=len(all_candidates)
    if not ordinary:return dict(ordinary=[],diverse=[],pool=[],port_graphs=considered)
    pool=[];keys=set()
    def add(edges,kind):
        key=complete_key(edges)
        if key in keys or not is_fragment_tree(len(runtime.labels),edges):return
        try:mol,_,_=assemble_slots(runtime.lib,runtime.labels,edges,oov=runtime.oov)
        except ChemistryRejected:return
        keys.add(key)
        pool.append(dict(connections=edges,kind=kind,score=float(sum(e['log_odds'] for e in edges)),
            constitution=canonical(mol,False),skeleton=skeleton_key(runtime.labels,edges)))
    for c in ordinary+all_candidates:add(c['connections'],c['kind'])
    edges=sorted(prediction['pool'],key=lambda e:(-e['log_odds'],edge_key(e)));n=len(runtime.labels)
    def tree(forbidden_pair=None,noise=None):
        parent=list(range(n));used={};chosen=[]
        def root(i):
            while parent[i]!=i:i=parent[i]
            return i
        order=edges if noise is None else sorted(edges,key=lambda e:(-e['log_odds']-noise[e['i'],e['j']],edge_key(e)))
        for e in order:
            i,j,a,b,o=edge_key(e)
            if (i,j)==forbidden_pair or root(i)==root(j):continue
            if any(used.get(v,0)+o>runtime.capacity.get(v,0) for v in ((i,a),(j,b))):continue
            chosen.append(e);parent[root(i)]=root(j)
            for v in ((i,a),(j,b)):used[v]=used.get(v,0)+o
            if len(chosen)==n-1:break
        return chosen
    for candidate in ordinary[:8]:
        for e in candidate['connections']:add(tree((e['i'],e['j'])),'slot_pair_exclusion')
    rng=np.random.default_rng(seed+23000)
    for _ in range(32):
        noise=rng.gumbel(0,.75,(n,n));add(tree(noise=noise),'skeleton_perturbation')
    # Chemical equivalences are collapsed after full connection deduplication;
    # high model score chooses their representative without target information.
    chemistry={}
    for c in pool:
        if c['constitution'] not in chemistry or c['score']>chemistry[c['constitution']]['score']:chemistry[c['constitution']]=c
    candidates=list(chemistry.values())
    first=ordinary[0];selected=[next(c for c in pool if complete_key(c['connections'])==complete_key(first['connections']))]
    seen={selected[0]['constitution']};scores=np.array([c['score']/max(1,n-1) for c in candidates]);scale=max(.1,float(scores.std()))
    mean=float(scores.mean())
    def pairset(c):return {(e['i'],e['j'],e['order']) for e in c['connections']}
    while len(selected)<k:
        available=[c for c in candidates if c['constitution'] not in seen]
        if not available:break
        def priority(c):
            cs=pairset(c);similarity=max(len(cs&pairset(s))/max(1,len(cs|pairset(s))) for s in selected)
            unseen_skeleton=all(c['skeleton']!=s['skeleton'] for s in selected)
            novelty=(1-similarity)+.25*unseen_skeleton
            return (c['score']/max(1,n-1)-mean)/scale+diversity_weight*novelty
        chosen=max(available,key=lambda c:(priority(c),c['score'],complete_key(c['connections'])))
        selected.append(chosen);seen.add(chosen['constitution'])
    return dict(ordinary=ordinary,diverse=selected,pool=pool,port_graphs=considered,
        pool_skeletons=len({c['skeleton'] for c in pool}),diversity_weight=diversity_weight)
