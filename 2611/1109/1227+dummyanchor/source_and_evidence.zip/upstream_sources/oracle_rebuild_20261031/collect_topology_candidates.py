#!/usr/bin/env python3
"""Matched ordinary/diverse topology trajectories with isolated ranking labels."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
import traceback

import bootstrap
import numpy as np
import torch

from evaluate_robust_connections import edge_set
from oracle_graph import assemble
from prepare_reranker_experiment import ROOT
from run_connection_trajectories import save_result
from run_validation import load_official,seed_all,write_json
from topology_diversity import topology_search,complete_key,skeleton_key
from topology_reranker import extract_features,analytical_scores,SCHEMA
from trajectory_connections import ConnectionRuntime,GraphFactory,load_connection,run_trajectory
from validation import digest
from vocab_chemistry import VocabLibrary,canonical

BASE=bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt'


def candidate_id(edges):
    return hashlib.sha256(json.dumps(complete_key(edges)).encode()).hexdigest()[:16]


def evaluation_labels(fixture,result):
    # Called only after target-free generation and feature extraction.
    actual=edge_set(fixture['oracle_edges']);predicted=edge_set(result['connections'])
    mol=assemble(result['spec']);target=fixture['target_mol']
    return dict(constitution_correct=canonical(mol,False)==canonical(target,False),
        connections_correct=actual==predicted,connection_f1=2*len(actual&predicted)/max(1,len(actual)+len(predicted)),
        slot_atom_rmsd_A=float(np.sqrt(np.mean(np.sum((result['positions'][-1]-fixture['target_xyz'])**2,-1)))))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--ids',required=True)
    p.add_argument('--role',choices=['train','calibration','holdout'],required=True);p.add_argument('--seeds',required=True)
    p.add_argument('--device',default='cuda:7');p.add_argument('--max-k',type=int,default=8)
    p.add_argument('--checkpoint',type=Path,default=BASE);p.add_argument('--resume',action='store_true')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8');torch.use_deterministic_algorithms(True)
    torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    cohorts=json.loads((a.root/'cohorts.json').read_text())
    expected=set(cohorts[{'train':'train','calibration':'calibration','holdout':'casf_holdout'}[a.role]])
    ids=a.ids.split(',')
    if not set(ids)<=expected:raise ValueError('IDs outside the requested ranking split')
    hashes={n:digest(bootstrap.PROJECT/n) for n in ['topology_reranker.py','topology_diversity.py','collect_topology_candidates.py','trajectory_connections.py']}
    contract=dict(schema=SCHEMA,source_sha256=hashes,checkpoint_sha256=digest(a.checkpoint),role=a.role,max_k=a.max_k,
        cohorts_sha256=digest(a.root/'cohorts.json'),seeds=list(map(int,a.seeds.split(','))))
    if (a.output/'protocol.json').exists():
        if not a.resume:raise ValueError('Existing collector requires --resume')
        if json.loads((a.output/'protocol.json').read_text())!=contract:raise ValueError('Collector source/model contract changed')
    write_json(a.output/'protocol.json',contract)
    den=load_official(bootstrap.CHECKPOINT,a.output,device);lib=VocabLibrary();checkpoint=load_connection(a.checkpoint,device)
    report=dict(contract=contract,groups=[],failures=[],enrichment_train_only=True,identity_updates=False,
        oracle_repair_in_holdout=False,tree_constraint='Current non-ring-cut fragment profile only; future inter-fragment cycles require a different search profile.')
    began=time.time()
    for pid in ids:
        fixture=torch.load(a.root/f'inputs/{pid}/fixture.pt',weights_only=False)
        if a.role!='holdout' and (fixture['audit']['casf'] or fixture['audit']['split']!='train'):raise ValueError('CASF leaked into reranker fitting data')
        if a.role=='holdout' and not fixture['audit']['casf']:raise ValueError('Expected held-out CASF receptor')
        runtime=ConnectionRuntime(lib,checkpoint,fixture['labels'],fixture['oov'],device,policy='wide',head='full')
        factory=GraphFactory(lib,fixture['labels'],fixture['oov'],fixture['context'])
        for seed in map(int,a.seeds.split(',')):
            group=a.output/f'{pid}_{seed}';group.mkdir(exist_ok=True)
            if a.resume and (group/'group.json').exists():
                report['groups'].append(json.loads((group/'group.json').read_text()));continue
            seed_all(seed);C,Q=den.diffuser.sample_ref(len(fixture['labels']),device)
            T=C.cpu().numpy()*2.7+np.asarray(fixture['context']['pocket_com']).reshape(3)
            prediction=runtime.predict(T,Q.cpu().numpy(),.9)
            search_start=time.time();search=topology_search(runtime,prediction,seed=seed,k=a.max_k)
            search_seconds=time.time()-search_start
            methods={method:[candidate_id(c['connections']) for c in search[method]] for method in ['ordinary','diverse']}
            candidates={candidate_id(c['connections']):c for method in ['ordinary','diverse'] for c in search[method]}
            if methods['ordinary'] and methods['diverse'] and methods['ordinary'][0]!=methods['diverse'][0]:raise AssertionError('K=1 initial hypothesis differs')
            enrichment=[]
            if a.role=='train':
                # Correct/incorrect candidate supervision; this candidate is
                # never present in calibration or held-out generation pools.
                true_id=candidate_id(fixture['oracle_edges'])
                if true_id not in candidates:
                    candidates[true_id]=dict(connections=fixture['oracle_edges'],kind='supervised_training_positive')
                    enrichment=[true_id]
            rows=[];labels=[]
            for key,candidate in candidates.items():
                folder=group/key;folder.mkdir(exist_ok=True);candidate_start=time.time()
                if a.resume and (folder/'candidate.json').exists() and (folder/'labels.json').exists():
                    rows.append(json.loads((folder/'candidate.json').read_text()));labels.append(dict(key=key,**json.loads((folder/'labels.json').read_text())));continue
                try:
                    result=run_trajectory(den,runtime,factory,seed=seed,steps=25,mode='closed',initial_edges=candidate['connections'])
                    feature_start=time.time()
                    features=extract_features(runtime,spec=result['spec'],connections=result['connections'],frames=result['frames'],
                        positions=result['positions'],pocket=fixture['context']['pocket'])
                    scores=analytical_scores(features);feature_seconds=time.time()-feature_start
                    save_result(folder,result,fixture)
                    row=dict(key=key,success=True,features=features,scores=scores,seconds=time.time()-candidate_start,
                        feature_seconds=feature_seconds,backbone_evaluations=24,initial_connections=candidate['connections'],
                        final_connections=result['connections'],constitution=canonical(assemble(result['spec']),False),
                        initial_skeleton=skeleton_key(fixture['labels'],candidate['connections']),
                        final_skeleton=skeleton_key(fixture['labels'],result['connections']))
                    # Labels are written to a separate file after features.
                    label=evaluation_labels(fixture,result);write_json(folder/'labels.json',label)
                    labels.append(dict(key=key,**label));write_json(folder/'candidate.json',row)
                except Exception as exc:
                    if isinstance(exc,torch.OutOfMemoryError):raise
                    (folder/'error.txt').write_text(traceback.format_exc())
                    row=dict(key=key,success=False,error=repr(exc),seconds=time.time()-candidate_start)
                    write_json(folder/'candidate.json',row);report['failures'].append(dict(id=pid,seed=seed,**row))
                rows.append(row)
                print('CANDIDATE',a.role,pid,seed,key,row['success'],'elapsed',round(time.time()-began),flush=True)
            record=dict(id=pid,seed=seed,role=a.role,methods=methods,enrichment=enrichment,candidates=rows,
                search_seconds=search_seconds,pool_skeletons=search.get('pool_skeletons',0),port_graphs_considered=search['port_graphs'],
                source_casf=fixture['audit']['casf'],source_split=fixture['audit']['split'],labels_path=str(group/'labels.json'))
            write_json(group/'labels.json',labels);write_json(group/'group.json',record)
            report['groups'].append(record);write_json(a.output/'report.partial.json',report)
    report['elapsed_seconds']=time.time()-began;write_json(a.output/'report.json',report)


if __name__=='__main__':main()
