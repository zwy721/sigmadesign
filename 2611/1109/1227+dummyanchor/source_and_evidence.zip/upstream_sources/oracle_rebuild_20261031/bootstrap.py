"""Use the unmodified official source, independently of training3684 imports."""
import os
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
WORKSPACE = PROJECT.parent
OFFICIAL = WORKSPACE / 'third_party/sigmadock_official_repo_20261030'
SOURCE = OFFICIAL / 'src'
CHECKPOINT = WORKSPACE / 'pretrained/sigmadock_official/official_sample_checkpoint_0.ckpt'
CACHE = WORKSPACE / 'geom_m12/assets/diffusion_cache'
INPUTS = WORKSPACE / 'core497_joint_experiments_20261019/training3684/diagnostics/official_native_inputs'
RECORDS = Path('/data/zhouwanyao/cutoff_pdbbind_pose_cache_v1_20261025/records')
os.environ.setdefault('MPLCONFIGDIR', str(PROJECT / 'results/matplotlib'))
os.environ.setdefault('WANDB_MODE', 'disabled')
sys.path.insert(0, str(SOURCE))


def verify_imports():
    import sigmadock
    for name, module in tuple(sys.modules.items()):
        if name == 'sigmadock' or name.startswith('sigmadock.'):
            if getattr(module, '__file__', None) and not Path(module.__file__).resolve().is_relative_to(SOURCE):
                raise RuntimeError(f'Mixed SigmaDock sources: {name}: {module.__file__}')
    return str(Path(sigmadock.__file__).resolve())
