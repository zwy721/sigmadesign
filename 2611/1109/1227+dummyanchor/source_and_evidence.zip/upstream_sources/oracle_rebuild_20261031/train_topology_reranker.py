#!/usr/bin/env python3
"""Group-balanced pairwise reranker fitting, strictly on non-CASF candidates."""
import argparse
import copy
import json
from pathlib import Path
import time

import bootstrap
import numpy as np
import torch
from torch.nn import functional as F

from prepare_reranker_experiment import ROOT
from run_validation import write_json
from topology_reranker import TopologyReranker,SCHEMA,score_candidates
from validation import digest


def load_split(root,role):
    cohorts=json.loads((root/'cohorts.json').read_text());expected=set(cohorts[role])
    records=[];groups=[];seen=set();files=[]
    for path in sorted(root.glob(f'{role}_*/report.json')):
        report=json.loads(path.read_text())
        if report['contract']['role']!=role:raise ValueError('Ranking split mismatch')
        if report['contract']['schema']!=SCHEMA or report['contract']['source_sha256']['topology_reranker.py']!=digest(bootstrap.PROJECT/'topology_reranker.py'):
            raise ValueError('Candidate feature definition changed')
        files.append(path)
        for group in report['groups']:
            if group['role']!=role or group['source_casf'] or group['source_split']!='train':raise ValueError('CASF/non-training ranking input forbidden')
            if group['id'] not in expected:raise ValueError('Unexpected ranking molecule')
            key=(group['id'],group['seed'])
            if key in seen:raise ValueError('Duplicate ranking group')
            seen.add(key)
            labels={x['key']:x for x in json.loads(Path(group['labels_path']).read_text())}
            files.append(Path(group['labels_path']))
            group_indices=[];index_by_key={}
            for candidate in group['candidates']:
                if not candidate['success']:continue
                label=labels[candidate['key']]
                index=len(records);group_indices.append(index);index_by_key[candidate['key']]=index
                records.append(dict(id=group['id'],seed=group['seed'],key=candidate['key'],features=candidate['features'],
                    label=label,baseline_score=candidate['scores']['heuristic']))
            if role=='calibration' and group['enrichment']:raise ValueError('Oracle enrichment forbidden in calibration')
            groups.append(dict(id=group['id'],seed=group['seed'],indices=group_indices,
                methods={method:[index_by_key.get(k) for k in keys] for method,keys in group['methods'].items()}))
    present={g['id'] for g in groups}
    if present!=expected:raise ValueError(f'{role} data incomplete: missing {expected-present}')
    return records,groups,files


def ranking_metrics(scores,records,groups):
    accuracy=[];reciprocal=[];coverage=[];partial=[]
    for group in groups:
        for method in ('ordinary','diverse'):
            for k in (4,8):
                candidates=[i for i in group['methods'][method][:k] if i is not None]
                ordered=sorted(candidates,key=lambda i:-float(scores[i]))
                positives=[j for j,i in enumerate(ordered) if records[i]['label']['constitution_correct']]
                accuracy.append(bool(positives and positives[0]==0));reciprocal.append(1/(positives[0]+1) if positives else 0.)
                coverage.append(bool(positives))
                partial.append(records[ordered[0]]['label']['connection_f1'] if ordered else 0.)
    return dict(accuracy=float(np.mean(accuracy)),mrr=float(np.mean(reciprocal)),coverage=float(np.mean(coverage)),tasks=len(accuracy),
        selected_connection_f1=float(np.mean(partial)))


def pair_data(records,groups):
    left=[];right=[];weights=[]
    for group in groups:
        def grade(i):
            r=records[i]['label'];return 1.+.05*r['connections_correct'] if r['constitution_correct'] else .5*r['connection_f1']
        pairs=[(i,j,grade(i)-grade(j)) for i in group['indices'] for j in group['indices'] if grade(i)>grade(j)+.05]
        for i,j,w in pairs:left.append(i);right.append(j);weights.append(w/max(1,len(pairs)))
    if not left:raise ValueError('No supervised positive/negative or graded ranking pairs')
    return torch.tensor(left),torch.tensor(right),torch.tensor(weights,dtype=torch.float32)


def exclude_groups(records,groups,excluded):
    kept=[i for i,r in enumerate(records) if r['id'] not in excluded];mapping={old:new for new,old in enumerate(kept)}
    result=[]
    for group in groups:
        if group['id'] in excluded:continue
        result.append(dict(group,indices=[mapping[i] for i in group['indices']],
            methods={method:[mapping[i] if i is not None else None for i in ii] for method,ii in group['methods'].items()}))
    if not result:raise ValueError('No ranking groups remain after chemical overlap exclusion')
    return [records[i] for i in kept],result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--epochs',type=int,default=300)
    p.add_argument('--hidden',type=int,default=16);p.add_argument('--lr',type=float,default=.002)
    p.add_argument('--exclusion-audit',type=Path)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2);torch.manual_seed(1901)
    if (a.output/'best.pt').exists():raise ValueError('Choose a new reranker training directory')
    train,train_groups,train_files=load_split(a.root,'train');cal,cal_groups,cal_files=load_split(a.root,'calibration')
    exclusion={}
    if a.exclusion_audit:
        exclusion=json.loads(a.exclusion_audit.read_text())
        if exclusion['casf_read_failures']:raise ValueError('Incomplete CASF chemical overlap audit')
        excluded=set(exclusion['excluded_ids']);train,train_groups=exclude_groups(train,train_groups,excluded)
        cal,cal_groups=exclude_groups(cal,cal_groups,excluded)
    if {r['id'] for r in train}&{r['id'] for r in cal}:raise ValueError('Train/calibration overlap')
    names=sorted(train[0]['features'])
    if any(set(r['features'])!=set(names) for r in train+cal):raise ValueError('Feature schema mismatch')
    x=torch.tensor([[r['features'][n] for n in names] for r in train],dtype=torch.float32)
    mean=x.mean(0);scale=x.std(0,unbiased=False).clamp_min(.001);x=((x-mean)/scale).clamp(-10,10)
    xc=torch.tensor([[r['features'][n] for n in names] for r in cal],dtype=torch.float32);xc=((xc-mean)/scale).clamp(-10,10)
    y=torch.tensor([r['label']['constitution_correct'] for r in train],dtype=torch.float32)
    point_weight=torch.zeros(len(train))
    for group in train_groups:
        point_weight[group['indices']]=1/max(1,len(group['indices']))
    li,ri,pw=pair_data(train,train_groups)
    cli,cri,cpw=pair_data(cal,cal_groups)
    model=TopologyReranker(len(names),a.hidden)
    opt=torch.optim.AdamW(model.parameters(),lr=a.lr,weight_decay=.02)
    baseline=ranking_metrics([r['baseline_score'] for r in cal],cal,cal_groups)
    protocol=dict(schema=SCHEMA,feature_names=names,train_molecules=len(train_groups),calibration_molecules=len(cal_groups),
        train_candidates=len(train),calibration_candidates=len(cal),supervised_pairs=len(li),seed=1901,
        source_sha256={n:digest(bootstrap.PROJECT/n) for n in ['topology_reranker.py','train_topology_reranker.py']},
        cohorts_sha256=digest(a.root/'cohorts.json'),
        chemical_exclusion_audit_sha256=digest(a.exclusion_audit) if a.exclusion_audit else None,
        train_ids=sorted({r['id'] for r in train}),calibration_ids=sorted({r['id'] for r in cal}),
        excluded_ids=exclusion.get('excluded_ids',[]),
        data_sha256={str(f):digest(f) for f in train_files+cal_files},
        split='Non-CASF train/calibration only; holdout_* and historical CASF data never read',
        baseline_calibration=baseline,epochs=a.epochs,hidden=a.hidden,lr=a.lr,
        loss='Group-balanced pairwise logistic on full correctness / partial connection grades + .2 group-balanced BCE',
        normalization='Mean/std fitted only to training candidates; normalized values clipped at +/-10',
        selection='Calibration top-1 accuracy, then MRR, selected partial connection F1, then graded pairwise loss; generated pools only, no calibration oracle enrichment',
        calibration_pairs=len(cli),
        connection_head_updated=False,identity_model_updated=False,official_backbone_updated=False)
    write_json(a.output/'protocol.json',protocol)
    history=[];best=(-1.,-1.,-1.,-float('inf'));best_epoch=0;began=time.time()
    pos_weight=((1-y).sum()/y.sum().clamp_min(1)).clamp(1,8)
    for epoch in range(1,a.epochs+1):
        model.train();opt.zero_grad(set_to_none=True);scores=model(x)
        pair_loss=(F.softplus(-(scores[li]-scores[ri]))*pw).sum()/pw.sum()
        bce=F.binary_cross_entropy_with_logits(scores,y,pos_weight=pos_weight,reduction='none')
        loss=pair_loss+.2*(bce*point_weight).sum()/point_weight.sum()
        loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
        model.eval()
        with torch.no_grad():
            cal_scores=model(xc);metrics=ranking_metrics(cal_scores.tolist(),cal,cal_groups)
            cal_pair_loss=float((F.softplus(-(cal_scores[cli]-cal_scores[cri]))*cpw).sum()/cpw.sum())
        row=dict(epoch=epoch,train_loss=float(loss.detach()),pair_loss=float(pair_loss.detach()),calibration=metrics,
            calibration_pair_loss=cal_pair_loss,elapsed_seconds=time.time()-began)
        history.append(row)
        value=(metrics['accuracy'],metrics['mrr'],metrics['selected_connection_f1'],-cal_pair_loss)
        if value>best:
            best=value;best_epoch=epoch
            torch.save(dict(schema=SCHEMA,model=copy.deepcopy(model.state_dict()),feature_names=names,mean=mean,scale=scale,
                hidden=a.hidden,epoch=epoch,calibration=metrics,protocol=protocol),a.output/'best.pt')
        if epoch%10==0 or epoch==1:print(json.dumps(row),flush=True)
        if epoch-best_epoch>=60 and epoch>=100:break
    write_json(a.output/'history.json',history)
    write_json(a.output/'status.json',dict(status='complete',epoch=history[-1]['epoch'],best_epoch=best_epoch,
        calibration_accuracy=best[0],calibration_mrr=best[1],heuristic_accuracy=baseline['accuracy'],
        recommended_over_heuristic_on_calibration=best[0]>baseline['accuracy'],elapsed_seconds=time.time()-began))


if __name__=='__main__':main()
