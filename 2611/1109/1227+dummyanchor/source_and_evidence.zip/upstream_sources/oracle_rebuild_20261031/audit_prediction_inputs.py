#!/usr/bin/env python3
"""Fingerprint, cached chemistry/atom-order and class coverage audit."""
import argparse
import json
from pathlib import Path

import bootstrap
import numpy as np
import torch
from rdkit import Chem

from prediction_data import compact_cache,stable
from run_validation import write_json
from validation import digest
from vocab_chemistry import VocabLibrary,canonical


def signature(mol):
    return dict(atoms=[(a.GetAtomicNum(),a.GetFormalCharge(),a.GetIsAromatic(),a.GetIsotope()) for a in mol.GetAtoms()],
                bonds=sorted((min(b.GetBeginAtomIdx(),b.GetEndAtomIdx()),max(b.GetBeginAtomIdx(),b.GetEndAtomIdx()),
                              str(b.GetBondType())) for b in mol.GetBonds()))


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--cache',type=Path,required=True);a=p.parse_args();torch.set_num_threads(2)
    data=compact_cache(a.cache);lib=VocabLibrary()
    checkpoint=bootstrap.WORKSPACE/'core497_joint_experiments_20261019/training3684/runs/geom_ipa3684_100ep_20261029_cuda01234_bs372_fast/best_loss.pt'
    saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
    sha={k:digest(lib.assets/k) for k in ('mapping.json','templates.json','properties.json')}
    assert all(saved['provenance']['assets_sha256'][k]==v for k,v in sha.items())
    assert len(lib.ids)==3684 and len(set(lib.ids))==3684
    for i,cid in enumerate(lib.ids):
        assert lib.mapping['type_to_class'][cid]==i
        assert lib.properties[i]['class_id']==i and lib.properties[i]['core_id']==cid
        assert lib.mapping['core_smiles_to_class'][lib.properties[i]['core_smiles']]==i
    report=dict(checkpoint_sha256=digest(checkpoint),asset_sha256=sha,asset_fingerprint_matches_checkpoint=True,
                all_3684_mapping_directions_match=True,K=3684,MASK=3684,OOV=-1,
                split_sha256=data['split_sha256'],coverage={},chemistry_audit=[],failures=[])
    train_counts=torch.bincount(torch.cat([r['labels'][r['labels']>=0] for r in data['train']]),minlength=3684)
    for split in ('train','val'):
        labels=torch.cat([r['labels'] for r in data[split]]);known=labels[labels>=0]
        report['coverage'][split]=dict(molecules=len(data[split]),all_slots=len(labels),known_slots=len(known),
            oov_slots=int((labels<0).sum()),known_classes=len(known.unique()),
            classes_unseen_in_pdbbind_train=int((train_counts[known.unique()]==0).sum()),
            slots_unseen_in_pdbbind_train=int((train_counts[known]==0).sum()))
    checked=sorted(data['train'],key=lambda r:stable('mapping-audit',r['id']))[:256]+data['val']
    for record in checked:
        r=torch.load(bootstrap.RECORDS/f"{record['id']}.pt",weights_only=False)
        case=r['graph']['case'];m=Chem.MolFromMolBlock(case['native_molblock'],removeHs=False)
        mapping=[];parts=Chem.GetMolFrags(m,asMols=True,sanitizeFrags=True,fragsMolAtomMapping=mapping)
        lookup={tuple(g):mol for g,mol in zip(mapping,parts)}
        row=dict(id=r['id'],known_slots=0,ordered_atom_bond_mismatch=[],canonical_mismatch=[],template_local_max_error_A=0.)
        for i,label in enumerate(r['labels'].tolist()):
            if label<0:continue
            row['known_slots']+=1
            template,xyz=lib.template(label);part=lookup[tuple(case['native_groups'][i])]
            if signature(template)!=signature(part):row['ordered_atom_bond_mismatch'].append(i)
            if canonical(template,False)!=canonical(part,False):row['canonical_mismatch'].append(i)
            stored=np.asarray(case['fragments'][i]['template_local'])
            if stored.shape!=xyz.shape:raise AssertionError('Template/local atom count mismatch')
            row['template_local_max_error_A']=max(row['template_local_max_error_A'],float(np.max(abs(stored-xyz))))
        report['chemistry_audit'].append(row)
    rows=report['chemistry_audit']
    report['summary']=dict(molecules_checked=len(rows),known_slots_checked=sum(r['known_slots'] for r in rows),
        ordered_mismatch_slots=sum(len(r['ordered_atom_bond_mismatch']) for r in rows),
        constitution_mismatch_slots=sum(len(r['canonical_mismatch']) for r in rows),
        max_template_local_error_A=max(r['template_local_max_error_A'] for r in rows))
    write_json(a.output,report);print(json.dumps(report['coverage'],indent=2));print(report['summary'])


if __name__=='__main__':main()
