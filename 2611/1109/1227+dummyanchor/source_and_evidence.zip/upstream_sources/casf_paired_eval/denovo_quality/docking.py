from __future__ import annotations
from functools import lru_cache
import json
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from rdkit import Chem
from .protein import read_protein

@lru_cache(maxsize=2)
def receptor_vina(path,center,box,cpu,seed):
    from vina import Vina
    v=Vina(sf_name='vina',cpu=cpu,seed=seed,verbosity=0);v.set_receptor(path);v.compute_vina_maps(center=list(center),box_size=list(box));return v

def evaluate_vina(mol,row,cfg):
    if not cfg['enabled']:return dict(status='disabled')
    if not row.get('receptor_pdbqt_path'):return dict(status='unavailable',reason='Prepared receptor PDBQT not supplied')
    try:
        from vina import Vina
        from meeko import MoleculePreparation,PDBQTWriterLegacy
    except ImportError as e:return dict(status='unavailable',reason=str(e))
    source=[a for a in read_protein(row['protein_path'])['atoms'] if a['kind']=='protein'];source_xyz=np.array([a['xyz'] for a in source]);prepared=[]
    for line in Path(row['receptor_pdbqt_path']).read_text().splitlines():
        if not line.startswith(('ATOM  ','HETATM')):continue
        atom_type=line.split()[-1]
        if atom_type in ['H','HD','HS']:continue
        prepared.append([float(line[30:38]),float(line[38:46]),float(line[46:54])])
    if not len(prepared) or not len(source_xyz):return dict(status='unavailable',reason='Empty receptor heavy atom set')
    near=cKDTree(np.array(prepared)).query(source_xyz)[0];fraction=float(np.mean(near<=cfg['prepared_receptor_match_tolerance_A']))
    if fraction<cfg['minimum_receptor_heavy_match_fraction']:return dict(status='unavailable',reason='Existing PDBQT heavy coordinates do not match evaluation receptor',matched_receptor_fraction=fraction)
    center=row.get('box_center')
    if isinstance(center,str):center=json.loads(center) if center else None
    if center is None:center=source_xyz.mean(0).tolist()
    xyz=np.array(mol.GetConformer().GetPositions());inside=bool((np.abs(xyz-np.array(center))<=np.array(cfg['box_size_A'])/2).all())
    if not inside:return dict(status='unavailable',reason='Raw pose outside fixed Vina box; no recentering/redocking performed',inside_box=False,box_center=center,box_size_A=cfg['box_size_A'])
    q=Chem.AddHs(Chem.Mol(mol),addCoords=True);prep=MoleculePreparation(rigid_macrocycles=True);setups=prep.prepare(q)
    if len(setups)!=1:raise ValueError('Meeko produced multiple ligand setups')
    pdbqt,ok,error=PDBQTWriterLegacy.write_string(setups[0])
    if not ok:raise ValueError(str(error))
    exported=[]
    for line in pdbqt.splitlines():
        if line.startswith(('ATOM  ','HETATM')) and line.split()[-1] not in ['H','HD','HS']:exported.append([float(line[30:38]),float(line[38:46]),float(line[46:54])])
    coord_error=float(cKDTree(np.array(exported)).query(xyz)[0].max())
    if coord_error>0.002:raise ValueError('Ligand preparation changed heavy coordinates or atom set')
    v=receptor_vina(row['receptor_pdbqt_path'],tuple(center),tuple(cfg['box_size_A']),cfg['cpu'],cfg['seed']);v.set_ligand_from_string(pdbqt);energies=v.score()
    return dict(status='ok',score_only=True,optimization_performed=False,docking_performed=False,total_kcal_mol=float(energies[0]),components=[float(x) for x in energies],box_center=center,box_size_A=cfg['box_size_A'],cpu=cfg['cpu'],seed=cfg['seed'],inside_box=True,matched_receptor_fraction=fraction,max_ligand_preparation_heavy_coordinate_error_A=coord_error,
        receptor_preparation=row.get('receptor_preparation','User-supplied existing receptor; no new preparation'),ligand_preparation='Meeko; added H at RDKit positions; rigid macrocycles; no minimization or coordinate change. Undefined stereochemistry preserved; score is a pose diagnostic, not affinity.')
