from __future__ import annotations
import hashlib,importlib.metadata,json,math,os,platform
from pathlib import Path
import numpy as np
import pandas as pd

def clean(value):
    if value is pd.NA or value is pd.NaT:return None
    if isinstance(value,dict):return {str(k):clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple,set)):return [clean(v) for v in value]
    if isinstance(value,np.ndarray):return clean(value.tolist())
    if isinstance(value,np.generic):return clean(value.item())
    if isinstance(value,float) and not math.isfinite(value):return None
    if isinstance(value,Path):return str(value)
    return value

def write_json(path,value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(clean(value),ensure_ascii=False,indent=2,allow_nan=False)+'\n');tmp.replace(p)

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def object_hash(value):return hashlib.sha256(json.dumps(clean(value),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def versions():
    result={'python':platform.python_version(),'platform':platform.platform()}
    for name in ['rdkit','posebusters','numpy','scipy','pandas','matplotlib','vina','meeko']:
        try:result[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:result[name]=None
    return result

def conjunction(values):
    """Three-valued conjunction: known failures survive missing checks."""
    values=list(values)
    if any(v is False for v in values):return False
    if not values or any(v is None for v in values):return None
    return True

def rate(values):
    values=list(values);p=sum(v is True for v in values);f=sum(v is False for v in values);n=len(values);a=p+f
    return dict(total=n,passed=p,failed=f,unavailable=n-a,pass_rate_all=p/n if n else None,pass_rate_evaluable=p/a if a else None)

def merge(a,b):
    for key,value in b.items():
        if isinstance(value,dict) and isinstance(a.get(key),dict):merge(a[key],value)
        else:a[key]=value
    return a

def load_config(path=None):
    result=json.loads(Path(__file__).with_name('default_config.json').read_text())
    if path:
        merge(result,json.loads(Path(path).read_text()))
        if result.get('training_smiles_path'):
            result['training_smiles_path']=str((Path(path).resolve().parent/result['training_smiles_path']).resolve())
    return result

def flattened(value,prefix=''):
    result={}
    for key,item in value.items():
        name=f'{prefix}.{key}' if prefix else key
        if isinstance(item,dict):result.update(flattened(item,name))
        elif isinstance(item,(list,tuple)):result[name]=json.dumps(clean(item),ensure_ascii=False)
        else:result[name]=item
    return result
