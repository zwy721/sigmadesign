from __future__ import annotations
from functools import lru_cache
from rdkit import Chem
from rdkit.Chem import Crippen,Descriptors,Lipinski,QED,rdMolDescriptors
from rdkit.Chem.MolStandardize import rdMolStandardize
from .common import conjunction

def standardized_smiles(mol,isomeric=True):
    q=Chem.RemoveHs(Chem.Mol(mol));q=rdMolStandardize.Cleanup(q)
    for a in q.GetAtoms():a.SetAtomMapNum(0)
    return Chem.MolToSmiles(q,canonical=True,isomericSmiles=isomeric)

def stereo_elements(mol):
    q=Chem.Mol(mol);Chem.AssignStereochemistry(q,cleanIt=True,force=True)
    out=[]
    for s in Chem.FindPotentialStereo(q,cleanIt=True,flagPossible=True):
        if str(s.type) not in ['Atom_Tetrahedral','Bond_Double']:continue
        out.append(dict(type=str(s.type),center=int(s.centeredOn),specified=str(s.specified),descriptor=str(s.descriptor)))
    return out

@lru_cache(maxsize=1)
def alert_catalog():
    from rdkit.Chem.FilterCatalog import FilterCatalog,FilterCatalogParams
    p=FilterCatalogParams();p.AddCatalog(FilterCatalogParams.FilterCatalogs.BRENK);p.AddCatalog(FilterCatalogParams.FilterCatalogs.PAINS)
    return FilterCatalog(p)

def evaluate_chemistry(mol,parse_info):
    out=dict(parse_info);checks={'sdf_parse_success':parse_info['parse_success'],'chemical_valid':conjunction([parse_info['parse_success'],parse_info['sanitize_success']]),'fully_connected':None,'stereo_definition_complete':None,'stereo_geometry_consistent':None}
    if mol is None:return out,checks
    heavy=[a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum()>1];components=Chem.GetMolFrags(mol,sanitizeFrags=False)
    heavy_components=[sorted(set(c)&set(heavy)) for c in components if set(c)&set(heavy)]
    out.update(heavy_components=len(heavy_components),component_sizes=[len(c) for c in heavy_components],isolated_heavy_atoms=[i for i in heavy if mol.GetAtomWithIdx(i).GetDegree()==0],total_formal_charge=sum(a.GetFormalCharge() for a in mol.GetAtoms()))
    checks['fully_connected']=len(heavy_components)==1
    if not parse_info['sanitize_success']:return out,checks
    out.update(radical_electrons=sum(a.GetNumRadicalElectrons() for a in mol.GetAtoms()),dummy_atoms=sum(a.GetAtomicNum()==0 for a in mol.GetAtoms()),aromatic_atoms=sum(a.GetIsAromatic() for a in mol.GetAtoms()),aromatic_bonds=sum(b.GetIsAromatic() for b in mol.GetBonds()))
    out['chemistry_warnings']=[]
    if abs(out['total_formal_charge'])>4:out['chemistry_warnings'].append('absolute_formal_charge_above_4')
    if out['radical_electrons']:out['chemistry_warnings'].append('radicals')
    if out['dummy_atoms']:out['chemistry_warnings'].append('dummy_atoms')
    checks['chemical_valid']=not (out['radical_electrons'] or out['dummy_atoms'])
    try:out['structural_alerts']=[e.GetDescription() for e in alert_catalog().GetMatches(mol)]
    except Exception as e:out['structural_alerts']=None;out['structural_alert_error']=str(e)
    # Alerts are descriptive, not an automatic drug-likeness or quality filter.
    try:
        out['stereo_elements']=stereo_elements(mol);undefined=[s for s in out['stereo_elements'] if s['specified']!='Specified']
        out['undefined_tetra_centres']=sum(s['type']=='Atom_Tetrahedral' for s in undefined);out['undefined_double_bonds']=sum(s['type']=='Bond_Double' for s in undefined)
        checks['stereo_definition_complete']=not undefined if not parse_info.get('declared_chemistry_error') else None
    except Exception as e:out['stereo_error']=str(e)
    try:out['canonical_smiles']=standardized_smiles(mol,True);out['constitution_smiles']=standardized_smiles(mol,False)
    except Exception as e:out['canonical_error']=str(e)
    if mol.GetNumConformers() and mol.GetConformer().Is3D() and not parse_info.get('declared_chemistry_error'):
        try:
            from rdkit.Chem import rdCIPLabeler
            declared=Chem.Mol(mol);derived=Chem.Mol(mol);Chem.RemoveStereochemistry(derived);Chem.AssignStereochemistryFrom3D(derived,replaceExistingTags=True)
            for q in [declared,derived]:
                Chem.AssignStereochemistry(q,cleanIt=True,force=True);rdCIPLabeler.AssignCIPLabels(q)
            mismatches=[];missing3d=[];nassigned=0
            for a in declared.GetAtoms():
                if not a.HasProp('_CIPCode'):continue
                nassigned+=1;ref=a.GetProp('_CIPCode');b=derived.GetAtomWithIdx(a.GetIdx());pred=b.GetProp('_CIPCode') if b.HasProp('_CIPCode') else None
                if pred is None:missing3d.append(dict(atom=a.GetIdx(),declared=ref))
                elif pred!=ref:mismatches.append(dict(atom=a.GetIdx(),declared=ref,from_3D=pred))
            for b in declared.GetBonds():
                if b.GetStereo() not in [Chem.BondStereo.STEREOE,Chem.BondStereo.STEREOZ]:continue
                nassigned+=1;pred=derived.GetBondWithIdx(b.GetIdx()).GetStereo()
                if pred==Chem.BondStereo.STEREONONE:missing3d.append(dict(bond=b.GetIdx(),declared=str(b.GetStereo())))
                elif pred!=b.GetStereo():mismatches.append(dict(bond=b.GetIdx(),declared=str(b.GetStereo()),from_3D=str(pred)))
            out.update(assigned_stereo_elements_compared=nassigned,declared_vs_3D_mismatches=mismatches,declared_stereo_not_resolvable_from_3D=missing3d)
            checks['stereo_geometry_consistent']=not (mismatches or missing3d)
        except Exception as e:out['stereo_geometry_error']=str(e)
    return out,checks

def properties(mol):
    return dict(MW=Descriptors.MolWt(mol),LogP=Crippen.MolLogP(mol),QED=QED.qed(mol),TPSA=rdMolDescriptors.CalcTPSA(mol),HBD=Lipinski.NumHDonors(mol),HBA=Lipinski.NumHAcceptors(mol),rotatable_bonds=Lipinski.NumRotatableBonds(mol),rings=rdMolDescriptors.CalcNumRings(mol),aromatic_rings=rdMolDescriptors.CalcNumAromaticRings(mol),heavy_atoms=mol.GetNumHeavyAtoms(),formal_charge=Chem.GetFormalCharge(mol))
