from __future__ import annotations
from collections import Counter,defaultdict
from itertools import combinations
import csv,html,json,re,shutil
from pathlib import Path
import numpy as np
from rdkit import Chem
from .common import clean,conjunction,flattened,object_hash,rate,write_json
from .diversity import analyze_diversity,distribution

LABELS={
 'sdf_parse_success':'SDF/SMILES解析','chemical_valid':'化学有效','fully_connected':'完整连通','stereo_definition_complete':'立体定义完整','stereo_geometry_consistent':'已声明立体与三维一致',
 'no_severe_internal_clash':'分子内无严重碰撞','bond_geometry_valid':'键长有效','angle_geometry_valid':'键角有效','ring_geometry_valid':'环几何有效','torsion_geometry_valid':'酰胺扭转有效',
 'no_severe_protein_clash':'蛋白无严重碰撞','in_target_pocket':'位于目标口袋','posebusters_mol_all_pass':'PoseBusters mol全通过','posebusters_all_pass':'PoseBusters dock全通过','posebusters_without_water_pass':'PB去除固定水检查（敏感性）','geometric_quality_without_stereo':'几何质量（不含立体/PB）','high_quality':'综合高质量','chemically_valid_connected':'化学有效且连通'}
CAUSE_LABELS={'disconnected':'Disconnected','cross_bond_geometry':'Cross-fragment bond','other_bond_geometry':'Other bond','internal_clash':'Internal clash','protein_clash':'Protein clash','angle_geometry':'Bond angles','ring_geometry':'Ring geometry','torsion_geometry':'Amide torsion','stereo_undefined':'Undefined stereo','stereo_conflict':'Stereo vs 3D','high_strain_diagnostic':'High strain (diagnostic)','PB_internal_energy':'PB energy','PB_other':'Other PB'}

def csv_write(path,rows):
    rows=[clean(r) for r in rows];keys=list(dict.fromkeys(k for r in rows for k in r));path=Path(path)
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def sdf_record_text(path,index):
    records=Path(path).read_text().split('$$$$');text=records[index]
    # The newline after a previous delimiter is not the next molecule's name.
    # Preserve a blank first-line molecule name, which is a valid SDF header.
    if index>0 and text.startswith('\n'):text=text[1:]
    return text+('' if text.endswith('\n') else '\n')+'$$$$\n'

def failure_flags(r):
    c=r['checks'];m=r['modules'];g=m.get('geometry',{});p=m.get('posebusters',{}).get('tests',{})
    flags=dict(disconnected=c.get('fully_connected') is False,cross_bond_geometry=(g.get('cross_fragment_abnormal_bond_count') or 0)>0,other_bond_geometry=(g.get('within_fragment_abnormal_bond_count') or 0)>0,
        internal_clash=c.get('no_severe_internal_clash') is False,protein_clash=c.get('no_severe_protein_clash') is False,angle_geometry=c.get('angle_geometry_valid') is False,ring_geometry=c.get('ring_geometry_valid') is False,torsion_geometry=c.get('torsion_geometry_valid') is False,stereo_undefined=c.get('stereo_definition_complete') is False,stereo_conflict=c.get('stereo_geometry_consistent') is False,high_strain_diagnostic=m.get('forcefield',{}).get('high_strain_diagnostic') is True,PB_internal_energy=p.get('internal_energy') is False,PB_other=any(v is False for k,v in p.items() if k!='internal_energy'))
    return flags

def aggregate(results,config):
    groups=defaultdict(list)
    for r in results:groups[r['metadata']['group']].append(r)
    keys=sorted({k for r in results for k in r['checks']}|set(config['quality']['required_checks']));pbkeys=sorted({k for r in results for k in r['modules'].get('posebusters',{}).get('tests',{})});summary={'total_molecules':len(results),'groups':{},'quality_definition':config['quality'],'top_k':[]}
    for group,rr in groups.items():
        row=dict(n=len(rr),receptors=len({r['metadata']['receptor_id'] for r in rr}),checks={k:rate(r['checks'].get(k) for r in rr) for k in keys},posebusters_tests={k:rate(r['modules'].get('posebusters',{}).get('tests',{}).get(k) for r in rr) for k in pbkeys},failure_counts={k:sum(failure_flags(r)[k] for r in rr) for k in CAUSE_LABELS})
        row['numeric']={}
        for module,fields in {'geometry':['severe_internal_clash_pairs','abnormal_bond_count','cross_fragment_abnormal_bond_count','cross_fragment_max_bond_deviation_A','max_bond_deviation_A','max_bond_length_A','abnormal_angle_count'],'protein':['severe_clash_pairs','minimum_distance_A','minimum_vdw_ratio','pocket_atom_fraction','contact_pairs'],'forcefield':['energy_drop_kcal_mol','energy_drop_per_heavy_atom','heavy_atom_RMSD_no_alignment_A','max_cross_fragment_bond_change_A'],'vina':['total_kcal_mol'],'properties':['MW','LogP','QED','TPSA','HBD','HBA','rotatable_bonds','rings','aromatic_rings','heavy_atoms','formal_charge']}.items():
            for field in fields:row['numeric'][f'{module}.{field}']=distribution([r['modules'].get(module,{}).get(field) for r in rr])
        row['fragment_bond_totals']={key:sum((r['modules'].get('geometry',{}).get(key) or 0) for r in rr) for key in ['bond_count','abnormal_bond_count','cross_fragment_bond_count','cross_fragment_abnormal_bond_count','within_fragment_bond_count','within_fragment_abnormal_bond_count']};row['fragment_mapping_available_count']=sum(r['modules'].get('geometry',{}).get('fragment_mapping_available') is True for r in rr)
        row['vina_status_counts']=dict(Counter(r['modules'].get('vina',{}).get('status','unavailable') for r in rr));row['forcefield_status_counts']=dict(Counter(r['modules'].get('forcefield',{}).get('status','unavailable') for r in rr));row['local_forcefield_converged']=sum(r['modules'].get('forcefield',{}).get('local_optimization_converged') is True for r in rr);row['input_unchanged_count']=sum(r.get('input_unchanged') is True for r in rr);summary['groups'][group]=row
        row['internal_clash_pair_severities']={severity:sum(r['modules'].get('geometry',{}).get('clash_severity_counts',{}).get(severity,0) for r in rr) for severity in ['severe','moderate','mild']}
        row['metal_raw_vdw_overlap_molecules']=sum((r['modules'].get('protein',{}).get('inorganic_cofactor_raw_vdw_severe_pairs') or 0)>0 for r in rr)
    # A Top-K attempt groups a pocket/seed/model/config, and uses only real ranks.
    attempts=defaultdict(list)
    for r in results:
        meta=r['metadata']
        if meta.get('candidate_rank'):attempts[(meta['group'],meta['receptor_id'],str(meta.get('seed','')),meta.get('model_name',''),meta.get('experiment_config',''))].append(r)
    for k in config.get('top_k',[1,4,8]):
        bygroup=defaultdict(list)
        for key,rr in attempts.items():
            ranked={int(r['metadata']['candidate_rank']):r for r in rr}
            if not all(i in ranked for i in range(1,k+1)):continue
            values=[ranked[i]['checks'].get('high_quality') for i in range(1,k+1)];out=True if any(v is True for v in values) else None if any(v is None for v in values) else False;bygroup[key[0]].append(out)
        for group,values in bygroup.items():summary['top_k'].append(dict(group=group,K=k,attempts=len(values),any_high_quality=rate(values)))
    return summary

def make_plots(summary,results,output):
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    groups=list(summary['groups']);metrics=['chemical_valid','fully_connected','no_severe_internal_clash','bond_geometry_valid','angle_geometry_valid','no_severe_protein_clash','posebusters_all_pass','stereo_definition_complete','high_quality'];labels=['Chemical valid','Connected','No internal clash','Bond lengths','Bond angles','No protein clash','PoseBusters dock','Stereo complete','High quality'];fig,ax=plt.subplots(figsize=(14,6));x=np.arange(len(metrics));width=.8/max(len(groups),1)
    for index,group in enumerate(groups):
        stats=summary['groups'][group]['checks'];values=[100*(stats[k]['pass_rate_all'] or 0) for k in metrics];bars=ax.bar(x-.4+width*(index+.5),values,width,label=f'{group} (n={summary["groups"][group]["n"]})')
        for bar,k in zip(bars,metrics):
            if stats[k]['unavailable']:ax.text(bar.get_x()+bar.get_width()/2,max(bar.get_height(),1)+1,f'NA {stats[k]["unavailable"]}',fontsize=6,rotation=90,ha='center',va='bottom')
    ax.set_xticks(x,labels,rotation=25,ha='right');ax.set_ylim(0,115);ax.set_ylabel('Passed / all input molecules (%)');ax.legend(fontsize=8);ax.grid(axis='y',alpha=.2);ax.set_title('Original poses only; no reference identity or recovery RMSD in quality gates');fig.tight_layout();fig.savefig(output/'quality_comparison.png',dpi=180);plt.close(fig)
    causes=list(CAUSE_LABELS);fig,(ax,heat)=plt.subplots(1,2,figsize=(19,7),gridspec_kw={'width_ratios':[1.3,1]});x=np.arange(len(causes))
    for index,group in enumerate(groups):ax.bar(x-.4+width*(index+.5),[summary['groups'][group]['failure_counts'][k] for k in causes],width,label=group)
    ax.set_xticks(x,[CAUSE_LABELS[k] for k in causes],rotation=65,ha='right');ax.set_ylabel('Number of molecules');ax.set_title('Failure flags overlap; high strain is diagnostic');ax.legend(fontsize=7);ax.grid(axis='y',alpha=.2)
    primary=next((g for g in groups if g.startswith('A_')),groups[0] if groups else '')
    chosen=['cross_bond_geometry','internal_clash','protein_clash','angle_geometry','ring_geometry','stereo_undefined','high_strain_diagnostic'];flags=[failure_flags(r) for r in results if r['metadata']['group']==primary];matrix=np.array([[sum(f[a] and f[b] for f in flags) for b in chosen] for a in chosen]);im=heat.imshow(matrix,cmap='Reds',vmin=0,vmax=max(len(flags),1))
    heat.set_xticks(range(len(chosen)),[CAUSE_LABELS[k] for k in chosen],rotation=65,ha='right',fontsize=8);heat.set_yticks(range(len(chosen)),[CAUSE_LABELS[k] for k in chosen],fontsize=8)
    for i in range(len(chosen)):
        for j in range(len(chosen)):heat.text(j,i,str(matrix[i,j]),ha='center',va='center',fontsize=9,color='white' if matrix[i,j]>.55*max(len(flags),1) else 'black')
    heat.set_title(f'Co-occurring failures: {primary}');fig.colorbar(im,ax=heat,fraction=.046);fig.tight_layout();fig.savefig(output/'failure_distribution.png',dpi=180);plt.close(fig)

def examples(results,output,per_group):
    folder=output/'examples';folder.mkdir(exist_ok=True);groups=defaultdict(list)
    for r in results:
        if r['metadata'].get('sdf_path') and Path(r['metadata']['sdf_path']).is_file() and r['checks'].get('chemical_valid') is True:groups[r['metadata']['group']].append(r)
    entries=[]
    for group,rows in groups.items():
        ranked=sorted(rows,key=lambda r:(r['checks'].get('high_quality') is not True,len(r['failed_checks']),r['molecule_id']));selected=[]
        for r in ranked[:max(per_group-1,1)]+ranked[-1:]:
            if r['molecule_id'] not in {a['molecule_id'] for a in selected}:selected.append(r)
        for r in selected:
            stem=re.sub(r'[^A-Za-z0-9_.-]','_',r['molecule_id']);m=r['metadata'];sub=folder/stem;sub.mkdir(exist_ok=True);raw=sdf_record_text(m['sdf_path'],int(m.get('record_index',0)));(sub/'original.sdf').write_text(raw)
            pdb=Path(m['protein_path']).read_text() if m.get('protein_path') and Path(m['protein_path']).is_file() else '';(sub/'receptor.pdb').write_text(pdb)
            pml='load receptor.pdb, receptor\nload original.sdf, generated\nhide everything\nshow cartoon, receptor\nshow sticks, generated\nshow sticks, byres (receptor within 4.5 of generated)\ncolor cyan, generated and elem C\nzoom generated, 6\n'
            for index,pair in enumerate(r['modules'].get('geometry',{}).get('clash_pairs',[])[:10]):
                if pair['severity']=='severe':pml+=f'distance internal_clash_{index}, generated and index {pair["atom_i"]+1}, generated and index {pair["atom_j"]+1}\n'
            (sub/'view.pml').write_text(pml);caption=f'{r["molecule_id"]}: high_quality={r["checks"].get("high_quality")}; failures={r["failed_checks"]}'
            page='''<!doctype html><html><head><meta charset="utf-8"><title>Molecular quality diagnostic</title><script src="https://3Dmol.org/build/3Dmol-min.js"></script></head><body><p>CAPTION</p><p>Original generated coordinates. Cyan ligand; gray receptor. Red dashed lines: severe internal collisions. No optimization applied.</p><div id="viewer" style="width:100%;height:700px;position:relative"></div><script>const v=$3Dmol.createViewer('viewer',{backgroundColor:'white'});v.addModel(PDB,'pdb');v.setStyle({model:0},{cartoon:{color:'lightgray'}});v.addModel(SDF,'sdf');v.setStyle({model:1},{stick:{colorscheme:'cyanCarbon'},sphere:{scale:0.22,colorscheme:'cyanCarbon'}});LINES;v.zoomTo({model:1});v.render();</script></body></html>'''
            lines=[]
            mol=Chem.SDMolSupplier(str(sub/'original.sdf'),sanitize=False,removeHs=False)[0]
            if mol is not None and mol.GetNumConformers():
                xyz=mol.GetConformer().GetPositions();orig=r.get('original_heavy_atom_indices',list(range(len(xyz))))
                for pair in r['modules'].get('geometry',{}).get('clash_pairs',[])[:20]:
                    if pair['severity']!='severe':continue
                    a,b=xyz[orig[pair['atom_i']]],xyz[orig[pair['atom_j']]];lines.append('v.addLine('+json.dumps(dict(start=dict(zip(['x','y','z'],a.tolist())),end=dict(zip(['x','y','z'],b.tolist())),color='red',dashed=True))+')')
            page=page.replace('CAPTION',html.escape(caption)).replace('PDB',json.dumps(pdb).replace('</',r'<\/')).replace('SDF',json.dumps(raw).replace('</',r'<\/')).replace('LINES',';'.join(lines));(sub/'view.html').write_text(page)
            write_json(sub/'metrics.json',r);entries.append(dict(molecule_id=r['molecule_id'],group=group,high_quality=r['checks'].get('high_quality'),html=str((sub/'view.html').relative_to(output)),pymol=str((sub/'view.pml').relative_to(output))))
    return entries

def render(summary,results,output,config):
    n=lambda v:'—' if v is None else f'{v:.3f}'
    groups=summary['groups'];div=summary['diversity'];description='；'.join(f"{name}：{g['n']}个结构、{g['receptors']}个口袋" for name,g in groups.items())
    lines=['# SigmaDock de novo 分子生成质量评测','',f"本轮评价 {summary['total_molecules']} 个已有结构。{description}。",'']
    if 'A_predicted_t0.6' in groups:lines+=['A为t=0.6普通预测，B为同口袋官方真实完整图全程采样，C为原始晶体配体，每个口袋只计一次。B为已知分子对接几何对照，任务难度与A不同。','']
    if 'A_predicted_t0.6' in groups:
        a=groups['A_predicted_t0.6'];count=a['n'];c=a['checks'];f=a['failure_counts'];lines += [f"**主要结果：** 预测组{c['chemical_valid']['passed']}/{count}化学有效且{c['fully_connected']['passed']}/{count}完整连通，但{f['internal_clash']}/{count}仍有严重分子内碰撞，{f['cross_bond_geometry']}/{count}有跨片段异常键。PoseBusters dock通过{c['posebusters_all_pass']['passed']}/{count}，按预设规则综合高质量{c['high_quality']['passed']}/{count}；这与参考配体是否恢复是不同问题。",'']
    lines += [
        '主指标不要求生成分子等同参考配体。构造一致、参考Tanimoto和恢复RMSD仅在辅助列中报告。全部评测使用原始坐标，未重新采样、对接或训练；局部力场优化只产生独立诊断副本。','',
        '## 预先固定的规则与统计分母','',
        '运行前冻结的配置见[config_used.json](config_used.json)。综合高质量要求以下项目全部明确通过：'+ '、'.join(LABELS.get(k,k) for k in config['quality']['required_checks'])+'。任何明确失败记fail；无明确失败但存在缺失记unavailable。主通过率为通过数/全部输入，另给可评价分母；missing不冒充通过或失败。分子内应变下降阈值、药物性质、结构警报、Vina分数和参考恢复均不参与综合筛选。','',
        '- 化学图：RDKit解析、sanitize、无dummy/自由基；连通率按重原子组分计。化学有效不等于三维有效。',
        '- 原子碰撞：排除1–2成键对；1–3/1–4分别使用其RDKit化学/环拓扑距离下界，严重阈值为下界的0.70；1–5及更远/不同组分使用元素vdW半径和，严重阈值0.60。中等/轻度阈值分别为局部0.80/0.90和非局部0.75/0.85。碰撞类别互斥。',
        '- 键长和角：使用RDKit DG化学、键级、局部拓扑和环约束的上下界，容差25%；角异常按两端原子距离界判断，同时记录实际角度。等价末端共轭键对称化；不使用全元素统一键长。',
        '- 环与扭转：芳香环离最佳平面最大偏离≤0.25 Å，闭环键也按DG键长检查。重原子酰胺扭转偏离0/180°不超过30°；另保存ETKDG匹配扭转角，未对所有柔性转子强加单一角度阈值。PoseBusters还检查非芳香环非平面性和双键平面性。',
        '- 蛋白：只对protein类型重原子距离<0.75×vdW半径和计蛋白严重碰撞；至少80%配体重原子距原口袋原子≤5 Å才记位于口袋。水不计自定义碰撞；有机辅因子使用vdW，无机辅因子按PoseBusters惯例使用共价半径，阈值均为0.75。金属原始vdW重叠保留作诊断，不将正常Zn/Mg配位误称为蛋白碰撞。PoseBusters另按标准测试水/辅因子。首个PDB model、同名原子最高占有率altloc；重原子测试忽略输入氢，不重新指定质子化。',
        '- 原始预测图的手性从给定spec恢复，避免SDF读取从三维自动派生标签造成虚假“预测完整”。C晶体/无sidecar通用SDF报告读取后立体定义，不能据此推断模型是否显式预测了标签。','',
        '## 主要质量指标','', '| 检查 | '+' | '.join(groups)+' |','| --- | '+' | '.join('---:' for _ in groups)+' |']
    metrics=['sdf_parse_success','chemical_valid','fully_connected','no_severe_internal_clash','bond_geometry_valid','angle_geometry_valid','ring_geometry_valid','torsion_geometry_valid','stereo_definition_complete','stereo_geometry_consistent','no_severe_protein_clash','in_target_pocket','posebusters_mol_all_pass','posebusters_all_pass','posebusters_without_water_pass','geometric_quality_without_stereo','high_quality']
    for key in metrics:
        vals=[]
        for group in groups:
            r=groups[group]['checks'].get(key,rate([]));vals.append(f"{r['passed']}/{r['total']} ({100*(r['pass_rate_all'] or 0):.1f}%)；fail={r['failed']}，NA={r['unavailable']}")
        lines.append('| '+LABELS[key]+' | '+' | '.join(vals)+' |')
    lines+=['','![质量比较](quality_comparison.png)','','## 三维几何、跨片段键与应变','', '| 组别 | 严重内碰撞对：中位/最大 | 跨片段异常键 / 全部跨片段键 | 最大键长偏差中位数 Å | 蛋白碰撞对中位数 | ΔE/重原子中位数 | 局部优化收敛 |', '| --- | --- | --- | ---: | ---: | ---: | --- |']
    for group,g in groups.items():
        b=g['fragment_bond_totals'];s=g['numeric'];ic=s['geometry.severe_internal_clash_pairs'];lines.append(f"| {group} | {n(ic['median'])} / {n(ic['max'])} | {b['cross_fragment_abnormal_bond_count']} / {b['cross_fragment_bond_count']}；映射可用{g['fragment_mapping_available_count']}/{g['n']} | {n(s['geometry.max_bond_deviation_A']['median'])} | {n(s['protein.severe_clash_pairs']['median'])} | {n(s['forcefield.energy_drop_per_heavy_atom']['median'])} | {g['local_forcefield_converged']}/{g['n']} |")
    lines+=['','所有逐键、逐角、碰撞对、最严重距离及vdW重叠、环与酰胺扭转明细保存在[JSONL](molecule_metrics.jsonl)和details/。跨片段/片段内标注仅来自保存的原始划分；C未核实原晶体原子顺序对应关系，故不猜测跨片段指标。','',
        '力场优先MMFF94s，缺参时用UFF；先保持全部重原子固定，只放松新增H，以原始重原子pose计算能量，再对克隆分子进行最多500次局部最小化。ΔE、优化位移及跨片段键长改变只用于诊断；不将不同分子绝对能量作为质量排名，不将优化后的结构计入原始通过率。未收敛保留实际状态，不声称得到全局最低能量。','',
        '| 组别 | 严重 / 中等 / 轻度内碰撞原子对总数 | 有金属原始vdW近接的分子（非蛋白碰撞） |', '| --- | --- | ---: |']
    for group,g in groups.items():
        counts=g['internal_clash_pair_severities'];lines.append(f"| {group} | {counts['severe']} / {counts['moderate']} / {counts['mild']} | {g['metal_raw_vdw_overlap_molecules']} |")
    lines += ['',
        '## PoseBusters标准检查','',
        '主评价使用官方dock配置，不提供mol_true。mol列是同次运行中的分子自身标准检查子集；dock再加入受体距离、体积重叠和口袋距离等测试。redock/身份/RMSD类检查不进入主通过率。保持0.6.5官方阈值及50构象UFF能量对照，仅将能量计算线程固定为1，未使用fast模式。实际配置见[冻结的PoseBusters配置](posebusters_effective_config.json)，接口见[官方API](https://posebusters.readthedocs.io/en/latest/api.html)，标准实现见[dock配置](https://github.com/maabuu/posebusters/blob/main/posebusters/config/dock.yml)与[mol配置](https://github.com/maabuu/posebusters/blob/main/posebusters/config/mol.yml)。',
        '全部通过要求所有标准布尔检查明确为True。表中每项为pass / fail / unavailable；缺少环、双键、水或辅因子时，相应“无违规”可由官方实现返回逻辑空集通过，表示没有可违规对象，不证明实际验证过该化学类型。非布尔能量/距离的NaN保留为空，不映射为True。','', '| 标准测试 | '+' | '.join(groups)+' |','| --- | '+' | '.join('---:' for _ in groups)+' |']
    for key in sorted({k for g in groups.values() for k in g['posebusters_tests']}):
        vals=[]
        for g in groups.values():
            r=g['posebusters_tests'].get(key,rate([]));vals.append(f"{r['passed']} / {r['failed']} / {r['unavailable']}")
        lines.append('| '+key+' | '+' | '.join(vals)+' |')
    lines+=['','每项比例及可评价分母见[posebusters_tests.csv](posebusters_tests.csv)。失败原因为每分子evaluation.log、errors和PoseBusters errors；未完成项目保留unavailable。','',
        '固定晶体水对de novo分子尤其敏感：新结构可能置换原结合水，固定水碰撞不能独立证明分子不可结合。因此另列“PB去除固定水检查”敏感性指标，只从同次标准输出中去掉minimum_distance_to_waters和volume_overlap_with_waters，不改任何阈值、不重跑pose，也不替代官方整体通过率或综合高质量定义。','',
        '## 蛋白相容性和可选score-only','',
        '使用与模型输入相同的原口袋PDB，因此结论限于这些口袋原子，不能排除与完整蛋白其他区域的碰撞。保存极性原子近邻和疏水接触距离计数，不将其称作已验证的定向氢键。质子化、H方向、缺失侧链及溶剂暴露未经独立重建，埋藏未满足极性基团和严格氢键数量为unavailable。','',
        'Vina只对原始pose调用score()，不调用optimize()/dock()。复用已准备PDBQT，记录histidine/备用准备来源；核对与评价蛋白的重原子坐标重合率≥99%，以及配体准备前后重原子位置差≤0.002 Å。盒中心来自输入口袋，24 Å边长；出盒/缺参/准备失败均记unavailable，不重新放置或对接。Vina及Meeko版本见protocol.json，其分数只是辅助数值，不代表实验亲和力。','', '| 组别 | Vina状态 | score中位数 kcal/mol | 可评分数 |', '| --- | --- | ---: | ---: |']
    for group,g in groups.items():
        v=g['numeric']['vina.total_kcal_mol'];lines.append(f"| {group} | {g['vina_status_counts']} | {n(v['median'])} | {v['n']}/{g['n']} |")
    lines+=['','## 性质、多样性与有效产量','', '标准化规则：'+div['standardization'],'', '| 组别 | 有效连通分子 | 有效唯一立体结构 / 二维构造 | 唯一立体结构 / 全部输入 | 每口袋有效唯一立体结构均值 | 每口袋高质量唯一结构均值 | 全部输出成对Tanimoto均值 |', '| --- | ---: | --- | --- | ---: | ---: | ---: |']
    for group,d in div['groups'].items():lines.append(f"| {group} | {d['chemically_valid_connected']} | {d['unique_isomeric']} / {d['unique_constitution']} | {d['unique_isomeric']}/{d['n']} | {n(d['mean_valid_unique_per_pocket'])} | {n(d['mean_high_quality_unique_per_pocket'])} | {n(d['all_output_pair_tanimoto']['mean'])} |")
    lines+=['', '| 组别 | MW | LogP | QED | TPSA | HBD / HBA | 可旋转键 | 环 / 芳环 | 重原子 | 形式电荷 |', '| --- | ---: | ---: | ---: | ---: | --- | ---: | --- | ---: | ---: |']
    for group,g in groups.items():
        med=lambda key:n(g['numeric'][f'properties.{key}']['median'])
        lines.append(f"| {group} | {med('MW')} | {med('LogP')} | {med('QED')} | {med('TPSA')} | {med('HBD')} / {med('HBA')} | {med('rotatable_bonds')} | {med('rings')} / {med('aromatic_rings')} | {med('heavy_atoms')} | {med('formal_charge')} |")
    lines+=['', '性质表为全部有效输出的中位数，完整均值、范围及5%/95%分位见summary.json。', '']
    lines += ['| 组别 | 不在所提供训练二维集合中的输出 / 全部 | 此类唯一二维构造 | 不可评价 |', '| --- | --- | ---: | ---: |']
    for group,d in div['groups'].items():
        value=d['novel_constitution_vs_supplied_training'];lines.append(f"| {group} | {value['passed']}/{value['total']} | {d['novel_unique_constitution_vs_supplied_training']} | {value['unavailable']} |")
    lines+=['','[pocket_yields.csv](pocket_yields.csv)列出每个口袋的有效唯一和高质量唯一产量；[conformer_diversity.csv](conformer_diversity.csv)仅对同口袋、相同标准化立体结构的多个输出报告对称感知对齐RMSD及受体坐标系RMSD，区分化学多样性与构象/摆位多样性。相似度分布同时给出全部输出与唯一二维构造两种分母；超出max_pairs才用固定seed抽样。MW、LogP、QED、TPSA、HBD/HBA、可旋转键、环、芳环、重原子和形式电荷逐分子及分组分布均已保存。','',
        '训练结构新颖性：`'+json.dumps(div['training_reference'],ensure_ascii=False)+'`。仅对实际提供的训练结构集合计算“不在该集合”的比例；本轮若只提供PDBBind阶段成员，不能声称已覆盖GEOM预训练、连接头或官方SigmaDock的所有训练结构。不同于当前参考配体是另外的辅助指标，不等于训练新颖。','',
        '## 失败原因及重叠','', '| 原因 | '+' | '.join(groups)+' |','| --- | '+' | '.join('---:' for _ in groups)+' |']
    for cause in CAUSE_LABELS:lines.append('| '+CAUSE_LABELS[cause]+' | '+' | '.join(str(g['failure_counts'][cause]) for g in groups.values())+' |')
    lines+=['','![失败及重叠](failure_distribution.png)','','各原因可同时出现；高应变是辅助旗标，不自动拒绝原始样本。PoseBusters其他失败可能与逐键/碰撞检查重复，不将各项之和当作失败分子数。','',
        '## 本轮问题回答','']
    ag=next((g for k,g in groups.items() if k.startswith('A_')),None)
    if ag:
        count=ag['n'];check=ag['checks'];fc=ag['failure_counts'];d=div['groups'][next(k for k in groups if k.startswith('A_'))]
        lines += [f"- **不连通问题**：{check['fully_connected']['passed']}/{count} 个图完整连通，失败{check['fully_connected']['failed']}、不可评价{check['fully_connected']['unavailable']}。这是本批图层面的结论；空间上长键或片段分离仍由几何检查单独识别。",
            f"- **分子内碰撞**：{fc['internal_clash']}/{count} 存在自定义严重碰撞，PoseBusters内碰撞通过率另见标准表；不能由sanitize或连通性推断其已解决。",
            f"- **新建跨片段键**：{fc['cross_bond_geometry']}/{count} 个分子至少一条跨片段键异常；总计{ag['fragment_bond_totals']['cross_fragment_abnormal_bond_count']}/{ag['fragment_bond_totals']['cross_fragment_bond_count']}条异常。",
            f"- **口袋内合理性**：蛋白无严重碰撞{check['no_severe_protein_clash']['passed']}/{count}、位于口袋{check['in_target_pocket']['passed']}/{count}；几何组合通过{check['geometric_quality_without_stereo']['passed']}/{count}。距离接触不能证明结合亲和力。",
            f"- **PoseBusters整体通过率**：dock为{check['posebusters_all_pass']['passed']}/{count}（{100*(check['posebusters_all_pass']['pass_rate_all'] or 0):.1f}%），fail={check['posebusters_all_pass']['failed']}、unavailable={check['posebusters_all_pass']['unavailable']}。",
            f"- **每口袋产量**：本次每口袋只生成3个seed；平均高质量且结构不同产量为{d['mean_high_quality_unique_per_pocket']:.3f}，化学有效连通唯一结构均值为{d['mean_valid_unique_per_pocket']:.3f}，二者不能混用。"]
        main=sorted([(k,v) for k,v in fc.items() if k not in ['high_strain_diagnostic','PB_other']],key=lambda kv:-kv[1]);lines.append('- **主要失败模式**：'+ '、'.join(f'{CAUSE_LABELS[k]}={v}/{count}' for k,v in main[:5])+'；参见重叠图，不以参考构造错误给de novo分子判质量失败。')
        lines.append(f"- **改进优先级（由本批现象推断）**：优先加强跨片段化学几何约束与连接—坐标耦合，包括键长/角度、非键排斥、酰胺平面性和附着后立体输出。本批全部{ag['fragment_bond_totals']['abnormal_bond_count']}条异常键均为跨片段键，片段内{ag['fragment_bond_totals']['within_fragment_bond_count']}条键无异常；图层面的不连通已不是主要失败模式。")
        bg=groups.get('B_official_true_graph')
        if bg:lines.append(f"  官方真图对照也有{bg['failure_counts']['cross_bond_geometry']}/{bg['n']}个分子存在跨片段异常键，说明只提高连接图正确率不足以解决全部几何问题。应并行定位片段模板/接口与几何扩散中的边界约束，再决定模型改进；不能把全部差异归因于连接搜索或主干。本轮仅评价，不修改或训练模型。")
        accepted=[r for r in results if r['metadata']['group'].startswith('A_') and r['checks'].get('posebusters_all_pass') is True]
        if accepted:
            different=sum(r['modules'].get('reference_and_novelty_diagnostic',{}).get('constitution_exact') is False for r in accepted);missing=sum(r['checks'].get('stereo_definition_complete') is False for r in accepted);amide=sum(r['checks'].get('torsion_geometry_valid') is False for r in accepted)
            lines += ['', f"{len(accepted)}个通过PB dock的预测中，{different}个与参考配体二维构造不同，仍然通过标准物理检查，说明恢复率不能替代de novo质量评价。其未达到综合标准的原因包括{missing}个缺失立体定义、{amide}个酰胺平面性越界（可重叠）；这些是预设额外条件，PB自身没有要求恢复参考手性。"]
    lines+=['','## 辅助参考恢复诊断','', '| 组别 | 构造一致 | 立体一致 | 构造一致RMSD<2 Å | 严格RMSD<2 Å |', '| --- | ---: | ---: | ---: | ---: |']
    for group in groups:
        aux=[r['modules'].get('reference_and_novelty_diagnostic',{}) for r in results if r['metadata']['group']==group];lines.append(f"| {group} | {sum(a.get('constitution_exact') is True for a in aux)} | {sum(a.get('stereo_exact') is True for a in aux)} | {sum(a.get('constitution_RMSD_no_alignment_A') is not None and a['constitution_RMSD_no_alignment_A']<2 for a in aux)} | {sum(a.get('strict_RMSD_no_alignment_A') is not None and a['strict_RMSD_no_alignment_A']<2 for a in aux)} |")
    lines+=['','不同二维构造的恢复RMSD留空；不将固定槽位原子RMSD或参考分子相似性混入质量通过率。','',
        '## 可复现性、限制和产物','',
        '- [逐分子CSV](molecule_metrics.csv)、[完整逐分子JSONL](molecule_metrics.jsonl)、[summary.json](summary.json)、[failure_analysis.csv](failure_analysis.csv)。',
        '- [输入manifest](manifest_used.json)、[配置](config_used.json)、[版本、源码与参数指纹](protocol.json)、[Top-K统计](top_k_summary.csv)。cache/以输入内容、计算源码、版本及完整配置为键，支持断点与重复评价；不需要重新生成分子。',
        '- [三维示例索引](examples/index.json)：每例保留原始SDF副本、受体PDB、PyMOL脚本和交互HTML；HTML使用3Dmol.js，PyMOL文件可离线查看。没有达到综合标准的组只展示明确标记为失败的相对较好/较差样本。',
        '- 若输入为本轮SWITCH对照：受控测试给定真实片段身份、N及OOV结构，CASF曾用于旧权重选择，仅12个口袋×3seed，不代表自由身份/N生成或独立盲测。同一口袋多个seed不视作独立受体。',
        '- 化学/几何阈值是明确的操作性筛选，不等价于可合成性、毒性、安全性或实验活性。结构警报仅为描述。配置在批量运行前固定，不按这批通过率回调。','']
    (output/'DE_NOVO_QUALITY_RESULTS.md').write_text('\n'.join(lines))

def deliver(results,config,output,protocol):
    for r in results:
        tests=r['modules'].get('posebusters',{}).get('tests',{});r['checks']['posebusters_without_water_pass']=conjunction(value for key,value in tests.items() if key not in ['minimum_distance_to_waters','volume_overlap_with_waters'])
    output=Path(output);div,pocket_rows=analyze_diversity(results,config);summary=aggregate(results,config);summary['diversity']=div;summary['protocol_sha256']=object_hash(protocol);summary['versions']=protocol['versions'];summary['cache_hits']=sum(r.get('cache_hit') is True for r in results);summary['source_input_unchanged']=all(r.get('input_unchanged') is True for r in results)
    write_json(output/'config_used.json',config);write_json(output/'manifest_used.json',[r['metadata'] for r in results]);write_json(output/'summary.json',summary)
    csv_write(output/'molecule_metrics.csv',[flattened(r) for r in results]);(output/'molecule_metrics.jsonl').write_text(''.join(json.dumps(clean(r),ensure_ascii=False,allow_nan=False)+'\n' for r in results));csv_write(output/'failure_analysis.csv',[dict(molecule_id=r['molecule_id'],group=r['metadata']['group'],receptor_id=r['metadata']['receptor_id'],**failure_flags(r),failed_checks=json.dumps(r['failed_checks']),unavailable_checks=json.dumps(r['unavailable_checks']),errors=json.dumps(r['errors'])) for r in results]);csv_write(output/'pocket_yields.csv',pocket_rows);csv_write(output/'conformer_diversity.csv',[flattened(r) for r in div['conformer_diversity']]);csv_write(output/'top_k_summary.csv',[flattened(r) for r in summary['top_k']]);csv_write(output/'posebusters_tests.csv',[dict(group=group,test=test,**r) for group,g in summary['groups'].items() for test,r in g['posebusters_tests'].items()]);entries=examples(results,output,config['examples_per_group']);write_json(output/'examples/index.json',entries);make_plots(summary,results,output);render(summary,results,output,config)
