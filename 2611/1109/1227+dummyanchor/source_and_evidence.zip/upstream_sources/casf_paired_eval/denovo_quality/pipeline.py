from __future__ import annotations
import argparse,contextlib,copy,json,logging,os,random,re,sys,time,traceback
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
from rdkit import Chem,RDLogger
from . import __version__
from .common import clean,conjunction,load_config,object_hash,sha256,versions,write_json
from .io import PATH_FIELDS,has_coordinates,heavy_copy,load_molecule,read_manifest
from .chemistry import evaluate_chemistry,properties
from .geometry import GEOMETRY_CHECKS,evaluate_geometry
from .protein import evaluate_protein
from .forcefield import evaluate_strain
from .posebusters_adapter import evaluate_posebusters
from .docking import evaluate_vina

COMPUTE_MODULES=['__init__.py','common.py','io.py','chemistry.py','geometry.py','protein.py','forcefield.py','posebusters_adapter.py','docking.py','pipeline.py']

@contextlib.contextmanager
def molecule_log(path):
    """Keep RDKit/PoseBusters' global log stream valid between batch records."""
    import rdkit
    handler=rdkit.log_handler;saved=handler.stream
    if getattr(saved,'closed',False):saved=sys.__stderr__
    with Path(path).open('w') as log:
        try:
            handler.stream=log
            with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):yield
        finally:
            # CaptureLogger restores its stream to the redirected sys.stderr.
            # Restore before that per-record stream is closed, including errors.
            handler.stream=saved

def input_hashes(row):
    return {key:sha256(value) if Path(value).is_file() else 'MISSING' for key,value in row.items() if key in PATH_FIELDS and value}

def evaluate_one(row,config,output,computation_hash,dependency_versions,refresh=False):
    started=time.perf_counter();output=Path(output);input_sha=input_hashes(row);key=object_hash(dict(row=row,inputs=input_sha,config=config,code=computation_hash,versions=dependency_versions))
    safe=re.sub(r'[^A-Za-z0-9_.-]','_',row['molecule_id'])[:160];cache=output/'cache'/f'{safe}_{key[:16]}.json';folder=output/'details'/f'{safe}_{key[:16]}'
    if cache.exists() and not refresh:
        cached=json.loads(cache.read_text());cached['cache_hit']=True;return cached
    folder.mkdir(parents=True,exist_ok=True);result=dict(molecule_id=row['molecule_id'],metadata=row,input_sha256=input_sha,cache_key=key,cache_hit=False,checks={},errors={},modules={})
    checks=result['checks'];checks.update({name:None for name in config['quality']['required_checks']});random.seed(20261103);np.random.seed(20261103)
    def module(name,func):
        try:
            value=func();result['modules'][name]=clean(value);return value
        except Exception as e:result['errors'][name]=dict(reason=f'{type(e).__name__}: {e}',traceback=traceback.format_exc());result['modules'][name]=dict(status='unavailable',reason=str(e));return None
    with molecule_log(folder/'evaluation.log'):
        mol,info,fragments=load_molecule(row);chem=module('chemistry',lambda:evaluate_chemistry(mol,info))
        if chem is not None:
            details,ch=chem;result['modules']['chemistry']=details;checks.update(ch)
        if mol is not None and info['sanitize_success']:
            module('properties',lambda:properties(mol))
            heavy,hfrags,orig=heavy_copy(mol,fragments);result['original_heavy_atom_indices']=orig
            if has_coordinates(heavy):
                geom=module('geometry',lambda:evaluate_geometry(heavy,hfrags,config['geometry']))
                if geom is not None:result['modules']['geometry'],ch=geom;checks.update(ch)
                if row.get('protein_path'):
                    protein=module('protein',lambda:evaluate_protein(heavy,row['protein_path'],config['protein']))
                    if protein is not None:result['modules']['protein'],ch=protein;checks.update(ch)
                else:result['modules']['protein']=dict(status='unavailable',reason='No protein_path supplied')
                module('forcefield',lambda:evaluate_strain(heavy,hfrags,config['forcefield'],folder/'optimized_diagnostic.sdf'))
                module('vina',lambda:evaluate_vina(heavy,row,config['vina']))
            else:
                for name in ['geometry','protein','forcefield','vina']:result['modules'][name]=dict(status='unavailable',reason='No finite original 3D conformer; SMILES/2D coordinates are not embedded for primary quality scoring')
            pb=module('posebusters',lambda:evaluate_posebusters(mol,row.get('protein_path'),config['posebusters']))
            if pb is not None:checks['posebusters_all_pass']=pb['all_pass'];checks['posebusters_mol_all_pass']=pb['mol_all_pass']
        else:
            for name in ['geometry','protein','forcefield','vina','properties','posebusters']:result['modules'][name]=dict(status='unavailable',reason='Molecule could not be parsed and sanitized')
    checks['geometric_quality_without_stereo']=conjunction(checks.get(k) for k in ['chemical_valid','fully_connected','no_severe_internal_clash','bond_geometry_valid','angle_geometry_valid','ring_geometry_valid','torsion_geometry_valid','no_severe_protein_clash','in_target_pocket'])
    checks['high_quality']=conjunction(checks.get(k) for k in config['quality']['required_checks'])
    checks['chemically_valid_connected']=conjunction([checks['chemical_valid'],checks['fully_connected']])
    result['failed_checks']=[k for k,v in checks.items() if v is False];result['unavailable_checks']=[k for k,v in checks.items() if v is None]
    result['seconds']=time.perf_counter()-started;result['detail_directory']=str(folder.resolve());result['input_unchanged']=input_sha==input_hashes(row)
    if not result['input_unchanged']:raise RuntimeError(f"Input changed while evaluating {row['molecule_id']}")
    result=clean(result);write_json(cache,result);return result

def task(arguments):
    row,*rest=arguments
    try:return evaluate_one(row,*rest)
    except Exception as e:
        return dict(molecule_id=row['molecule_id'],metadata=row,checks={'sdf_parse_success':None,'chemical_valid':None,'fully_connected':None,'high_quality':None},modules={},errors={'worker':dict(reason=str(e),traceback=traceback.format_exc())},failed_checks=[],unavailable_checks=['worker_failure'],cache_hit=False)

def main():
    p=argparse.ArgumentParser(description='Evaluate existing de novo molecules without regenerating or modifying them.');p.add_argument('--manifest',required=True);p.add_argument('--output',required=True);p.add_argument('--config');p.add_argument('--workers',type=int,default=4);p.add_argument('--refresh',action='store_true');p.add_argument('--summarize-only',action='store_true');a=p.parse_args()
    os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('MPLCONFIGDIR',str(Path(a.output).resolve()/'matplotlib'));RDLogger.DisableLog('rdApp.info');RDLogger.DisableLog('rdApp.warning')
    output=Path(a.output).resolve();output.mkdir(parents=True,exist_ok=True);config=load_config(a.config);rows=read_manifest(a.manifest);v=versions();package=Path(__file__).parent
    code={str(path.name):sha256(path) for path in package.glob('*.py')};compute=object_hash({name:code[name] for name in COMPUTE_MODULES});protocol=dict(tool_version=__version__,manifest_path=str(Path(a.manifest).resolve()),manifest_sha256=sha256(a.manifest),configuration=config,configuration_sha256=object_hash(config),versions=v,source_sha256=code,computation_sha256=compute,input_count=len(rows),primary_evaluation='No reference structure or reference RMSD supplied to primary quality checks')
    run_key=object_hash(protocol);write_json(output/'protocols'/f'{run_key}.json',protocol);write_json(output/'protocol.json',protocol)
    if config.get('training_smiles_path') and Path(config['training_smiles_path']).is_file():
        protocol['training_reference_sha256']=sha256(config['training_smiles_path']);write_json(output/'protocol.json',protocol)
    write_json(output/'config_used.json',config)
    try:
        from .posebusters_adapter import effective_config
        write_json(output/'posebusters_effective_config.json',effective_config(config['posebusters']['mode'],config['posebusters']['energy_num_threads']))
    except Exception as e:write_json(output/'posebusters_effective_config.json',dict(status='unavailable',reason=str(e)))
    arguments=[(row,config,str(output),compute,v,a.refresh) for row in rows];results=[]
    if a.summarize_only:
        for args in arguments:
            row=args[0];key=object_hash(dict(row=row,inputs=input_hashes(row),config=config,code=compute,versions=v));safe=re.sub(r'[^A-Za-z0-9_.-]','_',row['molecule_id'])[:160];path=output/'cache'/f'{safe}_{key[:16]}.json'
            if not path.exists():raise RuntimeError(f'No matching cache for {row["molecule_id"]}')
            results.append(json.loads(path.read_text()))
    elif a.workers==1:
        for args in arguments:
            r=task(args);results.append(r);print(f'{len(results)}/{len(rows)} {r["molecule_id"]} high_quality={r["checks"].get("high_quality")} cached={r["cache_hit"]}',flush=True)
    else:
        with ProcessPoolExecutor(max_workers=max(a.workers,1)) as pool:
            futures=[pool.submit(task,args) for args in arguments]
            for future in as_completed(futures):
                r=future.result();results.append(r);print(f'{len(results)}/{len(rows)} {r["molecule_id"]} high_quality={r["checks"].get("high_quality")} cached={r["cache_hit"]}',flush=True)
    by_id={r['molecule_id']:r for r in results};results=[by_id[row['molecule_id']] for row in rows]
    from .report import deliver
    deliver(results,config,output,protocol);print(f'Complete: {len(results)} molecules; report: {output/"DE_NOVO_QUALITY_RESULTS.md"}',flush=True)
