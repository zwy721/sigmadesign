from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from rdkit import Chem

WATER={'HOH','WAT','DOD'}
STANDARD={'ALA','ARG','ASN','ASP','CYS','GLN','GLU','GLY','HIS','ILE','LEU','LYS','MET','PHE','PRO','SER','THR','TRP','TYR','VAL','HID','HIE','HIP','CYX','MSE'}

@lru_cache(maxsize=128)
def read_protein(path):
    pt=Chem.GetPeriodicTable();records={};hydrogens=0;invalid=0
    for line in Path(path).read_text(errors='replace').splitlines():
        if line.startswith('ENDMDL'):break
        if not line.startswith(('ATOM  ','HETATM')):continue
        try:
            element=line[76:78].strip().title()
            if not element:
                name=line[12:16];letters=''.join(c for c in name if c.isalpha());element=letters[0].upper() if name.startswith(' ') else letters[:2].title()
                if element not in ['Cl','Br','Zn','Fe','Mg','Mn','Ca','Na','Cu','Ni','Co','Se']:element=letters[0].upper()
            if element in ['H','D','T']:hydrogens+=1;continue
            z=pt.GetAtomicNumber(element);xyz=[float(line[30:38]),float(line[38:46]),float(line[46:54])];occupancy=float(line[54:60].strip() or 1.)
            if not z or not np.isfinite(xyz).all():raise ValueError('bad atom')
            res=line[17:20].strip();kind='water' if res in WATER else 'protein' if line.startswith('ATOM') or res in STANDARD else 'organic_cofactor' if element in ['C','N','O','S','P','F','Cl','Br','I'] else 'inorganic_cofactor'
            key=(line[21:22],line[22:27],res,line[12:16]);alt=line[16:17];rank=(occupancy,alt in [' ','A'],alt==' ')
            row=dict(xyz=xyz,element=element,z=z,vdw_radius_A=pt.GetRvdw(z),covalent_radius_A=pt.GetRcovalent(z),kind=kind,residue=f'{line[21:22]}:{res}{line[22:27].strip()}',name=line[12:16].strip(),altloc=alt,occupancy=occupancy,rank=rank)
            if key not in records or rank>records[key]['rank']:records[key]=row
        except Exception:invalid+=1
    atoms=list(records.values())
    if not atoms:raise ValueError('No usable receptor heavy atoms')
    return dict(atoms=atoms,input_hydrogen_records=hydrogens,invalid_atom_records=invalid,altloc_policy='First model; highest occupancy per residue/atom name, ties blank then A',scope='Original pocket PDB. No new protonation or missing-sidechain repair.')

def evaluate_protein(mol,path,cfg):
    protein=read_protein(str(path));atoms=[a for a in protein['atoms'] if cfg['include_waters_in_custom_clashes'] or a['kind']!='water']
    if not atoms:raise ValueError('No non-water conditioning atoms')
    coords=np.array([a['xyz'] for a in atoms]);xyz=np.asarray(mol.GetConformer().GetPositions());pt=Chem.GetPeriodicTable();r=np.array([pt.GetRvdw(a.GetAtomicNum()) for a in mol.GetAtoms()]);pr=np.array([a['vdw_radius_A'] for a in atoms]);dist=np.linalg.norm(xyz[:,None]-coords[None,:],axis=-1);ratio=dist/(r[:,None]+pr[None,:]);overlap=r[:,None]+pr[None,:]-dist
    raw_severe=ratio<cfg['severe_vdw_ratio'];protein_mask=np.array([a['kind']=='protein' for a in atoms]);organic_mask=np.array([a['kind']=='organic_cofactor' for a in atoms]);inorganic_mask=np.array([a['kind']=='inorganic_cofactor' for a in atoms])
    if not protein_mask.any():raise ValueError('No protein heavy atoms; cofactor-only structures cannot establish protein compatibility')
    # Metal coordination is not a protein steric collision. Keep raw vdW
    # overlaps, but type the conditioning atoms and evaluate inorganic atoms
    # using the same covalent-radius convention as standard PoseBusters.
    cov=np.array([pt.GetRcovalent(a.GetAtomicNum()) for a in mol.GetAtoms()]);pcov=np.array([a['covalent_radius_A'] for a in atoms]);cov_ratio=dist/(cov[:,None]+pcov[None,:])
    severe=raw_severe&protein_mask[None,:];moderate=(ratio<cfg['moderate_vdw_ratio'])&(~raw_severe)&protein_mask[None,:];near=dist.min(1);pairs=np.argwhere(severe)
    order=sorted(pairs.tolist(),key=lambda ij:ratio[tuple(ij)]);details=[dict(ligand_atom=i,receptor_atom=j,receptor_residue=atoms[j]['residue'],receptor_atom_name=atoms[j]['name'],receptor_kind=atoms[j]['kind'],distance_A=dist[i,j],vdw_ratio=ratio[i,j],overlap_A=overlap[i,j]) for i,j in order[:cfg['max_pair_details']]]
    polar=0;hydrophobic=0;polar_atoms_with_contact=set()
    for i,a in enumerate(mol.GetAtoms()):
        for j in np.where(dist[i]<cfg['contact_distance_A'])[0]:
            b=atoms[int(j)]
            if a.GetSymbol() in ['N','O','S'] and b['element'] in ['N','O','S'] and dist[i,j]<cfg['polar_contact_distance_A']:polar+=1;polar_atoms_with_contact.add(i)
            if a.GetSymbol() in ['C','S','F','Cl','Br','I'] and b['element'] in ['C','S'] and dist[i,j]<cfg['hydrophobic_contact_distance_A']:hydrophobic+=1
    fraction=float(np.mean(near<=cfg['pocket_nearest_distance_A']));hist=np.histogram(dist,bins=[0,1,2,3,4,4.5,5,6,8,np.inf])[0]
    out=dict(status='ok',receptor_heavy_atoms=len(atoms),input_hydrogen_records_ignored=protein['input_hydrogen_records'],invalid_receptor_atom_records=protein['invalid_atom_records'],receptor_atom_kinds={kind:sum(a['kind']==kind for a in atoms) for kind in set(a['kind'] for a in atoms)},altloc_policy=protein['altloc_policy'],preparation_scope=protein['scope'],
        severe_clash_pairs=int(severe.sum()),severe_clashing_ligand_atoms=int(np.any(severe,axis=1).sum()),moderate_clash_pairs=int(moderate.sum()),minimum_distance_A=float(dist[:,protein_mask].min()),minimum_vdw_ratio=float(ratio[:,protein_mask].min()),maximum_vdw_overlap_A=float(overlap[:,protein_mask].max()),clash_pair_details=details,
        raw_all_nonwater_vdw_severe_pairs=int(raw_severe.sum()),organic_cofactor_vdw_severe_pairs=int((raw_severe&organic_mask[None,:]).sum()),inorganic_cofactor_raw_vdw_severe_pairs=int((raw_severe&inorganic_mask[None,:]).sum()),inorganic_cofactor_covalent_radius_severe_pairs=int(((cov_ratio<cfg['severe_vdw_ratio'])&inorganic_mask[None,:]).sum()),
        receptor_type_policy='Protein clash rate uses protein atoms only. Organic cofactors use vdW and inorganic cofactors covalent radii, with identical 0.75 ratio. Raw inorganic vdW overlaps retained for audit; metal coordination is not automatically a protein collision. Full cofactor tests remain in standard PoseBusters gate.',
        pocket_atom_fraction=fraction,centroid_nearest_protein_A=float(cKDTree(coords).query(xyz.mean(0))[0]),contact_pairs=int((dist<cfg['contact_distance_A']).sum()),contacting_ligand_atom_fraction=float(np.mean(near<cfg['contact_distance_A'])),distance_histogram_bins_A=['0-1','1-2','2-3','3-4','4-4.5','4.5-5','5-6','6-8','8+'],distance_histogram_counts=hist.tolist(),
        potential_polar_contact_pairs=polar,potential_hydrophobic_contact_pairs=hydrophobic,hydrogen_bonds=None,buried_unsatisfied_polar_groups=None,
        interaction_limitations='Heavy-atom distance contacts only. Donor direction, hydrogen placement/protonation and solvent exposure are not validated; buried unsatisfied polarity and directional hydrogen bonds are unavailable.')
    return out,{'no_severe_protein_clash':not bool(severe.any()),'in_target_pocket':fraction>=cfg['minimum_pocket_atom_fraction']}
