"""Reference-independent quality evaluation of generated molecular structures."""
__version__ = '1.0.0'
