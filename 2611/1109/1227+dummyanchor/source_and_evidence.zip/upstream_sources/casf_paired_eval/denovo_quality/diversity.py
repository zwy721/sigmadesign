from __future__ import annotations
from collections import defaultdict
from itertools import combinations
import json,math
from pathlib import Path
import numpy as np
from rdkit import Chem,DataStructs
from rdkit.Chem import rdFingerprintGenerator,rdMolAlign
from .chemistry import standardized_smiles
from .common import rate,sha256
from .io import heavy_copy,load_molecule,has_coordinates

def distribution(values):
    values=[float(v) for v in values if v is not None and math.isfinite(v)]
    return dict(n=len(values),mean=float(np.mean(values)) if values else None,median=float(np.median(values)) if values else None,min=min(values) if values else None,max=max(values) if values else None,p05=float(np.quantile(values,.05)) if values else None,p95=float(np.quantile(values,.95)) if values else None)

def sampled_pairs(n,limit,seed):
    total=n*(n-1)//2
    if total<=limit:return list(combinations(range(n),2)),False
    rng=np.random.default_rng(seed);pairs=set()
    while len(pairs)<limit:
        i,j=map(int,rng.integers(0,n,2))
        if i!=j:pairs.add(tuple(sorted((i,j))))
    return sorted(pairs),True

def structural_fingerprint(mol,generator):
    # Explicit hydrogens in crystal SDFs must not change structural similarity.
    normalized=Chem.MolFromSmiles(standardized_smiles(mol,False))
    if normalized is None:raise ValueError('Cannot fingerprint standardized heavy-atom structure')
    return generator.GetFingerprint(normalized)

def reference_diagnostic(mol,reference_path,generator,cfg):
    out=dict(status='unavailable',reason='No readable reference supplied',constitution_exact=None,stereo_exact=None,tanimoto=None,constitution_RMSD_no_alignment_A=None,strict_RMSD_no_alignment_A=None)
    if not reference_path:return out
    ref,info,_=load_molecule(dict(sdf_path=reference_path,record_index=0))
    if ref is None or not info['sanitize_success']:return out
    out.update(status='ok',reason=None,constitution_exact=standardized_smiles(mol,False)==standardized_smiles(ref,False),stereo_exact=standardized_smiles(mol,True)==standardized_smiles(ref,True),tanimoto=float(DataStructs.TanimotoSimilarity(structural_fingerprint(mol,generator),structural_fingerprint(ref,generator))))
    if has_coordinates(mol) and has_coordinates(ref) and out['constitution_exact']:
        a,_,_=heavy_copy(Chem.Mol(mol));b,_,_=heavy_copy(Chem.Mol(ref))
        # Match the same chemically meaningful stereo used by canonical SMILES.
        # SDF 3D perception can leave tags on non-stereogenic/symmetric atoms;
        # these must not silently veto an otherwise identical strict mapping.
        for normalized in (a,b):Chem.AssignStereochemistry(normalized,cleanIt=True,force=True)
        matches=a.GetSubstructMatches(b,useChirality=False,uniquify=False,maxMatches=cfg['max_symmetry_matches'])
        if matches:
            x=a.GetConformer().GetPositions();y=b.GetConformer().GetPositions();out['constitution_RMSD_no_alignment_A']=min(float(np.sqrt(np.mean(np.sum((x[list(m)]-y)**2,axis=1)))) for m in matches);out['symmetry_mapping_count']=len(matches);out['symmetry_mapping_cap']=cfg['max_symmetry_matches']
        if out['stereo_exact']:
            matches=a.GetSubstructMatches(b,useChirality=True,uniquify=False,maxMatches=cfg['max_symmetry_matches'])
            out['strict_symmetry_mapping_count']=len(matches)
            if matches:out['strict_RMSD_no_alignment_A']=min(float(np.sqrt(np.mean(np.sum((x[list(m)]-y)**2,axis=1)))) for m in matches)
            else:out['strict_mapping_error']='Stereo identity agrees but no chirality-preserving isomorphism was found'
    return out

def training_reference(path):
    if not path:return None,None,dict(status='unavailable',reason='No actual training structure list supplied')
    p=Path(path)
    if not p.is_file():return None,None,dict(status='unavailable',reason='Training structure list not found')
    exact=set();constitution=set();invalid=0;scope='user-supplied training structures'
    if p.suffix=='.json':
        data=json.loads(p.read_text());rows=data.get('records',data) if isinstance(data,dict) else data
        if isinstance(data,dict):scope=data.get('scope',scope)
        for row in rows:
            if isinstance(row,dict) and row.get('canonical_smiles'):
                exact.add(row['canonical_smiles']);constitution.add(row['constitution_smiles'])
            else:invalid+=1
    else:
        for line in p.read_text().splitlines():
            if not line.strip() or line.startswith('#'):continue
            m=Chem.MolFromSmiles(line.split()[0])
            if m is None:invalid+=1;continue
            try:exact.add(standardized_smiles(m,True));constitution.add(standardized_smiles(m,False))
            except Exception:invalid+=1
    return exact,constitution,dict(status='ok' if exact else 'unavailable',scope=scope,path=str(p.resolve()),sha256=sha256(p),unique_isomeric=len(exact),unique_constitution=len(constitution),invalid_or_missing_records=invalid,full_training_universe_covered=False)

def analyze_diversity(results,config):
    cfg=config['diversity'];generator=rdFingerprintGenerator.GetMorganGenerator(radius=cfg['morgan_radius'],fpSize=cfg['morgan_bits'],includeChirality=False);exact,constitution,training=training_reference(config.get('training_smiles_path'));mols={};fps={};groups=defaultdict(list)
    for r in results:
        groups[r['metadata']['group']].append(r)
        if r['checks'].get('chemical_valid') is not True:continue
        mol,info,_=load_molecule(r['metadata'])
        if mol is None or not info['sanitize_success']:continue
        mols[r['molecule_id']]=mol;fps[r['molecule_id']]=structural_fingerprint(mol,generator)
        aux=reference_diagnostic(mol,r['metadata'].get('reference_path'),generator,cfg);chem=r['modules']['chemistry']
        aux['different_from_corresponding_reference_constitution']=not aux['constitution_exact'] if aux['constitution_exact'] is not None else None
        aux['absent_from_supplied_training_isomeric']=chem.get('canonical_smiles') not in exact if exact else None
        aux['absent_from_supplied_training_constitution']=chem.get('constitution_smiles') not in constitution if constitution else None
        r['modules']['reference_and_novelty_diagnostic']=aux
    summary={};pocket_rows=[];conformer_rows=[]
    for group,rr in groups.items():
        valid=[r for r in rr if r['checks'].get('chemically_valid_connected') is True and r['molecule_id'] in fps];ids=[r['molecule_id'] for r in valid];smiles=[r['modules']['chemistry'].get('canonical_smiles') for r in valid];consts=[r['modules']['chemistry'].get('constitution_smiles') for r in valid]
        pairs,sampled=sampled_pairs(len(ids),cfg['max_pairs'],cfg['seed']);similarity=[DataStructs.TanimotoSimilarity(fps[ids[i]],fps[ids[j]]) for i,j in pairs]
        unique_ids=list(dict.fromkeys(consts));unique_fps=[generator.GetFingerprint(Chem.MolFromSmiles(s)) for s in unique_ids if s];upairs,usampled=sampled_pairs(len(unique_fps),cfg['max_pairs'],cfg['seed']);usim=[DataStructs.TanimotoSimilarity(unique_fps[i],unique_fps[j]) for i,j in upairs]
        summary[group]=dict(n=len(rr),chemically_valid_connected=len(valid),unique_isomeric=len(set(smiles)),unique_constitution=len(set(consts)),unique_fraction_all=len(set(smiles))/len(rr) if rr else None,unique_fraction_valid=len(set(smiles))/len(valid) if valid else None,all_output_pair_tanimoto=distribution(similarity),pair_sampling=sampled,unique_constitution_pair_tanimoto=distribution(usim),unique_pair_sampling=usampled,internal_diversity_1_minus_tanimoto=1-float(np.mean(similarity)) if similarity else None)
        bypocket=defaultdict(list)
        for r in rr:bypocket[r['metadata']['receptor_id']].append(r)
        for pid,pocket in bypocket.items():
            validp=[r for r in pocket if r['checks'].get('chemically_valid_connected') is True];high=[r for r in pocket if r['checks'].get('high_quality') is True];geom=[r for r in pocket if r['checks'].get('geometric_quality_without_stereo') is True]
            def unique(rows,key='canonical_smiles'):return len({r['modules']['chemistry'][key] for r in rows if r['modules'].get('chemistry',{}).get(key)})
            pids=[r['molecule_id'] for r in validp if r['molecule_id'] in fps];pairs,psampled=sampled_pairs(len(pids),cfg['max_pairs'],cfg['seed']);sims=[DataStructs.TanimotoSimilarity(fps[pids[i]],fps[pids[j]]) for i,j in pairs]
            pocket_rows.append(dict(group=group,receptor_id=pid,generated=len(pocket),valid_connected=len(validp),valid_unique_isomeric=unique(validp),valid_unique_constitution=unique(validp,'constitution_smiles'),high_quality=len(high),high_quality_unique_isomeric=unique(high),high_quality_unique_constitution=unique(high,'constitution_smiles'),geometric_quality=len(geom),geometric_unique_constitution=unique(geom,'constitution_smiles'),mean_pair_tanimoto=float(np.mean(sims)) if sims else None,pair_sampling=psampled))
            # Conformer diversity applies only to the same chemical structure in the same pocket.
            same=defaultdict(list)
            for r in validp:
                mid=r['molecule_id']
                if mid in mols and has_coordinates(mols[mid]):same[r['modules']['chemistry']['canonical_smiles']].append(mid)
            for smi,mids in same.items():
                pairs,csampled=sampled_pairs(len(mids),min(cfg['max_pairs'],10000),cfg['seed']);aligned=[];world=[]
                for i,j in pairs:
                    a,_,_=heavy_copy(Chem.Mol(mols[mids[i]]));b,_,_=heavy_copy(Chem.Mol(mols[mids[j]]));matches=a.GetSubstructMatches(b,useChirality=True,uniquify=False,maxMatches=cfg['max_symmetry_matches'])
                    if not matches:continue
                    x=a.GetConformer().GetPositions();y=b.GetConformer().GetPositions();wr=min(float(np.sqrt(np.mean(np.sum((x[list(m)]-y)**2,axis=1)))) for m in matches)
                    ar=float(rdMolAlign.GetBestRMS(Chem.Mol(a),Chem.Mol(b),maxMatches=cfg['max_symmetry_matches']));world.append(wr);aligned.append(ar)
                if pairs:conformer_rows.append(dict(group=group,receptor_id=pid,canonical_smiles=smi,outputs=len(mids),pair_sampling=csampled,aligned_RMSD_A=distribution(aligned),receptor_frame_RMSD_A=distribution(world),distinct_conformer_pair_fraction=float(np.mean(np.asarray(aligned)>=cfg['conformer_distinct_rmsd_A'])) if aligned else None))
        group_pockets=[r for r in pocket_rows if r['group']==group];summary[group]['pocket_count']=len(group_pockets);summary[group]['mean_valid_unique_per_pocket']=float(np.mean([r['valid_unique_isomeric'] for r in group_pockets]));summary[group]['mean_high_quality_unique_per_pocket']=float(np.mean([r['high_quality_unique_isomeric'] for r in group_pockets]));summary[group]['reference_tanimoto']=distribution([r['modules'].get('reference_and_novelty_diagnostic',{}).get('tanimoto') for r in rr]);summary[group]['novel_constitution_count_vs_supplied_training']=sum(r['modules'].get('reference_and_novelty_diagnostic',{}).get('absent_from_supplied_training_constitution') is True for r in rr)
        summary[group]['novel_constitution_vs_supplied_training']=rate(r['modules'].get('reference_and_novelty_diagnostic',{}).get('absent_from_supplied_training_constitution') for r in rr)
        summary[group]['novel_unique_constitution_vs_supplied_training']=len({r['modules']['chemistry']['constitution_smiles'] for r in rr if r['modules'].get('reference_and_novelty_diagnostic',{}).get('absent_from_supplied_training_constitution') is True})
    return dict(groups=summary,training_reference=training,standardization='RDKit Cleanup + canonical SMILES, atom maps removed, retain components/charge/stereo; no tautomer collapse or neutralization. Morgan radius=2/2048 bits, chirality off for structural similarity.',conformer_diversity=conformer_rows),pocket_rows
