from __future__ import annotations
from pathlib import Path
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem

def aligned_rmsd(a,b):
    a=a-a.mean(0);b=b-b.mean(0);u,_,v=np.linalg.svd(a.T@b);r=u@np.diag([1,1,np.linalg.det(u@v)])@v
    return float(np.sqrt(np.mean(np.sum((a@r-b)**2,axis=1))))

def evaluate_strain(mol,fragment_ids,cfg,output_path):
    if not cfg['enabled']:return dict(status='disabled')
    q=Chem.AddHs(Chem.Mol(mol),addCoords=True);n=mol.GetNumAtoms();original=np.array(mol.GetConformer().GetPositions());props=None
    if AllChem.MMFFHasAllMoleculeParams(q):
        props=AllChem.MMFFGetMoleculeProperties(q,mmffVariant=cfg['variant']);name=cfg['variant']
        def ff():return AllChem.MMFFGetMoleculeForceField(q,props,nonBondedThresh=100.,ignoreInterfragInteractions=False)
    elif AllChem.UFFHasAllMoleculeParams(q):
        name='UFF'
        def ff():return AllChem.UFFGetMoleculeForceField(q,vdwThresh=100.,ignoreInterfragInteractions=False)
    else:return dict(status='unavailable',reason='MMFF94s and UFF parameters missing')
    f=ff()
    if f is None:return dict(status='unavailable',reason='Force field construction failed')
    initial_H_placement_energy=float(f.CalcEnergy())
    for i in range(n):f.AddFixedPoint(i)
    h_status=int(f.Minimize(maxIts=cfg['hydrogen_max_iterations']));raw=float(f.CalcEnergy());fixed=np.array(q.GetConformer().GetPositions())[:n]
    if not np.array_equal(fixed,original):
        if np.abs(fixed-original).max()>1e-8:raise ValueError('Hydrogen preparation moved original heavy atoms')
    f=ff();opt_status=int(f.Minimize(maxIts=cfg['max_iterations']));optimized=float(f.CalcEnergy());new=np.array(q.GetConformer().GetPositions())[:n];delta=raw-optimized
    cross=[]
    if fragment_ids is not None:
        for b in mol.GetBonds():
            i,j=b.GetBeginAtomIdx(),b.GetEndAtomIdx()
            if fragment_ids[i]==fragment_ids[j]:continue
            before=float(np.linalg.norm(original[i]-original[j]));after=float(np.linalg.norm(new[i]-new[j]));cross.append(dict(atoms=[i,j],before_A=before,after_A=after,absolute_change_A=abs(after-before)))
    Path(output_path).parent.mkdir(parents=True,exist_ok=True)
    with Chem.SDWriter(str(output_path)) as writer:writer.write(q)
    return dict(status='ok',forcefield=name,initial_added_H_energy_kcal_mol=initial_H_placement_energy,raw_pose_H_relaxed_energy_kcal_mol=raw,local_optimized_energy_kcal_mol=optimized,energy_drop_kcal_mol=delta,energy_drop_per_heavy_atom=delta/max(n,1),high_strain_diagnostic=delta/max(n,1)>cfg['high_strain_kcal_per_heavy_atom'],hydrogen_optimization_status=h_status,local_optimization_status=opt_status,local_optimization_converged=opt_status==0,iterations_limit=cfg['max_iterations'],
        heavy_atom_RMSD_no_alignment_A=float(np.sqrt(np.mean(np.sum((new-original)**2,axis=1)))),heavy_atom_RMSD_aligned_A=aligned_rmsd(new,original),cross_fragment_bond_changes=cross,
        significant_cross_bond_change=any(r['absolute_change_A']>cfg['significant_cross_bond_change_A'] for r in cross) if fragment_ids is not None else None,
        max_cross_fragment_bond_change_A=max((r['absolute_change_A'] for r in cross),default=None),diagnostic_optimized_sdf=str(Path(output_path).resolve()),
        interpretation='Original heavy atoms fixed during added-H relaxation. Full local minimization is diagnostic only, with unchanged graph, no receptor and no replacement of model output. Absolute energies are not comparable across molecules.')
