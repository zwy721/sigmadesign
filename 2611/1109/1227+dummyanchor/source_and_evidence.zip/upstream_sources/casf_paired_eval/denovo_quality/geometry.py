from __future__ import annotations
from collections import Counter,defaultdict
from itertools import combinations
import math
import numpy as np
from rdkit import Chem
from rdkit.Chem import rdDistGeom,rdMolTransforms
from .common import clean

GEOMETRY_CHECKS=['no_severe_internal_clash','bond_geometry_valid','angle_geometry_valid','ring_geometry_valid','torsion_geometry_valid']

def bounds_matrix(mol):
    bounds=rdDistGeom.GetMoleculeBoundsMatrix(mol,set15bounds=True,scaleVDW=True,doTriangleSmoothing=True,useMacrocycle14config=False)
    # Equivalent terminal conjugated atoms can exchange bond order (e.g. carboxylate).
    groups=defaultdict(list)
    for a in mol.GetAtoms():
        if a.GetAtomicNum() in [7,8] and a.GetDegree()==1:
            b=a.GetBonds()[0]
            if b.GetIsConjugated():groups[(a.GetNeighbors()[0].GetIdx(),a.GetAtomicNum())].append(a.GetIdx())
    for (center,z),ids in groups.items():
        if len(ids)<2:continue
        low=min(bounds[max(center,i),min(center,i)] for i in ids);high=max(bounds[min(center,i),max(center,i)] for i in ids)
        for i in ids:bounds[max(center,i),min(center,i)]=low;bounds[min(center,i),max(center,i)]=high
    return bounds

def ring_plane(xyz):
    centered=xyz-xyz.mean(0);_,_,v=np.linalg.svd(centered,full_matrices=False)
    return float(np.abs(centered@v[-1]).max())

def evaluate_geometry(mol,fragment_ids,cfg):
    xyz=np.asarray(mol.GetConformer().GetPositions());n=len(xyz);bounds=bounds_matrix(mol);topo=Chem.GetDistanceMatrix(mol)
    dist=np.linalg.norm(xyz[:,None]-xyz[None,:],axis=-1);pt=Chem.GetPeriodicTable();radii=np.array([pt.GetRvdw(a.GetAtomicNum()) for a in mol.GetAtoms()])
    checks={key:None for key in GEOMETRY_CHECKS};out={'status':'ok','coordinate_unit':'angstrom','heavy_atoms':n,'fragment_mapping_available':fragment_ids is not None}
    bonds=[]
    for b in mol.GetBonds():
        i,j=b.GetBeginAtomIdx(),b.GetEndAtomIdx();a,c=sorted([i,j]);low,high=float(bounds[c,a]),float(bounds[a,c]);d=float(dist[i,j]);nominal=(low+high)/2
        bad=d<low*(1-cfg['bond_bound_tolerance']) or d>high*(1+cfg['bond_bound_tolerance'])
        bonds.append(dict(atom_i=i,atom_j=j,elements=mol.GetAtomWithIdx(i).GetSymbol()+'-'+mol.GetAtomWithIdx(j).GetSymbol(),bond_type=str(b.GetBondType()),in_ring=b.IsInRing(),
            fragment_relation=('cross_fragment' if fragment_ids[i]!=fragment_ids[j] else 'within_fragment') if fragment_ids is not None else 'unavailable',
            distance_A=d,lower_bound_A=low,upper_bound_A=high,nominal_A=nominal,deviation_A=d-nominal,relative_deviation=abs(d-nominal)/max(nominal,1e-12),abnormal=bool(bad)))
    out['bonds']=bonds;out['bond_count']=len(bonds);out['abnormal_bond_count']=sum(b['abnormal'] for b in bonds);out['abnormal_bond_fraction']=out['abnormal_bond_count']/len(bonds) if bonds else 0.
    out['max_bond_deviation_A']=max((abs(b['deviation_A']) for b in bonds),default=0.);out['max_bond_length_A']=max((b['distance_A'] for b in bonds),default=None)
    for key,relation in [('cross_fragment','cross_fragment'),('within_fragment','within_fragment')]:
        subset=[b for b in bonds if b['fragment_relation']==relation]
        out[key+'_bond_count']=len(subset) if fragment_ids is not None else None;out[key+'_abnormal_bond_count']=sum(b['abnormal'] for b in subset) if fragment_ids is not None else None
        out[key+'_max_bond_deviation_A']=max((abs(b['deviation_A']) for b in subset),default=None)
    checks['bond_geometry_valid']=out['abnormal_bond_count']==0
    angles=[]
    for b in mol.GetAtoms():
        j=b.GetIdx()
        for i,k in combinations([a.GetIdx() for a in b.GetNeighbors()],2):
            a,c=sorted([i,k]);d=float(dist[i,k]);low=float(bounds[c,a]);high=float(bounds[a,c]);u,v=xyz[i]-xyz[j],xyz[k]-xyz[j]
            denom=np.linalg.norm(u)*np.linalg.norm(v);angle=math.degrees(math.acos(np.clip(float(u@v)/denom,-1,1))) if denom>1e-12 else None
            bad=angle is None or d<low*(1-cfg['angle_bound_tolerance']) or d>high*(1+cfg['angle_bound_tolerance'])
            angles.append(dict(atoms=[i,j,k],angle_deg=angle,hybridization=str(b.GetHybridization()),ring_center=b.IsInRing(),end_distance_A=d,lower_bound_A=low,upper_bound_A=high,abnormal=bool(bad)))
    out['angles']=angles;out['angle_count']=len(angles);out['abnormal_angle_count']=sum(r['abnormal'] for r in angles);checks['angle_geometry_valid']=out['abnormal_angle_count']==0
    clashes=[];severities=Counter();topologies=Counter();pair_counts=Counter();minimum=None
    for i in range(n):
        for j in range(i+1,n):
            t=int(topo[i,j]);d=float(dist[i,j])
            if t==1:continue
            kind='1-3' if t==2 else '1-4' if t==3 else 'disconnected' if t>n else '1-5_or_more';pair_counts[kind]+=1
            vdw=float(radii[i]+radii[j]);dg_lower=float(bounds[j,i]);local=t in [2,3];base=dg_lower if local else vdw
            ratio=d/max(base,1e-12);prefix='local' if local else 'nonlocal'
            def threshold(level):return cfg[f'{prefix}_{level}_lower_bound_ratio' if local else f'{prefix}_{level}_vdw_ratio']
            severity='severe' if ratio<threshold('severe') else 'moderate' if ratio<threshold('moderate') else 'mild' if ratio<threshold('mild') else None
            row=dict(atom_i=i,atom_j=j,topology=kind,distance_A=d,vdw_sum_A=vdw,vdw_overlap_A=vdw-d,vdw_distance_ratio=d/max(vdw,1e-12),DG_lower_A=dg_lower,effective_lower_bound_ratio=ratio,severity=severity,
                fragment_relation=('within_fragment' if fragment_ids[i]==fragment_ids[j] else 'cross_fragment') if fragment_ids is not None else 'unavailable')
            if minimum is None or ratio<minimum['effective_lower_bound_ratio']:minimum=row
            if severity:clashes.append(row);severities[severity]+=1;topologies[f'{kind}/{severity}']+=1
    clashes.sort(key=lambda r:r['effective_lower_bound_ratio']);out.update(clash_pairs=clashes[:cfg['max_pair_details']],clash_pair_details_truncated=len(clashes)>cfg['max_pair_details'],clash_severity_counts={k:severities[k] for k in ['severe','moderate','mild']},clash_topology_counts=dict(topologies),nonbonded_pair_counts=dict(pair_counts),worst_nonbonded_pair=minimum,severe_internal_clash_pairs=severities['severe'])
    checks['no_severe_internal_clash']=severities['severe']==0
    rings=[]
    for ring in mol.GetRingInfo().AtomRings():
        aromatic=all(mol.GetAtomWithIdx(i).GetIsAromatic() for i in ring);plane=ring_plane(xyz[list(ring)]) if len(ring)>=3 else None
        ring_set=set(ring);bad_bonds=[b for b in bonds if b['in_ring'] and b['atom_i'] in ring_set and b['atom_j'] in ring_set and b['abnormal']]
        rings.append(dict(atoms=list(ring),size=len(ring),aromatic=aromatic,max_plane_distance_A=plane,abnormal_bonds=len(bad_bonds),abnormal=bool(bad_bonds or (aromatic and plane>cfg['planarity_max_distance_A']))))
    out['rings']=rings;out['abnormal_ring_count']=sum(r['abnormal'] for r in rings);checks['ring_geometry_valid']=out['abnormal_ring_count']==0
    torsions=[]
    amide=Chem.MolFromSmarts('[O,S]=[C]-[N]-[!#1]')
    for ids in mol.GetSubstructMatches(amide):
        angle=rdMolTransforms.GetDihedralDeg(mol.GetConformer(),*ids);deviation=min(abs(angle),abs(180-abs(angle)))
        torsions.append(dict(atoms=list(ids),kind='amide_planarity',dihedral_deg=angle,planarity_deviation_deg=deviation,abnormal=bool(not math.isfinite(angle) or deviation>cfg['amide_max_planarity_deviation_deg'])))
    experimental=[]
    try:
        for t in rdDistGeom.GetExperimentalTorsions(mol):
            ids=list(t['atomIndices']);angle=rdMolTransforms.GetDihedralDeg(mol.GetConformer(),*ids)
            experimental.append(dict(atoms=ids,bond_index=t['bondIndex'],torsion_index=t['torsionIndex'],smarts=t['smarts'],angle_deg=angle))
    except Exception as e:out['experimental_torsion_error']=str(e)
    out['amide_torsions']=torsions;out['experimental_torsions']=experimental;out['abnormal_amide_torsion_count']=sum(t['abnormal'] for t in torsions);out['torsion_scope']='Heavy-atom amide planarity; ETKDG matched torsion angles are diagnostic. General rotor preference violations are not assigned a universal cutoff.'
    checks['torsion_geometry_valid']=out['abnormal_amide_torsion_count']==0
    return clean(out),checks
