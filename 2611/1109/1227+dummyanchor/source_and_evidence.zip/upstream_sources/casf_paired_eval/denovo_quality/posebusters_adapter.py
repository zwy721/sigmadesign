from __future__ import annotations
import copy,logging
from functools import lru_cache
import numpy as np
from rdkit import Chem
from .common import clean,conjunction

def test_names(config):
    return [(m.get('rename_outputs',{}).get(k,k+m.get('rename_suffix',''))).lower().replace(' ','_') for m in config['modules'] for k in m.get('chosen_binary_test_output',[])]

@lru_cache(maxsize=8)
def effective_config(mode,num_threads):
    from posebusters import PoseBusters
    if mode not in ['mol','dock']:raise ValueError('Primary de novo PoseBusters mode must be mol or dock; reference-identity modes are auxiliary only')
    config=copy.deepcopy(PoseBusters(config=mode,max_workers=0).config)
    for m in config['modules']:
        if m['function']=='energy_ratio':m.setdefault('parameters',{})['num_threads']=num_threads
    return config

def evaluate_posebusters(mol,protein_path,cfg):
    if not cfg['enabled']:return dict(status='disabled',tests={},all_pass=None,mol_all_pass=None)
    try:
        from posebusters import PoseBusters
        config=effective_config(cfg['mode'],cfg['energy_num_threads']);names=test_names(config)
        buster=PoseBusters(config=copy.deepcopy(config),max_workers=0)
        logging.getLogger('posebusters').setLevel(logging.WARNING)
    except Exception as e:return dict(status='unavailable',reason=str(e),tests={},all_pass=None,mol_all_pass=None)
    record={};errors=[]
    try:
        table=buster.bust(Chem.Mol(mol),mol_true=None,mol_cond=protein_path or None,full_report=True)
        record=clean(table.iloc[0].to_dict())
    except Exception as e:
        errors.append(str(e))
        # Preserve unaffected official module results if one module raises.
        for module in config['modules']:
            single=copy.deepcopy(config);single['modules']=[module]
            try:
                df=PoseBusters(config=single,max_workers=0).bust(Chem.Mol(mol),mol_cond=protein_path or None,full_report=True);record.update(clean(df.iloc[0].to_dict()))
            except Exception as error:errors.append(module['name']+': '+str(error))
    tests={k:(bool(record[k]) if isinstance(record.get(k),(bool,np.bool_)) else None) for k in names}
    mol_names=test_names(effective_config('mol',cfg['energy_num_threads']));mol_tests={k:tests.get(k) for k in mol_names}
    missing=[k for k,v in tests.items() if v is None]
    if missing:
        errors.append('Unavailable official outputs: '+','.join(missing))
        if 'internal_energy' in missing:errors.append('Energy ensemble / UFF calculation did not return a finite pass value; see raw energy fields and per-molecule log')
    return dict(status='ok' if not missing else 'partial',mode=cfg['mode'],reference_molecule_supplied=False,tests=tests,mol_tests=mol_tests,all_pass=conjunction(tests.values()),mol_all_pass=conjunction(mol_tests.values()),all_tests_evaluable=not missing,details=record,errors=errors,
        energy_note='Standard package thresholds and 50-conformer UFF reference ensemble, ETKDG randomSeed=42. Only num_threads is fixed to 1; no fast mode or energy skipping.')
