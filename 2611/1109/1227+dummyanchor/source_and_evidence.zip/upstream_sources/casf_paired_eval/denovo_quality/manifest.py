"""Adapters are separate from the generic molecule evaluator."""
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
from rdkit import Chem
from .common import write_json

def write_manifest(path,rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);keys=list(dict.fromkeys(k for r in rows for k in r))
    if path.suffix=='.json':write_json(path,rows)
    else:
        with path.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def build_switch(args):
    import torch  # Only the adapter needs the existing experiment's fixture format.
    root=Path(args.switch_root).resolve();inputs=Path(args.inputs_root).resolve();cohort=json.loads(Path(args.cohort).read_text());source=Path(cohort['source_root']);plan=json.loads((root/'plan.json').read_text());out=Path(args.output).resolve();rows=[]
    prepared={}
    if args.prepared_cohort:prepared={r['pocket']:r for r in json.loads(Path(args.prepared_cohort).read_text())}
    for pid in plan['ids']:
        fixture_path=source/'inputs'/pid/'fixture.pt';fixture=torch.load(fixture_path,map_location='cpu',weights_only=False);ctx=fixture['context'];reference=Path(ctx['ligand_path']).resolve();protein=Path(ctx['pdb_path']).resolve();meta=json.loads((inputs/pid/'meta.json').read_text())
        receptor=Path(args.receptors_root).resolve()/f'{pid}.pdbqt' if args.receptors_root else None;record=prepared.get(pid,{})
        rec_preparation={'source':'Existing casf_paired_eval receptor prepared before this evaluation','hydrogens':'Protein H ignored for heavy-atom clash tests; Vina uses existing PDBQT protonation','histidine_assumption':record.get('histidine_assumption'),'fallback':record.get('receptor_fallback',record.get('receptor_error')),'metadata':record}
        common=dict(receptor_id=pid,ligand_id=pid,protein_path=str(protein),reference_path=str(reference),receptor_pdbqt_path=str(receptor) if receptor and receptor.exists() else '',receptor_preparation=json.dumps(rec_preparation,ensure_ascii=False),box_center=json.dumps(meta['origin']))
        for seed in plan['seeds']:
            case=root/'cases'/f'{pid}_{seed}'
            for group,sub,spec,model in [
                ('A_predicted_t0.6',case/'switch_t0.6/predicted',case/'switch_t0.6/predicted_spec.json','legacy_prefix+official_SigmaDock_predicted_graph'),
                ('B_official_true_graph',case/'official_full',inputs/pid/'chemistry.json','official_SigmaDock_true_complete_graph')]:
                rows.append(dict(common,molecule_id=f'{group}__{pid}__{seed}__1',group=group,seed=seed,candidate_id='1',candidate_rank=1,sdf_path=str(sub/'final.sdf'),record_index=0,chemistry_spec_path=str(spec),record_path=str(sub/'result.json'),model_name=model,experiment_config=json.dumps({'source_plan':str(root/'plan.json'),'t_switch':.6 if group.startswith('A') else None,'NFE':100})))
        # Crystals are 12 distinct observations, not 36 seed-replicated controls.
        rows.append(dict(common,molecule_id=f'C_crystal__{pid}__experimental__1',group='C_crystal',seed='experimental',candidate_id='1',candidate_rank=1,sdf_path=str(reference),record_index=0,chemistry_spec_path='',record_path=str(fixture_path),model_name='experimental_crystal',experiment_config=json.dumps({'source':'original ligand SDF','fragment_mapping':'unavailable: no verified original crystal atom-order sidecar'})))
    write_manifest(out,rows);print(json.dumps({'manifest':str(out),'molecules':len(rows),'groups':{k:sum(r['group']==k for r in rows) for k in sorted({r['group'] for r in rows})}},ensure_ascii=False))

def build_directory(args):
    rows=[]
    for path in sorted(Path(args.sdf_directory).resolve().glob(args.pattern)):
        # Invalid records still receive stable IDs and are evaluated, not omitted.
        supplier=Chem.SDMolSupplier(str(path),sanitize=False,removeHs=False);n=max(len(supplier),1)
        for idx in range(n):
            rows.append(dict(molecule_id=f'{path.stem}__record_{idx}',receptor_id=args.receptor_id,ligand_id='',seed='',candidate_id=str(idx+1),group=args.group,sdf_path=str(path),record_index=idx,protein_path=str(Path(args.protein_path).resolve()) if args.protein_path else '',reference_path=str(Path(args.reference_path).resolve()) if args.reference_path else '',model_name=args.model_name))
    write_manifest(args.output,rows);print(f'Wrote {len(rows)} records to {args.output}')

def main():
    p=argparse.ArgumentParser(description='Create portable manifests; evaluation itself has no CASF path assumptions.');sub=p.add_subparsers(dest='adapter',required=True)
    s=sub.add_parser('switch');s.add_argument('--switch-root',required=True);s.add_argument('--inputs-root',required=True);s.add_argument('--cohort',required=True);s.add_argument('--receptors-root');s.add_argument('--prepared-cohort');s.add_argument('--output',required=True);s.set_defaults(func=build_switch)
    s=sub.add_parser('sdf-directory');s.add_argument('--sdf-directory',required=True);s.add_argument('--pattern',default='**/*.sdf');s.add_argument('--protein-path');s.add_argument('--reference-path');s.add_argument('--receptor-id',default='unspecified');s.add_argument('--group',default='generated');s.add_argument('--model-name',default='unspecified');s.add_argument('--output',required=True);s.set_defaults(func=build_directory)
    a=p.parse_args();a.func(a)
