from __future__ import annotations
import csv,json
from pathlib import Path
import numpy as np
from rdkit import Chem

PATH_FIELDS=['sdf_path','protein_path','reference_path','chemistry_spec_path','fragment_path','record_path','receptor_pdbqt_path']

def read_manifest(path):
    path=Path(path).resolve()
    if path.suffix.lower()=='.json':rows=json.loads(path.read_text());rows=rows.get('molecules',[]) if isinstance(rows,dict) else rows
    elif path.suffix.lower()=='.jsonl':rows=[json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    else:
        with path.open(newline='') as f:rows=list(csv.DictReader(f))
    seen=set()
    for row in rows:
        if not row.get('molecule_id'):raise ValueError('Every row needs a stable molecule_id')
        if row['molecule_id'] in seen:raise ValueError(f"Duplicate molecule_id: {row['molecule_id']}")
        seen.add(row['molecule_id']);row.setdefault('group','generated');row.setdefault('receptor_id','unspecified')
        if not row.get('sdf_path') and not row.get('smiles'):raise ValueError('Each row needs sdf_path or smiles')
        for key in PATH_FIELDS:
            if row.get(key):row[key]=str((path.parent/row[key]).resolve())
        row['record_index']=int(row.get('record_index') or 0)
    return rows

def spec_molecule(spec):
    """Read the project's explicit chemistry contract without network imports."""
    atoms={int(i):a for f in spec['fragments'] for i,a in zip(f['atom_ids'],f['atoms'])}
    if sorted(atoms)!=list(range(len(atoms))):raise ValueError('Spec must partition consecutive atom indices')
    rw=Chem.RWMol()
    for i in range(len(atoms)):
        data=atoms[i];a=Chem.Atom(int(data['z']));a.SetFormalCharge(int(data.get('charge',0)));a.SetIsotope(int(data.get('isotope',0)))
        a.SetChiralTag(Chem.ChiralType.values[int(data.get('chiral_tag',0))]);a.SetNumExplicitHs(int(data.get('explicit_hs',0)));a.SetNoImplicit(bool(data.get('no_implicit',False)))
        a.SetIsAromatic(bool(data.get('aromatic',False)));a.SetNumRadicalElectrons(int(data.get('radicals',0)));a.SetAtomMapNum(int(data.get('atom_map',0)));rw.AddAtom(a)
    bonds=sorted([b for f in spec['fragments'] for b in f['bonds']]+spec.get('connections',[]),key=lambda b:b['order'])
    for b in bonds:
        rw.AddBond(int(b['begin']),int(b['end']),Chem.BondType.values[int(b['bond_type'])]);bond=rw.GetBondBetweenAtoms(int(b['begin']),int(b['end']))
        bond.SetIsAromatic(bool(b.get('aromatic',False)));bond.SetIsConjugated(bool(b.get('conjugated',False)));bond.SetBondDir(Chem.BondDir.values[int(b.get('direction',0))])
    for b in bonds:
        bond=rw.GetBondBetweenAtoms(int(b['begin']),int(b['end']))
        if b.get('stereo_atoms'):bond.SetStereoAtoms(*map(int,b['stereo_atoms']))
        bond.SetStereo(Chem.BondStereo.values[int(b.get('stereo',0))])
    mol=rw.GetMol();Chem.SanitizeMol(mol);return mol

def load_molecule(row):
    info={'parse_success':False,'sanitize_success':None,'parse_error':None,'sanitize_error':None,'stereo_source':None,'fragment_mapping_available':False}
    raw=None
    try:
        if row.get('sdf_path'):
            supplier=Chem.SDMolSupplier(row['sdf_path'],sanitize=False,removeHs=False,strictParsing=True)
            if row['record_index']<0 or row['record_index']>=len(supplier):raise IndexError('SDF record_index out of range')
            raw=supplier[row['record_index']];info['stereo_source']='SDF as read; 3D stereo perception may occur'
        else:raw=Chem.MolFromSmiles(row['smiles'],sanitize=False);info['stereo_source']='explicit SMILES'
        if raw is None:raise ValueError('RDKit returned no molecule')
        info['parse_success']=True
    except Exception as e:info['parse_error']=str(e);return None,info,None
    mol=Chem.Mol(raw)
    try:Chem.SanitizeMol(mol);info['sanitize_success']=True
    except Exception as e:info['sanitize_success']=False;info['sanitize_error']=str(e);return raw,info,None
    fragment_ids=None
    if row.get('chemistry_spec_path'):
        try:
            spec=json.loads(Path(row['chemistry_spec_path']).read_text());declared=spec_molecule(spec)
            if mol.GetNumAtoms()!=declared.GetNumAtoms():raise ValueError('Spec/SDF atom count mismatch')
            if [a.GetAtomicNum() for a in mol.GetAtoms()]!=[a.GetAtomicNum() for a in declared.GetAtoms()]:raise ValueError('Spec/SDF atom order mismatch')
            def edges(m):return {tuple(sorted((b.GetBeginAtomIdx(),b.GetEndAtomIdx()))):str(b.GetBondType()) for b in m.GetBonds()}
            if edges(mol)!=edges(declared):raise ValueError('Spec/SDF chemistry differs')
            if mol.GetNumConformers():declared.AddConformer(Chem.Conformer(mol.GetConformer()),assignId=True)
            mol=declared;info['stereo_source']='original explicit chemistry spec; SDF geometry retained'
            fragment_ids=[None]*mol.GetNumAtoms()
            for f in spec['fragments']:
                for i in f['atom_ids']:fragment_ids[int(i)]=int(f['slot'])
            info['fragment_mapping_available']=True
        except Exception as e:info['declared_chemistry_error']=str(e);info['stereo_source']='unavailable: chemistry sidecar mismatch'
    elif row.get('fragment_path'):
        try:
            data=json.loads(Path(row['fragment_path']).read_text());fragment_ids=data.get('atom_fragment_ids') if isinstance(data,dict) else data
            if len(fragment_ids)!=mol.GetNumAtoms() or any(v is None for v in fragment_ids):raise ValueError('Invalid atom_fragment_ids')
            info['fragment_mapping_available']=True
        except Exception as e:info['fragment_mapping_error']=str(e);fragment_ids=None
    return mol,info,fragment_ids

def heavy_copy(mol,fragment_ids=None):
    indices=[a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum()>1]
    for a in mol.GetAtoms():a.SetIntProp('_quality_original_idx',a.GetIdx())
    heavy=Chem.RemoveHs(Chem.Mol(mol),sanitize=True)
    # RemoveHs can retain isotopic or exceptional H; exclude all atomic-number 1 explicitly.
    rw=Chem.RWMol(heavy)
    for idx in reversed([a.GetIdx() for a in rw.GetAtoms() if a.GetAtomicNum()<=1]):rw.RemoveAtom(idx)
    heavy=rw.GetMol();Chem.SanitizeMol(heavy)
    orig=[a.GetIntProp('_quality_original_idx') for a in heavy.GetAtoms()]
    return heavy,([fragment_ids[i] for i in orig] if fragment_ids is not None else None),orig

def has_coordinates(mol):
    return bool(mol is not None and mol.GetNumConformers() and mol.GetConformer().Is3D() and np.isfinite(mol.GetConformer().GetPositions()).all())
