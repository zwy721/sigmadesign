"""Geometry-only stereo derivation. No target or reference input accepted."""
import copy,json
import numpy as np
from rdkit import Chem
from rdkit.Chem import rdCIPLabeler,rdMolTransforms
from denovo_quality.chemistry import stereo_elements

PARAMETERS=dict(min_normalized_tetra_volume=.10,perturbation_sigma_A=.01,perturbations=16,max_double_planarity_deviation_deg=15.,seed=20261103)

def perceive(mol,xyz):
    q=Chem.Mol(mol);Chem.RemoveStereochemistry(q)
    for i,x in enumerate(xyz):q.GetConformer().SetAtomPosition(i,x.tolist())
    Chem.AssignStereochemistryFrom3D(q,replaceExistingTags=True);Chem.AssignStereochemistry(q,cleanIt=True,force=True);rdCIPLabeler.AssignCIPLabels(q)
    return q

def code(m,s):
    if s['type']=='Atom_Tetrahedral':
        a=m.GetAtomWithIdx(s['center']);return a.GetProp('_CIPCode') if a.HasProp('_CIPCode') else None
    b=m.GetBondWithIdx(s['center']);return str(b.GetStereo()) if b.GetStereo() in [Chem.BondStereo.STEREOE,Chem.BondStereo.STEREOZ,Chem.BondStereo.STEREOCIS,Chem.BondStereo.STEREOTRANS] else None

def derive(mol,spec):
    x=np.array(mol.GetConformer().GetPositions());p=PARAMETERS;rng=np.random.default_rng(p['seed']);q=perceive(mol,x);pert=[perceive(mol,x+rng.normal(0,p['perturbation_sigma_A'],x.shape)) for _ in range(p['perturbations'])];decisions=[]
    for s in stereo_elements(mol):
        s=dict(s);c=code(q,s);stable=c is not None and all(code(m,s)==c for m in pert);reasons=[]
        if not stable:reasons.append('missing_or_perturbation_unstable_CIP')
        if s['type']=='Atom_Tetrahedral':
            a=q.GetAtomWithIdx(s['center']);ids=[v.GetIdx() for v in a.GetNeighbors()];vectors=x[ids]-x[a.GetIdx()]
            if len(ids)==4:vectors=vectors[:3]-vectors[3]
            volume=abs(float(np.linalg.det(vectors)))/max(float(np.prod(np.linalg.norm(vectors,axis=1))),1e-12) if vectors.shape==(3,3) else 0.
            s['normalized_volume']=volume
            if volume<p['min_normalized_tetra_volume']:reasons.append('nearly_coplanar_or_degenerate')
            if reasons:q.GetAtomWithIdx(s['center']).SetChiralTag(Chem.ChiralType.CHI_UNSPECIFIED)
        else:
            b=q.GetBondWithIdx(s['center']);ids=list(b.GetStereoAtoms());dev=None
            if len(ids)==2:
                phi=rdMolTransforms.GetDihedralDeg(q.GetConformer(),ids[0],b.GetBeginAtomIdx(),b.GetEndAtomIdx(),ids[1]);dev=min(abs(phi),180-abs(phi))
            s['double_planarity_deviation_deg']=dev
            if dev is None or not np.isfinite(dev) or dev>p['max_double_planarity_deviation_deg']:reasons.append('double_geometry_not_planar_or_degenerate')
            if reasons:b.SetStereo(Chem.BondStereo.STEREONONE)
        s.update(geometry_CIP=c,reliable=not reasons,reasons=reasons);decisions.append(s)
    Chem.AssignStereochemistry(q,cleanIt=True,force=True);rdCIPLabeler.AssignCIPLabels(q)
    outspec=copy.deepcopy(spec)
    for f in outspec['fragments']:
        for i,data in zip(f['atom_ids'],f['atoms']):data['chiral_tag']=int(q.GetAtomWithIdx(i).GetChiralTag())
    for data in [b for f in outspec['fragments'] for b in f['bonds']]+outspec.get('connections',[]):
        b=q.GetBondBetweenAtoms(data['begin'],data['end']);data['stereo']=int(b.GetStereo());data['stereo_atoms']=list(b.GetStereoAtoms());data['direction']=int(b.GetBondDir())
    return q,outspec,dict(parameters=p,decisions=decisions,reliable=sum(d['reliable'] for d in decisions),unavailable=sum(not d['reliable'] for d in decisions),policy='Independent geometry-derived graph; original explicit graph retained; no target tags; not network stereo accuracy')
