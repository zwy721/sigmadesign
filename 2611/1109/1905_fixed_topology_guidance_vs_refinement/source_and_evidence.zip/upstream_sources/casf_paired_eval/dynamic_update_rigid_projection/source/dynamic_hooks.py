"""Explicit hooks around (never inside) unchanged reference transfer."""
from common import *
import torch
from joint_sampler import topology_key,chemical_graph
from vocab_chemistry import ChemistryRejected
from extract_events import changed_slots
from projection import worker,metadata,apply_to_state

MODE=None;POOL=None;CONFIG=None
SELECTED_GRAPHS={}

def configure(mode,pool,config):
    global MODE,POOL,CONFIG
    MODE,POOL,CONFIG=mode,pool,config
    SELECTED_GRAPHS.clear()

def saved_event(case,step):
    p=OUT/'events'/f'{case["pid"]}_{case["seed"]}_s{step:02d}'/'event.pt'
    return torch.load(p,weights_only=False,map_location='cpu') if p.exists() else None

def prepare(case,step,proposed):
    saved=saved_event(case,step) if MODE else None
    if MODE in ['Baseline','Projection_locked'] and saved is not None:return saved['entry']['new_labels'].copy()
    return proposed

def select(case,step,proposed,T,R,search,lib,state,event):
    saved=saved_event(case,step) if MODE else None
    if saved is not None:
        original=saved['entry'];event['historical_accepted']=original['accepted']
        if not original['accepted']:raise ChemistryRejected('historical_rejection_preserved: '+str(original['reason']))
        first=search['candidates'][0]['connections']
        event['unlocked_chemistry_matches_baseline']=topology_key(event.get('unlocked_proposed_labels',proposed),first)==topology_key(original['new_labels'],original['new_connections'])
        if MODE in ['Baseline','Projection_locked']:
            return original['new_connections']
    if MODE!='Feasibility':return search['candidates'][0]['connections']
    previous=state.physical();records=[];options=[]
    import orientation
    from runtime import Geometry
    for rank,candidate in enumerate(search['candidates'][:4]):
        nc=candidate['connections']
        try:
            g,groups,spec=get_graph(lib,proposed,nc,case,step)
            wanted=[]
            for i,label in enumerate(proposed):
                old=previous[state.pn+np.asarray(state.groups[i])]
                if label==case['labels'][i]:wanted.append(old.copy())
                else:
                    _,q=lib.template(label);wanted.append((q-q.mean(0))@R[i].T+old.mean(0))
            with torch.no_grad():replacement=orientation.construct_state(state.den,g,groups,'cuda:0',lib,proposed,desired=wanted,preferred=R)
            if max(replacement.transfer_errors,default=0)>.5:raise ChemistryRejected('Reference transfer fit exceeds frozen 0.5 A bound')
            x=replacement.physical()[replacement.pn:replacement.pn+sum(map(len,groups))]
            slots=changed_slots(case['labels'],proposed,case['connections'],nc)
            job=dict(spec=spec,context=case['context'],xyz=x,slots=slots,config=CONFIG,arm='D')
            options.append((rank,nc,g,groups,spec,POOL.submit(worker,job)))
        except (ChemistryRejected,ValueError,RuntimeError,AssertionError) as exc:records.append(dict(rank=rank,status='rejected',reason=repr(exc)))
    ranked=[]
    graphs={}
    for rank,nc,g,groups,spec,future in options:
        r=future.result();metrics=Geometry(spec,case['context']).metrics(r['xyz'])
        score=(metrics['cross_bond_MAE_A']/.15)**2+(metrics['cross_angle_MAE_deg']/15)**2+10*metrics['severe_cross_internal_pairs']+10*metrics['severe_protein_pairs']
        records.append(dict(rank=rank,status=r['status'],score=score,geometry=metrics,projection=metadata(r)))
        ranked.append((score,rank,nc))
        graphs[rank]=(g,groups,spec)
    event['candidate_geometry_evaluations']=sorted(records,key=lambda r:r['rank']);event['candidate_count']=len(search['candidates'][:4])
    if not ranked:raise ChemistryRejected('No candidate satisfies frozen transfer contract')
    _,rank,nc=min(ranked,key=lambda v:(v[0],v[1]));event['selected_candidate_rank']=rank
    SELECTED_GRAPHS[(case['pid'],case['seed'],step)]=graphs[rank]
    return nc

def get_graph(lib,proposed,nc,case,step):
    cached=SELECTED_GRAPHS.pop((case['pid'],case['seed'],step),None)
    if cached is not None:return cached
    saved=saved_event(case,step) if MODE else None
    if saved is not None and topology_key(proposed,nc)==topology_key(saved['entry']['new_labels'],saved['entry']['new_connections']):
        return saved['graph'].clone(),saved['groups'],saved['spec']
    return chemical_graph(lib,proposed,nc,case['context'],[None]*case['N'],seed=case['seed'])

def project_items(active,step,fulltime=False):
    if MODE is None or MODE=='Baseline':return
    if fulltime and MODE!='Full_guidance':return
    if not fulltime and MODE=='Full_guidance':return
    work=[]
    for item in active:
        event=item['record']['events'][-1] if item['record']['events'] else None
        if not fulltime and (event is None or event['step']!=step or not event['accepted']):continue
        c,s=item['case'],item['state'];n=item['geometry'].mol.GetNumAtoms();x=s.physical()[s.pn:s.pn+n]
        slots=list(range(c['N'])) if fulltime else changed_slots(event['old_labels'],event['new_labels'],event['old_connections'],event['new_connections'])
        job=dict(spec=c['spec'],context=c['context'],xyz=x,slots=slots,config=CONFIG,arm='D')
        work.append((item,x,POOL.submit(worker,job)))
    for item,x,future in work:
        result=future.result();apply_to_state(item['state'],result)
        record=dict(step=step,mode=MODE,kind='fulltime_after_network' if fulltime else 'after_accepted_update',stage='local_projection',**metadata(result))
        item['record'].setdefault('projections',[]).append(record)
        if not fulltime:item['record']['events'][-1]['projection']=record
        folder=item['folder']/'projections';folder.mkdir(exist_ok=True)
        np.savez_compressed(folder/f'step_{step:02d}_{"full" if fulltime else "update"}.npz',native_before_projection=x,local_projection=item['state'].physical()[item['state'].pn:item['state'].pn+len(x)])
