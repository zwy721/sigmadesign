from common import *
import torch
from run_validation import load_official
from stable_precision import install
from vocab_chemistry import VocabLibrary
from event_experiment import validate_reconstruction

if __name__=='__main__':
    torch.set_num_threads(2);torch.cuda.set_device(0)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.use_deterministic_algorithms(True)
    den=load_official(bootstrap.CHECKPOINT,OUT/'cache/official','cuda:0');install(den)
    validate_reconstruction(den,VocabLibrary())
