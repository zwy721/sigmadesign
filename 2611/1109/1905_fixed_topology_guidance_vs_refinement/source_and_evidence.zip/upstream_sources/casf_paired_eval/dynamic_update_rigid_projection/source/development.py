from common import *
import copy,itertools
import torch
from runtime import Geometry
from projection import worker,metadata
from extract_events import initial,changed_slots
import run_experiment as rx
import dynamic_hooks

def candidates():
    result=[]
    # Predeclared finite grid: no formal-case performance is consulted.
    for iterations in [5,10,20]:
        for name,t,r,w in [('small',.2,.12,[1.,1.,10.,10.,.05]),('balanced',.35,.2,[1.,1.,20.,20.,.03]),('strong',.5,.3,[1.,1.,40.,40.,.02])]:
            result.append(dict(name=f'{name}_{iterations}',iterations=iterations,learning_rate=.02,step_translation_A=.04,step_rotation_rad=.02,max_translation_A=t,max_rotation_rad=r,weights=w,movable_scope='changed slots only',protein_guard='no new severe atom pair; no worse maximum overlap',one_four='0.7 x frozen RDKit DG lower bound; exclude 1-2 and 1-3',nonlocal_clash='0.6 x VDW sum',translation_normalization_A=t,rotation_normalization_rad=r))
    return result

def select(den,client,search_pool,projection_pool,lib):
    path=OUT/'frozen_projection.json'
    if path.exists():
        selected=load(path);assert selected['development_sha256']==sha256(OUT/'development_selection.json');return selected['config']
    gridpath=OUT/'development_grid.json';grid=candidates()
    if gridpath.exists():assert load(gridpath)==grid
    else:dump(gridpath,grid)
    cases=[initial(row,dev=True) for row in load(OUT/'protocol.json')['development']]
    for c in cases:c['role']='development/b6'
    dynamic_hooks.configure(None,None,None)
    records=rx.run_batch(cases,'C',den,client,search_pool,lib,tag='Baseline')
    jobs=[];events=[]
    for c,rec in zip(cases,records):
        for e in rec['events']:
            if not e['accepted']:continue
            # Dev graph may be rebuilt with its own recorded reference, just as
            # event extraction does. Labels/order/stereo stay exactly fixed.
            from vocab_chemistry import assemble_slots,spec_from_slots
            from rdkit import Chem
            mol,groups,cuts=assemble_slots(lib,e['proposed_labels'],e['proposed_connections'],oov=[None]*c['N']);conf=Chem.Conformer(mol.GetNumAtoms())
            for group,a in zip(groups,e['reference_transfer_orientation']):
                for atom,x in zip(group,a['source_reference_coordinates']):conf.SetAtomPosition(int(atom),x)
            mol.RemoveAllConformers();mol.AddConformer(conf);spec=spec_from_slots(mol,groups,cuts,e['proposed_labels'],'recorded dev reference')
            x=np.load(Path(rec['folder'])/f'event_{e["step"]:02d}/proposal_transfer.npz')['actual_xyz']
            events.append(dict(pid=c['pid'],seed=c['seed'],step=e['step'],spec=spec,context=c['context'],xyz=x,slots=changed_slots(e['old_labels'],e['proposed_labels'],e['old_connections'],e['proposed_connections'])))
    assert events,'No accepted development events'
    for config in grid:
        for e in events:
            job={k:e[k] for k in ['spec','context','xyz','slots']};job.update(config=config,arm='D')
            jobs.append((config,e,projection_pool.submit(worker,job)))
    results=[]
    for config,e,future in jobs:
        r=future.result();g=Geometry(e['spec'],e['context']);m=g.metrics(r['xyz'])
        # Denominators include unavailable or failed optimizations as penalties.
        score=(m['cross_bond_MAE_A']/.15)**2+(m['cross_angle_MAE_deg']/15)**2+10*m['severe_cross_internal_pairs']+10*m['severe_protein_pairs']+.1*r.get('core_RMSD_A',0.)/.5
        if r['status']=='fallback':score+=1000
        results.append(dict(config=config['name'],pid=e['pid'],seed=e['seed'],step=e['step'],score=score,metrics=m,projection=metadata(r)))
    summaries=[dict(name=config['name'],mean_score=float(np.mean([v['score'] for v in results if v['config']==config['name']])),events=len(events)) for config in grid]
    best=min(range(len(grid)),key=lambda i:(summaries[i]['mean_score'],i));selection=dict(development_cases=6,accepted_events=len(events),rejected_events=24-len(events),rule='mean same-event postprojection geometry score + 0.1 RMSD/0.5A; fallback +1000; tie grid ordinal',grid=grid,summaries=summaries,selected=grid[best],results=results,formal_case_metrics_used=False)
    dump(OUT/'development_selection.json',selection)
    dump(path,dict(config=grid[best],development_sha256=sha256(OUT/'development_selection.json'),grid_sha256=sha256(gridpath),formal_case_metrics_used=False))
    print('DEVELOPMENT SELECTED',grid[best]['name'],summaries,flush=True)
    return grid[best]
