"""Exact recorded-reference reconstruction and locked-chemistry continuations."""
from common import *
import copy,time
import torch
from runtime import BatchEngine,Geometry,SCALE
from random_frames import attach
from joint_sampler import NativeState
from run_validation import seed_all
from projection import worker,metadata,apply_to_state
import orientation

def event_state(saved,den,lib):
    e=saved['entry'];case=dict(saved['case'],graph=saved['graph'],spec=saved['spec'],groups=saved['groups'],labels=e['new_labels'],connections=e['new_connections'])
    data=np.load(OUT/'events'/e['event_id']/'stages.npz');wanted=[np.asarray(a['wanted_coordinates']) for a in e['historical']['reference_transfer_orientation']]
    seed_all(case['seed'])
    with torch.no_grad():
        s=orientation.construct_state(den,saved['graph'],saved['groups'],'cuda:0',lib,e['new_labels'],desired=wanted,preferred=data['R'])
        # C/Q are recorded physical state variables, not refitted coordinates.
        s.C=torch.as_tensor(data['C'],device='cuda:0');s.Q=torch.as_tensor(data['Q'],device='cuda:0')
        s.pos=den._apply_transformations(s.pos0,s.batch,s.T0,s.R0,s.Q,s.C)
    s.base=s.batch.to_data_list()[0];attach(s,case,step=e['step'])
    x=s.physical()[s.pn:s.pn+len(data['actual_xyz'])];delta=np.linalg.norm(x-data['actual_xyz'],axis=-1)
    assert delta.max()<.0002,('Recorded state reconstruction failed',e['event_id'],float(delta.max()))
    return s,case,float(delta.max())

def validate_reconstruction(den,lib):
    target=OUT/'event_replay_verification.json'
    if target.exists():assert load(target)['passed'];return
    rows=[];grid=(1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3
    inventory=load(OUT/'event_inventory.json')['events'];accepted=[e for e in inventory if e['accepted']]
    for step in [5,10,15,20]:
        entries=[e for e in accepted if e['step']==step];states=[]
        for e in entries:
            saved=torch.load(OUT/'events'/e['event_id']/'event.pt',weights_only=False,map_location='cpu')
            s,c,error=event_state(saved,den,lib);states.append(s)
            rows.append(dict(event_id=e['event_id'],T0_max_delta_A=error))
        engine=BatchEngine(den);engine.step(states,grid[step],grid[step]-grid[step+1])
        for e,s,r in zip(entries,states,rows[-len(entries):]):
            src=Path(e['source_event']).parent/'after_next_network.npz';old=np.load(src)['xyz'];x=s.physical()[s.pn:s.pn+len(old)]
            d=np.linalg.norm(x-old,axis=-1);r.update(first_step_max_delta_A=float(d.max()),first_step_RMSD_A=float(np.sqrt(np.mean(d*d))))
            assert d.max()<=.025 and r['first_step_RMSD_A']<=.005,('First-step replay gate',r)
        print('REPLAY',step,len(entries),max(r['first_step_max_delta_A'] for r in rows[-len(entries):]),flush=True)
    dump(target,dict(passed=True,events=len(rows),rows=rows,note='Recorded reference graph and C/Q; same semantic random keys; graph locked after event. Later historical topology changes are not replayed.'))

def run_locked(den,lib,projection_pool,config):
    if (OUT/'locked_event_results.json').exists():
        old=load(OUT/'locked_event_results.json');assert len(old['paired_runs'])==484;return old['paired_runs']
    inventory=load(OUT/'event_inventory.json')['events'];accepted=[e for e in inventory if e['accepted']]
    allrows=[];trajectory=[];performance=[]
    grid=(1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3
    for step in [5,10,15,20]:
        entries=[e for e in accepted if e['step']==step]
        for arm in ['A','B','C','D']:
            items=[];futures=[];start=time.perf_counter()
            for e in entries:
                folder=OUT/'locked_events'/e['event_id']/arm
                if (folder/'result.json').exists():
                    r=load(folder/'result.json');allrows.append(r);trajectory.extend(load(folder/'trajectory.json'));continue
                folder.mkdir(parents=True,exist_ok=True)
                saved=torch.load(OUT/'events'/e['event_id']/'event.pt',weights_only=False,map_location='cpu');s,c,error=event_state(saved,den,lib)
                geom=Geometry(c['spec'],c['context']);xyz=s.physical()[s.pn:s.pn+geom.mol.GetNumAtoms()]
                job=dict(spec=c['spec'],context=c['context'],xyz=xyz,slots=e['changed_slots'],config=config,arm=arm)
                futures.append(projection_pool.submit(worker,job));items.append(dict(e=e,s=s,case=c,geom=geom,folder=folder,T0=geom.metrics(xyz),xyz0=xyz,old_distances=[np.linalg.norm(xyz[g][:,None]-xyz[g][None,:],axis=-1) for g in c['groups']],trajectory=[]))
            for item,future in zip(items,futures):
                result=future.result();apply_to_state(item['s'],result);item['projection']=metadata(result)
                x=item['s'].physical()[item['s'].pn:item['s'].pn+len(result['xyz'])];item['xyz1']=x;item['T1']=item['geom'].metrics(x)
                np.savez_compressed(item['folder']/'T0_T1.npz',native_after_graph_transfer=item['xyz0'],local_projection=x)
            engine=BatchEngine(den)
            for current in range(step,24):
                engine.step([v['s'] for v in items],grid[current],grid[current]-grid[current+1])
                for item in items:
                    s=item['s'];x=s.physical()[s.pn:s.pn+len(item['xyz0'])]
                    delta=max(float(np.max(np.abs(np.linalg.norm(x[g][:,None]-x[g][None,:],axis=-1)-d))) for g,d in zip(item['case']['groups'],item['old_distances']))
                    assert delta<=.0002,('Rigid invariant',item['e']['event_id'],arm,current,delta)
                    tr=dict(event_id=item['e']['event_id'],arm=arm,update_step=step,step=current,stage='native_after_remaining_denoising',metrics=item['geom'].metrics(x),internal_distance_delta_A=delta)
                    item['trajectory'].append(tr)
            for item in items:
                e=item['e'];s=item['s'];x=s.physical()[s.pn:s.pn+len(item['xyz0'])]
                r=dict(event_id=e['event_id'],pid=e['pid'],seed=e['seed'],step=step,t=e['t'],update_type=e['update_type'],arm=arm,accepted=True,
                    spec_sha256=e['proposed_spec_sha256'],T0=item['T0'],T1=item['T1'],T2=item['geom'].metrics(x),projection=item['projection'],remaining_steps=24-step,
                    T1_stage='local_projection' if arm!='A' else 'native_after_graph_transfer',T2_stage='native_after_remaining_denoising',
                    T2_RMSD_from_T0_A=float(np.sqrt(np.mean(np.sum((x-item['xyz0'])**2,axis=-1)))),T2_RMSD_from_T1_A=float(np.sqrt(np.mean(np.sum((x-item['xyz1'])**2,axis=-1)))))
                np.savez_compressed(item['folder']/'T2.npz',xyz=x,C=s.C.cpu().numpy(),Q=s.Q.cpu().numpy())
                dump(item['folder']/'trajectory.json',item['trajectory']);dump(item['folder']/'result.json',r);allrows.append(r);trajectory.extend(item['trajectory'])
            perf=dict(update_step=step,arm=arm,events=len(items),wall_seconds=time.perf_counter()-start,network=engine.timings,forward_calls=engine.calls,oom=engine.oom)
            performance.append(perf);dump(OUT/'locked_events'/f'performance_s{step}_{arm}.json',perf)
            print('LOCKED COMPLETE',step,arm,len(items),round(perf['wall_seconds'],2),flush=True)
    assert len(allrows)==484
    # Rejections have no valid accepted replacement state; do not invent a T2.
    rejected=[dict(event_id=e['event_id'],pid=e['pid'],seed=e['seed'],step=e['step'],accepted=False,reason=e['reason'],update_type=e['update_type'],historical=e['historical']) for e in inventory if not e['accepted']]
    dump(OUT/'locked_event_results.json',dict(accepted_events=121,rejected_events=rejected,paired_runs=allrows,performance=performance))
    csvwrite(OUT/'PER_UPDATE_RESULTS.csv',allrows+rejected);csvwrite(OUT/'PROJECTION_TRAJECTORY.csv',trajectory)
    return allrows

def save_trajectory_evidence(den,lib,pool,config):
    """Save complete C/Q/core trajectories and verify the historical interval.

    This independently repeats each continuation from recorded T0; matching
    saved T1/T2 is required before accepting the added trajectory evidence.
    """
    target=OUT/'event_trajectory_verification.json'
    if target.exists():assert load(target)['passed'];return
    inventory=load(OUT/'event_inventory.json')['events'];rows=[]
    grid=(1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3
    for step in [5,10,15,20]:
        entries=[e for e in inventory if e['accepted'] and e['step']==step]
        for arm in ['A','B','C','D']:
            items=[]
            for e in entries:
                folder=OUT/'locked_events'/e['event_id']/arm;record=load(folder/'result.json')
                saved=torch.load(OUT/'events'/e['event_id']/'event.pt',weights_only=False,map_location='cpu');s,c,error=event_state(saved,den,lib)
                x=s.physical()[s.pn:s.pn+sum(map(len,c['groups']))]
                job=dict(spec=c['spec'],context=c['context'],xyz=x,slots=e['changed_slots'],config=config,arm=arm)
                nextstep=min([v['step'] for v in inventory if v['pid']==e['pid'] and v['seed']==e['seed'] and v['accepted'] and v['step']>step]+[24])
                items.append(dict(e=e,s=s,folder=folder,future=pool.submit(worker,job),nextstep=nextstep,interval_max_delta_A=0.))
            for item in items:
                r=item['future'].result();apply_to_state(item['s'],r);s=item['s'];old=np.load(item['folder']/'T0_T1.npz')['local_projection'];x=s.physical()[s.pn:s.pn+len(old)]
                assert np.max(np.linalg.norm(x-old,axis=-1))<2e-4,'T1 repeat mismatch'
                (item['folder']/'trajectory').mkdir(exist_ok=True)
            engine=BatchEngine(den)
            for current in range(step,24):
                engine.step([item['s'] for item in items],grid[current],grid[current]-grid[current+1])
                for item in items:
                    s=item['s'];n=len(np.load(item['folder']/'T2.npz')['xyz']);x=s.physical()[s.pn:s.pn+n]
                    np.savez_compressed(item['folder']/f'trajectory/step_{current:02d}.npz',xyz=x,C=s.C.cpu().numpy(),Q=s.Q.cpu().numpy())
                    if arm=='A' and current<item['nextstep']:
                        old=np.load(Path(item['e']['source_trajectory'])/f'step_{current:02d}.npz')['xyz'];delta=float(np.linalg.norm(x-old,axis=-1).max())
                        item['interval_max_delta_A']=max(item['interval_max_delta_A'],delta);assert delta<=.025,'Historical interval replay failed'
            for item in items:
                s=item['s'];old=np.load(item['folder']/'T2.npz')['xyz'];x=s.physical()[s.pn:s.pn+len(old)];delta=float(np.linalg.norm(x-old,axis=-1).max())
                assert delta<=.025,'T2 repeat mismatch'
                rows.append(dict(event_id=item['e']['event_id'],arm=arm,T2_repeat_max_delta_A=delta,historical_interval_end_exclusive=item['nextstep'],historical_interval_max_delta_A=item['interval_max_delta_A'] if arm=='A' else None))
            print('EVENT TRAJECTORY SAVED',step,arm,len(items),flush=True)
    dump(target,dict(passed=True,paired_continuations=len(rows),rows=rows,all_C_Q_and_core_coordinates_saved=True))
