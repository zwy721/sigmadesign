"""Evidence-derived reports; no parameter selection from formal outcomes."""
from common import *
from collections import Counter,defaultdict
from datetime import datetime,timezone
import math
import torch
from joint_sampler import topology_key
from denovo_quality.geometry import evaluate_geometry

KEYS=['cross_bond_MAE_A','cross_angle_MAE_deg','severe_cross_internal_pairs','severe_protein_pairs']

def mean(values):
    values=[v for v in values if v is not None and math.isfinite(v)]
    return float(np.mean(values)) if values else None

def fmt(value,n=4):return 'unavailable' if value is None else f'{value:.{n}f}'

def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])+'\n'

def put(name,text):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.rstrip()+'\n')

def enrich_events(data):
    cache=OUT/'event_frozen_geometry.json'
    if cache.exists():return load(cache)
    cfg=load_config(OUT/'quality_config.json')['geometry'];rows=[]
    from oracle_graph import assemble
    for r in data['paired_runs']:
        folder=OUT/'locked_events'/r['event_id']/r['arm'];saved=torch.load(OUT/'events'/r['event_id']/'event.pt',weights_only=False,map_location='cpu');spec=saved['spec'];mol=assemble(spec)
        fids=np.empty(mol.GetNumAtoms(),dtype=int)
        for i,g in enumerate(saved['groups']):fids[g]=i
        initial=np.load(folder/'T0_T1.npz');xyzs=dict(T0=initial['native_after_graph_transfer'],T1=initial['local_projection'],T2=np.load(folder/'T2.npz')['xyz'])
        extra={}
        for stage,x in xyzs.items():
            for i,p in enumerate(x):mol.GetConformer().SetAtomPosition(i,p.tolist())
            details,checks=evaluate_geometry(mol,fids,cfg)
            extra[stage]=dict(HQ_severe_internal_pairs=details['severe_internal_clash_pairs'],HQ_geometry_checks=checks,abnormal_bonds=details['abnormal_bond_count'],abnormal_angles=details['abnormal_angle_count'])
        r=dict(r,frozen_geometry=extra);rows.append(r)
    dump(cache,rows);return rows

def generate():
    protocol=load(OUT/'protocol.json');config=load(OUT/'frozen_projection.json')['config'];data=load(OUT/'locked_event_results.json');events=enrich_events(data)
    historical_events=[e['historical'] for e in load(OUT/'event_inventory.json')['events'] if e['accepted']]
    intended_bond=mean([e['proposed_topology_before_transfer']['cross_bond_MAE_A'] for e in historical_events])
    actual_bond=mean([e['proposed_topology_after_transfer']['cross_bond_MAE_A'] for e in historical_events])
    transfer_RMSD=mean([e['transfer_target_RMSD_A'] for e in historical_events])
    generation=load(OUT/'generation_inventory.json')['records'];qrows=[];details=[];by=defaultdict(list);failures=[]
    required=load_config(OUT/'quality_config.json')['quality']['required_checks']
    for rec in generation:
        q=load(Path(rec['folder'])/'quality_complete.json');mode=rec['strategy'];assert q['input_unchanged']
        baseline_path=OUT/'full32/b32/structures'/f'{rec["receptor_id"]}_{rec["seed"]}_Baseline/result.json';base=load(baseline_path)
        same=topology_key(rec['labels'],rec['connections'])==topology_key(base['labels'],base['connections']);rmsd=None
        if same:
            a=np.load(Path(rec['folder'])/'trajectory/step_23.npz')['xyz'];b=np.load(Path(base['folder'])/'trajectory/step_23.npz')['xyz']
            # Full-time guidance is applied after this raw-network snapshot.
            if mode=='Full_guidance':a=np.load(Path(rec['folder'])/'projections/step_23_full.npz')['local_projection']
            if a.shape==b.shape:rmsd=float(np.sqrt(np.mean(np.sum((a-b)**2,axis=-1))))
        divergence=next((e['step'] for e in rec['events'] if e.get('unlocked_chemistry_matches_baseline') is False),None)
        projections=rec.get('projections',[])
        for m in q['metrics']:
            stage=m['metadata']['group'];ch=m['checks'];declared=q['declared_stereo'].get(stage,{})
            geometry=rec['final_geometry'] if stage=='native_final' else None
            if stage=='posthoc_MMFF_repair' and not q['repair_errors']:
                from rdkit import Chem
                from runtime import Geometry
                repaired=next(x for x in Chem.SDMolSupplier(str(Path(rec['folder'])/stage/'raw.sdf'),removeHs=False) if x is not None)
                geometry=Geometry(rec['spec'],dict(pdb_path=rec['context_pdb'])).metrics(repaired.GetConformer().GetPositions())
            row=dict(pid=rec['receptor_id'],seed=rec['seed'],mode=mode,stage='native_after_remaining_denoising' if stage=='native_final' else stage,
                algorithm_stage='network_only' if mode=='Baseline' and stage=='native_final' else 'end_only_optimizer' if stage!='native_final' else 'explicit_projection_plus_network',
                high_quality=ch.get('high_quality') is True,posebusters_all_pass=ch.get('posebusters_all_pass'),checks=ch,declared_checks=declared.get('checks'),
                final_geometry=geometry,same_final_chemistry_as_baseline=same,paired_final_RMSD_A=rmsd if stage=='native_final' else None,first_unlocked_prediction_divergence_step=divergence,
                projections=len(projections),projected=sum(v['status']=='projected' for v in projections),fallbacks=sum(v['status']=='fallback' for v in projections),
                projection_seconds=sum(v['seconds'] for v in projections),maximum_single_projection_RMSD_A=max((v.get('core_RMSD_A',0.) for v in projections),default=0.),
                batch_wall_seconds=rec['batch_wall_seconds'],failed_checks=m['failed_checks'],unavailable_checks=m['unavailable_checks'],errors=m['errors'],input_unchanged=m['input_unchanged'],folder=rec['folder'])
            qrows.append(row);by[(mode,stage)].append(row);details.append(m)
            if not row['high_quality']:failures.append(dict(pid=row['pid'],seed=row['seed'],mode=mode,stage=stage,failed_checks=row['failed_checks'],unavailable_checks=row['unavailable_checks'],errors=row['errors']))
    assert len(by[('Baseline','native_final')])==32 and len(qrows)==192
    summary=[]
    for (mode,stage),rs in by.items():
        summary.append(dict(mode=mode,stage=stage,attempts=len(rs),HQ=sum(r['high_quality'] for r in rs),PB=sum(r['posebusters_all_pass'] is True for r in rs),
            bond_MAE_A=mean([r['final_geometry']['cross_bond_MAE_A'] for r in rs if r['final_geometry']]),
            angle_MAE_deg=mean([r['final_geometry']['cross_angle_MAE_deg'] for r in rs if r['final_geometry']]),
            internal_pairs=mean([r['final_geometry']['severe_cross_internal_pairs'] for r in rs if r['final_geometry']]),
            protein_pairs=mean([r['final_geometry']['severe_protein_pairs'] for r in rs if r['final_geometry']]),
            declared_stereo_defined=sum((r.get('declared_checks') or {}).get('stereo_definition_complete') is True for r in rs),
            declared_stereo_consistent=sum((r.get('declared_checks') or {}).get('stereo_geometry_consistent') is True for r in rs),
            same_final_chemistry=sum(r['same_final_chemistry_as_baseline'] for r in rs),unavailable_attempts=sum(bool(r['unavailable_checks']) for r in rs)))
    event_summary=[]
    for arm in ['A','B','C','D']:
        rs=[r for r in events if r['arm']==arm]
        for stage in ['T0','T1','T2']:
            event_summary.append(dict(arm=arm,stage=stage,events=len(rs),**{k:mean([r[stage][k] for r in rs]) for k in KEYS},HQ_severe_internal_pairs=mean([r['frozen_geometry'][stage]['HQ_severe_internal_pairs'] for r in rs])))
    csvwrite(OUT/'PAIRED_GENERATION_RESULTS.csv',qrows);csvwrite(OUT/'QUALITY_CHECKS.csv',[dict(pid=r['pid'],seed=r['seed'],mode=r['mode'],stage=r['stage'],**r['checks']) for r in qrows])
    csvwrite(OUT/'PER_UPDATE_RESULTS.csv',[dict(event_id=r['event_id'],arm=r['arm'],accepted=True,step=r['step'],update_type=r['update_type'],spec_sha256=r['spec_sha256'],
        **{f'{s}_{k}':r[s][k] for s in ['T0','T1','T2'] for k in KEYS},**{f'{s}_HQ_severe_internal_pairs':r['frozen_geometry'][s]['HQ_severe_internal_pairs'] for s in ['T0','T1','T2']},projection=r['projection'],T2_RMSD_from_T0_A=r['T2_RMSD_from_T0_A']) for r in events]+data['rejected_events'])
    dump(OUT/'failure_cases.json',dict(generation_HQ_failures=failures,historical_rejected_events=data['rejected_events'],projection_fallbacks=[r for r in events if r['projection']['status']=='fallback']))
    dump(OUT/'summary.json',dict(full_generation=summary,events=event_summary,config=config,accepted_events=121,rejected_events=7,denominators=dict(event_pairs=484,full32_attempts=160,posthoc_reference=32,development_cases=6,precheck_generated=80)))
    put('RIGID_PROJECTION_METHOD.md',f'''# Constrained rigid projection method

## Frozen setup

Nine profiles (5/10/20 iterations × three bounded weight/cap settings) were compared only on six disjoint development-pocket cases, containing 23 accepted update events and one rejected event. The minimum mean predeclared geometry-plus-displacement score selected `{config['name']}`. All 32 stress cases were excluded from parameter selection. `development_grid.json`, `development_selection.json`, `frozen_projection.json` retain every candidate and result.

Selected limits: {config['iterations']} iterations; per-step translation {config['step_translation_A']} Å and actual relative rotation {config['step_rotation_rad']} rad; cumulative translation {config['max_translation_A']} Å and rotation {config['max_rotation_rad']} rad about each T0 real-core centroid. Cumulative limits restart only at a separately recorded projection invocation. Full-time guidance therefore has more invocations; its total drift is not bounded by a single invocation's cap.

## Variables and energy

Only changed identity slots and endpoints of changed connections may move. There is no neighbor expansion selected in this run. Rigid SO(3) matrix exponentials and translations move existing fragment nodes together; protein and unrelated fragments remain fixed. Real-core atoms alone define the objective. MMFF94s predicted-graph equilibrium parameters define cross-fragment bonds and angles. Bond errors are normalized by 0.15 Å; angle cosine errors by 0.25. Repulsive overlaps are squared and summed per real atom. The displacement prior separately normalizes translation by {config['max_translation_A']} Å and rotation by {config['max_rotation_rad']} rad.

Weights `[bond, angle, internal, protein, displacement]` are `{config['weights']}`. B enables only bonds/angles; C adds internal repulsion; D adds protein and displacement. The hard protein safeguard applies to all three to avoid new severe pairs or worsening maximum overlap. 1–2/1–3 pairs are excluded from repulsion; 1–4 use the frozen local DG lower bound; longer pairs use VDW bounds. This is not a full MMFF potential and does not include independent rotor-energy optimization.

## Solver and safety

Float64 CPU gradients drive bounded descent with five fixed backtracking factors. Each step must lower the enabled objective. SO(3) determinants/orthogonality, finite values, internal-distance preservation, step/cumulative motion and protein safety are checked. Unavailable MMFF parameters or numerical exceptions retain T0 and an explicit reason. A safe point can remain imperfect when caps or the protein guard prevent further descent; this is recorded, not treated as geometric success. Caches retain unchanged protein data; eight worker processes parallelize independent projections. State C/Q and existing helper nodes receive the same rigid transform without editing chemistry or reference transfer.

## Paired regimes and stage labels

All 121 accepted historical events receive A/B/C/D on identical complete chemistry/reference/T0. Seven historical rejects remain rejects. T2 locks that event graph until step 24. `native_before_update`, `native_after_graph_transfer` (T0), `local_projection` (T1), `native_after_remaining_denoising` (T2), and `posthoc_MMFF_repair` are separate evidence stages. T1 is an optimizer result. Complete C/Q/core trajectories are saved under `locked_events/`.

Full generation has 32 initializations per regime: Baseline replays recorded reference graphs and update decisions; Projection_locked uses exactly those chemical updates; Projection_closedloop reruns prediction after projection; Feasibility keeps at most four candidates from unchanged search beams and reranks by projected geometry; Full_guidance applies the same D projector to all fragments after each of 24 network steps (no additional update-time projector). All preserve historical rejected steps. `k=4` changes only final selection from the existing pool, not beam widths/check budget. Candidate raw/reference/after-projection metrics and rank are recorded. Closed-loop or reranking benefits are algorithm-level comparisons, not fixed-graph repair attribution.

Frozen full HQ/PoseBusters checks retain unavailable results and all failures. Existing coordinate-derived stereo scoring is supplemented by original predicted-chemistry stereo checks. End-only historical rigid MMFF repair is evaluated on the 32 Baseline outputs only as an independent reference.
''')
    ertable=table(['Arm','Stage','n','Bond MAE Å','Angle MAE °','Legacy internal pairs','Frozen-QC internal pairs','Protein pairs'],[[r['arm'],r['stage'],r['events'],fmt(r[KEYS[0]]),fmt(r[KEYS[1]],2),fmt(r[KEYS[2]],3),fmt(r['HQ_severe_internal_pairs'],3),fmt(r[KEYS[3]],3)] for r in event_summary])
    bins=[]
    index={(r['event_id'],r['arm']):r for r in events}
    for step in [5,10,15,20]:
        for arm in ['A','B','C','D']:
            rs=[r for r in events if r['step']==step and r['arm']==arm]
            bins.append(dict(step=step,arm=arm,n=len(rs),T0_bond=mean([r['T0'][KEYS[0]] for r in rs]),T1_bond=mean([r['T1'][KEYS[0]] for r in rs]),T2_bond=mean([r['T2'][KEYS[0]] for r in rs]),T2_angle=mean([r['T2'][KEYS[1]] for r in rs])))
    csvwrite(OUT/'EVENT_STEP_SUMMARY.csv',bins)
    fixes=[]
    for arm in ['B','C','D']:
        rs=[r for r in events if r['arm']==arm]
        fixes.append([arm,sum(r['T1'][KEYS[0]]<r['T0'][KEYS[0]]-1e-6 for r in rs),sum(r['T2'][KEYS[0]]<index[(r['event_id'],'A')]['T2'][KEYS[0]]-1e-6 for r in rs),
            fmt(mean([r['projection'].get('core_RMSD_A',0.) for r in rs])),fmt(max(r['projection'].get('translation_max_A',0.) for r in rs)),fmt(max(r['projection'].get('rotation_max_rad',0.) for r in rs)),
            sum(r['projection']['status']=='fallback' for r in rs),sum(r['projection']['reason']=='no_safe_descent' for r in rs),fmt(mean([r['projection']['seconds'] for r in rs]))])
    put('PROJECTION_ABLATION_RESULTS.md','# Locked-event projection ablation\n\n121 accepted events × four arms = 484 continuations. Seven rejected events are retained separately; none are promoted. Every pair fixes identity, atom order, connection sites/order/stereo and the entire reference graph. T2 has no later identity/connection revisions.\n\n'+ertable+'\n'+table(['Arm','T1 bond improved /121','T2 bond better than paired A /121','Mean T1 RMSD Å','Max translation Å','Max rotation rad','Fallback','No safe descent','Mean CPU s'],fixes)+'\n## Update timing\n\n'+table(['Step','Arm','n','T0 bond Å','T1 bond Å','T2 bond Å','T2 angle °'],[[r['step'],r['arm'],r['n'],fmt(r['T0_bond']),fmt(r['T1_bond']),fmt(r['T2_bond']),fmt(r['T2_angle'],2)] for r in bins])+'''\nAll 128 updates change both identity and connection. Other update-type strata have n=0 and cannot support comparisons. Step strata differ in molecules and update states; lateness associations do not establish that fewer remaining steps cause the errors.

T0→T1 isolates explicit projection. T1→T2 describes subsequent denoising, which can improve some quantities and worsen others. T0→T2 alone cannot attribute improvements to projection: compare with the paired A continuation. `PER_UPDATE_RESULTS.csv` gives paired values, frozen-QC internal clashes, unavailable equilibrium information, drift and fallback reasons. `PROJECTION_TRAJECTORY.csv` retains every measured denoising step; NPZ files retain coordinates/C/Q. B combines bonds and angles, so their individual causal contributions cannot be separated by this four-arm design. C−B tests adding internal repulsion; D−C jointly adds protein/displacement.
''')
    fulltable=table(['Regime','Stage','HQ /32','PB /32','Bond MAE Å','Angle MAE °','Same final chemistry /32','Unavailable'],[[r['mode'],r['stage'],r['HQ'],r['PB'],fmt(r['bond_MAE_A']),fmt(r['angle_MAE_deg'],2),r['same_final_chemistry'],r['unavailable_attempts']] for r in summary])
    breakdown=[]
    for (mode,stage),rs in by.items():
        for check in required:
            breakdown.append(dict(mode=mode,stage=stage,check=check,passed=sum(r['checks'].get(check) is True for r in rs),failed=sum(r['checks'].get(check) is False for r in rs),unavailable=sum(r['checks'].get(check) is None for r in rs),denominator=len(rs)))
    csvwrite(OUT/'QUALITY_BREAKDOWN.csv',breakdown)
    stereo_table=table(['Regime','Stage','Original predicted stereo defined /32','Original predicted stereo consistent /32'],[[r['mode'],r['stage'],r['declared_stereo_defined'],r['declared_stereo_consistent']] for r in summary])
    put('QUALITY_BREAKDOWN.md','# Full-generation quality\n\nFive regimes each attempt the same 32 initializations (160 total). Eight-case b4/b8 prechecks are separate (80 generated attempts; 40 b8 QC records). Baseline end-only MMFF repair adds 32 independent reference outputs. Failures and unavailable checks remain in each denominator.\n\n'+fulltable+'\n'+table(['Regime','Stage','Check','Pass','Fail','Unavailable','n'],[[r['mode'],r['stage'],r['check'],r['passed'],r['failed'],r['unavailable'],r['denominator']] for r in breakdown])+'\n'+stereo_table+'''\nHistorical HQ uses the frozen coordinate-derived stereo annotation; the original predicted-chemistry stereo checks above are separate and must not be replaced by the derived annotation. `PAIRED_GENERATION_RESULTS.csv` includes all final required checks, original declared stereo checks, exact failure/unavailable lists, chemistry equality, first prediction divergence, and projection costs. Full PoseBusters test dictionaries and geometry/protein/ring/torsion details remain in each `quality_complete.json`. No endpoint repair is included in native/guided HQ. Native/guided shared checkpoint use does not imply any learned repair.

Final atom RMSD is compared only for exactly matching ordered chemistry. Different final chemistry has no valid one-to-one atom-displacement comparison. Reported single-projection RMSDs describe explicit local motion, while full algorithm drift includes subsequent diffusion and changing identities. The legacy cross-fragment pair count is diagnostic; full HQ uses the separately frozen topology-aware check.
''')
    perfs=[]
    for mode in protocol['full_arms']:
        rs=[r for r in generation if r['strategy']==mode];folder=OUT/'full32/b32/batches';batch=list(folder.glob(f'*_{mode}.json'));assert len(batch)==1
        p=load(batch[0]);projs=[v for r in rs for v in r.get('projections',[])];forward=sum(t['forward_ms'] for t in p['timings'])/1000
        perfs.append(dict(mode=mode,batch=32,wall_seconds=p['wall_seconds'],molecules_per_second=32/p['wall_seconds'],forward_seconds=forward,forward_molecule_steps_per_second=32*24/forward,forward_calls=p['forward_calls'],
            projection_invocations=len(projs),projection_CPU_worker_seconds=sum(v['seconds'] for v in projs),peak_memory_GiB=max(t['peak_memory_bytes'] for t in p['timings'])/2**30,OOM_splits=len(p['oom']),
            search_worker_seconds=sum(e.get('search_seconds',0) for r in rs for e in r['events']),candidate_projection_CPU_seconds=sum(c['projection']['seconds'] for r in rs for e in r['events'] for c in e.get('candidate_geometry_evaluations',[]) if c.get('projection'))))
    csvwrite(OUT/'PERFORMANCE.csv',perfs)
    put('A100_PERFORMANCE.md','# A100 performance\n\nOne physical A100 GPU, FP32 frozen weights/interfaces with the unchanged verified v5 higher-precision contraction path. Every time step uses one true PyG batched backbone forward, followed by original sample mechanics. Four CPU search workers, eight independent projection workers, and eight QC workers are used. Invariant protein data are cached.\n\n'+table(['Regime','Batch','Generation wall s','Molecules/s','Backbone s','Molecule-steps/s backbone','Projection calls','Projection CPU-worker s','Peak GiB','OOM splits'],[[p['mode'],32,fmt(p['wall_seconds'],2),fmt(p['molecules_per_second'],3),fmt(p['forward_seconds'],2),fmt(p['forward_molecule_steps_per_second'],2),p['projection_invocations'],fmt(p['projection_CPU_worker_seconds'],2),fmt(p['peak_memory_GiB'],2),p['OOM_splits']] for p in perfs])+'''\nBatch16/32 gate compares identical 32 recorded states over three continuation steps. Dynamic b4/b8 prechecks cover all five regimes before scaling. `batch16_32_gate.json`, `precheck8_verification.json`, batch timing files and comparison files preserve the original numerical gates (0.025 Å maximum atom, 0.005 Å RMSD, 0.0002 Å internal-distance).

Generation wall time includes identity queries, CPU connection search, candidate assembly, state transfer, projection waits, trajectory IO, and batched diffusion. It excludes later full QC/end-only reference repair. Backbone throughput measures network GPU event time only. CPU-worker seconds overlap and are not additive wall time; candidate scoring in Feasibility is listed separately in `PERFORMANCE.csv`. Baseline/locked modes still execute identity and connection prediction to observe divergence; recorded reference/decisions are replayed. Model initialization, development selection, event studies and prechecks are separate costs.

There remain CPU↔GPU state transfers at graph revisions and candidate construction. This is measured implementation overhead; no claim of a fully GPU-resident projector is made. These are sequential regime timings on a possibly shared server, not randomized performance trials. No performance threshold or quality criterion was relaxed.
''')
    A=[r for r in events if r['arm']=='A'];D=[r for r in events if r['arm']=='D'];b0=mean([r['T0'][KEYS[0]] for r in D]);b1=mean([r['T1'][KEYS[0]] for r in D]);b2=mean([r['T2'][KEYS[0]] for r in D]);ba=mean([r['T2'][KEYS[0]] for r in A])
    candidates=[c for r in generation if r['strategy']=='Feasibility' for e in r['events'] for c in e.get('candidate_geometry_evaluations',[])]
    unsuitable=[c for c in candidates if c['status']=='rejected' or c.get('geometry',{}).get('cross_bond_MAE_A',0)>.15 or c.get('geometry',{}).get('cross_angle_MAE_deg',0)>15 or c.get('geometry',{}).get('severe_cross_internal_pairs',0)>0 or c.get('geometry',{}).get('severe_protein_pairs',0)>0]
    lock=next(r for r in summary if r['mode']=='Projection_locked');base=next(r for r in summary if r['mode']=='Baseline' and r['stage']=='native_final');guide=next(r for r in summary if r['mode']=='Full_guidance')
    timing_A={s:mean([r['T2'][KEYS[0]] for r in A if r['step']==s]) for s in [5,10,15,20]}
    timing_D={s:mean([r['T2'][KEYS[0]] for r in D if r['step']==s]) for s in [5,10,15,20]}
    drift_mean=mean([r['projection'].get('core_RMSD_A',0.) for r in D]);drift_max=max(r['projection'].get('core_max_delta_A',0.) for r in D)
    decision=f'''# Next-step decision

## Evidence and answers

1. Chemistry changes at complete predicted-graph construction; the new template placement and rigid reference transfer create T0. On the same new chemistry, intended-placement bond MAE is already {fmt(intended_bond)} Å, versus {fmt(actual_bond)} Å after transfer; mean transfer coordinate RMSD is {fmt(transfer_RMSD)} Å. Most instantaneous bond error therefore exists before reference transfer, in the proposed identity/ports plus their placement. This does not distinguish connection ranking from template placement causally, but does not support blaming reference-frame transfer alone.
2. With identical chemistry, D changes mean cross-bond MAE from {fmt(b0)} Å (T0) to {fmt(b1)} Å (explicit projection T1). Its locked T2 is {fmt(b2)} Å, versus {fmt(ba)} Å for A. This is partial repair: most immediate bond error remains within the caps/protein safeguard. Reaching an optimizer iteration limit or a lower objective is not a geometry pass.
3. A→B tests bonds/angles jointly; B→C adds internal repulsion; C→D adds protein and pose prior jointly. The detailed table identifies these marginal changes. This experiment cannot rank bond-only versus angle-only causal contributions.
4. Every accepted projection is capped at {config['max_translation_A']} Å and {config['max_rotation_rad']} rad per fragment per invocation; exact SO(3), rigidity and protein safeguards apply. D mean core RMSD is {fmt(drift_mean)} Å and maximum single-atom displacement is {fmt(drift_max)} Å. Rotation can move distal atoms more than the translation cap; the result is not universally negligible motion. Full-time repeated guidance can accumulate larger total motion.
5. D improves further from T1 {fmt(b1)} Å to T2 {fmt(b2)} Å; A also reaches {fmt(ba)} Å without projection. The final mean same-graph advantage is only {fmt(ba-b2)} Å, much smaller than the immediate gain {fmt(b0-b1)} Å. This indicates baseline denoising catches up on average, rather than demonstrating that SigmaDock generally destroys a successful bond repair. Individual worsening and angle/collision behavior must be read separately from the saved trajectories.
6. Update-only locked Projection has HQ {lock['HQ']}/32; all-step guidance has HQ {guide['HQ']}/32; Baseline is {base['HQ']}/32. All-step guidance is an auxiliary closed-loop algorithm comparison with a larger intervention budget and potentially different chemistry, so this is not a fixed-graph attribution. See performance/drift and original predicted-stereo checks before choosing a regime.
7. Feasibility examined {len(candidates)} retained legal candidates, of which {len(unsuitable)} either failed transfer or remained outside the declared geometry diagnostic at their projected pose. These are local capped-search failures, not proofs that a chemical graph has no feasible embedding. Historical seven transfer rejects remain rejected in every regime.
8. Immediate errors are dominated by proposed chemistry/placement; small rigid projection cannot eliminate most of them, while denoising repairs much of the bond error. Locked A final bond MAE by steps 5/10/15/20 is {[round(timing_A[s],4) for s in [5,10,15,20]]} Å (D: {[round(timing_D[s],4) for s in [5,10,15,20]]}). Treat any late-step excess as an association: identities and connection content differ across events. Reference transfer is a smaller incremental bond-error source in these saved states; full-generation candidate ranking, stereo/protein failures, and continuation residuals determine the final HQ bottleneck.
9. Do not start training from this diagnostic alone. If a frozen small-motion teacher produces repeatable same-graph gains that survive continuation and improve HQ without extra drift, it is a candidate for later auxiliary supervision. Otherwise prioritize the stage where the recorded errors persist. No new training is performed here.

## Limits and recommendation

All 128 updates are identity-plus-connection events. Other topology-type comparisons are unavailable, and timing strata are confounded by update content. The 32 previously viewed stress inputs across six ligand-defined pockets are not an independent generalization benchmark. Retain the current stable orientation algorithm; virtual anchors are unchanged and no additional virtual atoms are introduced. Preserve this evidence before proposing a new study or changing any frozen formal protocol.
'''
    put('NEXT_STEP_DECISION.md',decision)
    frozen=load(OUT/'frozen_run.json');source_unchanged=all(sha256(OUT/'source'/n)==h for n,h in frozen['source_sha256'].items());assert source_unchanged
    historical_unchanged=all(sha256(k)==v for k,v in load(OUT/'frozen_inputs.json').items());assert historical_unchanged
    initial_unchanged=all(sha256(k)==v for k,v in load(OUT/'initial_case_sha256.json').items());assert initial_unchanged
    verification=dict(passed=True,UTC=datetime.now(timezone.utc).isoformat(),historical_inputs_unchanged=historical_unchanged,initial_cases_unchanged=initial_unchanged,source_unchanged=source_unchanged,
        weights_unchanged=all(sha256(w['path'])==w['sha256'] for w in protocol['weights'].values()),protocol_unchanged=sha256(OUT/'protocol.json')==frozen['protocol_sha256'],projection_unchanged=sha256(OUT/'frozen_projection.json')==frozen['projection_sha256'],
        event_replay_passed=load(OUT/'event_replay_verification.json')['passed'],event_trajectories_passed=load(OUT/'event_trajectory_verification.json')['passed'],precheck_passed=load(OUT/'precheck8_verification.json')['passed'],batch16_32_passed=load(OUT/'batch16_32_gate.json')['passed'],
        event_runs=len(events),generation_runs=len(generation),quality_records=len(qrows),all_QC_inputs_unchanged=all(m['input_unchanged'] for m in details),no_training=True)
    assert all(verification[k] for k in ['weights_unchanged','protocol_unchanged','projection_unchanged','event_replay_passed','event_trajectories_passed','precheck_passed','batch16_32_passed','all_QC_inputs_unchanged'])
    dump(OUT/'completion_verification.json',verification)
    put('README.md','# Dynamic update rigid projection\n\nCompleted controlled diagnostic from `2611/1109/1736_refresh/prompt.md`. No new training or 216-run formal comparison.\n\n'+fulltable+'\nRead `UPDATE_GEOMETRY_AUDIT.md`, `RIGID_PROJECTION_METHOD.md`, `PROJECTION_ABLATION_RESULTS.md`, `QUALITY_BREAKDOWN.md`, `A100_PERFORMANCE.md`, and `NEXT_STEP_DECISION.md`. `completion_verification.json` checks all frozen inputs, weights, sources, stage gates and denominators.\n\nReproduce from workspace root using the historical Python environment and a free GPU:\n\n```bash\nPYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B -m pytest -q dynamic_update_rigid_projection/tests/\nCUDA_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B dynamic_update_rigid_projection/source/driver.py --through complete\n```\n\nCompleted immutable stages are reused only after hash verification. Raw molecular structures, graph tensors, native/projection trajectories, full QC details, model caches, logs and failure evidence remain local. GitHub delivery, when requested, should retain a compact set of reports/configs/code/tables/manifests.\n')
    dump(OUT/'status.json',dict(stage='complete',execution_complete=True,UTC=verification['UTC'],generation_attempts=160,event_continuations=484,posthoc_reference=32))
    archive=ROOT/'2611/1109/1736_refresh'
    putpath=archive/'README.md';putpath.write_text('# 动态更新后的受限刚体投影实验\n\n实验已完成。完整结果位于 `dynamic_update_rigid_projection/`。\n\n'+fulltable+'\n请阅读该目录的 `NEXT_STEP_DECISION.md` 与 `completion_verification.json`。未训练新模型，未启动 216 次新正式对照。\n')
    print('EXPERIMENT COMPLETE',summary,flush=True)

if __name__=='__main__':generate()
