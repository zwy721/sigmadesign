from common import *
import argparse,traceback
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import torch
import run_experiment as rx
from run_validation import load_official
from stable_precision import install
from event_experiment import validate_reconstruction,run_locked,save_trajectory_evidence
from development import select

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--through',choices=['dev','events','complete'],default='complete');args=parser.parse_args()
    torch.set_num_threads(2);torch.cuda.set_device(0);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.use_deterministic_algorithms(True)
    for k,v in load(OUT/'frozen_inputs.json').items():assert sha256(k)==v,('Historical input changed',k)
    den=load_official(bootstrap.CHECKPOINT,OUT/'cache/official','cuda:0');install(den);lib=rx.VocabLibrary()
    validate_reconstruction(den,lib)
    with ProcessPoolExecutor(4,mp_context=get_context('spawn'),initializer=rx.cpu_init) as search_pool, ProcessPoolExecutor(8,mp_context=get_context('spawn')) as projection_pool:
        client=rx.Client()
        try:
            set_status('development_selection');config=select(den,client,search_pool,projection_pool,lib)
            if args.through=='dev':return
            set_status('locked_event_ablation');run_locked(den,lib,projection_pool,config)
            if args.through=='events':return
            set_status('locked_event_trajectory_evidence');save_trajectory_evidence(den,lib,projection_pool,config)
            from full_experiment import complete
            complete(den,client,search_pool,projection_pool,lib,config)
        finally:client.close()

if __name__=='__main__':
    try:main()
    except Exception as exc:
        set_status('failed',error=repr(exc),traceback=traceback.format_exc());raise
