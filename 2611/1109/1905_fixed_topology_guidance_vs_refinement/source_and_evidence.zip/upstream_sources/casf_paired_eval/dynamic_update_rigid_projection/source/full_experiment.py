from common import *
import copy,time
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import torch
import run_experiment as rx
import dynamic_hooks
from extract_events import initial,historical
from full_quality import evaluate
from runtime import state_from,BatchEngine
from event_experiment import event_state

def execute(rows,mode,role,size,den,client,search_pool,projection_pool,lib,config):
    cases=[initial(r) for r in rows]
    for c in cases:c['role']=role
    dynamic_hooks.configure(mode,projection_pool,config);records=[]
    for i in range(0,len(cases),size):records.extend(rx.run_batch(cases[i:i+size],'C',den,client,search_pool,lib,tag=mode))
    return records

def compare(left,right,name):
    rows=[]
    for a,b in zip(left,right):
        assert (a['receptor_id'],a['seed'])==(b['receptor_id'],b['seed'])
        discrete=a['labels']==b['labels'] and a['connections']==b['connections']
        row=dict(pid=a['receptor_id'],seed=a['seed'],discrete=discrete,max_atom_delta_A=0.,RMSD_A=0.)
        for step in range(24):
            x=np.load(Path(a['folder'])/f'trajectory/step_{step:02d}.npz');y=np.load(Path(b['folder'])/f'trajectory/step_{step:02d}.npz')
            assert np.array_equal(x['labels'],y['labels']),('Trajectory chemistry',name,row,step)
            d=np.linalg.norm(x['xyz']-y['xyz'],axis=-1);row['max_atom_delta_A']=max(row['max_atom_delta_A'],float(d.max()));row['RMSD_A']=max(row['RMSD_A'],float(np.sqrt(np.mean(d*d))))
        if a['strategy']=='Full_guidance':
            x=np.load(Path(a['folder'])/'projections/step_23_full.npz')['local_projection'];y=np.load(Path(b['folder'])/'projections/step_23_full.npz')['local_projection']
            d=np.linalg.norm(x-y,axis=-1);row['max_atom_delta_A']=max(row['max_atom_delta_A'],float(d.max()));row['RMSD_A']=max(row['RMSD_A'],float(np.sqrt(np.mean(d*d))))
        row['passed']=discrete and row['max_atom_delta_A']<=.025 and row['RMSD_A']<=.005
        rows.append(row)
    result=dict(name=name,passed=all(r['passed'] for r in rows),rows=rows)
    dump(OUT/'comparisons'/f'{name}.json',result);assert result['passed'],('Full dynamic comparison gate',result)
    return result

def batch_gate(den,lib):
    target=OUT/'batch16_32_gate.json'
    if target.exists():assert load(target)['passed'];return
    events=[e for e in load(OUT/'event_inventory.json')['events'] if e['accepted'] and e['step']==10]
    assert len(events)==32;out=[]
    for size in [16,32]:
        states=[]
        for e in events:
            saved=torch.load(OUT/'events'/e['event_id']/'event.pt',weights_only=False,map_location='cpu');s,c,error=event_state(saved,den,lib);states.append(s)
        engine=BatchEngine(den);grid=(1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3;start=time.perf_counter()
        for step in range(10,13):
            for i in range(0,32,size):engine.step(states[i:i+size],grid[step],grid[step]-grid[step+1])
        out.append(dict(size=size,xyz=[s.physical() for s in states],wall_seconds=time.perf_counter()-start,timings=engine.timings,oom=engine.oom))
    deltas=[np.linalg.norm(a-b,axis=-1) for a,b in zip(out[0]['xyz'],out[1]['xyz'])]
    result=dict(passed=all(d.max()<=.025 and np.sqrt(np.mean(d*d))<=.005 for d in deltas),max_atom_delta_A=max(float(d.max()) for d in deltas),max_RMSD_A=max(float(np.sqrt(np.mean(d*d))) for d in deltas),
        performance=[{k:v for k,v in r.items() if k!='xyz'} for r in out],scope='32 exact same accepted step10 states, three remaining steps; no threshold change')
    dump(target,result);assert result['passed']

def complete(den,client,search_pool,projection_pool,lib,config):
    protocol=load(OUT/'protocol.json');eight=protocol['precheck_cases'];full=protocol['main_cases'];modes=protocol['full_arms']
    batch_gate(den,lib)
    freeze=OUT/'frozen_run.json'
    now=dict(source_sha256={p.name:sha256(p) for p in (OUT/'source').glob('*.py')},tests_sha256={p.name:sha256(p) for p in (OUT/'tests').glob('*.py')},protocol_sha256=sha256(OUT/'protocol.json'),projection_sha256=sha256(OUT/'frozen_projection.json'))
    if freeze.exists():assert load(freeze)==now,'Frozen source/config changed'
    else:dump(freeze,now)
    gate=OUT/'precheck8_verification.json'
    with ProcessPoolExecutor(8,mp_context=get_context('spawn')) as quality_pool:
        if not gate.exists():
            checks=[];qualities=[]
            for mode in modes:
                set_status('precheck8',mode=mode)
                a=execute(eight,mode,'precheck8/b4',4,den,client,search_pool,projection_pool,lib,config)
                b=execute(eight,mode,'precheck8/b8',8,den,client,search_pool,projection_pool,lib,config)
                checks.append(compare(a,b,mode+'_precheck_b4_b8'))
                if mode=='Baseline':checks.append(compare([load(historical(r)/'result.json') for r in eight],b,'Baseline_precheck_matches_historical'))
                jobs=[quality_pool.submit(evaluate,r['folder']) for r in b]
                for job in jobs:
                    q=job.result();assert q['input_unchanged'] and len(q['metrics'])==1;qualities.append(q)
                print('PRECHECK COMPLETE',mode,len(b),flush=True)
            dump(gate,dict(passed=all(c['passed'] for c in checks),comparisons=checks,quality_attempts=len(qualities),full_QC_saved=True,all_input_unchanged=all(q['input_unchanged'] for q in qualities)))
        assert load(gate)['passed'];records=[];quality_jobs=[]
        for mode in modes:
            set_status('full32',mode=mode)
            these=execute(full,mode,'full32/b32',32,den,client,search_pool,projection_pool,lib,config)
            records.extend(these)
            if mode=='Baseline':compare([load(historical(r)/'result.json') for r in full],these,'Baseline_full32_matches_historical')
            quality_jobs.extend(quality_pool.submit(evaluate,r['folder'],mode=='Baseline') for r in these)
        for job in quality_jobs:job.result()
    dump(OUT/'generation_inventory.json',dict(attempts=160,per_arm=32,records=records,precheck_attempts=80,precheck_QC_attempts=40))
    set_status('final_reporting',sampling_attempts=160)
    from reports import generate
    generate()
