from common import *
import traceback
import torch

def evaluate(folder,repair=False):
    from denovo_quality.common import object_hash,versions
    from denovo_quality.pipeline import task
    from denovo_quality.io import load_molecule
    from denovo_quality.chemistry import evaluate_chemistry
    torch.set_num_threads(1);folder=Path(folder);path=folder/'quality_complete.json'
    if path.exists() and (not repair or load(path).get('repair_requested')):return load(path)
    rec=load(folder/'result.json');install_pb();errors={}
    if repair:
        inp=torch.load(folder/'postprocess_input.pt',weights_only=False,map_location='cpu');hist=history_module('run')
        try:
            fids=np.empty(inp['mol'].GetNumAtoms(),dtype=int)
            for i,g in enumerate(inp['groups']):fids[g]=i
            fixed,meta=hist.repair(inp['mol'],fids,inp['context']['pdb_path'])
            dump(folder/'posthoc_MMFF_repair/repair.json',meta)
            if not any(r['group']=='posthoc_MMFF_repair' for r in rec['manifest']):hist.save_stage(folder,'posthoc_MMFF_repair',fixed,inp['spec'],rec,inp['context'])
        except Exception as exc:errors['posthoc_MMFF_repair']=dict(error=repr(exc),traceback=traceback.format_exc())
    cfg=load_config(OUT/'quality_config.json');deps=versions();compute=object_hash({str(p):sha256(p) for p in list((ROOT/'denovo_quality').glob('*.py'))+[Path(__file__),OUT/'source/common.py']})
    metrics=[task((row,cfg,str(OUT/rec['phase']/'quality'),compute,deps,False)) for row in rec['manifest']]
    if repair and not any(m['metadata']['group']=='posthoc_MMFF_repair' for m in metrics):
        metrics.append(dict(molecule_id=rec['attempt_id']+'__posthoc_MMFF_repair',metadata=dict(group='posthoc_MMFF_repair'),checks={**{k:None for k in cfg['quality']['required_checks']},'high_quality':False},errors=errors,
            failed_checks=['repair_failed'],unavailable_checks=cfg['quality']['required_checks'],modules={},input_unchanged=True))
    declared={}
    for stage in ['native_final']+(['posthoc_MMFF_repair'] if repair else []):
        try:
            mol,info,_=load_molecule(dict(sdf_path=str(folder/stage/'raw.sdf'),chemistry_spec_path=str(folder/stage/'original_spec.json'),record_index=0))
            details,checks=evaluate_chemistry(mol,info);declared[stage]=dict(checks=checks,details=details)
        except Exception as exc:declared[stage]=dict(unavailable=True,reason=repr(exc))
    result=dict(attempt_id=rec['attempt_id'],metrics=metrics,declared_stereo=declared,repair_requested=repair,repair_errors=errors,
        input_unchanged=all(r.get('input_unchanged',False) for r in metrics))
    rec['status']='complete';dump(folder/'result.json',rec);dump(path,result);dump(folder/'declared_stereo.json',declared)
    return result
