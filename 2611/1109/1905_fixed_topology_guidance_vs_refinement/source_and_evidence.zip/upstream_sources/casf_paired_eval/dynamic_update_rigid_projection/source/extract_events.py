"""Read-only extraction of all four historical updates per stress sample."""
from common import *
import copy
from collections import Counter
import torch
from joint_sampler import chemical_graph, topology_key
from vocab_chemistry import VocabLibrary, assemble_slots, spec_from_slots
from oracle_graph import rebuild
from rdkit import Chem

PRIOR=ROOT/'pose_generation_four_arm_comparison/paired_final'
VIRTUAL=ROOT/'virtual_anchor_orientation_ablation'

def initial(row,dev=False):
    base=ROOT/'pose_generation_four_arm_comparison/dev' if dev else PRIOR/'main'
    return torch.load(base/'initial'/f'{row["pid"]}_{row["seed"]}'/'case.pt',weights_only=False,map_location='cpu')

def historical(row):
    return VIRTUAL/'full32/b32/structures'/f'{row["pid"]}_{row["seed"]}_A_Current'

def changed_slots(old_labels,new_labels,old_connections,new_connections):
    changed={i for i,(a,b) in enumerate(zip(old_labels,new_labels)) if a!=b}
    def key(c):return tuple(c.get(k,0) for k in ['i','j','a','b','order','stereo'])
    old={key(c):c for c in old_connections};new={key(c):c for c in new_connections}
    for k in old.keys()^new.keys():changed.update(k[:2])
    return sorted(changed)

def main():
    torch.set_num_threads(1);lib=VocabLibrary();rows=[];counts=Counter()
    for row in load(OUT/'protocol.json')['main_cases']:
        case=initial(row);src=historical(row);rec=load(src/'result.json')
        oldspec=case['spec'];oldgraph=case['graph'];oldgroups=case['groups']
        for event in rec['events']:
            step=event['step'];folder=OUT/'events'/f'{row["pid"]}_{row["seed"]}_s{step:02d}'
            folder.mkdir(parents=True,exist_ok=True)
            dest=folder/'event.pt'
            if dest.exists():
                entry=load(folder/'event.json');rows.append(entry);counts[str(event['accepted'])]+=1
                if event['accepted']:
                    saved=torch.load(dest,weights_only=False,map_location='cpu');oldspec=saved['spec'];oldgraph=saved['graph'];oldgroups=saved['groups']
                continue
            # Never redraw an RDKit reference: the recorded reference coordinates
            # are part of the event, including any dependency-version effects.
            mol,groups,cuts=assemble_slots(lib,event['proposed_labels'],event['proposed_connections'],oov=[None]*case['N'])
            conf=Chem.Conformer(mol.GetNumAtoms())
            for group,audit in zip(groups,event['reference_transfer_orientation']):
                for atom,x in zip(group,audit['source_reference_coordinates']):conf.SetAtomPosition(int(atom),list(x))
            mol.RemoveAllConformers();mol.AddConformer(conf)
            spec=spec_from_slots(mol,groups,cuts,event['proposed_labels'],'historical saved reference, no re-embedding')
            graph=rebuild(spec,**case['context'])
            pn=int((graph.frag_idx_map==-1).sum());ref=graph.ref_pos.numpy()
            err=max(float(np.max(np.abs(ref[pn+np.asarray(g)]-np.asarray(a['source_reference_coordinates'])))) for g,a in zip(groups,event['reference_transfer_orientation']))
            assert err<2e-5,('Reference regeneration mismatch',row,step,err)
            transfer=np.load(src/f'event_{step:02d}/proposal_transfer.npz');before=np.load(src/f'event_{step:02d}/before.npz')
            identity=event['old_labels']!=event['proposed_labels']
            connection=topology_key([],event['old_connections'])!=topology_key([],event['proposed_connections'])
            kind='both' if identity and connection else 'identity_only' if identity else 'connection_only' if connection else 'no_change'
            entry=dict(event_id=folder.name,pid=row['pid'],seed=row['seed'],step=step,t=event['t'],accepted=event['accepted'],reason=event.get('reason'),update_type=kind,
                old_labels=event['old_labels'],new_labels=event['proposed_labels'],old_connections=event['old_connections'],new_connections=event['proposed_connections'],
                changed_slots=changed_slots(event['old_labels'],event['proposed_labels'],event['old_connections'],event['proposed_connections']),
                source_event=str(src/f'event_{step:02d}/event.json'),source_trajectory=str(src/'trajectory'),original_final_geometry=rec['final_geometry'],
                reference_regeneration_max_delta_A=err,old_spec_sha256=hashlib.sha256(json.dumps(oldspec,sort_keys=True).encode()).hexdigest(),
                proposed_spec_sha256=hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest(),historical=event)
            np.savez_compressed(folder/'stages.npz',before_xyz=before['xyz'],before_C=before['C'],before_Q=before['Q'],before_T=before['T'],before_R=before['R'],
                target_xyz=transfer['target_xyz'],actual_xyz=transfer['actual_xyz'],C=transfer['C'],Q=transfer['Q'],R=transfer['R'])
            torch.save(dict(case=case,graph=graph,groups=groups,spec=spec,old_spec=oldspec,old_graph=oldgraph,old_groups=oldgroups,entry=entry),dest)
            dump(folder/'event.json',entry);rows.append(entry);counts[str(event['accepted'])]+=1
            if event['accepted']:oldspec=spec;oldgraph=graph;oldgroups=groups
        print('EXTRACT',row['pid'],row['seed'],flush=True)
    assert len(rows)==128 and counts['True']==121 and counts['False']==7
    dump(OUT/'event_inventory.json',dict(total=len(rows),counts=dict(counts),events=rows,reference_regeneration_passed=True))
    csvwrite(OUT/'EVENT_INVENTORY.csv',[{k:v for k,v in r.items() if k!='historical'} for r in rows])
    print('EXTRACTION COMPLETE',dict(counts),flush=True)

if __name__=='__main__':main()
