# 固定预测化学图：持续引导与末端细化协议

依据：`prompt.md`、`reply.md`及用户对SLSQP/L-BFGS-B桥接和共同氢处理的补充确认。新实验独立保存，不训练模型，不修改历史结果、权重、朝向恢复算法或HQ/PoseBusters阈值。

## 数据与初始化

Primary为既有32例压力样本，每组分母32；不是未查看的泛化测试。6例开发集为2zwz/4i5p/2wos×42001/42002，与压力口袋不重叠；8例预检单列。

原预测图取旧Baseline `result.json.spec`，固定所有原子/键/立体标签与映射。保留保存的未结合参考片段内部坐标。通过未修改的朝向恢复算法建立词表模板至参考坐标系映射，然后应用原随机初始化核心质心及种子旋转。保存实际C/Q、参考T0/R0、初始坐标与语义随机键。最终生成位姿、晶体位姿均不用于初始化。口袋沿用旧研究，含已有配体定义口袋的条件依赖。

`ref_pos`永远来自保存的未结合参考，不用随机desired坐标重建。每条连接两端端口参考长度相同；`PORT_REFERENCE_AUDIT.csv`分别记录此长度、MMFF化学平衡目标和随机初始化实际距离。前两者是原神经表示与几何能量的不同约定，不能隐去或混作同一个数；所有组统一沿用。

## 核心与桥接

|组|网络路径|末端处理|归因|
|---|---|---|---|
|A|24步，无引导|无|neural_only|
|B|与A完全相同|20步简化投影|final_local_projection|
|C|step0–22网络更新后各投影一次，step23不投影|无|diffusion_guided|
|D|与C完全相同|与B相同的一次投影|final_local_projection，保留引导前史|
|E|A终态|原完整刚性MMFF|posthoc_MMFF|
|F|A终态|简化内部能量，SLSQP共同求解器|显式末端优化|
|G|A终态|MMFF内部能量，SLSQP共同求解器|posthoc_MMFF|
|G_LBFGSB_Hrigid|A终态|与G相同能量/氢/边界，改用L-BFGS-B|求解器对照|

F/G共同先固定重原子进行最多200步氢预优化，再将氢随父片段刚体移动，无独立氢变量；两组SE(3)变量、初态、800次预算、XYZ欧拉角盒、逐坐标平移盒完全一致。共同蛋白软罚半径0.80、系数200，重原子位姿系数5、欧拉角系数2、超过2 Å的软位移罚系数200。G内部能量为MMFF94s并保留旧酰胺窗口约束，F为简化键/角/排斥；F整体内部能量尺度仅在6例开发集从1/10/100选择。

G−F检验该共同求解流程下的内部势能差异；G与G_LBFGSB_Hrigid检验求解器及停止规则；后者与E检验独立氢自由度。非凸优化及交互存在，不将差值相加声称完全分解。

## 冻结投影与额外诊断

所有片段可动。另设确定性的`local_first_connection`选区，只移动按原连接顺序第一条连接两端片段，单列消融。

保留20步、学习率0.02、单步0.04 Å/0.02 rad、累计0.5 Å/0.3 rad、权重[1,1,40,40,0.02]和硬蛋白安全保护。位移正则化尺度独立固定为0.5 Å/0.3 rad，不随运动上限改变。

在相同A终态增加：800步原范围、20步扩大范围、800步扩大范围。扩大范围使用平移模长√12 Å、SO(3)角π，是原MMFF逐坐标±2 Å/逐欧拉角±π/2盒的包络近似，不是同一可行域；单步限幅不变。记录实际触界、路径、评估次数、梯度、终止原因，避免把未探索到扩展区域解释为范围无用。

另对D进行同参数MMFF。Secondary历史Baseline原态/末端投影/MMFF和历史动态Full_guidance已发布投影后原态/MMFF分为两批32例，不混入Primary。

## 验收、评价与性能

先验收默认投影等价性、上限/先验独立、桥接解析梯度及MMFF观测插桩等价性。8例运行A/B和C/D独立重复路径并要求逐位一致；另以8例重复填满真实PyG batch16/32，比较完整24步。批间门槛沿用最大原子差0.025 Å、RMSD0.005 Å；内部刚性门槛0.0002 Å。正式主干以32个不同样本真正合批前向，禁止逐分子完整去噪。

保存网络步后与引导后坐标、C/Q、能量、误差、碰撞、净移动与累计路径；所有失败保留分母。原预测立体定义完整数12/32在所有Primary组不变；坐标推导注释与原图定义/几何一致性分列。

报告逻辑24步NFE、实际共享GPU前向次数、CPU优化次数/函数与梯度评估、观测墙时、指标与落盘开销、扣除该开销的生成墙时、GPU峰值。不同能量单位不直接比较数值大小。32例结果不用于改参数。

## 复现

```bash
PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B fixed_topology_guidance_vs_refinement/source/prepare_inputs.py
PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -m pytest -q fixed_topology_guidance_vs_refinement/tests/
CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B fixed_topology_guidance_vs_refinement/source/driver.py --through complete
```

仅在完整开发阶段冻结、8例与代码验收通过后进入32例。`frozen_run.json`约束计算源码和设置哈希；恢复复用完整批次边界，不重新抽样或覆盖历史结果。

## 本轮QC路径恢复记录

初次启动漏设已有`.quality_deps`路径，PoseBusters检查不可用。代码/轨迹/几何门槛在正式采样前通过，但完整PoseBusters评价在最终复核时才补齐。此前中间报告与QC保留为明确排除的审计记录，不能解释为HQ=0。

恢复使用仓库既有PoseBusters 0.6.5，其实际配置与冻结JSON逐项相同。只对保存的648个终态（预检72、Primary416、Secondary160）重新进行完整评价；网络、优化器、初态和冻结参数均不重跑/不改变。命令：

```bash
PYTHONPATH="$PWD/.quality_deps:$PWD" OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 ../.venv-cutoff-train/bin/python -B fixed_topology_guidance_vs_refinement/analysis/complete_quality.py
```
