"""Resumable stage supervisor: development -> acceptance -> frozen main -> QC."""
from common import *
import argparse
import os
import time
import traceback
from datetime import datetime,timezone
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import torch
from run_validation import load_official
from stable_precision import install
from prepare_inputs import key
from sampling import run_path,compare_paths,read_case
from settings import freeze_settings,projection_config
from endpoints import terminal_job,evaluate_endpoint,jobs_from_paths


def run_terminal_jobs(jobs,pool):
    results=[pool.submit(terminal_job,j) for j in jobs]
    records=[]
    for future in results:
        r=future.result();records.append(r)
        print('ENDPOINT',r['phase'],r['pid'],r['seed'],r['method'],(r.get('optimizer') or {}).get('termination'),flush=True)
    return records


def develop(den,pool,settings):
    path=OUT/'development_selection.json'
    if path.exists():return load(path)['selected']
    rows=load(OUT/'protocol.json')['development'];set_status('development_fixed_graph')
    native=run_path(rows,'development','A',den,pool,settings['projection'],development=True,batch_size=6)
    guided=run_path(rows,'development','C',den,pool,settings['projection'],guided=True,development=True,batch_size=6)
    # Only new internal-potential scale is selected here; retain the old frozen
    # 20-step projection and guidance for the main causal comparisons.
    grid=[dict(simple_internal_scale=scale,max_iterations=800) for scale in [1.,10.,100.]]
    dump(OUT/'development_grid.json',grid);jobs=[]
    for c in grid:
        for r in native:
            case=read_case(r,True);inp=torch.load(Path(r['folder'])/'endpoint.pt',weights_only=False,map_location='cpu')
            jobs.append(dict(folder=str(OUT/'development'/f'bridge_scale_{c["simple_internal_scale"]}'/key(r)),case=case,xyz=inp['xyz'],
                             mode='F',method='F',role='development',config=c,source=dict(path_folder=r['folder'])))
    records=run_terminal_jobs(jobs,pool);summary=[]
    for c in grid:
        scores=[]
        for rec in records:
            if f'bridge_scale_{c["simple_internal_scale"]}/' not in rec['folder']:continue
            m=rec['geometry'];meta=rec.get('optimizer') or {}
            score=(m['cross_bond_MAE_A']/.15)**2+(m['cross_angle_MAE_deg']/15)**2+10*m['severe_cross_internal_pairs']+10*m['severe_protein_pairs']
            if meta.get('status')=='failed':score+=1000
            scores.append(score)
        assert len(scores)==6
        summary.append(dict(config=c,mean_score=float(np.mean(scores)),cases=6))
    selected=grid[min(range(len(grid)),key=lambda i:(summary[i]['mean_score'],i))]
    # G and solver control are checked on all six cases, without selecting on
    # the pressure set or changing the established MMFF reference.
    jobs=jobs_from_paths(native,'development',bridge_config=selected,diagnostics=False)+jobs_from_paths(guided,'development',guided=True,diagnostics=False)
    selected_records=run_terminal_jobs(jobs,pool)
    assert not any((r.get('optimizer') or {}).get('status') in ['failed','fallback'] for r in selected_records)
    dump(path,dict(selected=selected,grid=grid,summaries=summary,formal_metrics_used=False,
                   selection_rule='mean six-dev geometry score; ties retain grid order; optimizer failure +1000',
                   development_case_keys=[key(r) for r in rows],records=[r['folder'] for r in selected_records]))
    print('DEVELOPMENT FROZEN',selected,flush=True)
    return selected


def precheck(den,pool,settings,bridge):
    target=OUT/'precheck8_verification.json'
    if target.exists():assert load(target)['passed'];return
    rows=load(OUT/'protocol.json')['precheck_cases'];checks=[];set_status('precheck8_independent_paths')
    a=run_path(rows,'precheck8','A',den,pool,settings['projection'],batch_size=8)
    b=run_path(rows,'precheck8','B_independent',den,pool,settings['projection'],batch_size=8)
    repeat=run_path(rows,'precheck8','A_repeat',den,pool,settings['projection'],batch_size=8)
    checks.append(compare_paths(a,b,'precheck_A_B_bitwise'));checks.append(compare_paths(a,repeat,'precheck_A_repeat_bitwise'))
    c=run_path(rows,'precheck8','C',den,pool,settings['projection'],guided=True,batch_size=8)
    d=run_path(rows,'precheck8','D_independent',den,pool,settings['projection'],guided=True,batch_size=8)
    repeat=run_path(rows,'precheck8','C_repeat',den,pool,settings['projection'],guided=True,batch_size=8)
    checks.append(compare_paths(c,d,'precheck_C_D_bitwise'));checks.append(compare_paths(c,repeat,'precheck_C_repeat_bitwise'))
    # Eight distinct precheck inputs replicated to fill true batches, not a
    # sequence of single-molecule forwards. Main uses 32 distinct saved cases.
    for guided,base in [(False,a),(True,c)]:
        for size in [16,32]:
            expanded=rows*(size//len(rows));label=f'{"C" if guided else "A"}_batch{size}'
            full=run_path(expanded,f'precheck_batch{size}',label,den,pool,settings['projection'],guided=guided,batch_size=size)
            checks.append(compare_paths(base*(size//8),full,f'{label}_vs_precheck8',exact=False))
    # Compare initial runtime tensors (including the dummy/virtual graph).
    for ra,rb,rc,rd in zip(a,b,c,d):
        init=[np.load(Path(r['folder'])/'initial_state.npz') for r in [ra,rb,rc,rd]]
        assert all(all(np.array_equal(init[0][f],v[f]) for f in init[0].files) for v in init[1:])
    jobs=jobs_from_paths(a,'precheck8',bridge_config=bridge,diagnostics=False)
    # Use independently replayed D path for its actual terminal fork.
    jobs+=jobs_from_paths(d,'precheck8',guided=True,diagnostics=False)
    endpoints=run_terminal_jobs(jobs,pool)
    assert len(endpoints)==8*9
    failures=[r for r in endpoints if (r.get('optimizer') or {}).get('status') in ['failed','fallback']]
    assert not failures,[(r['method'],r['pid'],r['seed']) for r in failures]
    projections=[r for r in endpoints if r['method'] in ['B','D']]
    assert any((r['optimizer'] or {}).get('core_RMSD_A',0)>0 for r in projections),'Projection was a no-op'
    for r in endpoints:
        previous=load(ROOT/'dynamic_update_rigid_projection/full32/b32/structures'/f'{r["pid"]}_{r["seed"]}_Baseline/declared_stereo.json')['native_final']['checks']['stereo_definition_complete']
        assert r['declared_stereo']['checks']['stereo_definition_complete']==previous
    qualities=[pool.submit(evaluate_endpoint,r['folder']) for r in endpoints]
    for f in qualities:
        q=f.result();assert q['input_unchanged'] and not q['optimizer_failed'],q['attempt_id']
    dump(target,dict(passed=True,unique_cases=8,independent_network_paths=48,comparisons=checks,
                     methods_per_case=9,quality_outputs=len(endpoints),all_initial_tensors_equal=True,
                     projection_has_nonzero_updates=True,original_declared_stereo_unchanged=True,
                     batch_check_scope='eight distinct inputs repeated to true batch16/32, all24 steps; actual main32 distinct cases'))


def run_main(den,pool,settings,bridge):
    assert load(OUT/'precheck8_verification.json')['passed']
    rows=load(OUT/'protocol.json')['main_cases'];set_status('main32_fixed_topology')
    a=run_path(rows,'primary32','A',den,pool,settings['projection'],batch_size=32)
    c=run_path(rows,'primary32','C',den,pool,settings['projection'],guided=True,batch_size=32)
    jobs=jobs_from_paths(a,'primary32',bridge_config=bridge)+jobs_from_paths(c,'primary32',guided=True)
    results=run_terminal_jobs(jobs,pool)
    assert len(results)==32*13
    dump(OUT/'primary_inventory.json',dict(cases=32,logical_endpoints=len(results),unique_network_paths=64,
                                          folders=[r['folder'] for r in results]))
    return results


def secondary(pool,settings):
    from prepare_inputs import OLD,source_folder
    target=OUT/'secondary_inventory.json'
    if target.exists():return [load(Path(f)/'result.json') for f in load(target)['folders']]
    jobs=[]
    for row in load(OUT/'protocol.json')['main_cases']:
        for arm in ['Baseline','Full_guidance']:
            src=OLD/'full32/b32/structures'/f'{key(row)}_{arm}'
            inp=torch.load(src/'postprocess_input.pt',weights_only=False,map_location='cpu');mol=inp['mol']
            case=dict(pid=row['pid'],seed=row['seed'],spec=inp['spec'],groups=inp['groups'],context=inp['context'],N=len(inp['groups']))
            original=mol.GetConformer().GetPositions()
            variants=[(f'historical_{arm}','identity'),(f'secondary_{arm}_MMFF','MMFF')]
            if arm=='Baseline':variants.append(('secondary_Baseline_projection','projection'))
            for method,mode in variants:
                jobs.append(dict(folder=str(OUT/'secondary32'/arm/f'{key(row)}_{method}'),case=case,xyz=original,
                                 role='secondary32',method=method,mode=mode,
                                 source=dict(folder=str(src),input_sha256=sha256(src/'postprocess_input.pt'),
                                             historical_final_includes_terminal_projection=arm=='Full_guidance',full_precision_input=True)))
    results=run_terminal_jobs(jobs,pool)
    dump(target,dict(cases_per_cohort=32,separate_chemical_graph_cohorts=True,logical_endpoints=len(results),folders=[r['folder'] for r in results]))
    return results


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--through',choices=['development','precheck','complete'],default='complete');args=parser.parse_args()
    torch.set_num_threads(2);torch.cuda.set_device(0);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.use_deterministic_algorithms(True)
    settings=freeze_settings()
    for p,digest in load(OUT/'frozen_historical_inputs.json').items():assert sha256(p)==digest,('Historical file changed',p)
    dump(OUT/'environment.json',dict(UTC=datetime.now(timezone.utc).isoformat(),python=sys.version,executable=sys.executable,torch=torch.__version__,
                                   GPU=torch.cuda.get_device_name(0),CUDA=torch.version.cuda,physical_GPU=os.environ.get('CUDA_VISIBLE_DEVICES'),
                                   CUBLAS_WORKSPACE_CONFIG=os.environ.get('CUBLAS_WORKSPACE_CONFIG'),official_import=bootstrap.verify_imports()))
    den=load_official(bootstrap.CHECKPOINT,OUT/'cache/official','cuda:0');install(den)
    with ProcessPoolExecutor(8,mp_context=get_context('spawn')) as pool:
        bridge=develop(den,pool,settings)
        if args.through=='development':
            set_status('development_complete');return
        freeze=dict(source_sha256={p.name:sha256(p) for p in (OUT/'source').glob('*.py')},tests_sha256={p.name:sha256(p) for p in (OUT/'tests').glob('*.py')},
                    protocol_sha256=sha256(OUT/'protocol.json'),settings_sha256=sha256(OUT/'frozen_settings.json'),development_selection_sha256=sha256(OUT/'development_selection.json'))
        if (OUT/'frozen_run.json').exists():assert load(OUT/'frozen_run.json')==freeze,'Compute source or config changed'
        else:dump(OUT/'frozen_run.json',freeze)
        precheck(den,pool,settings,bridge)
        if args.through=='precheck':return
        primary=run_main(den,pool,settings,bridge);other=secondary(pool,settings)
        set_status('final_quality',primary=len(primary),secondary=len(other));futures=[pool.submit(evaluate_endpoint,r['folder']) for r in primary+other]
        for i,future in enumerate(futures):
            q=future.result();assert q['input_unchanged'],q['attempt_id']
            if i%16==0:print('QUALITY',i+1,'/',len(futures),flush=True)
    for p,digest in load(OUT/'frozen_historical_inputs.json').items():assert sha256(p)==digest,('Historical file changed',p)
    set_status('final_reporting')
    from reports import generate
    generate()
    dump(OUT/'status.json',dict(stage='complete',execution_complete=True,UTC=datetime.now(timezone.utc).isoformat()))


if __name__=='__main__':
    try:main()
    except Exception as exc:
        set_status('failed',error=repr(exc),traceback=traceback.format_exc());raise
