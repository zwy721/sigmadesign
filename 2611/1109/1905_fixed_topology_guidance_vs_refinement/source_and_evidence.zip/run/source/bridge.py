"""Matched rigid-H F/G bridge and explicit solver-only control.

F/G differ only in internal potential. They have identical coordinates, hydrogen
initialization/attachment, variables, bounds, shared penalties and SLSQP options.
The L-BFGS-B control changes only the optimizer and its stopping convention.
"""
from common import *
import time
import torch
from rdkit import Chem
from rdkit.Chem import AllChem,rdMolTransforms
from scipy.optimize import minimize
from scipy.spatial.distance import cdist
from scipy.spatial.transform import Rotation
from projection import Terms
from settings import projection_config
from mmff_reference import PARAMETERS,rotation_derivatives
from oracle_graph import assemble
from denovo_quality.protein import read_protein


class SharedModel:
    def __init__(self,spec,context,xyz,config):
        self.config=config;self.spec=spec;self.p=dict(PARAMETERS);self.x0=np.asarray(xyz,dtype=float)
        self.groups=[np.asarray(f['atom_ids']) for f in spec['fragments']];self.n=len(xyz);self.G=len(self.groups)
        mol=assemble(spec)
        for i,x in enumerate(xyz):mol.GetConformer().SetAtomPosition(i,x.tolist())
        self.q=Chem.AddHs(Chem.Mol(mol),addCoords=True)
        if not AllChem.MMFFHasAllMoleculeParams(self.q):raise ValueError('MMFF bridge parameters unavailable')
        props=AllChem.MMFFGetMoleculeProperties(self.q,mmffVariant='MMFF94s')
        ff=AllChem.MMFFGetMoleculeForceField(self.q,props,nonBondedThresh=100.,ignoreInterfragInteractions=False)
        for i in range(self.n):ff.AddFixedPoint(i)
        self.hstatus=ff.Minimize(maxIts=self.p['hydrogen_iterations'])
        self.coords=self.q.GetConformer().GetPositions().copy();self.ff=AllChem.MMFFGetMoleculeForceField(self.q,props,nonBondedThresh=100.,ignoreInterfragInteractions=False)
        self.amides=[]
        for ids in mol.GetSubstructMatches(Chem.MolFromSmarts('[O,S]=[C]-[N]-[!#1]')):
            phi=rdMolTransforms.GetDihedralDeg(mol.GetConformer(),*ids);target=0. if abs(phi)<90 else (180. if phi>=0 else -180.)
            self.ff.MMFFAddTorsionConstraint(*ids,False,target-5.,target+5.,2.)
            self.amides.append(dict(atoms=list(ids),initial_deg=phi,target_deg=target))
        fids=np.empty(self.n,dtype=int)
        for j,g in enumerate(self.groups):fids[g]=j
        allfids=list(fids)
        for i in range(self.n,len(self.coords)):
            heavy=[a.GetIdx() for a in self.q.GetAtomWithIdx(i).GetNeighbors() if a.GetIdx()<self.n]
            assert len(heavy)==1,'Each bridge hydrogen must have one real parent'
            allfids.append(fids[heavy[0]])
        allfids=np.array(allfids);self.allgroups=[np.where(allfids==j)[0] for j in range(self.G)]
        self.centers=np.array([self.x0[g].mean(0) for g in self.groups]);self.local=[self.coords[g]-self.centers[j] for j,g in enumerate(self.allgroups)]
        self.simple=Terms(spec,context,self.x0,list(range(self.G)),projection_config()).tensors()
        atoms=[a for a in read_protein(context['pdb_path'])['atoms'] if a['kind']!='water']
        pc=np.array([a['xyz'] for a in atoms]);pt=Chem.GetPeriodicTable()
        rv=np.array([pt.GetRvdw(a.GetAtomicNum()) for a in mol.GetAtoms()]);rc=np.array([pt.GetRcovalent(a.GetAtomicNum()) for a in mol.GetAtoms()])
        pv=np.array([a['vdw_radius_A'] for a in atoms]);prc=np.array([a['covalent_radius_A'] for a in atoms]);metal=np.array([a['kind']=='inorganic_cofactor' for a in atoms])
        limits=.8*(rv[:,None]+pv[None,:]);limits[:,metal]=.8*(rc[:,None]+prc[None,metal])
        keep=(cdist(self.x0,pc)<10.).any(0);self.pc=pc[keep];self.limits=limits[:,keep]
        self.bounds=[bound for _ in range(self.G) for bound in [(-2.,2.)]*3+[(-np.pi/2,np.pi/2)]*3]
        self.calls=0;self.last_components={}

    def coordinates(self,v):
        u=np.asarray(v).reshape(self.G,6);xx=self.coords.copy();derivatives=[]
        for j,g in enumerate(self.allgroups):
            R,dR=rotation_derivatives(u[j,3:]);xx[g]=self.local[j]@R.T+self.centers[j]+u[j,:3];derivatives.append(dR)
        return xx,u,derivatives

    def simple_internal(self,xyz):
        x=torch.tensor(xyz,dtype=torch.float64,requires_grad=True);d=self.simple;z=x.sum()*0
        b=d['bonds'];a=d['angles'];p=d['pairs']
        eb=(((x[b[:,0].long()]-x[b[:,1].long()]).norm(dim=-1)-b[:,2])/.15).square().mean() if len(b) else z
        if len(a):
            u=x[a[:,0].long()]-x[a[:,1].long()];v=x[a[:,2].long()]-x[a[:,1].long()]
            ea=(((u*v).sum(-1)/(u.norm(dim=-1)*v.norm(dim=-1)).clamp_min(1e-12)-a[:,3])/.25).square().mean()
        else:ea=z
        ec=torch.relu(p[:,2]-(x[p[:,0].long()]-x[p[:,1].long()]).norm(dim=-1)).square().sum()/len(x) if len(p) else z
        e=self.config['simple_internal_scale']*(eb+ea+40.*ec)
        grad=torch.autograd.grad(e,x)[0].detach().numpy()
        return float(e.detach()),grad

    def objective(self,v,internal):
        self.calls+=1;xx,u,derivatives=self.coordinates(v)
        if internal=='MMFF':
            flat=tuple(xx.ravel());energy=float(self.ff.CalcEnergy(flat));grad=np.array(self.ff.CalcGrad(flat)).reshape(-1,3)
        elif internal=='simplified':
            energy,g=self.simple_internal(xx[:self.n]);grad=np.zeros_like(xx);grad[:self.n]=g
        else:raise ValueError(internal)
        parts=dict(internal=energy)
        delta=xx[:self.n]-self.x0;pose=5.*np.square(delta).sum();grad[:self.n]+=10.*delta
        disp=np.linalg.norm(delta,axis=1);over=np.maximum(disp-2.,0);soft=200.*np.square(over).sum()
        grad[:self.n]+=400.*over[:,None]*delta/np.maximum(disp[:,None],1e-12)
        dp=xx[:self.n,None]-self.pc[None];dist=np.linalg.norm(dp,axis=-1);over=np.maximum(self.limits-dist,0)
        protein=200.*np.square(over).sum();grad[:self.n]+=(-400.*over[:,:,None]*dp/np.maximum(dist[:,:,None],1e-9)).sum(1)
        orientation=2.*np.square(u[:,3:]).sum();gg=np.zeros_like(u)
        for j,g in enumerate(self.allgroups):
            gg[j,:3]=grad[g].sum(0)
            for k in range(3):gg[j,3+k]=np.sum(grad[g]*(self.local[j]@derivatives[j][k].T))
        gg[:,3:]+=4.*u[:,3:]
        parts.update(pose=pose,soft_displacement=soft,protein=protein,orientation=orientation)
        self.last_components=parts
        return float(energy+pose+soft+protein+orientation),gg.ravel()


def optimize(spec,context,xyz,config,internal='MMFF',solver='SLSQP'):
    start=time.perf_counter();model=SharedModel(spec,context,xyz,config);v0=np.zeros(model.G*6);path=[]
    initial,initial_gradient=model.objective(v0,internal)
    def callback(v):path.append(np.array(v,copy=True))
    opts=dict(maxiter=config['max_iterations'],ftol=1e-8) if solver=='SLSQP' else dict(maxiter=config['max_iterations'],ftol=1e-10,gtol=1e-4,maxls=40)
    result=minimize(lambda v:model.objective(v,internal),v0,method=solver,jac=True,bounds=model.bounds,callback=callback,options=opts)
    final,gradient=model.objective(result.x,internal);xx,u,_=model.coordinates(result.x)
    heavy=xx[:model.n];x0=np.asarray(xyz);maxdist=max(float(np.max(np.abs(cdist(heavy[g],heavy[g])-cdist(x0[g],x0[g])))) for g in model.groups)
    assert np.isfinite(heavy).all() and maxdist<1e-8
    projected=gradient.copy()
    for i,(lo,hi) in enumerate(model.bounds):
        if result.x[i]<=lo+1e-8 and gradient[i]>0:projected[i]=0
        if result.x[i]>=hi-1e-8 and gradient[i]<0:projected[i]=0
    previous=v0.reshape(model.G,6);tp=np.zeros(model.G);rp=np.zeros(model.G)
    for v in path+[result.x]:
        current=v.reshape(model.G,6);tp+=np.linalg.norm(current[:,:3]-previous[:,:3],axis=-1)
        ra=np.array([rotation_derivatives(v)[0] for v in current[:,3:]]);rb=np.array([rotation_derivatives(v)[0] for v in previous[:,3:]])
        rp+=np.linalg.norm(Rotation.from_matrix(ra@rb.transpose(0,2,1)).as_rotvec(),axis=-1);previous=current
    meta=dict(status='optimized',success=bool(result.success),solver=solver,internal_potential=internal,
              initialization_sha256=hashlib.sha256(model.coords.tobytes()).hexdigest(),hydrogen_policy='200-step heavy-fixed relaxation then rigidly attached to parent fragment; no independent H variables',
              variables=model.G*6,initial_objective=initial,final_objective=final,final_energy_terms=model.last_components,
              iterations=int(result.nit),function_evaluations=model.calls,gradient_evaluations=model.calls,
              termination=str(result.message),scipy_status=int(result.status),final_gradient_L2=float(np.linalg.norm(gradient)),
              final_gradient_inf=float(np.max(np.abs(gradient))),final_projected_gradient_inf=float(np.max(np.abs(projected))),
              hydrogen_optimization_status=int(model.hstatus),heavy_RMSD_no_alignment_A=float(np.sqrt(np.mean(np.sum((heavy-x0)**2,axis=-1)))),
              atom_displacements_A=np.linalg.norm(heavy-x0,axis=-1).tolist(),max_atom_displacement_A=float(np.linalg.norm(heavy-x0,axis=-1).max()),
              centroid_displacement_A=float(np.linalg.norm(heavy.mean(0)-x0.mean(0))),max_fragment_pair_distance_change_A=maxdist,
              fragment_translation_A=u[:,:3].tolist(),fragment_Euler_rotation_rad=u[:,3:].tolist(),
              fragment_translation_path_A=tp.tolist(),fragment_rotation_path_rad=rp.tolist(),
              amide_constraints=model.amides if internal=='MMFF' else [],seconds=time.perf_counter()-start)
    return heavy,meta
