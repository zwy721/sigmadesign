"""Freeze original predicted chemistry and reconstruct a compatible random pose."""
from common import *
import copy
import shutil
import torch
from rdkit import Chem
from rdkit.Chem import AllChem
from oracle_graph import assemble, rebuild
from vocab_chemistry import VocabLibrary
from orientation import fit

OLD = ROOT/'dynamic_update_rigid_projection'
TASK = ROOT/'2611/1109/1905_fixed_topology_guidance_vs_refinement'


def key(row):
    return f'{row["pid"]}_{row["seed"]}'


def source_folder(row, development=False):
    phase = 'development/b6' if development else 'full32/b32'
    return OLD/phase/'structures'/f'{key(row)}_Baseline'


def prepare_case(row, lib, development=False):
    dest=OUT/'inputs'/('development' if development else 'main')/key(row)
    if (dest/'case.pt').exists():
        audit=load(dest/'audit.json')
        assert sha256(dest/'case.pt')==audit['case_sha256']
        for p,digest in audit['source_sha256'].items():assert sha256(p)==digest,p
        return audit
    phase=ROOT/'pose_generation_four_arm_comparison'/('dev' if development else 'paired_final/main')
    initial_path=phase/'initial'/key(row)/'case.pt'
    old=torch.load(initial_path,weights_only=False,map_location='cpu')
    src=source_folder(row,development);rec=load(src/'result.json')
    # This is the original declared graph and UNBOUND reference coordinates.
    # Never use native_final/spec.json (coordinate-derived stereo) or final T/R.
    spec=copy.deepcopy(rec['spec']);groups=[f['atom_ids'] for f in spec['fragments']]
    assert groups==rec['groups'] and len(groups)==old['N']
    graph=rebuild(spec,**old['context'])
    pn=int((graph.frag_idx_map==-1).sum());reference=graph.ref_pos.numpy()
    mol=assemble(spec);n=mol.GetNumAtoms();desired=[];maps=[]
    for slot,group in enumerate(groups):
        source=np.asarray(spec['fragments'][slot]['coordinates'])
        assert np.max(np.abs(reference[pn+np.asarray(group)]-source))<2e-5
        _,template=lib.template(int(rec['labels'][slot]))
        _,template_to_ref,error,audit=fit(template,source,np.eye(3))
        ref_to_world=old['R'][slot]@template_to_ref.T
        center=np.asarray(old['desired'][slot]).mean(0)
        wanted=(source-source.mean(0))@ref_to_world.T+center
        desired.append(wanted)
        maps.append(dict(slot=slot,label=rec['labels'][slot],template_to_reference=audit,
                         reference_to_random_world=ref_to_world.tolist(),initial_core_centroid_A=center.tolist(),
                         template_shape_fit_RMSD_A=error))
    case=dict(pid=row['pid'],seed=row['seed'],N=old['N'],labels=rec['labels'],connections=rec['connections'],
              graph=graph,groups=groups,spec=spec,context=old['context'],desired=desired,R=old['R'],
              role='fixed_topology',initialization='unbound saved final-graph reference; original random core centroids and seed rotations')
    q=Chem.AddHs(Chem.Mol(mol),addCoords=True);props=AllChem.MMFFGetMoleculeProperties(q,mmffVariant='MMFF94s')
    assert props is not None,'Missing MMFF graph parameters'
    xyz0=np.empty((n,3));refxyz=mol.GetConformer().GetPositions()
    for group,wanted in zip(groups,desired):xyz0[group]=wanted
    fragmented=graph.mol_info['fragmented']
    from sigmadock.chem.fragmentation import get_fragmented_anchors_dummies
    anchors,dummies=get_fragmented_anchors_dummies(fragmented)
    fragxyz=fragmented.GetConformer().GetPositions();ports=[]
    for b in spec['connections']:
        i,j=b['begin'],b['end'];reference_length=float(np.linalg.norm(refxyz[i]-refxyz[j]))
        equilibrium=props.GetMMFFBondStretchParams(q,i,j)[-1]
        a_lengths=[float(np.linalg.norm(fragxyz[a]-fragxyz[d])) for a,d in zip(anchors,dummies)
                   if (a==i and np.linalg.norm(fragxyz[d]-refxyz[j])<2e-5) or (a==j and np.linalg.norm(fragxyz[d]-refxyz[i])<2e-5)]
        assert len(a_lengths)==2,(row,i,j,a_lengths)
        assert max(abs(v-reference_length) for v in a_lengths)<2e-5
        ports.append(dict(pid=row['pid'],seed=row['seed'],development=development,begin=i,end=j,slots=b['slots'],
                          port_reference_lengths_A=a_lengths,shared_dummy_anchor_reference_A=reference_length,
                          projection_and_QC_MMFF_equilibrium_A=float(equilibrium),
                          initial_actual_distance_A=float(np.linalg.norm(xyz0[i]-xyz0[j])),
                          ref_pos_source='original predicted final-graph saved unbound reference, never random desired xyz',
                          target_convention='two port lengths share saved-reference target; projection/QC use chemistry MMFF equilibrium, explicitly separate'))
    dest.mkdir(parents=True,exist_ok=True);torch.save(case,dest/'case.pt')
    dump(dest/'original_spec.json',spec);np.savez_compressed(dest/'initialization.npz',real_xyz=xyz0,seed_R=old['R'],core_centers=np.array([x.mean(0) for x in old['desired']]))
    sources=[initial_path,src/'result.json',Path(old['context']['pdb_path'])]
    audit=dict(pid=row['pid'],seed=row['seed'],N=old['N'],atoms=n,development=development,
               case_sha256=sha256(dest/'case.pt'),spec_sha256=sha256(dest/'original_spec.json'),
               source_sha256={str(p):sha256(p) for p in sources},reference_frame_maps=maps,
               initial_xyz_sha256=hashlib.sha256(xyz0.tobytes()).hexdigest(),ports=ports,
               final_generated_pose_used=False,crystal_pose_used=False,reference_shape_preserved=True)
    dump(dest/'audit.json',audit)
    print('PREPARED',key(row),'dev' if development else 'main',flush=True)
    return audit


def main():
    torch.set_num_threads(1);p=load(OLD/'protocol.json')
    protocol=dict(version=1,steps=24,noise_scale=0.,main_cases=p['main_cases'],precheck_cases=p['precheck_cases'],
                  development=p['development'],weights=p['weights'],thresholds=p['thresholds'],
                  primary_arms=list('ABCDEFG'),additional_primary_arms=['G_LBFGSB_Hrigid','D_MMFF','budget_iterations','budget_range','budget_both','local_scope'],
                  training=False,batch_sizes=[16,32],physical_GPU=0,
                  original_predicted_stereo_definition_expected_complete=12,
                  continuous_projection_after_steps=list(range(23)),terminal_projection_after_step=23,
                  prompt_sha256=sha256(TASK/'prompt.md'),reply_sha256=sha256(TASK/'reply.md'),
                  topology_updates=False,template_orientation_algorithm='historical orientation.py unchanged',
                  primary_initialization='saved unbound final-predicted-graph fragments plus original random core centers / template seed rotations',
                  movable_scope='all fragments; separate optional deterministic local-scope flag',
                  stereo='historical derived HQ and original declared-graph stereo evaluated separately')
    if (OUT/'protocol.json').exists():assert load(OUT/'protocol.json')==protocol
    else:dump(OUT/'protocol.json',protocol)
    lib=VocabLibrary();audits=[]
    for dev in [True,False]:
        for row in protocol['development' if dev else 'main_cases']:audits.append(prepare_case(row,lib,dev))
    frozen={}
    for audit in audits:frozen.update(audit['source_sha256'])
    for path in list((OLD/'source').glob('*.py'))+list((PROJECT).glob('*.py'))+list((ROOT/'denovo_quality').glob('*.py')):
        frozen[str(path)]=sha256(path)
    for item in protocol['weights'].values():
        assert sha256(item['path'])==item['sha256'];frozen[item['path']]=item['sha256']
    for name in ['quality_config.json','posebusters_no_water.json']:
        assert sha256(OUT/name)==sha256(OLD/name);frozen[str(OLD/name)]=sha256(OLD/name)
    frozen[str(ROOT/'geometry_constraints_20261103/repair.py')]=sha256(ROOT/'geometry_constraints_20261103/repair.py')
    dump(OUT/'frozen_historical_inputs.json',frozen)
    dump(OUT/'input_audit.json',dict(passed=True,cases=len(audits),audits=audits,files=len(frozen),
                                   orientation_source_unchanged=sha256(OUT/'source/orientation.py')==sha256(OLD/'source/orientation.py')))
    csvwrite(OUT/'PORT_REFERENCE_AUDIT.csv',[r for a in audits for r in a['ports']])


if __name__=='__main__':main()
