"""Independent, bounded rigid projection; only real-core atoms define energy."""
from common import *
import time
from functools import lru_cache
import torch
from rdkit import Chem
from rdkit.Chem import AllChem
from scipy.spatial.transform import Rotation
from oracle_graph import assemble
from runtime import Geometry, SCALE
from denovo_quality.geometry import bounds_matrix

@lru_cache(maxsize=16)
def protein_data(path):
    from denovo_quality.protein import read_protein
    a=[v for v in read_protein(path)['atoms'] if v['kind']!='water']
    return np.asarray([v['xyz'] for v in a]),np.asarray([v['vdw_radius_A'] for v in a]),np.asarray([v['covalent_radius_A'] for v in a]),np.asarray([v['kind']=='inorganic_cofactor' for v in a])

class Terms:
    def __init__(self,spec,context,xyz,slots,config):
        self.mol=assemble(spec);n=self.mol.GetNumAtoms();self.groups=[f['atom_ids'] for f in spec['fragments']]
        self.fids=np.empty(n,dtype=int)
        for f,g in enumerate(self.groups):self.fids[g]=f
        slots=sorted(set(slots));self.slots=slots;self.movable=np.isin(self.fids,slots)
        self.centers=np.array([xyz[g].mean(0) for g in self.groups]);self.xyz=np.asarray(xyz,dtype=float)
        h=Chem.AddHs(Chem.Mol(self.mol),addCoords=True);props=AllChem.MMFFGetMoleculeProperties(h,mmffVariant='MMFF94s')
        self.bonds=[];self.angles=[];self.unavailable=[]
        for b in self.mol.GetBonds():
            i,j=b.GetBeginAtomIdx(),b.GetEndAtomIdx()
            if self.fids[i]==self.fids[j] or not (self.movable[i] or self.movable[j]):continue
            p=props.GetMMFFBondStretchParams(h,i,j) if props else None
            if p is None:self.unavailable.append(['bond',i,j])
            else:self.bonds.append([i,j,p[-1]])
        from itertools import combinations
        for atom in self.mol.GetAtoms():
            j=atom.GetIdx()
            for i,k in combinations([a.GetIdx() for a in atom.GetNeighbors()],2):
                if len({self.fids[i],self.fids[j],self.fids[k]})==1 or not any(self.movable[[i,j,k]]):continue
                p=props.GetMMFFAngleBendParams(h,i,j,k) if props else None
                if p is None:self.unavailable.append(['angle',i,j,k])
                else:self.angles.append([i,j,k,np.cos(np.deg2rad(p[-1]))])
        pt=Chem.GetPeriodicTable();r=np.array([pt.GetRvdw(a.GetAtomicNum()) for a in self.mol.GetAtoms()]);cr=np.array([pt.GetRcovalent(a.GetAtomicNum()) for a in self.mol.GetAtoms()])
        topo=Chem.GetDistanceMatrix(self.mol);bounds=bounds_matrix(self.mol);self.pairs=[]
        for i in range(n):
            for j in range(i+1,n):
                if self.fids[i]==self.fids[j] or topo[i,j]<=2 or not(self.movable[i] or self.movable[j]):continue
                # Same local-distance convention as frozen QC. This is a repulsive
                # feasibility surrogate, not a claim to evaluate MMFF total energy.
                limit=.7*bounds[j,i] if topo[i,j]==3 else .6*(r[i]+r[j])
                self.pairs.append([i,j,limit])
        protein,pr,pc,met=protein_data(str(context['pdb_path']));limits=.75*(r[:,None]+pr[None,:]);limits[:,met]=.75*(cr[:,None]+pc[None,met])
        self.protein=protein;self.limits=limits
        d=np.linalg.norm(xyz[:,None]-protein[None],axis=-1)
        maxrad=np.array([max(np.linalg.norm(xyz[g]-xyz[g].mean(0),axis=-1),default=0) for g in self.groups])
        budget=config['max_translation_A']+2*maxrad[self.fids]*np.sin(config['max_rotation_rad']/2)
        pi,pj=np.where(self.movable[:,None] & (d<limits+budget[:,None]+.001))
        self.pp=np.stack([pi,pj],-1);self.base_overlap=np.maximum(limits-d,0)
        self.cache={}
        self.function_evaluations=0

    def tensors(self):
        if self.cache:return self.cache
        def t(v):return torch.tensor(v,dtype=torch.float64)
        self.cache=dict(x=t(self.xyz),centers=t(self.centers),fids=torch.tensor(self.fids),
            bonds=t(self.bonds).reshape(-1,3),angles=t(self.angles).reshape(-1,4),pairs=t(self.pairs).reshape(-1,3),
            pi=torch.tensor(self.pp[:,0]),protein=t(self.protein[self.pp[:,1]]),limits=t(self.limits[self.pp[:,0],self.pp[:,1]]))
        return self.cache

    def coordinates(self,twist):
        d=self.tensors();nf=len(self.groups);full=torch.zeros((nf,6),dtype=twist.dtype)
        full=full.index_copy(0,torch.tensor(self.slots),twist);v=full[:,3:];z=torch.zeros_like(v[:,0])
        skew=torch.stack([z,-v[:,2],v[:,1],v[:,2],z,-v[:,0],-v[:,1],v[:,0],z],-1).reshape(-1,3,3)
        R=torch.matrix_exp(skew);center=d['centers'][d['fids']]
        x=torch.einsum('nij,nj->ni',R[d['fids']],d['x']-center)+center+full[d['fids'],:3]
        return x,R,full

    def energy(self,twist,config,arm):
        self.function_evaluations+=1
        x,R,full=self.coordinates(twist);d=self.tensors();zero=x.sum()*0;b=d['bonds'];a=d['angles'];p=d['pairs']
        eb=(((x[b[:,0].long()]-x[b[:,1].long()]).norm(dim=-1)-b[:,2])/.15).square().mean() if len(b) else zero
        if len(a):
            u=x[a[:,0].long()]-x[a[:,1].long()];v=x[a[:,2].long()]-x[a[:,1].long()]
            cos=(u*v).sum(-1)/(u.norm(dim=-1)*v.norm(dim=-1)).clamp_min(1e-12)
            ea=((cos-a[:,3])/.25).square().mean()
        else:ea=zero
        ec=torch.relu(p[:,2]-(x[p[:,0].long()]-x[p[:,1].long()]).norm(dim=-1)).square().sum()/len(x) if len(p) else zero
        ep=torch.relu(d['limits']-(x[d['pi']]-d['protein']).norm(dim=-1)).square().sum()/len(x) if len(d['pi']) else zero
        ed=displacement_prior(twist,config) if len(twist) else zero
        terms=torch.stack([eb,ea,ec,ep,ed]);w=config['weights'].copy()
        if arm=='B':w[2:]=[0.,0.,0.]
        elif arm=='C':w[3:]=[0.,0.]
        return (terms*torch.tensor(w,dtype=terms.dtype)).sum(),terms,x,R,full

def displacement_prior(twist,config):
    """The prior scales are independent of the feasible motion domain."""
    return ((twist[:,:3]/config['translation_normalization_A']).square().sum(-1).mean()
            +(twist[:,3:]/config['rotation_normalization_rad']).square().sum(-1).mean())

def clip_norm(x,limit):
    return x*np.minimum(1.,limit/np.maximum(np.linalg.norm(x,axis=-1,keepdims=True),1e-30))

def project(spec,context,xyz,slots,config,arm='D'):
    start=time.perf_counter();xyz=np.asarray(xyz,dtype=float);nf=len(spec['fragments'])
    result=dict(status='unchanged',reason=None,arm=arm,moved_slots=slots,iterations=0,seconds=0.)
    identity=np.repeat(np.eye(3)[None],nf,0);zero=np.zeros((nf,3));terms=None
    if arm=='A' or not slots:return dict(xyz=xyz,R=identity,translation=zero,**result)
    try:
        terms=Terms(spec,context,xyz,slots,config);tw=np.zeros((len(slots),6));trace=[];gradient_evaluations=0;backtracking_trials=0;outer_iterations=0;translation_path=np.zeros(len(slots));rotation_path=np.zeros(len(slots))
        if terms.unavailable:raise ValueError('MMFF equilibrium unavailable: '+str(terms.unavailable))
        with torch.enable_grad():
            value,*_=terms.energy(torch.tensor(tw),config,arm);initial=float(value);previous=initial
            for iteration in range(config['iterations']):
                outer_iterations+=1
                q=torch.tensor(tw,requires_grad=True);value,components,_,_,_=terms.energy(q,config,arm)
                grad=torch.autograd.grad(value,q)[0].detach().numpy()
                gradient_evaluations+=1
                if not np.isfinite(grad).all():raise FloatingPointError('nonfinite gradient')
                step=np.concatenate([clip_norm(-grad[:,:3]*config['learning_rate'],config['step_translation_A']),clip_norm(-grad[:,3:]*config['learning_rate'],config['step_rotation_rad'])],-1)
                accepted=False
                for factor in [1.,.5,.25,.125,.0625]:
                    backtracking_trials+=1
                    trial=tw+factor*step;trial[:,:3]=clip_norm(trial[:,:3],config['max_translation_A']);trial[:,3:]=clip_norm(trial[:,3:],config['max_rotation_rad'])
                    # Exact relative SO3 step, rather than relying on rotvec difference.
                    r0=Rotation.from_rotvec(tw[:,3:]).as_matrix();r1=Rotation.from_rotvec(trial[:,3:]).as_matrix()
                    angle=np.linalg.norm(Rotation.from_matrix(r1@r0.transpose(0,2,1)).as_rotvec(),axis=-1)
                    if np.any(angle>config['step_rotation_rad']+1e-10):continue
                    nv,nt,nx,nr,nfull=terms.energy(torch.tensor(trial),config,arm);number=float(nv)
                    if not np.isfinite(number) or number>=previous-1e-12:continue
                    # Every energy arm uses the same hard protein safeguard.
                    px=nx.detach().numpy();over=np.maximum(terms.limits-np.linalg.norm(px[:,None]-terms.protein[None],axis=-1),0)
                    if np.any((terms.base_overlap<=1e-6)&(over>1e-5)):continue
                    if np.max(over,initial=0)>np.max(terms.base_overlap,initial=0)+1e-5:continue
                    step_translation=float(np.linalg.norm(trial[:,:3]-tw[:,:3],axis=-1).max())
                    translation_path+=np.linalg.norm(trial[:,:3]-tw[:,:3],axis=-1);rotation_path+=angle
                    tw=trial;previous=number;accepted=True
                    trace.append(dict(iteration=iteration,energy=number,terms=nt.detach().numpy().tolist(),step_translation_A=step_translation,step_rotation_rad=float(angle.max()),max_translation_A=float(np.linalg.norm(tw[:,:3],axis=-1).max()),max_rotation_rad=float(np.linalg.norm(tw[:,3:],axis=-1).max())))
                    break
                if not accepted:break
            _,components,x,R,full=terms.energy(torch.tensor(tw),config,arm)
            terminal=torch.tensor(tw,requires_grad=True)
            final_value,*_=terms.energy(terminal,config,arm)
            terminal_gradient=torch.autograd.grad(final_value,terminal)[0].detach().numpy()
        x=x.detach().numpy();R=R.detach().numpy();full=full.detach().numpy()
        delta=max((float(np.max(np.abs(np.linalg.norm(x[g][:,None]-x[g][None,:],axis=-1)-np.linalg.norm(xyz[g][:,None]-xyz[g][None,:],axis=-1)))) for g in terms.groups),default=0.)
        assert np.isfinite(x).all() and delta<1e-8
        assert np.max(np.abs(R.transpose(0,2,1)@R-np.eye(3)))<1e-10 and np.min(np.linalg.det(R))>.999999
        result.update(status='projected' if trace else 'unchanged',reason=None if trace else 'no_safe_descent',iterations=len(trace),trace=trace,initial_energy=initial,final_energy=previous,
            final_energy_terms=components.detach().numpy().tolist(),internal_distance_delta_A=delta,translation_max_A=float(np.linalg.norm(full[:,:3],axis=-1).max()),rotation_max_rad=float(np.linalg.norm(full[:,3:],axis=-1).max()),
            core_RMSD_A=float(np.sqrt(np.mean(np.sum((x-xyz)**2,axis=-1)))),core_max_delta_A=float(np.linalg.norm(x-xyz,axis=-1).max()),equilibrium_unavailable=terms.unavailable,
            seconds=time.perf_counter()-start)
        result.update(function_evaluations=terms.function_evaluations,gradient_evaluations=gradient_evaluations+1,
            backtracking_trials=backtracking_trials,outer_iterations=outer_iterations,
            termination='iteration_limit' if len(trace)==config['iterations'] else 'no_safe_descent',
            final_gradient_L2=float(np.linalg.norm(terminal_gradient)),final_gradient_inf=float(np.max(np.abs(terminal_gradient))),
            translation_path_A=translation_path.tolist(),rotation_path_rad=rotation_path.tolist(),
            translation_boundary_slots=int(np.sum(np.linalg.norm(tw[:,:3],axis=-1)>=config['max_translation_A']-1e-8)),
            rotation_boundary_slots=int(np.sum(np.linalg.norm(tw[:,3:],axis=-1)>=config['max_rotation_rad']-1e-8)))
        return dict(xyz=x,R=R,translation=full[:,:3],**result)
    except Exception as exc:
        result.update(status='fallback',reason=repr(exc),seconds=time.perf_counter()-start,equilibrium_unavailable=terms.unavailable if terms else [])
        return dict(xyz=xyz,R=identity,translation=zero,**result)

def worker(job):
    torch.set_num_threads(1)
    result=project(**job)
    return result

def apply_to_state(state,result):
    """Move all existing fragment nodes consistently, keeping graph/features fixed."""
    if result['status']!='projected':return
    xyz=state.physical();centers=np.array([xyz[state.pn+np.asarray(g)].mean(0) for g in state.groups])
    R=torch.as_tensor(result['R'],device=state.C.device,dtype=state.C.dtype)
    c=state.C*SCALE+state.graph.pocket_com.reshape(3).to(state.C.device)
    center=torch.as_tensor(centers,device=c.device,dtype=c.dtype);trans=torch.as_tensor(result['translation'],device=c.device,dtype=c.dtype)
    C=(torch.einsum('nij,nj->ni',R,c-center)+center+trans-state.graph.pocket_com.reshape(3).to(c.device))/SCALE
    Q=R@state.Q
    with torch.no_grad():
        state.C,state.Q=C,Q
        state.pos=state.den._apply_transformations(state.pos0,state.batch,state.T0,state.R0,Q,C)
    actual=state.physical()[state.pn:state.pn+len(result['xyz'])]
    assert np.max(np.linalg.norm(actual-result['xyz'],axis=-1))<2e-4,'Rigid state transfer mismatch'

def metadata(result):return {k:v for k,v in result.items() if k not in ['xyz','R','translation']}
