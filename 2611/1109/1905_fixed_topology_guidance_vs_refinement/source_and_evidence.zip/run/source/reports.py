"""Paired, denominator-preserving reports; never select settings on main QC."""
from common import *
from collections import defaultdict,Counter
import math
import torch
from scipy.spatial.transform import Rotation
from runtime import SCALE


def write(name,lines):
    (OUT/name).write_text('\n'.join(lines)+'\n')


def mean(rows,field):
    x=[r[field] for r in rows if r.get(field) is not None]
    return float(np.mean(x)) if x else None


def fmt(value,places=4):
    return 'NA' if value is None else f'{value:.{places}f}'


def distribution(values):
    values=[v for v in values if v is not None and np.isfinite(v)]
    if not values:return dict(available=0)
    return dict(available=len(values),min=float(np.min(values)),median=float(np.median(values)),mean=float(np.mean(values)),max=float(np.max(values)))


def pair(left,right):
    a={(r['pid'],r['seed']):r for r in left};b={(r['pid'],r['seed']):r for r in right}
    assert set(a)==set(b)
    return dict(cases=len(a),HQ_wins=sum(not a[k]['HQ_no_water'] and b[k]['HQ_no_water'] for k in a),
                HQ_losses=sum(a[k]['HQ_no_water'] and not b[k]['HQ_no_water'] for k in a),
                bond_MAE_change_A=float(np.mean([b[k]['cross_bond_MAE_A']-a[k]['cross_bond_MAE_A'] for k in a])),
                angle_MAE_change_deg=float(np.mean([b[k]['cross_angle_MAE_deg']-a[k]['cross_angle_MAE_deg'] for k in a])))


def table(groups,order):
    lines=['|方法|分母|HQ_no_water|原图定义下HQ|PB全通过|键长MAE Å|键角MAE °|优化失败|',
           '|---|---:|---:|---:|---:|---:|---:|---:|']
    for name in order:
        rows=groups[name];n=len(rows)
        lines.append(f'|{name}|{n}|{sum(r["HQ_no_water"] for r in rows)}/{n}|{sum(r["HQ_with_original_declared_stereo"] for r in rows)}/{n}|{sum(r["posebusters_all_pass"] is True for r in rows)}/{n}|{fmt(mean(rows,"cross_bond_MAE_A"),6)}|{fmt(mean(rows,"cross_angle_MAE_deg"))}|{sum(r["optimizer_failed"] for r in rows)}|')
    return lines


def collect(inventory):
    rows=[];qc_rows=[];failures=[]
    from sampling import read_case
    for folder in load(OUT/inventory)['folders']:
        f=Path(folder);rec=load(f/'result.json');quality=load(f/'quality.json');q=quality['metric'];checks=q['checks'];modules=q.get('modules',{});meta=rec.get('optimizer') or {}
        inp=torch.load(f/'endpoint.pt',weights_only=False,map_location='cpu');x=np.asarray(inp['xyz']);pid=rec['pid'];seed=rec['seed']
        primary=rec['phase']=='primary32';method=rec['method']
        if primary:
            parent=OUT/'primary32/paths'/f'{pid}_{seed}_A';case=read_case(rec)
            initial=np.load(parent/'initial_state.npz')['xyz'];a=torch.load(parent/'endpoint.pt',weights_only=False,map_location='cpu')['xyz']
        else:
            src=Path(rec['source']['folder']);old=torch.load(src/'postprocess_input.pt',weights_only=False,map_location='cpu')
            a=old['mol'].GetConformer().GetPositions();initial=a;case=dict(groups=inp['groups'])
        displacement=np.linalg.norm(x-a,axis=-1);from_initial=np.linalg.norm(x-initial,axis=-1)
        internal=max(float(np.max(np.abs(np.linalg.norm(x[g][:,None]-x[g][None,:],axis=-1)-np.linalg.norm(initial[g][:,None]-initial[g][None,:],axis=-1)))) for g in inp['groups'])
        assert internal<.0002,('Final rigidity',folder,internal)
        declared=rec['declared_stereo']['checks'];declared_checks=dict(checks)
        for k in ['stereo_definition_complete','stereo_geometry_consistent']:declared_checks[k]=declared.get(k)
        protein=modules.get('protein',{});geometry=modules.get('geometry',{});pb=modules.get('posebusters',{})
        row=dict(phase=rec['phase'],method=method,pid=pid,seed=seed,attribution=rec['attribution'],HQ_no_water=quality['HQ_no_water'],
                 HQ_with_original_declared_stereo=all(declared_checks.get(k) is True for k in load(OUT/'quality_config.json')['quality']['required_checks']) and not quality['optimizer_failed'],
                 posebusters_all_pass=checks.get('posebusters_all_pass'),declared_stereo_definition_complete=declared.get('stereo_definition_complete'),
                 declared_stereo_geometry_consistent=declared.get('stereo_geometry_consistent'),coordinate_derived_stereo_definition_complete=checks.get('stereo_definition_complete'),
                 coordinate_derived_stereo_geometry_consistent=checks.get('stereo_geometry_consistent'),
                 original_graph_sha256=rec['graph_sha256'],optimizer_failed=quality['optimizer_failed'],**rec['geometry'],
                 all_severe_internal_pairs=geometry.get('severe_internal_clash_pairs'),abnormal_amide_torsions=geometry.get('abnormal_amide_torsion_count'),
                 amide_torsions=geometry.get('amide_torsions'),abnormal_rings=geometry.get('abnormal_ring_count'),
                 full_environment_severe_protein_pairs=protein.get('severe_clash_pairs'),pocket_atom_fraction=protein.get('pocket_atom_fraction'),
                 contact_pairs=protein.get('contact_pairs'),centroid_nearest_protein_A=protein.get('centroid_nearest_protein_A'),
                 RMSD_to_A_or_own_historical_endpoint_A=float(np.sqrt(np.mean(displacement**2))),max_displacement_to_A_or_historical_A=float(displacement.max()),
                 RMSD_from_initial_A=float(np.sqrt(np.mean(from_initial**2))),max_displacement_from_initial_A=float(from_initial.max()),
                 centroid_displacement_to_A_or_historical_A=float(np.linalg.norm(x.mean(0)-a.mean(0))),
                 per_atom_displacements_to_A_or_historical_A=displacement.tolist(),internal_distance_max_change_A=internal,
                 optimizer_success=meta.get('success'),optimizer_status=meta.get('status'),optimizer_iterations=meta.get('iterations'),
                 optimizer_outer_iterations=meta.get('outer_iterations'),function_evaluations=meta.get('function_evaluations'),gradient_evaluations=meta.get('gradient_evaluations'),
                 final_gradient_L2=meta.get('final_gradient_L2'),final_gradient_inf=meta.get('final_gradient_inf'),
                 final_projected_gradient_inf=meta.get('final_projected_gradient_inf'),termination=meta.get('termination') or meta.get('reason'),
                 optimizer_seconds=meta.get('seconds'),optimizer_initial_objective=meta.get('initial_objective',meta.get('initial_energy')),
                 optimizer_final_objective=meta.get('final_objective',meta.get('final_energy')),backtracking_trials=meta.get('backtracking_trials'),
                 translation_boundary_slots=meta.get('translation_boundary_slots'),rotation_boundary_slots=meta.get('rotation_boundary_slots'),
                 fragment_translation_A=meta.get('fragment_translation_A'),fragment_Euler_rotation_rad=meta.get('fragment_Euler_rotation_rad'),
                 optimization_translation_path_A=meta.get('translation_path_A',meta.get('fragment_translation_path_A')),
                 optimization_rotation_path_rad=meta.get('rotation_path_rad',meta.get('fragment_rotation_path_rad')),
                 pose_NFE=24 if primary else 0,endpoint_folder=folder,failed_checks=q.get('failed_checks'),unavailable_checks=q.get('unavailable_checks'),
                 input_unchanged=quality['input_unchanged'])
        if primary:
            path_name='C' if method in ['C','D','D_MMFF'] else 'A';path=load(OUT/'primary32/paths'/f'{pid}_{seed}_{path_name}'/'path.json')
            row.update(network_and_guidance_motion=path['motion'],source_path=path_name)
            if method=='D_MMFF':
                own=torch.load(OUT/'primary32/endpoints'/f'{pid}_{seed}_D'/'endpoint.pt',weights_only=False,map_location='cpu')['xyz']
                assert hashlib.sha256(own.tobytes()).hexdigest()==rec['source']['actual_MMFF_input_xyz_sha256'],'D to MMFF input mismatch'
            else:own=torch.load(Path(path['folder'])/'endpoint.pt',weights_only=False,map_location='cpu')['xyz']
            row['RMSD_from_immediate_optimizer_input_A']=float(np.sqrt(np.mean(np.sum((x-own)**2,axis=-1))))
        for name,status in checks.items():qc_rows.append(dict(phase=rec['phase'],method=method,pid=pid,seed=seed,check=name,value=status))
        for name,status in pb.get('tests',{}).items():qc_rows.append(dict(phase=rec['phase'],method=method,pid=pid,seed=seed,check='PoseBusters:'+name,value=status))
        if quality['optimizer_failed'] or not quality['HQ_no_water']:
            failures.append(dict(attempt_id=rec['attempt_id'],failed_checks=q.get('failed_checks'),unavailable_checks=q.get('unavailable_checks'),errors=q.get('errors'),optimizer=meta,folder=folder))
        rows.append(row)
    return rows,qc_rows,failures


def trajectory_rows():
    rows=[]
    for path in (OUT/'primary32/paths').glob('*/path.json'):
        rec=load(path);initial=np.load(path.parent/'initial_state.npz');previous_C=initial['C'];previous_Q=initial['Q']
        cumulative_T=np.zeros(len(previous_C));cumulative_R=np.zeros(len(previous_C))
        for stage in rec['trajectory']:
            step=stage['step'];state=np.load(path.parent/'trajectory'/f'step_{step:02d}.npz')
            netT=np.linalg.norm(state['network_C']-previous_C,axis=-1)*SCALE
            netR=np.linalg.norm(Rotation.from_matrix(state['network_Q']@previous_Q.transpose(0,2,1)).as_rotvec(),axis=-1)
            guideT=np.linalg.norm(state['C']-state['network_C'],axis=-1)*SCALE
            guideR=np.linalg.norm(Rotation.from_matrix(state['Q']@state['network_Q'].transpose(0,2,1)).as_rotvec(),axis=-1)
            cumulative_T+=netT+guideT;cumulative_R+=netR+guideR
            common=dict(pid=rec['pid'],seed=rec['seed'],path=rec['label'],step=step,t=stage['t'],
                        network_translation_A=netT.tolist(),network_rotation_rad=netR.tolist(),guidance_translation_A=guideT.tolist(),guidance_rotation_rad=guideR.tolist(),
                        cumulative_translation_A=cumulative_T.tolist(),cumulative_rotation_rad=cumulative_R.tolist(),
                        internal_distance_delta_A=stage['internal_distance_delta_A'],projection=stage['projection'])
            for name in ['network','after_guidance']:
                rows.append(dict(**common,stage=name,**stage[name],RMSD_to_path_endpoint_A=stage[name+'_RMSD_to_path_endpoint_A']))
            previous_C=state['C'];previous_Q=state['Q']
    return rows


def plots(rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(10,7),constrained_layout=True)
    for ax,field,title in zip(axes.flat,['cross_bond_MAE_A','cross_angle_MAE_deg','severe_cross_internal_pairs','severe_protein_pairs'],['Cross-fragment bond MAE (A)','Cross-fragment angle MAE (degrees)','Fast interfragment clash pairs','Fast protein clash pairs']):
        for path,stage,label in [('A','network','A: raw'),('C','network','C: after network'),('C','after_guidance','C: after guidance')]:
            values=[np.mean([r[field] for r in rows if r['path']==path and r['stage']==stage and r['step']==step]) for step in range(24)]
            ax.plot(range(1,25),values,label=label)
        ax.set(title=title,xlabel='Denoising update');ax.grid(alpha=.2)
    axes.flat[0].legend();fig.savefig(OUT/'PER_STEP_GEOMETRY.png',dpi=180);fig.savefig(OUT/'PER_STEP_GEOMETRY.pdf');plt.close(fig)


def generate():
    primary,qc,failures=collect('primary_inventory.json');secondary,sqc,sfail=collect('secondary_inventory.json')
    csvwrite(OUT/'PER_GENERATION_RESULTS.csv',primary+secondary);csvwrite(OUT/'QUALITY_CHECKS.csv',qc+sqc)
    dump(OUT/'failure_cases.json',failures+sfail)
    groups=defaultdict(list)
    for r in primary:groups[r['method']].append(r)
    other=defaultdict(list)
    for r in secondary:other[r['method']].append(r)
    assert all(len(v)==32 for v in groups.values()) and len(primary)==416 and len(secondary)==160
    for method,rows in groups.items():
        assert sum(r['declared_stereo_definition_complete'] is True for r in rows)==12,(method,'Original stereo definitions changed')
        for r in rows:
            baseline=next(a for a in groups['A'] if (a['pid'],a['seed'])==(r['pid'],r['seed']))
            assert baseline['original_graph_sha256']==r['original_graph_sha256']
    comparisons={}
    for a,b in [('A','C'),('A','B'),('C','D'),('B','D'),('B','E'),('D','E'),('E','D_MMFF'),('F','G'),('G','G_LBFGSB_Hrigid'),('G_LBFGSB_Hrigid','E'),
                ('B','budget_iterations'),('B','budget_range'),('B','budget_both'),('local_scope','B')]:
        comparisons[f'{a}_to_{b}']=pair(groups[a],groups[b])
    dump(OUT/'paired_comparisons.json',comparisons)
    curves=trajectory_rows();assert len(curves)==32*2*24*2;csvwrite(OUT/'PER_STEP_GEOMETRY.csv',curves);plots(curves)
    selected=load(OUT/'development_selection.json')['selected']
    summary=dict(primary_cases=32,primary_endpoints=len(primary),secondary_endpoints=len(secondary),
                 methods={k:dict(cases=len(v),HQ_no_water=sum(r['HQ_no_water'] for r in v),PB=sum(r['posebusters_all_pass'] is True for r in v),
                                bond_MAE_A=mean(v,'cross_bond_MAE_A'),angle_MAE_deg=mean(v,'cross_angle_MAE_deg')) for k,v in groups.items()},
                 secondary={k:dict(cases=len(v),HQ_no_water=sum(r['HQ_no_water'] for r in v)) for k,v in other.items()},comparisons=comparisons,selected_bridge=selected)
    dump(OUT/'summary.json',summary)
    core=table(groups,list('ABCDEFG')+['G_LBFGSB_Hrigid','D_MMFF'])
    lines=['# 固定图引导与末端优化结果','',
           'Primary为相同32张既有Baseline预测最终图重新随机初始化后的配对位姿生成。每组分母32。与历史动态图结果分开；所有末端优化保留归因。',
           'HQ_no_water沿用历史坐标推导注释口径，原图定义下HQ另列；后者没有把立体注释补全当成网络贡献。','']+core+['','## 配对比较','',
           '|比较（后者−前者）|HQ赢/输|键长MAE差 Å|键角MAE差 °|','|---|---:|---:|---:|']
    for name,values in comparisons.items():lines.append(f'|{name}|{values["HQ_wins"]}/{values["HQ_losses"]}|{fmt(values["bond_MAE_change_A"],6)}|{fmt(values["angle_MAE_change_deg"])}|')
    hq=lambda name:sum(r['HQ_no_water'] for r in groups[name])
    interaction=(hq('D')-hq('C'))-(hq('B')-hq('A'))
    lines+=['',f'2×2的HQ交互为 {interaction}/32；非线性、同样本配对且样本量小，不能把这些差值分摊成可加收益百分比。',
            '逐步曲线见 `PER_STEP_GEOMETRY.png` / `.pdf`；逐例成败、原图立体、位移、优化状态与失败保存在CSV/JSON。']
    write('GUIDANCE_ABLATION_RESULTS.md',lines)
    check=load(OUT/'precheck8_verification.json')
    write('TRAJECTORY_CONSISTENCY.md',['# 轨迹与几何一致性验收','',f'8例预检：通过={check["passed"]}；72个终态完成完整QC。',
          'A/B及C/D使用独立完整回放验收，要求逐位一致；相同方法独立重复也要求逐位一致。正式B/E从冻结A终态分叉，D从冻结C终态分叉，保留输入哈希。',
          '所有核心组初始实际坐标、C/Q与静态图完全相同；原预测立体定义保持12/32；保存的片段内部距离、有限性与正确SO(3)逐步检查。',
          'batch16/32由8例预检重复填满真实PyG批次，覆盖完整24步；该检查不代表32个不同分子的吞吐。正式运行另有32个不同样本实际合批。','',
          '|检查|通过|最大原子差 Å|最大RMSD Å|','|---|---|---:|---:|']+
          [f'|{c["name"]}|{c["passed"]}|{max(r["max_atom_delta_A"] for r in c["rows"]):.8g}|{max(r["max_RMSD_A"] for r in c["rows"]):.8g}|' for c in check['comparisons']]+
          ['','代码验收见 `unit_tests.log`；完整逐例证据见 `verification/`、`precheck8/`、`precheck_batch16/`和`precheck_batch32/`。'])
    budget_order=['B','budget_iterations','budget_range','budget_both','E','F','G','G_LBFGSB_Hrigid','local_scope']
    bridge_fair=[]
    for f in groups['F']:
        g=next(r for r in groups['G'] if (r['pid'],r['seed'])==(f['pid'],f['seed']))
        fm=load(Path(f['endpoint_folder'])/'result.json')['optimizer'];gm=load(Path(g['endpoint_folder'])/'result.json')['optimizer']
        assert fm['initialization_sha256']==gm['initialization_sha256'] and fm['variables']==gm['variables'] and fm['solver']==gm['solver']=='SLSQP'
        bridge_fair.append(dict(pid=f['pid'],seed=f['seed'],same_full_H_initialization=True,same_variables=True,same_solver=True))
    dump(OUT/'bridge_consistency.json',dict(passed=True,rows=bridge_fair))
    budget=['# 优化预算、运动范围与能量桥接','',f'简化内部能量尺度在独立6例开发集从1/10/100选择，冻结值={selected["simple_internal_scale"]}。32例不参与选择。','']+table(groups,budget_order)+['',
            '预算分别改变迭代上限或累计运动上限，正则化尺度与单步上限不变。扩大域为SO(3)/平移球包络近似，不等同于原MMFF盒。20步路径可达范围有限；无收益须结合触界/停止诊断。',
            'F/G完全相同SLSQP、SE(3)变量、H初态/刚性附着、边界、共同环境和位姿先验，仅替换内部势能。G与G_LBFGSB_Hrigid比较求解器/停止规则；后者与E比较独立氢自由度。',
            '能量模型贡献只对这个共享流程成立，内部能量单位/尺度不同，不能直接比较能量数字；非凸优化结果不是全局上界。',
            'local_scope只移动原图第一条连接两端，代表这个预先定义选区；不能泛化为所有局部选区。','',
            '|方法|迭代均值|函数评估均值|CPU秒均值|末梯度∞均值|终止原因|','|---|---:|---:|---:|---:|---|']
    for name in budget_order+['D_MMFF']:
        v=groups[name];budget.append(f'|{name}|{fmt(mean(v,"optimizer_iterations"),2)}|{fmt(mean(v,"function_evaluations"),2)}|{fmt(mean(v,"optimizer_seconds"))}|{fmt(mean(v,"final_gradient_inf"))}|{dict(Counter(r["termination"] for r in v))}|')
    budget+=['','完整迭代/评估、实际梯度、触界、位移分布和未收敛输出均在 `PER_GENERATION_RESULTS.csv` 中；未收敛与软件失败分列。']
    write('MMFF_BUDGET_MATCHING.md',budget)
    secondary_order=['historical_Baseline','secondary_Baseline_projection','secondary_Baseline_MMFF','historical_Full_guidance','secondary_Full_guidance_MMFF']
    old_mmff=other['secondary_Baseline_MMFF'];oldraw=other['historical_Baseline'];oldguide=other['historical_Full_guidance']
    assert sum(r['HQ_no_water'] for r in oldraw)==2 and sum(r['HQ_no_water'] for r in old_mmff)==28 and sum(r['HQ_no_water'] for r in oldguide)==8,'Historical endpoint/QC reproduction failed'
    secondary_report=['# 历史动态图末端配对','',
                      '两批各32例：历史Baseline图与历史Full_guidance图不同，分别统计。输入读取旧postprocess_input.pt完整精度；Full_guidance保留其已发布的末步投影后终态标签。所有末端优化重新运行，避免把缓存复用称作新耗时。','']+table(other,secondary_order)+['',
                      '历史Baseline原态2/32、同原MMFF28/32以及历史Full_guidance原态8/32均复现。此前MMFF均值RMSD约0.491 Å，27/32收敛、5/32达到上限作为历史事实保留。',
                      f'本轮Baseline→MMFF RMSD分布：`{distribution([r["RMSD_to_A_or_own_historical_endpoint_A"] for r in old_mmff])}`。',
                      f'最大单原子位移分布：`{distribution([r["max_displacement_to_A_or_historical_A"] for r in old_mmff])}`。',
                      f'收敛状态：`{dict(Counter(r["optimizer_success"] for r in old_mmff))}`；终止原因：`{dict(Counter(r["termination"] for r in old_mmff))}`。',
                      '逐分子原子位移列表、质心移动、梯度、口袋占据和终止原因均单列。小质心漂移不能替代局部位移检查，也不能仅凭高通过率认定图完全合理。']
    write('SECONDARY_DYNAMIC_GRAPH_MMFF.md',secondary_report)
    breakdown=[]
    for name,rows in groups.items():
        for check_name in sorted({r['check'] for r in qc if r['method']==name}):
            vals=[r['value'] for r in qc if r['method']==name and r['check']==check_name]
            breakdown.append(dict(method=name,check=check_name,denominator=32,passed=sum(v is True for v in vals),failed=sum(v is False for v in vals),unavailable=sum(v is None for v in vals)))
    csvwrite(OUT/'QUALITY_BREAKDOWN.csv',breakdown)
    quality_report=['# 质量与立体定义分解','',
                    '所有32例保留分母。HQ_no_water与全部非水PoseBusters门槛不变，原图定义完整12/32在全部13种Primary终态中一致；几何推导注释的完整性及一致性另列。',
                    '优化未收敛的可用终态仍评价并报告；优化器软件失败使用原态保留证据，但不记为该方法成功。失败、不可用、原图未定义立体均不能删除。',
                    'PER_GENERATION_RESULTS.csv记录严重内部/蛋白碰撞、跨片段键角、酰胺、环、口袋占据、接触及原图/推导立体；QUALITY_CHECKS.csv保留逐例全部检查，QUALITY_BREAKDOWN.csv按方法列出通过/失败/不可用。','',
                    '|方法|原图定义完整|原图几何立体一致|推导注释完整|内部刚性最大差 Å|','|---|---:|---:|---:|---:|']
    for name,v in groups.items():quality_report.append(f'|{name}|12/32|{sum(r["declared_stereo_geometry_consistent"] is True for r in v)}/32|{sum(r["coordinate_derived_stereo_definition_complete"] is True for r in v)}/32|{max(r["internal_distance_max_change_A"] for r in v):.8g}|')
    write('QUALITY_BREAKDOWN.md',quality_report)
    performance=[load(p) for p in OUT.glob('*/performance/*.json')];csvwrite(OUT/'PERFORMANCE.csv',[{k:v for k,v in r.items() if k!='timings'} for r in performance])
    perf=['# A100批处理与计算归因','',f'设备：{load(OUT/"environment.json")["GPU"]}；使用GPU0。FP32权重/接口、既有FP64稳定累积、24步时间网格、语义边随机方向均保持。',
          'Primary实际计算64条网络路径：32条A、32条C，每条24步；两个batch32共48次实际GPU主干前向。B/E/F/G和预算诊断从A分叉，D从C分叉；逻辑每种方法的网络NFE仍为每分子24，不能将共享缓存称为单次推理加速。',
          'C每例23次CPU投影，D再加一次；B每例一次。CPU优化迭代/函数与梯度评估不计为网络NFE。额外预检、开发、Secondary成本单列。',
          '观测墙时包含指标和证据落盘，另列扣除该开销的生成墙时；该差值仍含少量轨迹读取与汇总，不能当作纯GPU前向时间。CPU秒为每例优化函数计时，池墙时与单例时间总和不是同一口径。','',
          '|阶段/路径|batch|实际GPU前向|观测秒|指标/落盘秒|扣除后生成秒|纯前向秒|峰值GiB|','|---|---:|---:|---:|---:|---:|---:|---:|']
    for r in performance:perf.append(f'|{r["role"]}/{r["label"]}|{r["batch"]}|{r["actual_GPU_NFE"]}|{r["observed_wall_seconds"]:.3f}|{r["metric_and_evidence_seconds"]:.3f}|{r["generation_excluding_metric_evidence_seconds"]:.3f}|{sum(v["forward_ms"] for v in r["timings"])/1000:.3f}|{r["peak_GPU_allocated_bytes"]/2**30:.3f}|')
    write('A100_PERFORMANCE.md',perf)
    decisions=['# 实验决策','',f'固定图HQ：A={hq("A")}/32，B={hq("B")}/32，C={hq("C")}/32，D={hq("D")}/32，E={hq("E")}/32。',
               f'持续引导无末端修复 C−A={hq("C")-hq("A")}/32；仅末端投影 B−A={hq("B")-hq("A")}/32；引导路径末端增益 D−C={hq("D")-hq("C")}/32；末端相同 D−B={hq("D")-hq("B")}/32。',
               '以上是同32例配对诊断，不是未查看数据的泛化证明。连续误差和赢/输见配对表；少量HQ变化不能单独决定训练。','',
               f'预算分解：B={hq("B")}/32，增步={hq("budget_iterations")}/32，扩范围={hq("budget_range")}/32，同时={hq("budget_both")}/32。正则化尺度不变，但扩展球域与旧盒域不完全相同；应结合停止/触界判断。',
               f'能量桥接：F={hq("F")}/32，G={hq("G")}/32；相同共同条件下差值为{hq("G")-hq("F")}/32。求解器对照 G_LBFGSB_Hrigid={hq("G_LBFGSB_Hrigid")}/32；其与E的差异对应独立氢自由度。',
               f'引导后可修复性：D→MMFF={hq("D_MMFF")}/32，对照A→MMFF={hq("E")}/32；同时查看收敛、梯度、位移和总成本，不能由终点HQ推断全局能量地形。',
               '历史8/32与28/32来自不同生成路径/化学图且均含后处理，不能直接把20例差额全部归给持续引导或某一种能量项。本实验通过固定图Primary及两批Secondary给出受控证据；结论受固定片段内部形状、既有图质量及原图立体缺失限制。','']
    if hq('E')>=hq('D'):
        decisions.append('下一步优先将完整刚性MMFF作为有明确归因的细化参考，结合桥接对照定位可简化的成本；不能把优化结果称为神经网络几何能力。')
    if hq('D')>hq('B') and mean(groups['C'],'cross_bond_MAE_A')<mean(groups['A'],'cross_bond_MAE_A'):
        decisions.append('持续引导在固定图和相同末端处理下仍有诊断收益，值得在独立数据复核其增益/成本，再决定是否产品化。')
    else:decisions.append('当前固定图证据不足以优先推广持续引导：先完善末端细化与原预测化学定义，再在独立数据验证。')
    decisions.append('本轮不启动训练。是否加入可学习几何监督，应在新的独立评估和失败归因确认后另行讨论；刚体优化无法补全原图未定义立体或修复片段内部异常。')
    write('NEXT_STEP_DECISION.md',decisions)
    write('README.md',['# 固定化学图引导与末端细化','',f'完成32例Primary×13种终态、两批Secondary共160终态；8例预检通过。开发/正式严格分开。','']+core+['',
                      '协议见 FIXED_TOPOLOGY_PROTOCOL.md；主要配对结论见 GUIDANCE_ABLATION_RESULTS.md；下一步见 NEXT_STEP_DECISION.md。',
                      '完整科学结构、轨迹、QC缓存保留本地；如需GitHub交付，仅上传报告、源码、冻结配置、关键表和清单的紧凑归档。'])
    exclude={'ARTIFACT_MANIFEST.json','DELIVERY_VERIFICATION.json','status.json','process.json'}
    files={str(p.relative_to(OUT)):dict(bytes=p.stat().st_size,sha256=sha256(p)) for p in OUT.rglob('*') if p.is_file() and p.name not in exclude and p.suffix not in ['.log','.pyc']}
    dump(OUT/'ARTIFACT_MANIFEST.json',dict(files=files,file_count=len(files)))
    dump(OUT/'DELIVERY_VERIFICATION.json',dict(passed=True,primary_endpoints=416,secondary_endpoints=160,per_step_rows=len(curves),
                                             precheck_passed=check['passed'],bridge_passed=True,stereo_complete_each_group=12,
                                             historical_Baseline_HQ=2,historical_MMFF_HQ=28,historical_guidance_HQ=8,
                                             input_unchanged=all(r['input_unchanged'] for r in primary+secondary),manifest_files=len(files)))
    print('REPORTS COMPLETE',summary['methods'],flush=True)


if __name__=='__main__':generate()
