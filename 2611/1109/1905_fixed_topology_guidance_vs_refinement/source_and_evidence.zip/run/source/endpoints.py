"""Full precision terminal forks, unchanged QC and original stereo evidence."""
from common import *
import time
import traceback
import torch
from rdkit import Chem
from oracle_graph import assemble
from projection import project,metadata
from settings import projection_config,budget_configs,movable_slots
from runtime import Geometry
from mmff_reference import repair


def save_endpoint(folder,case,xyz,method,role,source,optimizer=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    mol=assemble(case['spec'])
    for i,x in enumerate(xyz):mol.GetConformer().SetAtomPosition(i,x.tolist())
    torch.save(dict(xyz=np.asarray(xyz),mol=mol,spec=case['spec'],context=case['context'],groups=case['groups']),folder/'endpoint.pt')
    with Chem.SDWriter(str(folder/'raw.sdf')) as writer:writer.write(mol)
    dump(folder/'original_spec.json',case['spec'])
    from denovo_quality.io import load_molecule
    from denovo_quality.chemistry import evaluate_chemistry
    from geometry_constraints_20261103.stereo import derive
    parsed,info,_=load_molecule(dict(record_index=0,sdf_path=str(folder/'raw.sdf'),chemistry_spec_path=str(folder/'original_spec.json')))
    details,checks=evaluate_chemistry(parsed,info)
    q,derived,decisions=derive(parsed,case['spec'])
    with Chem.SDWriter(str(folder/'derived.sdf')) as writer:writer.write(q)
    dump(folder/'derived_spec.json',derived);dump(folder/'stereo_decisions.json',decisions)
    attribution='neural_only' if method in ['A','historical_Baseline'] else 'diffusion_guided' if method=='C' else 'posthoc_MMFF' if method in ['E','D_MMFF','secondary_Baseline_MMFF','secondary_Full_guidance_MMFF','G','G_LBFGSB_Hrigid'] else 'final_local_projection'
    if method=='historical_Full_guidance':attribution='final_local_projection'
    aid=f'{role}_{case["pid"]}_{case["seed"]}_{method}'
    row=dict(molecule_id=aid,group=method,strategy=method,receptor_id=case['pid'],seed=case['seed'],phase=role,
             sdf_path=str(folder/'derived.sdf'),chemistry_spec_path=str(folder/'derived_spec.json'),protein_path=case['context']['pdb_path'],record_index=0)
    result=dict(attempt_id=aid,pid=case['pid'],seed=case['seed'],method=method,phase=role,folder=str(folder),
                attribution=attribution,source=source,optimizer=optimizer,manifest=row,
                graph_sha256=hashlib.sha256(json.dumps(case['spec'],sort_keys=True).encode()).hexdigest(),
                declared_stereo=dict(checks=checks,details=details),coordinate_derived_stereo=decisions,
                endpoint_sha256=sha256(folder/'endpoint.pt'),geometry=Geometry(case['spec'],case['context']).metrics(xyz))
    dump(folder/'result.json',result)
    return result


def terminal_job(job):
    torch.set_num_threads(1);folder=Path(job['folder'])
    if (folder/'result.json').exists():return load(folder/'result.json')
    case=job['case'];mode=job['mode'];x=np.asarray(job['xyz']);meta=None
    try:
        if mode=='projection':
            result=project(case['spec'],case['context'],x,movable_slots(case,job.get('scope','all')),job.get('config',projection_config()),'D')
            x=result['xyz'];meta=metadata(result)
        elif mode in ['MMFF','MMFF_after_projection']:
            if mode=='MMFF_after_projection':
                local=project(case['spec'],case['context'],x,movable_slots(case),projection_config(),'D')
                if local['status']=='fallback':raise RuntimeError(local['reason'])
                x=local['xyz']
                job['source']['intermediate_local_projection']=metadata(local)
                job['source']['actual_MMFF_input_xyz_sha256']=hashlib.sha256(x.tobytes()).hexdigest()
            mol=assemble(case['spec'])
            for i,v in enumerate(x):mol.GetConformer().SetAtomPosition(i,v.tolist())
            fids=np.empty(len(x),dtype=int)
            for i,g in enumerate(case['groups']):fids[g]=i
            mol,meta=repair(mol,fids,case['context']['pdb_path']);x=mol.GetConformer().GetPositions()
        elif mode in ['F','G','G_LBFGSB_Hrigid']:
            from bridge import optimize
            x,meta=optimize(case['spec'],case['context'],x,job['config'],internal='simplified' if mode=='F' else 'MMFF',
                            solver='L-BFGS-B' if mode=='G_LBFGSB_Hrigid' else 'SLSQP')
        elif mode!='identity':raise ValueError(mode)
    except Exception as exc:
        meta=dict(status='failed',error=repr(exc),traceback=traceback.format_exc());x=np.asarray(job['xyz'])
    return save_endpoint(folder,case,x,job['method'],job['role'],job['source'],meta)


def evaluate_endpoint(folder):
    torch.set_num_threads(1);folder=Path(folder);target=folder/'quality.json'
    if target.exists():return load(target)
    from denovo_quality.common import object_hash,versions
    from denovo_quality.pipeline import task
    install_pb();record=load(folder/'result.json');cfg=load_config(OUT/'quality_config.json')
    compute=object_hash({str(p):sha256(p) for p in (ROOT/'denovo_quality').glob('*.py')})
    metric=task((record['manifest'],cfg,str(OUT/record['phase']/'quality'),compute,versions(),False))
    failed_optimizer=(record.get('optimizer') or {}).get('status') in ['failed','fallback']
    result=dict(attempt_id=record['attempt_id'],metric=metric,optimizer_failed=failed_optimizer,
                HQ_no_water=metric['checks'].get('high_quality') is True and not failed_optimizer,
                declared_stereo=record['declared_stereo'],input_unchanged=metric.get('input_unchanged',False))
    dump(target,result);return result


def jobs_from_paths(paths,role,guided=False,bridge_config=None,diagnostics=True):
    from sampling import read_case
    from prepare_inputs import key
    jobs=[]
    for r in paths:
        row=dict(pid=r['pid'],seed=r['seed']);case=read_case(row,role.startswith('development'))
        inp=torch.load(Path(r['folder'])/'endpoint.pt',weights_only=False,map_location='cpu')
        method_modes=[('C','identity',None),('D','projection',None),('D_MMFF','MMFF_after_projection',None)] if guided else [('A','identity',None),('B','projection',None),('E','MMFF',None)]
        if not guided and diagnostics:
            method_modes.extend((name,'projection',c) for name,c in budget_configs().items())
            method_modes.append(('local_scope','projection',None))
        if not guided and bridge_config is not None:
            method_modes.extend((name,name,bridge_config) for name in ['F','G','G_LBFGSB_Hrigid'])
        for method,mode,config in method_modes:
            job=dict(folder=str(OUT/role/'endpoints'/f'{key(row)}_{method}'),case=case,xyz=inp['xyz'],mode=mode,method=method,role=role,
                     source=dict(path_folder=r['folder'],path_endpoint_sha256=r['endpoint_sha256'],shared_network_path=True))
            if config is not None:job['config']=config
            if method=='local_scope':job['scope']='local_first_connection'
            jobs.append(job)
    return jobs
