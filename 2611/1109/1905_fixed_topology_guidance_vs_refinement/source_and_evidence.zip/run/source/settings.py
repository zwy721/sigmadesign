from common import *
import copy
import math


def projection_config():
    c=copy.deepcopy(load(ROOT/'dynamic_update_rigid_projection/frozen_projection.json')['config'])
    c.update(movable_scope='all',translation_normalization_A=.5,rotation_normalization_rad=.3)
    return c


def budget_configs():
    base=projection_config()
    return {
        'budget_iterations':dict(base,iterations=800,name='800_iterations_same_domain'),
        'budget_range':dict(base,max_translation_A=math.sqrt(12),max_rotation_rad=math.pi,name='20_iterations_expanded_SO3_ball'),
        'budget_both':dict(base,iterations=800,max_translation_A=math.sqrt(12),max_rotation_rad=math.pi,name='800_iterations_expanded_SO3_ball'),
    }


def movable_slots(case, scope='all'):
    if scope=='all':return list(range(case['N']))
    if scope=='local_first_connection':return sorted(set(case['spec']['connections'][0]['slots']))
    raise ValueError(f'Unknown frozen movable scope: {scope}')


def freeze_settings():
    config=dict(projection=projection_config(),budget_variants=budget_configs(),
                original_budget_retained=True,formal_metrics_used_for_selection=False,
                expanded_domain_caveat='Translation norm sqrt(12) and SO3 angle pi are an enclosing approximation of the old Euler/coordinate box, not identical feasible sets',
                range_step_caps_unchanged=True,continuous_steps=list(range(23)),terminal_step=23,
                six_dev_cases=load(OUT/'protocol.json')['development'])
    path=OUT/'frozen_settings.json'
    if path.exists():assert load(path)==config
    else:dump(path,config)
    return config
