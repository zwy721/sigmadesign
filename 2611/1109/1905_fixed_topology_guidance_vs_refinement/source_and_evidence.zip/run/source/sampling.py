"""Two fixed-chemistry paths with independent replay and terminal forks."""
from common import *
import copy
import time
import torch
from rdkit import Chem
from scipy.spatial.transform import Rotation
from runtime import state_from,BatchEngine,Geometry,SCALE
from projection import worker,apply_to_state,metadata,Terms
from settings import movable_slots
from prepare_inputs import key


def read_case(row,development=False):
    return torch.load(OUT/'inputs'/('development' if development else 'main')/key(row)/'case.pt',weights_only=False,map_location='cpu')


def xyz_of(state):
    n=sum(map(len,state.groups))
    return state.physical()[state.pn:state.pn+n].copy()


def invariants(state,reference):
    x=xyz_of(state);q=state.Q.detach().cpu().numpy()
    assert np.isfinite(x).all() and np.isfinite(q).all()
    change=max(float(np.max(np.abs(np.linalg.norm(x[g][:,None]-x[g][None,:],axis=-1)-d))) for g,d in zip(state.groups,reference))
    orth=float(np.max(np.abs(q.transpose(0,2,1)@q-np.eye(3))))
    det=float(np.linalg.det(q).min())
    assert change<.0002,('rigidity',change)
    assert orth<.0002 and det>.9998,('SO3',orth,det)
    return dict(internal_distance_delta_A=change,rotation_orthogonality_error=orth,rotation_min_determinant=det)


def snapshot_metrics(geometry,x,case,config):
    values=geometry.metrics(x)
    terms=Terms(case['spec'],case['context'],x,movable_slots(case),config)
    with torch.no_grad():e,components,*_=terms.energy(torch.zeros((case['N'],6),dtype=torch.float64),config,'D')
    values.update(geometry_energy=float(e),geometry_energy_components=components.tolist())
    return values


def run_path(rows,role,label,den,pool,config,guided=False,batch_size=32,development=False):
    records=[]
    for offset in range(0,len(rows),batch_size):
        subset=rows[offset:offset+batch_size]
        folders=[OUT/role/'paths'/f'{key(r)}_{label}' for r in subset]
        if all((f/'path.json').exists() for f in folders):
            records.extend(load(f/'path.json') for f in folders);continue
        assert not any((f/'path.json').exists() for f in folders),'Partial batch requires explicit recovery boundary'
        cases=[read_case(r,development) for r in subset]
        states=[state_from(c,den) for c in cases]
        geometries=[Geometry(c['spec'],c['context']) for c in cases]
        reference=[];initial=[];trajectories=[[] for _ in cases];motions=[]
        for c,s,f in zip(cases,states,folders):
            f.mkdir(parents=True,exist_ok=True);(f/'trajectory').mkdir(exist_ok=True)
            x=xyz_of(s);initial.append(x)
            desired=np.empty_like(x)
            for g,v in zip(c['groups'],c['desired']):desired[g]=v
            assert np.max(np.linalg.norm(x-desired,axis=-1))<.0002
            reference.append([np.linalg.norm(x[g][:,None]-x[g][None,:],axis=-1) for g in c['groups']])
            np.savez_compressed(f/'initial_state.npz',xyz=x,pos=s.pos.cpu().numpy(),C=s.C.cpu().numpy(),Q=s.Q.cpu().numpy(),
                                graph_x=s.base.x.cpu().numpy(),edge_index=s.base.edge_index.cpu().numpy(),edge_attr=s.base.edge_attr.cpu().numpy())
            torch.save(dict(C=s.C.cpu(),Q=s.Q.cpu(),T0=s.T0.cpu(),R0=s.R0.cpu(),pos0=s.pos0.cpu(),random_key=s.replay_key,
                            semantic_node_keys=s.replay_node_keys),f/'initial_runtime_state.pt')
            motions.append(dict(network_translation_path_A=np.zeros(c['N']),network_rotation_path_rad=np.zeros(c['N']),
                                guidance_translation_path_A=np.zeros(c['N']),guidance_rotation_path_rad=np.zeros(c['N'])))
        grid=(1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3
        engine=BatchEngine(den);torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();start=time.perf_counter()
        projection_seconds=0.;metrics_seconds=0.;transfer_seconds=0.
        for step,t in enumerate(grid[:-1]):
            before=[(s.C.detach().cpu().numpy(),s.Q.detach().cpu().numpy()) for s in states]
            engine.step(states,t,t-grid[step+1])
            network=[xyz_of(s) for s in states];netC=[s.C.detach().cpu().numpy() for s in states];netQ=[s.Q.detach().cpu().numpy() for s in states]
            work=[]
            if guided and step<23:
                projection_start=time.perf_counter()
                for c,x in zip(cases,network):work.append(pool.submit(worker,dict(spec=c['spec'],context=c['context'],xyz=x,slots=movable_slots(c),config=config,arm='D')))
                results=[w.result() for w in work]
                projection_seconds+=time.perf_counter()-projection_start
                for s,r in zip(states,results):
                    assert r['status']!='fallback',r
                    ts=time.perf_counter();apply_to_state(s,r);transfer_seconds+=time.perf_counter()-ts
            else:results=[None]*len(cases)
            ts=time.perf_counter()
            for i,(c,s,g,f,r) in enumerate(zip(cases,states,geometries,folders,results)):
                assert torch.equal(s.base.x, c['graph'].x.to(s.base.x.device)),'Static node chemistry changed'
                final=xyz_of(s);inv=invariants(s,reference[i]);C=s.C.detach().cpu().numpy();Q=s.Q.detach().cpu().numpy()
                motions[i]['network_translation_path_A']+=np.linalg.norm(netC[i]-before[i][0],axis=-1)*SCALE
                motions[i]['network_rotation_path_rad']+=np.linalg.norm(Rotation.from_matrix(netQ[i]@before[i][1].transpose(0,2,1)).as_rotvec(),axis=-1)
                motions[i]['guidance_translation_path_A']+=np.linalg.norm(C-netC[i],axis=-1)*SCALE
                motions[i]['guidance_rotation_path_rad']+=np.linalg.norm(Rotation.from_matrix(Q@netQ[i].transpose(0,2,1)).as_rotvec(),axis=-1)
                metrics=snapshot_metrics(g,network[i],c,config)
                after=snapshot_metrics(g,final,c,config) if r is not None else metrics
                trajectories[i].append(dict(step=step,t=float(t),network=metrics,after_guidance=after,
                                             projection=metadata(r) if r is not None else None,**inv))
                np.savez_compressed(f/'trajectory'/f'step_{step:02d}.npz',network_xyz=network[i],xyz=final,
                                    network_C=netC[i],network_Q=netQ[i],C=C,Q=Q,pos=s.pos.detach().cpu().numpy())
            metrics_seconds+=time.perf_counter()-ts
            print('STEP',role,label,offset,step,flush=True)
        torch.cuda.synchronize();elapsed=time.perf_counter()-start
        perf=dict(role=role,label=label,batch=len(states),actual_GPU_NFE=engine.calls,logical_sample_NFE=24*len(states),
                  observed_wall_seconds=elapsed,projection_pool_wall_seconds=projection_seconds,
                  projection_state_transfer_seconds=transfer_seconds,metric_and_evidence_seconds=metrics_seconds,
                  generation_excluding_metric_evidence_seconds=elapsed-metrics_seconds,
                  peak_GPU_allocated_bytes=torch.cuda.max_memory_allocated(),timings=engine.timings,OOM_splits=engine.oom)
        assert engine.calls==24 and not engine.oom,'Expected true unsplit PyG Batch'
        dump(OUT/role/'performance'/f'{label}_{offset}.json',perf)
        for i,(c,s,f) in enumerate(zip(cases,states,folders)):
            x=xyz_of(s);last=trajectories[i]
            for step,values in enumerate(last):
                v=np.load(f/'trajectory'/f'step_{step:02d}.npz')
                values['network_RMSD_to_path_endpoint_A']=float(np.sqrt(np.mean(np.sum((v['network_xyz']-x)**2,axis=-1))))
                values['after_guidance_RMSD_to_path_endpoint_A']=float(np.sqrt(np.mean(np.sum((v['xyz']-x)**2,axis=-1))))
            torch.save(dict(xyz=x,C=s.C.detach().cpu(),Q=s.Q.detach().cpu(),pos=s.pos.detach().cpu(),
                            spec=c['spec'],groups=c['groups'],context=c['context']),f/'endpoint.pt')
            rec=dict(pid=c['pid'],seed=c['seed'],label=label,guided=guided,folder=str(f),steps=24,
                     initial_state_sha256=sha256(f/'initial_state.npz'),endpoint_sha256=sha256(f/'endpoint.pt'),
                     trajectory=last,motion=motions[i],initial_to_final_RMSD_A=float(np.sqrt(np.mean(np.sum((x-initial[i])**2,axis=-1)))),
                     projection_calls=sum(t['projection'] is not None for t in last),performance=perf,
                     reference_graph_sha256=hashlib.sha256(json.dumps(c['spec'],sort_keys=True).encode()).hexdigest())
            dump(f/'path.json',rec);records.append(rec)
        del states;torch.cuda.empty_cache()
    return records


def compare_paths(left,right,name,exact=True):
    rows=[]
    for a,b in zip(left,right):
        assert (a['pid'],a['seed'])==(b['pid'],b['seed'])
        maximum=0.;rms=0.;equal=True
        for step in range(24):
            x=np.load(Path(a['folder'])/'trajectory'/f'step_{step:02d}.npz');y=np.load(Path(b['folder'])/'trajectory'/f'step_{step:02d}.npz')
            for field in ['network_xyz','xyz','C','Q','pos']:
                equal=equal and np.array_equal(x[field],y[field])
            d=np.linalg.norm(x['xyz']-y['xyz'],axis=-1);maximum=max(maximum,float(d.max()));rms=max(rms,float(np.sqrt(np.mean(d*d))))
        passed=equal if exact else maximum<=.025 and rms<=.005
        row=dict(pid=a['pid'],seed=a['seed'],bitwise_equal=equal,max_atom_delta_A=maximum,max_RMSD_A=rms,passed=passed)
        assert a['reference_graph_sha256']==b['reference_graph_sha256']
        rows.append(row)
    result=dict(name=name,passed=all(r['passed'] for r in rows),exact_required=exact,rows=rows)
    dump(OUT/'verification'/f'{name}.json',result);assert result['passed'],result
    return result
