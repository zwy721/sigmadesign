# 历史动态图末端配对

两批各32例：历史Baseline图与历史Full_guidance图不同，分别统计。输入读取旧postprocess_input.pt完整精度；Full_guidance保留其已发布的末步投影后终态标签。所有末端优化重新运行，避免把缓存复用称作新耗时。

|方法|分母|HQ_no_water|原图定义下HQ|PB全通过|键长MAE Å|键角MAE °|优化失败|
|---|---:|---:|---:|---:|---:|---:|---:|
|historical_Baseline|32|2/32|1/32|3/32|0.173648|12.2221|0|
|secondary_Baseline_projection|32|5/32|1/32|6/32|0.044858|7.6694|0|
|secondary_Baseline_MMFF|32|28/32|10/32|28/32|0.036764|5.3090|0|
|historical_Full_guidance|32|8/32|3/32|11/32|0.050857|6.2969|0|
|secondary_Full_guidance_MMFF|32|30/32|12/32|30/32|0.029202|4.9049|0|

历史Baseline原态2/32、同原MMFF28/32以及历史Full_guidance原态8/32均复现。此前MMFF均值RMSD约0.491 Å，27/32收敛、5/32达到上限作为历史事实保留。
本轮Baseline→MMFF RMSD分布：`{'available': 32, 'min': 0.18981939580971133, 'median': 0.42785583630066554, 'mean': 0.4907899161974594, 'max': 0.8142961140997786}`。
最大单原子位移分布：`{'available': 32, 'min': 0.43478353534742337, 'median': 1.0242792696660366, 'mean': 1.0686394295575985, 'max': 2.021784786245163}`。
收敛状态：`{True: 27, False: 5}`；终止原因：`{'CONVERGENCE: RELATIVE REDUCTION OF F <= FACTR*EPSMCH': 27, 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT': 5}`。
逐分子原子位移列表、质心移动、梯度、口袋占据和终止原因均单列。小质心漂移不能替代局部位移检查，也不能仅凭高通过率认定图完全合理。
