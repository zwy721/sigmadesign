# 评价与报告恢复记录

正式采样前代码、独立轨迹、内部几何及批处理检查通过。首次启动未设置仓库已有`.quality_deps`路径，导致PoseBusters不可用；在最终历史结果复现检查中被发现。不可用检查不等于失败，最初生成的HQ中间报告已明确排除并保留审计副本。

恢复使用既有PoseBusters 0.6.5，实际配置与冻结JSON完全相同。仅重评648个已保存终态，没有重跑网络、优化器或选择参数。完整QC恢复126.4秒，历史2/32、8/32、28/32复现。

独立报告核验脚本的一处括号语法错误在QC及报告生成后修正，随后重新运行核验；其不影响任何生成、优化或质量评价结果。完整冻结源码/输入/权重及D→MMFF分叉哈希均通过。

32个历史Baseline→MMFF原始SDF与本轮Secondary逐字节相同。历史键长MAE约0.03675658 Å来自四位小数SDF；本轮0.03676433 Å来自完整精度优化坐标。该微小差异属于读数精度，未改变终态文件或HQ标准，见`historical_precision_reproduction.json`。

复现顺序：协议中的主实验命令 → `analysis/complete_quality.py` → `analysis/verify_delivery.py`、`analysis/interpret_results.py`、`analysis/finalize_delivery.py`。QC恢复命令会自动调用后三步。中间缺依赖QC、报告和早期错误分叉开发调试结果均明确排除，不用于正式结果或参数选择。
