"""Independent post-run hashes, endpoint lineage, motion and reference audit."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import torch
from runtime import SCALE


def main():
    frozen=load(OUT/'frozen_run.json')
    for folder,field in [('source','source_sha256'),('tests','tests_sha256')]:
        assert {p.name:sha256(p) for p in (OUT/folder).glob('*.py')}==frozen[field],('Changed frozen files',folder)
    for path,digest in load(OUT/'frozen_historical_inputs.json').items():assert sha256(path)==digest,path
    from rdkit import Chem
    from runtime import Geometry
    from sampling import read_case
    same=0;rounded=[];full=[]
    for row in load(OUT/'protocol.json')['main_cases']:
        k=f'{row["pid"]}_{row["seed"]}'
        old=ROOT/'dynamic_update_rigid_projection/full32/b32/structures'/f'{k}_Baseline/posthoc_MMFF_repair/raw.sdf'
        new=OUT/'secondary32/Baseline'/f'{k}_secondary_Baseline_MMFF/raw.sdf'
        same+=sha256(old)==sha256(new)
        c=read_case(row);g=Geometry(c['spec'],c['context'])
        mol=Chem.SDMolSupplier(str(old),removeHs=False)[0]
        rounded.append(g.metrics(mol.GetConformer().GetPositions())['cross_bond_MAE_A'])
        full.append(load(new.parent/'result.json')['geometry']['cross_bond_MAE_A'])
    assert same==32
    dump(OUT/'historical_precision_reproduction.json',dict(identical_historical_MMFF_raw_SDF_files=same,cases=32,
         historical_SDF_rounded_bond_MAE_A=float(np.mean(rounded)),new_full_precision_bond_MAE_A=float(np.mean(full)),
         explanation='Full-precision optimizer metrics vs four-decimal SDF metrics; molecular endpoints and quality thresholds unchanged'))
    ports=[];records=[];accounting=[]
    for folder in load(OUT/'primary_inventory.json')['folders']:
        f=Path(folder);rec=load(f/'result.json');records.append(rec)
        inp=torch.load(f/'endpoint.pt',weights_only=False,map_location='cpu');xyz=inp['xyz']
        audit=load(OUT/'inputs/main'/f'{rec["pid"]}_{rec["seed"]}'/'audit.json')
        for p in audit['ports']:
            ports.append(dict(p,method=rec['method'],final_actual_distance_A=float(np.linalg.norm(xyz[p['begin']]-xyz[p['end']])),
                              frozen_shared_reference_length_A=p['shared_dummy_anchor_reference_A'],
                              final_MMFF_shared_geometry_target_A=p['projection_and_QC_MMFF_equilibrium_A'],
                              chemistry_reference_and_initialization_unchanged=True))
        if rec['method'] in ['B','E','F','G','G_LBFGSB_Hrigid']:
            source=load(OUT/'primary32/paths'/f'{rec["pid"]}_{rec["seed"]}_A'/'path.json')
            assert rec['source']['path_endpoint_sha256']==source['endpoint_sha256']
        if rec['method']=='D_MMFF':
            d=torch.load(OUT/'primary32/endpoints'/f'{rec["pid"]}_{rec["seed"]}_D'/'endpoint.pt',weights_only=False,map_location='cpu')['xyz']
            assert rec['source']['actual_MMFF_input_xyz_sha256']==hashlib.sha256(d.tobytes()).hexdigest()
    csvwrite(OUT/'PORT_FINAL_LENGTHS.csv',ports)
    for inventory in ['primary_inventory.json','secondary_inventory.json']:
        for folder in load(OUT/inventory)['folders']:
            r=load(Path(folder)/'result.json');m=r.get('optimizer') or {}
            original_mmff=r['method'] in ['E','D_MMFF','secondary_Baseline_MMFF','secondary_Full_guidance_MMFF']
            accounting.append(dict(phase=r['phase'],method=r['method'],pid=r['pid'],seed=r['seed'],
                                   function_evaluations=m.get('function_evaluations'),
                                   solver_reported_gradient_evaluations=m.get('gradient_evaluations'),
                                   actual_outer_gradient_evaluations_including_initial=m.get('function_evaluations') if original_mmff else m.get('gradient_evaluations'),
                                   initialization_gradient_evaluations=1 if original_mmff else 0,
                                   hydrogen_preoptimization_internal_gradient_evaluations=None,
                                   hydrogen_preoptimization_count_note='RDKit Minimize exposes status, not exact internal iteration/gradient counters'))
    csvwrite(OUT/'EVALUATION_ACCOUNTING.csv',accounting)
    (OUT/'EVALUATION_ACCOUNTING.md').write_text('# 优化评估次数口径\n\n'
        'E、D→MMFF及两种Secondary MMFF保留SciPy报告的njev；原实现还在minimize前调用一次同时计算能量/梯度的obj(v0)。'
        '因此包含初始化的实际外层梯度次数等于记录的function_evaluations，比SciPy njev多1。'
        'EVALUATION_ACCOUNTING.csv同时列出两种口径，PER_GENERATION_RESULTS.csv中的gradient_evaluations保留原SciPy口径。\n\n'
        '投影与桥接按其显式计数记录。共同的氢预优化内部迭代/梯度次数不可从RDKit Minimize接口获得，记为不可用；'
        '其最大200步、状态与计入总优化时间的成本均保留，不能当作零成本。\n')
    import csv
    with (OUT/'PER_STEP_GEOMETRY.csv').open(newline='') as handle:steps=list(csv.DictReader(handle))
    paths={}
    for p in (OUT/'primary32/paths').glob('*/path.json'):
        r=load(p);paths[(r['pid'],str(r['seed']),r['label'])]=r
    for r in steps:
        if int(r['step'])!=23 or r['stage']!='after_guidance':continue
        path=paths[r['pid'],r['seed'],r['path']];motion=path['motion']
        expected=np.array(motion['network_translation_path_A'])+np.array(motion['guidance_translation_path_A'])
        actual=np.array(json.loads(r['cumulative_translation_A']))
        assert np.allclose(actual,expected,atol=1e-6,rtol=1e-7),('Motion unit / accumulation',r['pid'],r['seed'],r['path'],SCALE)
    assert len(records)==416 and len(steps)==3072
    result=dict(passed=True,frozen_compute_sources_unchanged=True,historical_inputs_and_weights_unchanged=True,
                endpoint_lineage_verified=True,D_MMFF_uses_exact_D=True,per_step_motion_units_verified=True,
                per_step_rows=len(steps),primary_endpoints=len(records),final_port_rows=len(ports))
    dump(OUT/'INDEPENDENT_VERIFICATION.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
