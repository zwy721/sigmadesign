"""Finalize verified local artifacts and dated links, without Git publication."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
from datetime import datetime,timezone


def main():
    verification=load(OUT/'INDEPENDENT_VERIFICATION.json');assert verification['passed']
    assert load(OUT/'quality_recovery.json')['passed'] and load(OUT/'precheck8_verification.json')['passed']
    summary=load(OUT/'summary.json')
    required=['FIXED_TOPOLOGY_PROTOCOL.md','TRAJECTORY_CONSISTENCY.md','GUIDANCE_ABLATION_RESULTS.md',
              'PER_STEP_GEOMETRY.csv','PER_GENERATION_RESULTS.csv','MMFF_BUDGET_MATCHING.md',
              'SECONDARY_DYNAMIC_GRAPH_MMFF.md','QUALITY_BREAKDOWN.md','A100_PERFORMANCE.md','NEXT_STEP_DECISION.md']
    for name in required:assert (OUT/name).is_file() and (OUT/name).stat().st_size>0
    assert '7 passed' in (OUT/'unit_tests.log').read_text()
    frozen=load(OUT/'frozen_run.json')
    for name,digest in frozen['source_sha256'].items():assert sha256(OUT/'source'/name)==digest,name
    for name,digest in frozen['tests_sha256'].items():assert sha256(OUT/'tests'/name)==digest,name
    assert sha256(OUT/'protocol.json')==frozen['protocol_sha256']
    assert sha256(OUT/'frozen_settings.json')==frozen['settings_sha256']
    assert sha256(OUT/'development_selection.json')==frozen['development_selection_sha256']
    for path,digest in load(OUT/'frozen_historical_inputs.json').items():assert sha256(path)==digest,path
    precision=load(OUT/'historical_precision_reproduction.json');assert precision['identical_historical_MMFF_raw_SDF_files']==32
    dated=ROOT/'2611/1109/1905_fixed_topology_guidance_vs_refinement'
    for name in required+['README.md','INDEPENDENT_VERIFICATION.json','PORT_FINAL_LENGTHS.csv','GRADIENT_TERMINATION_AUDIT.md','PER_STEP_GEOMETRY.png']:
        link=dated/name;target=os.path.relpath(OUT/name,dated)
        if link.is_symlink():assert os.readlink(link)==target
        elif link.exists():raise FileExistsError(f'Refusing to overwrite dated artifact: {link}')
        else:link.symlink_to(target)
    excluded={'ARTIFACT_MANIFEST.json','DELIVERY_VERIFICATION.json','status.json','process.json'}
    files={str(p.relative_to(OUT)):dict(bytes=p.stat().st_size,sha256=sha256(p)) for p in OUT.rglob('*')
           if p.is_file() and p.name not in excluded and p.suffix not in ['.log','.pyc']}
    dump(OUT/'ARTIFACT_MANIFEST.json',dict(files=files,file_count=len(files),
                                         excluded_interpretations=['analysis/superseded_reports_without_PoseBusters','*/quality_without_posebusters.json','development/superseded_C_MMFF_debug'],
                                         local_only=True))
    result=dict(passed=True,required_deliverables=len(required),primary_endpoints=416,secondary_endpoints=160,
                precheck_QC_endpoints=72,full_QC_endpoints=648,per_step_rows=3072,precheck_passed=True,
                independent_verification=True,bridge_consistency=load(OUT/'bridge_consistency.json')['passed'],
                stereo_complete_each_primary_group=12,old_MMFF_raw_SDF_identical_cases=32,
                historical_HQ_reproduced={k:summary['secondary'][k]['HQ_no_water'] for k in ['historical_Baseline','historical_Full_guidance','secondary_Baseline_MMFF']},
                frozen_compute_and_test_sources_unchanged=True,historical_inputs_and_weights_unchanged=True,
                artifact_files=len(files),manifest_sha256=sha256(OUT/'ARTIFACT_MANIFEST.json'),
                archived_to=str(dated),GitHub_upload_performed=False)
    dump(OUT/'DELIVERY_VERIFICATION.json',result)
    dump(OUT/'status.json',dict(stage='complete',execution_complete=True,UTC=datetime.now(timezone.utc).isoformat(),
                                quality_dependency_recovery=True,primary_endpoints=416,secondary_endpoints=160,independent_verification=True))
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
