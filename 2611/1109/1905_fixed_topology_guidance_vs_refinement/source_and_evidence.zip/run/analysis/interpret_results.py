"""Post-run interpretation, with no selection or changes to frozen experiments."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import csv


def main():
    with (OUT/'PER_GENERATION_RESULTS.csv').open(newline='') as h:rows=list(csv.DictReader(h))
    primary=[r for r in rows if r['phase']=='primary32'];audit=[]
    for r in rows:
        if not r['final_projected_gradient_inf']:continue
        audit.append(dict(phase=r['phase'],method=r['method'],pid=r['pid'],seed=r['seed'],
                          solver_reported_success=r['optimizer_success'],termination=r['termination'],
                          final_gradient_L2=r['final_gradient_L2'],final_gradient_inf=r['final_gradient_inf'],
                          final_projected_gradient_inf=r['final_projected_gradient_inf'],HQ_no_water=r['HQ_no_water'],
                          exploratory_projected_gradient_gt_0_01=float(r['final_projected_gradient_inf'])>.01))
    csvwrite(OUT/'GRADIENT_TERMINATION_AUDIT.csv',audit)
    lines=['# 求解器停止与实际梯度审计','',
           'SciPy的success或相对目标下降停止不等同于一阶驻点。以下1e-2只用于事后描述残余梯度，不参与参数选择、HQ门槛或样本筛选；不同目标的梯度量纲/尺度不同，不做跨能量数值优劣比较。','',
           '|方法|SciPy success|投影后梯度∞中位数|最大值|描述性>1e-2例数|','|---|---:|---:|---:|---:|']
    for method in ['F','G','G_LBFGSB_Hrigid','E','D_MMFF']:
        a=[r for r in audit if r['phase']=='primary32' and r['method']==method]
        v=[float(r['final_projected_gradient_inf']) for r in a]
        lines.append(f'|{method}|{sum(r["solver_reported_success"]=="True" for r in a)}/32|{np.median(v):.6g}|{max(v):.6g}|{sum(x>.01 for x in v)}/32|')
    lines+=['',
            '例如G的7ILZ/41005与9T4A/41012虽报告success，投影后梯度仍分别约7.24e6与1.73e6。E、D→MMFF也有高残余梯度。它们保留在分母与失败证据中；不能据此声称优化充分收敛，更不能将MMFF称为全局上限。',
            '本轮按冻结配置结束，不对32例调参。若继续，先在独立6例开发集检查扭转约束附近的梯度、停止尺度及求解器数值条件，再冻结新的诊断；本轮结果不据此重选。',
            '外层梯度次数的SciPy口径与包含初始化口径见EVALUATION_ACCOUNTING.md/.csv；氢预优化内部精确次数不可用。']
    (OUT/'GRADIENT_TERMINATION_AUDIT.md').write_text('\n'.join(lines)+'\n')
    text='''# 实验决策与8/32至28/32差距解释

## 1. 先固定比较对象

Primary是相同32张既有Baseline最终预测图、相同随机初态的24步重采样，每组分母32。历史动态Baseline是另一任务；其2/32与固定图A的11/32不能当作持续引导收益。本文HQ_no_water沿用历史坐标推导注释口径；原图立体定义下的HQ另列，禁止称为网络补齐了立体定义。

## 2. 持续引导与末端投影

无末端处理时A=11/32、C=10/32，配对4赢5输；持续引导虽然将键长MAE从0.058325降至0.022336 Å、键角从5.7974降至3.6469°，没有得到完整HQ提升。

末端投影B=12/32，相对A仅1赢0输；D=9/32，相对C为0赢1输。末端处理相同的D相对B为3赢6输。当前数据不支持优先推广单独持续引导，不能以键长/键角代理指标替代完整质量。

引导改变后续网络路径，单次投影的硬蛋白保护不保证整个后续网络轨迹安全：无严重蛋白碰撞从A的28/32降至C/D的24/32。扭转通过率A/B=22/32、C=21/32、D=20/32也是限制。上述质量检查有交叠，不把失败数直接相加。

## 3. 优化预算、运动范围和片段范围

B、增步、扩范围、两者同时的HQ为12、11、12、11/32。增步确实改善键角，扩大范围也产生不同位移：平均RMSD从B的0.157增加至同时放宽的0.346 Å；仍没有弥合至E=24/32的完整HQ差距。

原范围20步有6/32例触平移或旋转边界，800步有13/32；扩大球域时无例触累计边界，但保留原单步限幅、硬蛋白保护及正则化。结论限于这套冻结诊断，不能泛称运动范围不重要，扩展球域也不是原MMFF盒域的严格匹配。

确定性局部选区（原连接序第一条连接两端）11/32，全片段B为12/32；该选区差异不足以解释主要差距，不代表所有局部选区。

## 4. 能量函数、求解器与氢自由度

共同SLSQP、初始化、氢处理、SE(3)变量、运动边界和环境约束下，简化能量F=16/32，MMFF能量G=23/32，配对8赢1输。两组PoseBusters全通过数同为27/32，但自定义扭转检查F仅19/32、G为29/32。F键长更贴近平衡目标（0.002936对0.043540 Å），仍未转化为更完整HQ；支持完整内部势能/扭转处理在该流程下有价值，不能仅拟合键长键角。

这项对照没有进一步单独分离MMFF扭转、非键或额外酰胺窗口的贡献。G与相同刚性氢的L-BFGS-B对照均23/32，HQ逐例一致；允许独立氢自由度的E为24/32，多1赢0输。因此不能把原差距主要归给L-BFGS-B这个求解器名称。

求解器报告成功仍有残余梯度异常：G、刚性氢L-BFGS-B、E、D→MMFF分别有4、8、15、11例投影后梯度∞大于描述性的1e-2，其中少数达到1e5–1e6以上。详见GRADIENT_TERMINATION_AUDIT.md；所有例保留，不把success当作充分优化证明。

## 5. MMFF位移与引导后可修复性

历史Baseline→MMFF复现28/32，平均无对齐RMSD 0.490790 Å、最大0.814296 Å、最大单原子位移2.021785 Å，27例报告收敛、5例达到上限。固定图A→MMFF为24/32，平均RMSD 0.3942 Å、最大1.4125 Å、最大原子位移2.2296 Å。这些结果不支持“全部靠整体逃出口袋”的解释，但逐例口袋占据/接触仍需核对。

D→MMFF达29/32，相对E为6赢1输。MMFF相对其直接输入D的平均/最大RMSD为0.2884/0.6092 Å，但D本身相对A已经平均移动1.4238 Å；D→MMFF相对A最大RMSD达4.7387 Å、最大单原子差10.4734 Å。不能将29/32描述成在A附近的小修复，也不能保证保留原结合模式；它是另一条引导后位姿路径。

## 6. 历史8/32与28/32的直接解释边界

Secondary按原始完整精度终态重新评价/修复，历史Baseline 2/32、动态Full_guidance 8/32和Baseline→MMFF 28/32全部复现。动态Full_guidance自身的图经同参数MMFF可达30/32。这说明原8/32不主要意味着这些图全部不可修复；末端势能与优化处理能恢复大量质量。

结合固定图与桥接结果：持续引导有几何误差收益，但不足以同时保证蛋白、非键、扭转等完整质量；单纯增加简化投影预算或范围也不够。共享流程下MMFF内部势能带来净7例HQ收益，而换求解器没有HQ收益。上述条件效应不可相加成对原20例差额的百分比分摊，化学图、初态、求解条件和交互仍不同。

原预测立体定义仍只有12/32完整，所有固定图组完全不变。原图定义下A/B/C/D/E/F/G/D→MMFF的HQ分别为3/3/4/3/8/6/7/11（分母32）。按已声明要素判定“几何一致”不代表未定义要素已经补齐；少数残余几何失败也不能仅凭本实验判定拓扑或结合位姿正确性。

## 7. 下一步

优先验证带完整内部势能的快速刚性MMFF细化器。刚性附着氢的两种求解器均23/32，平均CPU约0.186–0.187秒；原完整E为24/32、约0.374秒。这是本轮并行池内观测计时，不是独立吞吐基准，不能直接宣称吞吐翻倍。它是独立数据上进一步测质量/耗时的候选，不是已验证可替换方案；先处理残余梯度与停止条件问题。

保留“引导路径+MMFF”作为另一个候选：29/32相对24/32有诊断收益，但batch32扣除指标/落盘后的网络生成路径从28.27秒增加至35.35秒，且位姿相对A的变化更大。应在独立数据同时验证HQ、接触保持、总墙时与漂移，不能仅据本32例宣称优越或原生网络更强。

本轮不启动训练。先复核完整几何能量、数值停止、化学/立体定义与独立评估，再讨论是否加入可学习几何监督。原图未定义立体、片段内部异常及真实结合合理性不由刚体修复自动解决。
'''
    (OUT/'NEXT_STEP_DECISION.md').write_text(text)
    annotations={
        'QUALITY_BREAKDOWN.md':'原图几何立体一致性只比较已声明要素；无已声明要素时可能为真，不代表原图未定义的立体要素已被补全。',
        'MMFF_BUDGET_MATCHING.md':'求解器success不能视为一阶驻点证明；残余梯度逐例审计见GRADIENT_TERMINATION_AUDIT.md/.csv。外层评估计数及氢预优化不可用计数见EVALUATION_ACCOUNTING.md/.csv。',
        'README.md':'完整QC已通过已有PoseBusters依赖路径恢复；此前缺依赖的中间报告已明确排除。完整配置匹配、恢复过程与未重跑采样/优化的记录见QC_ENVIRONMENT.json和quality_recovery.json。独立核验见INDEPENDENT_VERIFICATION.json。',
    }
    for name,note in annotations.items():
        path=OUT/name;body=path.read_text().replace(note,'').rstrip();path.write_text(body+'\n\n'+note+'\n')


if __name__=='__main__':main()
