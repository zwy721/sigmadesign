"""Recover QC using existing frozen PoseBusters dependency; never resample."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import shutil
import time
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
from datetime import datetime,timezone
from endpoints import evaluate_endpoint


def main():
    from denovo_quality import posebusters_adapter as pb
    from denovo_quality.common import versions
    import posebusters
    install_pb();assert pb.effective_config('dock',1)==load(OUT/'posebusters_no_water.json')
    environment=dict(posebusters_file=posebusters.__file__,versions=versions(),
                     exact_frozen_PB_configuration_match=True,configuration_sha256=sha256(OUT/'posebusters_no_water.json'),
                     PYTHONPATH=os.environ.get('PYTHONPATH'),recovery_scope='evaluation only; no new network paths or optimizations',
                     geometry_precheck_passed_before_main=True,QC_dependency_fix_after_sampling=True)
    dump(OUT/'QC_ENVIRONMENT.json',environment)
    folders=[str(p.parent) for p in (OUT/'precheck8/endpoints').glob('*/result.json')]
    for name in ['primary_inventory.json','secondary_inventory.json']:folders+=load(OUT/name)['folders']
    assert len(folders)==648
    for folder in folders:
        f=Path(folder)/'quality.json'
        if f.exists():
            q=load(f);pbmodule=q['metric'].get('modules',{}).get('posebusters',{})
            if pbmodule.get('status')=='unavailable' and 'No module named' in pbmodule.get('reason',''):
                backup=f.with_name('quality_without_posebusters.json')
                assert not backup.exists()
                shutil.move(str(f),str(backup))
    invalid=OUT/'analysis/superseded_reports_without_PoseBusters'
    if not invalid.exists():
        invalid.mkdir()
        for name in ['summary.json','PER_GENERATION_RESULTS.csv','PER_STEP_GEOMETRY.csv','QUALITY_CHECKS.csv','failure_cases.json','paired_comparisons.json',
                     'GUIDANCE_ABLATION_RESULTS.md','TRAJECTORY_CONSISTENCY.md','MMFF_BUDGET_MATCHING.md','PER_STEP_GEOMETRY.png','PER_STEP_GEOMETRY.pdf']:
            f=OUT/name
            if f.exists():shutil.move(str(f),str(invalid/name))
        shutil.copyfile(OUT/'precheck8_verification.json',invalid/'precheck8_verification.json')
        (invalid/'EXCLUDED.md').write_text('这些中间报告因未加载已有PoseBusters依赖而无完整HQ结论，已排除。生成/优化终态保持原样；完整QC从原始SDF重新执行。\n')
    start=time.perf_counter();set_status('recovering_full_QC',total=len(folders))
    results=[]
    with ProcessPoolExecutor(8,mp_context=get_context('spawn')) as pool:
        futures=[pool.submit(evaluate_endpoint,f) for f in folders]
        for i,future in enumerate(futures):
            q=future.result();assert q['input_unchanged'],q['attempt_id']
            p=q['metric'].get('modules',{}).get('posebusters',{})
            assert p.get('status') in ['ok','partial'],(q['attempt_id'],p)
            results.append(q)
            if i%16==0:
                print('FULL_QC',i+1,'/',len(folders),flush=True);set_status('recovering_full_QC',completed=i+1,total=len(folders))
    gate=load(OUT/'precheck8_verification.json')
    gate.update(full_PoseBusters_dependency_loaded=True,full_QC_rechecked_after_dependency_path_fix=True,
                all_precheck_QC_inputs_unchanged=True,QC_environment_sha256=sha256(OUT/'QC_ENVIRONMENT.json'))
    dump(OUT/'precheck8_verification.json',gate)
    dump(OUT/'quality_recovery.json',dict(passed=True,outputs=len(results),seconds=time.perf_counter()-start,
                                        network_and_optimizer_reexecutions=0,existing_dependency_path_restored=True,
                                        evaluation_only=True,exact_frozen_PB_configuration_match=True))
    for path,digest in load(OUT/'frozen_historical_inputs.json').items():assert sha256(path)==digest,path
    set_status('final_reporting')
    from reports import generate
    generate()
    from verify_delivery import main as verify
    verify()
    from interpret_results import main as interpret
    interpret()
    from finalize_delivery import main as finalize
    finalize()
    dump(OUT/'status.json',dict(stage='complete',execution_complete=True,UTC=datetime.now(timezone.utc).isoformat(),
                                quality_dependency_recovery=True,primary_endpoints=416,secondary_endpoints=160))


if __name__=='__main__':main()
