# 轨迹与几何一致性验收

8例预检：通过=True；72个终态完成完整QC。
A/B及C/D使用独立完整回放验收，要求逐位一致；相同方法独立重复也要求逐位一致。正式B/E从冻结A终态分叉，D从冻结C终态分叉，保留输入哈希。
所有核心组初始实际坐标、C/Q与静态图完全相同；原预测立体定义保持12/32；保存的片段内部距离、有限性与正确SO(3)逐步检查。
batch16/32由8例预检重复填满真实PyG批次，覆盖完整24步；该检查不代表32个不同分子的吞吐。正式运行另有32个不同样本实际合批。

|检查|通过|最大原子差 Å|最大RMSD Å|
|---|---|---:|---:|
|precheck_A_B_bitwise|True|0|0|
|precheck_A_repeat_bitwise|True|0|0|
|precheck_C_D_bitwise|True|0|0|
|precheck_C_repeat_bitwise|True|0|0|
|A_batch16_vs_precheck8|True|0|0|
|A_batch32_vs_precheck8|True|0|0|
|C_batch16_vs_precheck8|True|0|0|
|C_batch32_vs_precheck8|True|0|0|

代码验收见 `unit_tests.log`；完整逐例证据见 `verification/`、`precheck8/`、`precheck_batch16/`和`precheck_batch32/`。
