import importlib.util
import sys
from pathlib import Path
import numpy as np
import torch

SOURCE=Path(__file__).resolve().parents[1]/'source'
sys.path.insert(0,str(SOURCE))
from common import OUT,ROOT,load
from settings import projection_config,movable_slots
from projection import displacement_prior,Terms,project


def case():
    return torch.load(OUT/'inputs/development/2zwz_42001/case.pt',weights_only=False,map_location='cpu')


def test_prior_independent_of_motion_caps_value_and_gradient():
    c=projection_config();large=dict(c,max_translation_A=3.464,max_rotation_rad=np.pi)
    a=torch.tensor([[.1,.2,-.1,.03,-.05,.1]],dtype=torch.float64,requires_grad=True)
    e=displacement_prior(a,c);g=torch.autograd.grad(e,a)[0]
    b=a.detach().clone().requires_grad_();f=displacement_prior(b,large);h=torch.autograd.grad(f,b)[0]
    assert torch.equal(e,f) and torch.equal(g,h)


def test_default_energy_gradient_equivalent_to_historical():
    p=ROOT/'dynamic_update_rigid_projection/source/projection.py'
    s=importlib.util.spec_from_file_location('historical_projection',p);old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
    k=case();x=np.concatenate(k['desired']);c=projection_config();slots=movable_slots(k)
    # Atom order is contiguous by slot for this fixture; assert before using it.
    assert sum(k['groups'],[])==list(range(len(x)))
    new=Terms(k['spec'],k['context'],x,slots,c);historical=old.Terms(k['spec'],k['context'],x,slots,c)
    tw=torch.tensor(np.random.default_rng(9).normal(0,.01,(k['N'],6)),requires_grad=True)
    a,at,*_=new.energy(tw,c,'D');ag=torch.autograd.grad(a,tw)[0]
    tv=tw.detach().clone().requires_grad_();b,bt,*_=historical.energy(tv,c,'D');bg=torch.autograd.grad(b,tv)[0]
    assert torch.equal(a,b) and torch.equal(at,bt) and torch.equal(ag,bg)


def test_actual_all_fragment_projection_and_rigidity():
    k=case();x=np.concatenate(k['desired']);c=projection_config();slots=movable_slots(k)
    r=project(k['spec'],k['context'],x,slots,c)
    assert r['status']=='projected' and r['core_RMSD_A']>0,r
    assert r['internal_distance_delta_A']<1e-8
    assert r['translation_max_A']<=c['max_translation_A']+1e-10
    assert r['rotation_max_rad']<=c['max_rotation_rad']+1e-10
    assert len(movable_slots(k,'local_first_connection'))<k['N']


def test_reference_lengths_are_saved_chemistry_not_random_initial_separation():
    a=load(OUT/'inputs/development/2zwz_42001/audit.json')
    assert a['ports']
    assert any(abs(p['initial_actual_distance_A']-p['shared_dummy_anchor_reference_A'])>.5 for p in a['ports'])
    for p in a['ports']:
        assert max(abs(v-p['shared_dummy_anchor_reference_A']) for v in p['port_reference_lengths_A'])<2e-5


def test_shared_bridge_same_initialization_and_directional_gradients():
    from bridge import SharedModel
    from oracle_graph import assemble
    k=case();x=assemble(k['spec']).GetConformer().GetPositions()
    a=SharedModel(k['spec'],k['context'],x,dict(simple_internal_scale=10.,max_iterations=800))
    b=SharedModel(k['spec'],k['context'],x,dict(simple_internal_scale=10.,max_iterations=800))
    assert np.array_equal(a.coords,b.coords) and a.bounds==b.bounds
    assert a.G*6==b.G*6
    rng=np.random.default_rng(19);v=rng.normal(0,.01,a.G*6);direction=rng.normal(size=v.shape);direction/=np.linalg.norm(direction)
    for internal in ['simplified','MMFF']:
        energy,grad=a.objective(v,internal);eps=1e-5
        numerical=(a.objective(v+eps*direction,internal)[0]-a.objective(v-eps*direction,internal)[0])/(2*eps)
        assert np.isclose(numerical,grad@direction,rtol=2e-5,atol=2e-4),(internal,numerical,grad@direction)


def test_observational_mmff_instrumentation_preserves_optimizer():
    from oracle_graph import assemble
    from geometry_constraints_20261103.repair import repair as old
    from mmff_reference import repair as new
    k=case();mol=assemble(k['spec']);fids=np.empty(mol.GetNumAtoms(),dtype=int)
    for i,g in enumerate(k['groups']):fids[g]=i
    a,am=old(mol,fids,k['context']['pdb_path']);b,bm=new(mol,fids,k['context']['pdb_path'])
    assert np.array_equal(a.GetConformer().GetPositions(),b.GetConformer().GetPositions())
    for field in ['iterations','function_evaluations','initial_objective','final_objective','termination','success']:
        assert am[field]==bm[field]
    assert bm['final_gradient_L2']>=0 and bm['gradient_evaluations']>0


def test_D_MMFF_receives_exact_projected_D_not_C(tmp_path):
    from endpoints import terminal_job
    import hashlib
    k=case();x=np.concatenate(k['desired'])
    base=dict(case=k,xyz=x,role='unit',source=dict(path_folder='synthetic_C_fixture'))
    d=terminal_job(dict(base,folder=str(tmp_path/'D'),mode='projection',method='D'))
    mmff=terminal_job(dict(base,folder=str(tmp_path/'D_MMFF'),mode='MMFF_after_projection',method='D_MMFF'))
    projected=torch.load(tmp_path/'D/endpoint.pt',weights_only=False)['xyz']
    assert not np.array_equal(projected,x)
    assert hashlib.sha256(projected.tobytes()).hexdigest()==mmff['source']['actual_MMFF_input_xyz_sha256']
    assert (mmff.get('optimizer') or {}).get('status')!='failed'
