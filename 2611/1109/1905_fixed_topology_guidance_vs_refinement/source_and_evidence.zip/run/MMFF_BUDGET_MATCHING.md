# 优化预算、运动范围与能量桥接

简化内部能量尺度在独立6例开发集从1/10/100选择，冻结值=100.0。32例不参与选择。

|方法|分母|HQ_no_water|原图定义下HQ|PB全通过|键长MAE Å|键角MAE °|优化失败|
|---|---:|---:|---:|---:|---:|---:|---:|
|B|32|12/32|3/32|17/32|0.014082|3.9181|0|
|budget_iterations|32|11/32|2/32|17/32|0.006623|1.8612|0|
|budget_range|32|12/32|3/32|17/32|0.016393|4.0564|0|
|budget_both|32|11/32|2/32|17/32|0.004472|1.5269|0|
|E|32|24/32|8/32|26/32|0.051293|5.8884|0|
|F|32|16/32|6/32|27/32|0.002936|2.3034|0|
|G|32|23/32|7/32|27/32|0.043540|5.8852|0|
|G_LBFGSB_Hrigid|32|23/32|7/32|26/32|0.046928|5.9298|0|
|local_scope|32|11/32|3/32|16/32|0.030388|4.9218|0|

预算分别改变迭代上限或累计运动上限，正则化尺度与单步上限不变。扩大域为SO(3)/平移球包络近似，不等同于原MMFF盒。20步路径可达范围有限；无收益须结合触界/停止诊断。
F/G完全相同SLSQP、SE(3)变量、H初态/刚性附着、边界、共同环境和位姿先验，仅替换内部势能。G与G_LBFGSB_Hrigid比较求解器/停止规则；后者与E比较独立氢自由度。
能量模型贡献只对这个共享流程成立，内部能量单位/尺度不同，不能直接比较能量数字；非凸优化结果不是全局上界。
local_scope只移动原图第一条连接两端，代表这个预先定义选区；不能泛化为所有局部选区。

|方法|迭代均值|函数评估均值|CPU秒均值|末梯度∞均值|终止原因|
|---|---:|---:|---:|---:|---|
|B|18.56|44.53|0.0668|1.7192|{'iteration_limit': 29, 'no_safe_descent': 3}|
|budget_iterations|684.47|1610.69|2.2035|1.4571|{'iteration_limit': 27, 'no_safe_descent': 5}|
|budget_range|18.56|44.44|0.0730|1.3657|{'iteration_limit': 29, 'no_safe_descent': 3}|
|budget_both|686.28|1617.00|2.2942|0.5752|{'iteration_limit': 27, 'no_safe_descent': 5}|
|E|459.25|533.78|0.3741|60127.5847|{'CONVERGENCE: RELATIVE REDUCTION OF F <= FACTR*EPSMCH': 29, 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT': 3}|
|F|51.50|124.97|0.2303|0.0014|{'Optimization terminated successfully': 32}|
|G|79.34|206.00|0.1859|280587.5299|{'Optimization terminated successfully': 32}|
|G_LBFGSB_Hrigid|137.38|194.72|0.1870|8597.5115|{'CONVERGENCE: RELATIVE REDUCTION OF F <= FACTR*EPSMCH': 32}|
|local_scope|18.62|47.16|0.0678|0.7704|{'iteration_limit': 29, 'no_safe_descent': 3}|
|D_MMFF|437.50|499.50|0.3392|190072.7135|{'CONVERGENCE: RELATIVE REDUCTION OF F <= FACTR*EPSMCH': 29, 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT': 3}|

完整迭代/评估、实际梯度、触界、位移分布和未收敛输出均在 `PER_GENERATION_RESULTS.csv` 中；未收敛与软件失败分列。

求解器success不能视为一阶驻点证明；残余梯度逐例审计见GRADIENT_TERMINATION_AUDIT.md/.csv。外层评估计数及氢预优化不可用计数见EVALUATION_ACCOUNTING.md/.csv。
