"""Prerequisite gates -> independent development -> eight-case replay -> frozen32."""
from common import *
import argparse,copy,time,traceback,shutil
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import torch
from rdkit import Chem
from scipy.spatial.transform import Rotation
from run_validation import load_official
from stable_precision import install
from runtime import Engine,make_state,xyz,forward_noise,grid,invariants,random_stream,stream_seed,SCALE
from inputs import read_case,key,source,graph_hash,protocol,FIXED
from metrics import Metrics
from quality import evaluate
from audit_graphs import examine


def state_for(r,method,den,dev=False,noise=0.,tstart=.4,freeze=.4):
    case,saved=read_case(r,dev,freeze if method.startswith('D') else None)
    s=make_state(case,den,C=saved['C'],Q=saved['Q'],step=saved['step'])
    delta=np.linalg.norm(xyz(s)-saved['xyz'],axis=-1)
    assert delta.max()<.0002,('saved state reconstruction',key(r),method,delta.max())
    initial=xyz(s);info=dict(reconstruction_max_delta_A=float(delta.max()),start=saved['step'],source=saved['source'])
    if method.startswith('B') or method=='E':
        info.update(forward_noise(s,1. if method=='E' else tstart,'second_forward'))
        s.step_index=0;g=grid(1. if method=='E' else tstart)
    elif method.startswith('C'):
        if method=='C_replay':
            s.historical_initial_step=True
            p=FIXED/('development' if dev else 'primary32')/'paths'/f'{key(r)}_A'/'initial_runtime_state.pt'
            old=torch.load(p,weights_only=False,map_location='cpu')
            s.C=old['C'].to(s.C.device);s.Q=old['Q'].to(s.Q.device)
            assert torch.equal(s.pos0.cpu(),old['pos0']) and torch.equal(s.R0.cpu(),old['R0'])
            info.update(initialization='historical core center / Haar rotations',historical_initial_state_sha256=sha256(p))
        else:
            seed=case['seed']+(214200000 if method=='C_official_new' else 0)
            with random_stream(seed):s.C,s.Q=den.diffuser.sample_ref(case['N'],s.C.device)
            info.update(initialization='official sample_ref, IGSO3(t=1), not Haar',initialization_seed=seed)
        s.pos=den._apply_transformations(s.pos0,s.batch,s.T0,s.R0,s.Q,s.C)
        s.step_index=0;g=grid()
    elif method.startswith('D'):
        g=grid()[saved['step']:];info.update(freeze_time=freeze,last_accepted_update=saved['last_accepted_update'])
    else:raise ValueError(method)
    return case,s,g,initial,info


def prerequisites(den):
    dest=OUT/'audit/runtime_gate.json'
    if dest.exists():assert load(dest)['passed'];return
    assert load(OUT/'audit/graph_audit.json')['saved_graphs_passed']
    p=load(OUT/'protocol.json');rows=[]
    for dev,cases in [(True,p['development']),(False,p['main_cases'])]:
        for r in cases:
            for freeze in [None,.6,.4,.2]:
                c,v=read_case(r,dev,freeze);examine(c['graph'],c['spec'])
                s=make_state(c,den,C=v['C'],Q=v['Q'],step=v['step'])
                d=np.linalg.norm(xyz(s)-v['xyz'],axis=-1);assert d.max()<.0002
                ref=[np.linalg.norm(xyz(s)[g][:,None]-xyz(s)[g][None,:],axis=-1) for g in s.groups]
                before=(s.C.clone(),s.Q.clone(),s.pos.clone())
                forward_noise(s,0.,'noop')
                assert all(torch.equal(a,b) for a,b in zip(before,[s.C,s.Q,s.pos]))
                for t in [.2,.4,.6,1.]:
                    s.C,s.Q,s.pos=[x.clone() for x in before];forward_noise(s,t,'kernel_test')
                    c1,q1,x1=s.C.clone(),s.Q.clone(),s.pos.clone();inv=invariants(s,ref)
                    s.C,s.Q,s.pos=[x.clone() for x in before];forward_noise(s,t,'kernel_test')
                    assert torch.equal(c1,s.C) and torch.equal(q1,s.Q) and torch.equal(x1,s.pos)
                rows.append(dict(key=key(r),development=dev,freeze=freeze,reconstruction_max_delta_A=float(d.max()),**inv))
            print('STATE GATE',dev,key(r),flush=True)
    # The official SO3 t=0 has min_sigma>0; application zero uses explicit no-op.
    fixtures=[]
    for f in sorted((OUT/'audit').glob('fixture_*.pt')):
        v=torch.load(f,weights_only=False,map_location='cpu');g=v['graph'];groups=[x['atom_ids'] for x in v['spec']['fragments']]
        c=dict(graph=g,groups=groups,spec=v['spec'],labels=[-1]*len(groups),N=len(groups),pid=f.stem,seed=2142)
        s=make_state(c,den);ref=[np.linalg.norm(xyz(s)[group][:,None]-xyz(s)[group][None,:],axis=-1) for group in groups]
        forward_noise(s,.4,'fixture');inv=invariants(s,ref)
        t=torch.tensor(.4,device='cuda:0');eng=Engine(den);detail=eng.step([s],t,torch.tensor(.01,device='cuda:0'))[0]
        inv.update(invariants(s,ref));fixtures.append(dict(name=f.stem,passed=True,**inv))
    dump(dest,dict(passed=True,states=len(rows),rows=rows,fixtures=fixtures,
                   forward_kernel='unmodified SE3Diffuser.forward_marginal; translation VP Gaussian; rotation left-multiplied IGSO3',
                   zero_time_noop=True,official_SO3_min_sigma=den.diffuser._so3_diffuser.min_sigma if hasattr(den.diffuser._so3_diffuser,'min_sigma') else .1))


def path_jobs(rows,method,phase,den,noise=0.,tstart=.4,freeze=.4,batch_size=32,variant=None):
    label=variant or method;dev=phase.startswith('development');jobs=[]
    for offset in range(0,len(rows),batch_size):
        subset=rows[offset:offset+batch_size];folders=[OUT/phase/'paths'/f'{key(r)}_{label}' for r in subset]
        if all((f/'path.json').exists() for f in folders):
            for r,f in zip(subset,folders):
                c,_=read_case(r,dev,freeze if method.startswith('D') else None);base,bv=read_case(r,dev)
                v=torch.load(f/'endpoint.pt',weights_only=False,map_location='cpu')
                jobs.append(dict(case=c,baseline_case=base,baseline_xyz=bv['xyz'],xyz=v['xyz'],method=label,phase=phase,
                                 folder=str(OUT/phase/'endpoints'/f'{key(r)}_{label}'),extra_NFE=load(f/'path.json')['extra_NFE']))
            continue
        assert not any((f/'path.json').exists() for f in folders),'Partial batch boundary: preserve and recover explicitly'
        states=[];cases=[];infos=[];refs=[];baselines=[];metrics=[];trajectories=[[] for r in subset]
        for r,f in zip(subset,folders):
            c,s,g,initial,info=state_for(r,method,den,dev,noise,tstart,freeze)
            states.append(s);cases.append(c);infos.append(info);metrics.append(Metrics(c));base,bv=read_case(r,dev);baselines.append((base,bv))
            refs.append([np.linalg.norm(xyz(s)[a][:,None]-xyz(s)[a][None,:],axis=-1) for a in c['groups']])
            f.mkdir(parents=True,exist_ok=True);(f/'trajectory').mkdir(exist_ok=True)
            np.savez_compressed(f/'initial.npz',xyz=xyz(s),stage1_xyz=initial,C=s.C.cpu().numpy(),Q=s.Q.cpu().numpy(),pos=s.pos.cpu().numpy())
            info.update(before_resampling=metrics[-1].snapshot(initial),after_resampling=metrics[-1].snapshot(xyz(s)),
                        renoise_changes=metrics[-1].changes(initial,xyz(s),'renoise'),graph_hash=graph_hash(c['spec']))
        eng=Engine(den);torch.cuda.synchronize();start=time.perf_counter()
        for step,t in enumerate(g[:-1]):
            before=[xyz(s) for s in states]
            traces=eng.step(states,t,t-g[step+1],noise_scale=noise,role='reverse')
            for i,(s,c,f,m,tr) in enumerate(zip(states,cases,folders,metrics,traces)):
                x=xyz(s);inv=invariants(s,refs[i]);det=tr['deterministic_xyz']
                assert torch.equal(s.base.x.cpu(),c['graph'].x) and torch.equal(s.base.edge_entity.cpu(),c['graph'].edge_entity)
                row=dict(pid=c['pid'],seed=c['seed'],method=label,phase=phase,step=step,official_step=s.step_index-1,t=float(t),
                         t_next=float(g[step+1]),graph_hash=graph_hash(c['spec']),N=c['N'],**m.snapshot(x),
                         **m.changes(before[i],x),**m.changes(before[i],det,'deterministic'),**inv,
                         translation_delta_A=float(np.linalg.norm((tr['C']-tr['C_before']).numpy(),axis=-1).mean()*SCALE),
                         rotation_delta_rad=float(np.linalg.norm(Rotation.from_matrix((tr['Q']@tr['Q_before'].transpose(1,2)).numpy()).as_rotvec(),axis=-1).mean()),
                         pseudoforce_norm_mean=float(tr['pseudoforce'].norm(dim=-1).mean()),
                         fragment_force_norm_mean=float(tr['fragment_force'].norm(dim=-1).mean()),fragment_torque_norm_mean=float(tr['fragment_torque'].norm(dim=-1).mean()))
                # Pseudoforce projection on existing collision separation vectors.
                pf=np.zeros_like(before[i]);indices=tr['force_index'].numpy()-s.pn;mask=(indices>=0)&(indices<len(pf));pf[indices[mask]]=tr['pseudoforce'].numpy()[mask]
                di,dp=m.distances(before[i]);pairs=m.pairs;unit=(before[i][pairs[:,0]]-before[i][pairs[:,1]])/np.maximum(di[:,None],1e-12)
                proj=((pf[pairs[:,0]]-pf[pairs[:,1]])*unit).sum(-1);old=di<m.limits
                vec=(before[i][:,None]-m.protein[None,:])/np.maximum(dp[:,:,None],1e-12);pproj=(pf[:,None]*vec).sum(-1);pold=dp<m.plimits
                for name,values in [('internal',proj[old]),('protein',pproj[pold])]:
                    row.update({f'pseudoforce_{name}_outward':int((values>1e-8).sum()),f'pseudoforce_{name}_inward':int((values< -1e-8).sum()),
                                f'pseudoforce_{name}_projection_mean':float(values.mean()) if len(values) else None})
                np.savez_compressed(f/'trajectory'/f'step_{step:02d}.npz',xyz=x,C=s.C.cpu().numpy(),Q=s.Q.cpu().numpy())
                torch.save(tr,f/'trajectory'/f'trace_{step:02d}.pt');trajectories[i].append(row)
            print('STEP',phase,label,offset,step,flush=True)
        torch.cuda.synchronize();elapsed=time.perf_counter()-start
        for i,(r,c,s,f) in enumerate(zip(subset,cases,states,folders)):
            extra=0 if method.startswith('D') else len(g)-1
            torch.save(dict(xyz=xyz(s),C=s.C.cpu(),Q=s.Q.cpu(),spec=c['spec']),f/'endpoint.pt')
            dump(f/'trajectory.json',trajectories[i])
            dump(f/'path.json',dict(method=label,extra_NFE=extra,new_executed_sample_NFE=len(g)-1,historical_prefix_NFE=infos[i]['start'] if method.startswith('D') else 24,
                                   info=infos[i],noise_scale=noise,tstart=tstart,freeze=freeze,graph_hash=graph_hash(c['spec']),
                                   shared_batch_wall_seconds=elapsed,batch_size=len(states),GPU_calls=eng.calls,timings=eng.timings))
            base,bv=baselines[i];jobs.append(dict(case=c,baseline_case=base,baseline_xyz=bv['xyz'],xyz=xyz(s),method=label,phase=phase,
                                                folder=str(OUT/phase/'endpoints'/f'{key(r)}_{label}'),extra_NFE=extra))
        del states;torch.cuda.empty_cache()
    return jobs


def quality_jobs(jobs,pool):
    futures=[pool.submit(evaluate,j) for j in jobs]
    return [f.result() for f in futures]


def baseline(rows,phase,pool):
    jobs=[]
    for r in rows:
        c,v=read_case(r,phase.startswith('development'))
        jobs.append(dict(case=c,baseline_case=c,baseline_xyz=v['xyz'],xyz=v['xyz'],method='A',phase=phase,
                         folder=str(OUT/phase/'endpoints'/f'{key(r)}_A'),extra_NFE=0))
    return quality_jobs(jobs,pool)


def select(rows):
    return (-sum(r['HQ_no_water'] is True for r in rows),sum(r['severe_protein_pairs'] for r in rows),
            float(np.mean([r['RMSD_to_stage1_A'] for r in rows if r['RMSD_to_stage1_A'] is not None])) if any(r['RMSD_to_stage1_A'] is not None for r in rows) else float('inf'))


def develop(den,pool):
    path=OUT/'development_selection.json'
    if path.exists():return load(path)['selected']
    p=load(OUT/'protocol.json');rows=p['development'];results=[];summaries=[]
    baseline(rows,'development',pool)
    for t in [.2,.4,.6]:
        for noise in [0.,1.]:
            label=f'B_t{t:g}_noise{noise:g}';set_status('development',method=label)
            rec=quality_jobs(path_jobs(rows,'B','development',den,noise,t,variant=label,batch_size=6),pool)
            summaries.append(dict(method=label,tstart=t,noise_scale=noise,rank=list(select(rec))));results+=rec
    best=min(range(6),key=lambda i:(*summaries[i]['rank'],i));chosen=summaries[best]
    d=[]
    for freeze in [.6,.4,.2]:
        label=f'D_freeze{freeze:g}';set_status('development',method=label)
        rec=quality_jobs(path_jobs(rows,'D','development',den,0.,freeze=freeze,variant=label,batch_size=6),pool)
        d.append(dict(method=label,freeze=freeze,rank=list(select(rec))));results+=rec
    dbest=min(range(3),key=lambda i:(*d[i]['rank'],i))
    selected=dict(tstart=chosen['tstart'],noise_scale=chosen['noise_scale'],freeze=d[dbest]['freeze'])
    dump(path,dict(selected=selected,B=summaries,D=d,formal_metrics_used=False,development_cases=[key(r) for r in rows],records=results))
    print('FROZEN',selected,flush=True)
    return selected


def precheck(den,pool,chosen):
    dest=OUT/'precheck8_verification.json'
    if dest.exists():assert load(dest)['passed'];return
    p=load(OUT/'protocol.json');rows=p['precheck_cases'];methods=['B','C_replay','C_official_seed','C_official_new','D','E'];comparisons=[]
    baseline(rows,'precheck8',pool)
    for method in methods:
        noise=0. if method=='D' else chosen['noise_scale']
        kwargs=dict(noise=noise,tstart=chosen['tstart'],freeze=chosen['freeze'])
        quality_jobs(path_jobs(rows,method,'precheck8',den,**kwargs,batch_size=8),pool)
        path_jobs(rows,method,'precheck_repeat',den,**kwargs,batch_size=8)
        path_jobs(rows,method,'precheck_single',den,**kwargs,batch_size=1)
        for r in rows:
            ds=[]
            for phase in ['precheck8','precheck_repeat','precheck_single']:
                f=OUT/phase/'paths'/f'{key(r)}_{method}';ds.append(torch.load(f/'endpoint.pt',weights_only=False,map_location='cpu')['xyz'])
            exact=np.array_equal(ds[0],ds[1]);delta=float(np.linalg.norm(ds[0]-ds[2],axis=-1).max());rms=float(np.sqrt(np.mean(np.sum((ds[0]-ds[2])**2,axis=-1))))
            assert exact and delta<.025 and rms<.005,(method,key(r),exact,delta,rms)
            comparisons.append(dict(method=method,key=key(r),repeat_bitwise=exact,batch1_max_atom_delta_A=delta,batch1_RMSD_A=rms))
            if method=='C_replay' and noise==0.:
                old=torch.load(FIXED/'primary32/paths'/f'{key(r)}_A'/'endpoint.pt',weights_only=False,map_location='cpu')['xyz']
                delta=float(np.linalg.norm(ds[0]-old,axis=-1).max());rms=float(np.sqrt(np.mean(np.sum((ds[0]-old)**2,axis=-1))))
                assert delta<.025 and rms<.005,('historical C replay',key(r),delta,rms)
                comparisons[-1].update(historical_replay_max_delta_A=delta,historical_replay_RMSD_A=rms)
        print('PRECHECK',method,'PASSED',flush=True)
    dump(dest,dict(passed=True,unique_cases=8,methods=methods,comparisons=comparisons,quality_config_sha256=sha256(OUT/'quality_config.json'),
                   frozen_selection_sha256=sha256(OUT/'development_selection.json')))


def edge_sensitivity(den,chosen):
    dest=OUT/'audit/edge_sensitivity.json'
    if dest.exists():return
    p=load(OUT/'protocol.json');records=[]
    for r in p['precheck_cases'][:2]:
        for method in ['B','C_official_seed']:
            c,s,g,initial,info=state_for(r,method,den,False,chosen['noise_scale'],chosen['tstart'],chosen['freeze']);base=None
            for label,remove in [('full',[]),('no_auxiliary',['ligand_torsional_bond','fragment_triangulation','ligand_anchor_dummy']),('no_inter_fragments',['inter_fragments']),('no_inter_complex',['inter_complex'])]:
                e=Engine(den);tr=e.step([s],g[0],g[0]-g[1],ablation=remove if remove else None)
                # Full forward above advances; restore exact initial state for all diagnostics.
                if label=='full':
                    base=tr[0];c,s,g,initial,info=state_for(r,method,den,False,chosen['noise_scale'],chosen['tstart'],chosen['freeze'])
                t=tr[0];norm=float(t['pseudoforce'].norm());delta=float((t['pseudoforce']-base['pseudoforce']).norm())
                records.append(dict(key=key(r),method=method,ablation=label,pseudoforce_norm=norm,force_difference_norm=delta,
                                    deterministic_coordinate_difference_A=float(np.sqrt(np.mean((t['deterministic_xyz']-base['deterministic_xyz'])**2))),
                                    used_edge_types={name:int((t['edge_entity']==idx).sum()) for name,idx in __import__('sigmadock.oracle',fromlist=['HPARAMS']).HPARAMS.edge_entity.entity_indices.items()}))
    dump(dest,dict(records=records,causal_quality_claim=False))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['gate','development','all'],default='all');a=parser.parse_args()
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    torch.set_num_threads(2);torch.cuda.set_device(0)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    p=protocol();set_status('loading_official_model')
    den=load_official(bootstrap.CHECKPOINT,OUT/'cache','cuda:0');install(den)
    prerequisites(den)
    if a.stage=='gate':return
    with ProcessPoolExecutor(max_workers=6,mp_context=get_context('spawn')) as pool:
        chosen=develop(den,pool)
        if a.stage=='development':return
        frozen=dict(selected=chosen,development_selection_sha256=sha256(OUT/'development_selection.json'),
                    protocol_sha256=sha256(OUT/'protocol.json'),
                    source_sha256={str(f):sha256(f) for f in (OUT/'source').glob('*.py')},
                    quality_config_sha256=sha256(OUT/'quality_config.json'),
                    model_ligand_ligand_interactions=den.model.ligand_ligand_interactions,
                    cutoff_fragment_interactions=den.cutoff_fragment_interactions,
                    model_protein_ligand_interactions=den.model.protein_ligand_interactions,
                    cutoff_complex_interactions=den.cutoff_complex_interactions)
        if (OUT/'frozen_run.json').exists():assert load(OUT/'frozen_run.json')==frozen
        else:dump(OUT/'frozen_run.json',frozen)
        precheck(den,pool,chosen)
        set_status('formal_frozen32');records=baseline(p['main_cases'],'main',pool)
        for method in ['B','C_replay','C_official_seed','C_official_new','D','E']:
            noise=0. if method=='D' else chosen['noise_scale']
            records+=quality_jobs(path_jobs(p['main_cases'],method,'main',den,noise,chosen['tstart'],chosen['freeze']),pool)
        dump(OUT/'formal_results.json',records)
        edge_sensitivity(den,chosen)
        dump(OUT/'status.json',dict(stage='sampling_and_quality_complete',execution_complete=False,formal_rows=len(records)))

if __name__=='__main__':
    try:main()
    except Exception as exc:
        set_status('failed',error=repr(exc),traceback=traceback.format_exc());raise
