"""Recover exact saved graphs and latent states without generating conformers."""
from common import *
import copy,torch
from functools import lru_cache
from oracle_graph import rebuild,export_oracle,assemble
from vocab_chemistry import VocabLibrary,assemble_slots,spec_from_slots
from runtime import grid,make_state,xyz

OLD=ROOT/'dynamic_update_rigid_projection'
FIXED=ROOT/'fixed_topology_guidance_vs_refinement'


def key(r):return f'{r["pid"]}_{r["seed"]}'

def source(r,dev=False):return OLD/('development/b6' if dev else 'full32/b32')/'structures'/f'{key(r)}_Baseline'


def read_case(r,dev=False,freeze=None):
    return cached_case(r['pid'],r['seed'],dev,freeze)

@lru_cache(maxsize=192)
def cached_case(pid,seed,dev=False,freeze=None):
    r=dict(pid=pid,seed=seed)
    c=torch.load(FIXED/'inputs'/('development' if dev else 'main')/key(r)/'case.pt',weights_only=False,map_location='cpu')
    c['graph']=rebuild(c['spec'],**c['context'])
    src=source(r,dev);rec=load(src/'result.json')
    if freeze is None:
        v=np.load(src/'trajectory/step_23.npz')
        return c,dict(C=v['C'],Q=v['Q'],xyz=v['xyz'],step=24,source=str(src))
    g=grid(device='cpu').numpy();start=int(np.flatnonzero(g[:-1]<=freeze)[0])
    accepted=[e for e in rec['events'] if e['accepted'] and e['step']<start]
    if accepted:
        e=accepted[-1];labels=e['proposed_labels'];connections=e['proposed_connections'];audits=e['reference_transfer_orientation']
    else:
        labels=rec['initial_labels'];connections=rec['initial_connections'];audits=rec['initial_reference_transfer_orientation']
    lib=VocabLibrary();mol,groups,cuts=assemble_slots(lib,labels,connections,oov=[None]*len(labels))
    from rdkit import Chem
    conf=Chem.Conformer(mol.GetNumAtoms())
    for group,a in zip(groups,audits):
        for atom,x in zip(group,a['source_reference_coordinates']):conf.SetAtomPosition(int(atom),list(x))
    mol.RemoveAllConformers();mol.AddConformer(conf)
    spec=spec_from_slots(mol,groups,cuts,labels,'exact historical saved reference for early frozen graph; no re-embedding')
    c.update(spec=spec,graph=rebuild(spec,**c['context']),groups=groups,labels=labels,connections=connections)
    v=np.load(src/'trajectory'/f'step_{start-1:02d}.npz')
    return c,dict(C=v['C'],Q=v['Q'],xyz=v['xyz'],step=start,source=str(src),freeze_time=freeze,
                  last_accepted_update=accepted[-1]['step'] if accepted else None)


def graph_hash(spec):
    # Exclude reference_source prose but include atom order, chemistry, local geometry.
    return hashlib.sha256(json.dumps({k:v for k,v in spec.items() if k!='reference_source'},sort_keys=True).encode()).hexdigest()

def chemistry_hash(spec):
    c=copy.deepcopy(spec);c.pop('reference_source',None)
    for f in c['fragments']:f.pop('coordinates',None)
    return hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()


def comparable_drift(case,x,base,baseline_x):
    from orientation import fit
    left=[];right=[]
    for i,(a,b) in enumerate(zip(case['spec']['fragments'],base['spec']['fragments'])):
        if a['vocab3684']==b['vocab3684'] and a['atoms']==b['atoms'] and len(a['atom_ids'])==len(b['atom_ids']):
            # Local order is the vocabulary port contract. Check local chemical bonds.
            def bonds(f):
                ids={v:j for j,v in enumerate(f['atom_ids'])}
                return [(ids[v['begin']],ids[v['end']],v['bond_type'],v['aromatic']) for v in f['bonds']]
            if bonds(a)!=bonds(b):continue
            left.extend(x[a['atom_ids']]);right.extend(baseline_x[b['atom_ids']])
    if not left:return dict(RMSD_to_stage1_A=None,max_atom_displacement_A=None,mapped_atoms=0,mapping_coverage=0.)
    d=np.linalg.norm(np.array(left)-np.array(right),axis=-1)
    return dict(RMSD_to_stage1_A=float(np.sqrt(np.mean(d*d))),max_atom_displacement_A=float(d.max()),mapped_atoms=len(d),mapping_coverage=len(d)/len(x))


def protocol():
    p=load(OLD/'protocol.json')
    out=dict(prompt_sha256=sha256(OUT/'prompt.md'),main_cases=p['main_cases'],development=p['development'],precheck_cases=p['precheck_cases'],
             weights=p['weights'],steps=24,terminal_time=.005,local_times=[.2,.4,.6],freeze_times=[.6,.4,.2],noise_scales=[0.,1.],
             selection_rule=['max development HQ','min total severe protein pairs','min mean unaligned mapped RMSD to stage1; unavailable sorts last','predeclared grid order'],
             B_grid='24 cubic-spaced steps from t_start to .005',D_grid='original grid, stop updates before first t<=freeze',
             C_initializations=['historical core center/Haar replay','official sample_ref original seed','official sample_ref seed+214200000'],
             E='official forward marginal t=1 from A endpoint, then24 fixed-graph reverse steps; not an isolation of graph freezing',
             D_RMSD='same-identity exact local atom mapping; report coverage; unavailable behind finite values',
             training=False,external_repairs=False,formal_denominator=32,formal_independent_generalization=False,
             zero_time='explicit application no-op; official SO3 min_sigma>0 means kernel(t=0) itself is not identity',
             second_stage_noise='selected by B on development; C_replay reuses historical 0-noise output only if selected scale is0, otherwise reruns same initialization',
             RNG='torch fork_rng keyed by receptor, seed, purpose, step; edge frames use unchanged historical semantic streams',
             approvals=['C three initialization controls','24step B grid and dev ranking','E fixed graph same extra NFE','D mapped RMSD with coverage'])
    if (OUT/'protocol.json').exists():assert load(OUT/'protocol.json')==out
    else:dump(OUT/'protocol.json',out)
    frozen={}
    for folder in [OLD/'source',FIXED/'source',PROJECT,ROOT/'denovo_quality',Path(bootstrap.SOURCE)]:
        for f in folder.rglob('*.py'):frozen[str(f)]=sha256(f)
    for dev,rows in [(True,p['development']),(False,p['main_cases'])]:
        for r in rows:
            for f in source(r,dev).rglob('*'):
                if f.is_file():frozen[str(f)]=sha256(f)
            f=FIXED/'inputs'/('development' if dev else 'main')/key(r)/'case.pt';frozen[str(f)]=sha256(f)
    for item in p['weights'].values():frozen[item['path']]=sha256(item['path']);assert frozen[item['path']]==item['sha256']
    if (OUT/'frozen_historical_inputs.json').exists():assert load(OUT/'frozen_historical_inputs.json')==frozen
    else:dump(OUT/'frozen_historical_inputs.json',frozen)
    return out
