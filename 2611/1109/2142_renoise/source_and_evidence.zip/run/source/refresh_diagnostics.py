"""Repair diagnostic scope from saved coordinates; never rerun or alter endpoints."""
from common import *
import torch,shutil
from inputs import read_case,key
from metrics import Metrics


def main():
    refreshed=[];partials=[]
    for f in sorted((OUT/'development/paths').glob('*')):
        if not (f/'path.json').exists():
            dest=OUT/'interrupted_development'/f.name
            assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.move(str(f),str(dest));partials.append(str(dest));continue
        path=load(f/'path.json');method=path['method'];pid,seed,rest=f.name.split('_',2)
        freeze=path['freeze'] if method.startswith('D') else None
        c,_=read_case(dict(pid=pid,seed=int(seed)),True,freeze);m=Metrics(c)
        init=np.load(f/'initial.npz');prev=init['xyz'];rows=load(f/'trajectory.json')
        for i,row in enumerate(rows):
            x=np.load(f/'trajectory'/f'step_{i:02d}.npz')['xyz'];trace=torch.load(f/'trajectory'/f'trace_{i:02d}.pt',weights_only=False,map_location='cpu')
            row.update(m.snapshot(x),**m.changes(prev,x),**m.changes(prev,trace['deterministic_xyz'],'deterministic'))
            pf=np.zeros_like(prev);idx=trace['force_index'].numpy()-int((c['graph'].frag_idx_map==-1).sum());mask=(idx>=0)&(idx<len(pf));pf[idx[mask]]=trace['pseudoforce'].numpy()[mask]
            _,dp=m.distances(prev);proj=(pf[:,None]*(prev[:,None]-m.protein[None,:])/np.maximum(dp[:,:,None],1e-12)).sum(-1);v=proj[dp<m.plimits]
            row.update(pseudoforce_protein_outward=int((v>1e-8).sum()),pseudoforce_protein_inward=int((v< -1e-8).sum()),pseudoforce_protein_projection_mean=float(v.mean()) if len(v) else None)
            prev=x
        dump(f/'trajectory.json',rows)
        path['info'].update(before_resampling=m.snapshot(init['stage1_xyz']),after_resampling=m.snapshot(init['xyz']),renoise_changes=m.changes(init['stage1_xyz'],init['xyz'],'renoise'))
        dump(f/'path.json',path);refreshed.append(str(f))
    for f in sorted((OUT/'development/endpoints').glob('*/quality.json')):
        row=load(f);method=row['method'];freeze=float(method.removeprefix('D_freeze')) if method.startswith('D_freeze') else None
        c,v=read_case(row,True,freeze);m=Metrics(c)
        if method=='A':x=v['xyz']
        else:x=torch.load(OUT/'development/paths'/f'{key(row)}_{method}'/'endpoint.pt',weights_only=False,map_location='cpu')['xyz']
        full=row['full_quality'];row.update(m.snapshot(x))
        assert row['severe_internal_pairs']==full['modules']['geometry']['severe_internal_clash_pairs']
        assert row['severe_protein_pairs']==full['modules']['protein']['severe_clash_pairs']
        dump(f,row)
    dump(OUT/'RECOVERY_DIAGNOSTIC_SCOPE.json',dict(reason='Protein diagnostic originally included cofactors; align with frozen HQ protein-only scope before selection.',
         formal_run_started=False,development_selection_occurred=False,refreshed_paths=refreshed,preserved_partial_paths=partials,
         endpoints_modified=False,full_HQ_PB_recomputed=False,partial_network_NFE=sum(len(list(Path(f).glob('trajectory/trace_*.pt'))) for f in partials)))

if __name__=='__main__':main()
