"""Frozen full quality protocol; diagnostic minimizers never feed trajectories."""
from common import *
import torch
from rdkit import Chem
from oracle_graph import assemble
from denovo_quality.common import object_hash,versions,conjunction
from denovo_quality.io import load_molecule
from denovo_quality.chemistry import evaluate_chemistry
from geometry_constraints_20261103.stereo import derive
from denovo_quality.pipeline import task
from metrics import Metrics
from inputs import graph_hash,chemistry_hash,comparable_drift


def evaluate(job):
    torch.set_num_threads(1)
    c=job['case'];x=job['xyz'];f=Path(job['folder']);f.mkdir(parents=True,exist_ok=True)
    if (f/'quality.json').exists():return load(f/'quality.json')
    mol=assemble(c['spec'])
    for i,v in enumerate(x):mol.GetConformer().SetAtomPosition(i,v.tolist())
    with Chem.SDWriter(str(f/'raw.sdf')) as w:w.write(mol)
    dump(f/'original_spec.json',c['spec'])
    parsed,info,_=load_molecule(dict(record_index=0,sdf_path=str(f/'raw.sdf'),chemistry_spec_path=str(f/'original_spec.json')))
    details,declared=evaluate_chemistry(parsed,info)
    q,spec,decisions=derive(parsed,c['spec'])
    with Chem.SDWriter(str(f/'derived.sdf')) as w:w.write(q)
    dump(f/'derived_spec.json',spec);dump(f/'stereo_decisions.json',decisions)
    aid=f'{job["phase"]}_{c["pid"]}_{c["seed"]}_{job["method"]}'
    row=dict(molecule_id=aid,group=job['method'],receptor_id=c['pid'],seed=c['seed'],record_index=0,
             sdf_path=str(f/'derived.sdf'),chemistry_spec_path=str(f/'derived_spec.json'),protein_path=c['context']['pdb_path'])
    install_pb();config=load_config(OUT/'quality_config.json')
    compute=object_hash({str(p):sha256(p) for p in (ROOT/'denovo_quality').glob('*.py')})
    full=task((row,config,str(OUT/job['phase']/'quality'),compute,versions(),False))
    checks=full['checks'];original=dict(checks)
    for field in ['stereo_definition_complete','stereo_geometry_consistent']:original[field]=declared.get(field)
    originalHQ=conjunction(original.get(k) for k in config['quality']['required_checks'])
    m=Metrics(c);d=m.drift(x,job['baseline_xyz']) if graph_hash(c['spec'])==graph_hash(job['baseline_case']['spec']) else comparable_drift(c,x,job['baseline_case'],job['baseline_xyz'])
    result=dict(pid=c['pid'],seed=c['seed'],phase=job['phase'],method=job['method'],folder=str(f),
                HQ_no_water=checks.get('high_quality'),HQ_original_stereo=originalHQ,PB=checks.get('posebusters_all_pass'),
                original_stereo_complete=declared.get('stereo_definition_complete'),original_stereo_consistent=declared.get('stereo_geometry_consistent'),
                graph_hash=graph_hash(c['spec']),chemistry_hash=chemistry_hash(c['spec']),
                graph_changed_vs_A=chemistry_hash(c['spec'])!=chemistry_hash(job['baseline_case']['spec']),
                N=c['N'],atoms=len(x),**m.snapshot(x),**d,checks=checks,declared_stereo=declared,
                full_quality=full,attribution='raw_neural_only' if job['method']=='A' else 'fixed_graph_neural_resampling',
                extra_NFE=job['extra_NFE'],total_logical_NFE=24+job['extra_NFE'] if not job['method'].startswith('D') else 24)
    assert full.get('input_unchanged') is True
    # The frozen model graph and coordinate-derived QC graph can have different
    # stereochemistry, hence different stereo-sensitive RDKit distance bounds.
    # Preserve both definitions; never require equal counts across those graphs.
    result['HQ_derived_severe_internal_pairs']=full['modules']['geometry']['severe_internal_clash_pairs']
    result['HQ_derived_severe_protein_pairs']=full['modules']['protein']['severe_clash_pairs']
    result['collision_diagnostic_scope']='unrounded coordinates, original frozen predicted graph; HQ uses serialized coordinate-derived graph'
    dump(f/'quality.json',result)
    print('QC',job['phase'],job['method'],c['pid'],c['seed'],result['HQ_no_water'],flush=True)
    return result
