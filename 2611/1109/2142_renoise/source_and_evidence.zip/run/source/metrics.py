"""Read-only frozen-QC collision pairs and saved-reference geometry."""
from common import *
from rdkit import Chem
from oracle_graph import assemble
from denovo_quality.geometry import bounds_matrix
from denovo_quality.protein import read_protein
from itertools import combinations

class Metrics:
    def __init__(self,case):
        self.mol=assemble(case['spec']);self.groups=case['groups'];self.n=self.mol.GetNumAtoms()
        self.ref=self.mol.GetConformer().GetPositions()
        self.fids=np.empty(self.n,dtype=int)
        for slot,g in enumerate(self.groups):self.fids[g]=slot
        cfg=load(OUT/'quality_config.json');self.cfg=cfg
        topo=Chem.GetDistanceMatrix(self.mol);bounds=bounds_matrix(self.mol);pt=Chem.GetPeriodicTable()
        rv=np.array([pt.GetRvdw(a.GetAtomicNum()) for a in self.mol.GetAtoms()])
        self.pairs=np.array([(i,j) for i in range(self.n) for j in range(i+1,self.n) if topo[i,j]>1],int).reshape(-1,2)
        self.limits=[]
        for i,j in self.pairs:
            self.limits.append(bounds[j,i]*cfg['geometry']['local_severe_lower_bound_ratio'] if topo[i,j] in [2,3] else (rv[i]+rv[j])*cfg['geometry']['nonlocal_severe_vdw_ratio'])
        self.limits=np.array(self.limits)
        atoms=[a for a in read_protein(case['context']['pdb_path'])['atoms'] if a['kind']=='protein']
        self.protein=np.array([a['xyz'] for a in atoms]);pv=np.array([a['vdw_radius_A'] for a in atoms])
        self.plimits=cfg['protein']['severe_vdw_ratio']*(rv[:,None]+pv[None,:])
        metal=np.array([a['kind']=='inorganic_cofactor' for a in atoms])
        if metal.any():
            rc=np.array([pt.GetRcovalent(a.GetAtomicNum()) for a in self.mol.GetAtoms()])
            self.plimits[:,metal]=cfg['protein']['severe_vdw_ratio']*(rc[:,None]+np.array([a['covalent_radius_A'] for a in atoms])[None,metal])
        self.bonds=np.array([(b['begin'],b['end']) for b in case['spec']['connections']],int).reshape(-1,2)
        self.btarget=np.linalg.norm(self.ref[self.bonds[:,0]]-self.ref[self.bonds[:,1]],axis=-1)
        self.angles=[];self.atarget=[]
        for a in self.mol.GetAtoms():
            j=a.GetIdx()
            for i,k in combinations([b.GetIdx() for b in a.GetNeighbors()],2):
                if len({self.fids[i],self.fids[j],self.fids[k]})>1:self.angles.append((i,j,k))
        self.angles=np.array(self.angles,int).reshape(-1,3)
        self.atarget=self.angle_values(self.ref)
    def angle_values(self,x):
        if not len(self.angles):return np.array([])
        i,j,k=self.angles.T;u=x[i]-x[j];v=x[k]-x[j]
        return np.degrees(np.arccos(np.clip((u*v).sum(-1)/np.maximum(np.linalg.norm(u,axis=-1)*np.linalg.norm(v,axis=-1),1e-12),-1,1)))
    def distances(self,x):
        return (np.linalg.norm(x[self.pairs[:,0]]-x[self.pairs[:,1]],axis=-1),np.linalg.norm(x[:,None]-self.protein[None,:],axis=-1))
    def snapshot(self,x):
        d,p=self.distances(x);b=np.linalg.norm(x[self.bonds[:,0]]-x[self.bonds[:,1]],axis=-1)
        a=self.angle_values(x)
        return dict(severe_internal_pairs=int((d<self.limits).sum()),severe_protein_pairs=int((p<self.plimits).sum()),
                    minimum_nonbonded_distance_A=float(d.min()) if len(d) else None,
                    minimum_nonbonded_threshold_ratio=float((d/self.limits).min()) if len(d) else None,
                    minimum_protein_distance_A=float(p.min()),minimum_protein_threshold_ratio=float((p/self.plimits).min()),
                    cross_bond_reference_MAE_A=float(np.abs(b-self.btarget).mean()) if len(b) else None,
                    cross_angle_reference_MAE_deg=float(np.abs(a-self.atarget).mean()) if len(a) else None)
    def changes(self,before,after,prefix='actual'):
        out={}
        for name,a,b,limit in zip(['internal','protein'],self.distances(before),self.distances(after),[self.limits,self.plimits]):
            old=a<limit;new=b<limit;delta=b-a;v=delta[old]
            out.update({f'{prefix}_{name}_old_severe':int(old.sum()),f'{prefix}_{name}_relieved':int((v>1e-6).sum()),
                        f'{prefix}_{name}_worsened':int((v< -1e-6).sum()),f'{prefix}_{name}_removed':int((old & ~new).sum()),
                        f'{prefix}_{name}_new':int((~old & new).sum()),f'{prefix}_{name}_old_pair_mean_delta_A':float(v.mean()) if len(v) else None})
        b0=np.linalg.norm(before[self.bonds[:,0]]-before[self.bonds[:,1]],axis=-1)
        b1=np.linalg.norm(after[self.bonds[:,0]]-after[self.bonds[:,1]],axis=-1)
        out[f'{prefix}_bond_error_improvement_A']=float((np.abs(b0-self.btarget)-np.abs(b1-self.btarget)).mean()) if len(b0) else None
        return out
    def drift(self,x,baseline):
        d=np.linalg.norm(x-baseline,axis=-1)
        old=np.linalg.norm(baseline[:,None]-self.protein[None,:],axis=-1)<4.5
        new=np.linalg.norm(x[:,None]-self.protein[None,:],axis=-1)<4.5
        return dict(RMSD_to_stage1_A=float(np.sqrt(np.mean(d*d))),max_atom_displacement_A=float(d.max()),
                    original_contact_pairs=int(old.sum()),final_contact_pairs=int(new.sum()),
                    contact_retention=float((old & new).sum()/old.sum()) if old.any() else None)
