"""Read-only audit of saved predicted graphs using official explicit-cut semantics."""
from common import *
import collections
import traceback
import torch
from rdkit import Chem
from rdkit.Chem import AllChem
from oracle_graph import rebuild, assemble, export_oracle
from validation import compare_values, GRAPH_FIELDS
from sigmadock.oracle import HPARAMS
from sigmadock.chem.fragmentation import get_fragmented_anchors_dummies, get_fragment_map

EDGE_NAMES = ['ligand_bonds', 'ligand_torsional_bond', 'fragment_triangulation', 'ligand_anchor_dummy']


def examine(graph, spec):
    mol = assemble(spec)
    xyz = mol.GetConformer().GetPositions()
    pn = int((graph.frag_idx_map == -1).sum())
    n = mol.GetNumAtoms()
    assert np.max(np.abs(graph.ref_pos[pn:pn+n].numpy()-xyz)) < 2e-5
    assert graph.node_entity.ndim == 1
    assert graph.mask.dtype == torch.bool
    assert graph.edge_attr.shape[0] == graph.edge_index.shape[1] == len(graph.edge_entity)
    assert int(graph.edge_index.max()) < len(graph.x)
    fragmented = graph.mol_info['fragmented']
    anchors, dummies = map(np.asarray, get_fragmented_anchors_dummies(fragmented))
    fxyz = fragmented.GetConformer().GetPositions()
    edge = graph.edge_index.numpy()
    types = graph.edge_entity.numpy()
    valid = graph.mask.numpy()[edge].all(axis=0)
    connections = []
    for bond in spec['connections']:
        i, j = bond['begin'], bond['end']
        length = float(np.linalg.norm(xyz[i]-xyz[j]))
        assert .5 < length < 2.5, ('reference length', i, j, length)
        targets = []
        for a, d in zip(anchors, dummies):
            if (a == i and np.max(np.abs(fxyz[d]-xyz[j])) < 2e-5) or (a == j and np.max(np.abs(fxyz[d]-xyz[i])) < 2e-5):
                targets.append(float(np.linalg.norm(fxyz[a]-fxyz[d])))
        assert len(targets) == 2 and max(abs(t-length) for t in targets) < 2e-5
        e = types == HPARAMS.get_edge_idx('ligand_torsional_bond')
        forward = e & (edge[0] == pn+i) & (edge[1] == pn+j)
        backward = e & (edge[0] == pn+j) & (edge[1] == pn+i)
        assert (forward & valid).any() and (backward & valid).any(), ('missing torsion', i, j)
        # Bond order is carried by chemistry edges to each corresponding dummy.
        dummy_features = []
        for a, d in zip(anchors, dummies):
            if (a == i and np.max(np.abs(fxyz[d]-xyz[j])) < 2e-5) or (a == j and np.max(np.abs(fxyz[d]-xyz[i])) < 2e-5):
                q = (types == HPARAMS.get_edge_idx('ligand_bonds')) & (edge[0] == pn+a) & (edge[1] == pn+d)
                assert q.sum() == 1
                dummy_features.append(graph.edge_attr[torch.from_numpy(q)].tolist())
        connections.append(dict(begin=i,end=j,bond_type=bond['bond_type'],reference_length_A=length,
                                dummy_lengths_A=targets,chemical_dummy_edge_attrs=dummy_features,
                                torsional_directed_multiplicity=[int(forward.sum()),int(backward.sum())]))
    # Boundary edge attributes are officially all zero; reference geometry is in ref_pos.
    for name in EDGE_NAMES[1:]:
        select = graph.edge_entity == HPARAMS.get_edge_idx(name)
        assert not graph.edge_attr[select].any()
    mapping = get_fragment_map(fragmented)
    assert len(mapping['torsional_bonds']) == len(spec['connections'])
    return dict(passed=True,nodes=graph.num_nodes,atoms=n,N=len(spec['fragments']),connections=connections,
                edge_counts={k:int((types == HPARAMS.get_edge_idx(k)).sum()) for k in EDGE_NAMES},
                effective_edge_counts={k:int(((types == HPARAMS.get_edge_idx(k)) & valid).sum()) for k in EDGE_NAMES},
                reference_source=spec['reference_source'])


def fixtures(context):
    definitions = [
        ('single_connection','CCCC',[(1,2)]),
        ('multiport','CC(C)CC',[(0,1),(1,3)]),
        ('double_connection','CC=CC',[(1,2)]),
        ('triple_connection','CC#CC',[(1,2)]),
        ('aromatic_fragment','c1ccccc1CC',[(5,6)]),
        ('single_atom','CCC',[(0,1),(1,2)]),
        ('diatomic_symmetric','CCCC',[(1,2)]),
        ('ring_multilink','C1CCCCC1',[(0,1),(3,4)]),
        ('incomplete_stereo','CC(O)CC',[(2,1),(1,3)]),
    ]
    rows=[]
    for name,smiles,pairs in definitions:
        try:
            mol=Chem.AddHs(Chem.MolFromSmiles(smiles))
            assert AllChem.EmbedMolecule(mol,randomSeed=214211)==0
            mol=Chem.RemoveHs(mol) # ETKDG only, no force field optimization.
            cuts=[mol.GetBondBetweenAtoms(i,j).GetIdx() for i,j in pairs]
            fm=Chem.FragmentOnBonds(mol,cuts,addDummies=False)
            groups=[list(g) for g in Chem.GetMolFrags(fm)]
            spec=export_oracle(mol,groups,cuts,reference_source='synthetic ETKDG fixture; no minimization')
            graph=rebuild(spec,**context)
            row=examine(graph,spec)
            torch.save(dict(graph=graph,spec=spec),OUT/'audit'/f'fixture_{name}.pt')
            row.update(name=name,smiles=smiles,supported=True)
        except Exception as exc:
            row=dict(name=name,smiles=smiles,supported=False,error=repr(exc),traceback=traceback.format_exc())
        rows.append(row)
        print('FIXTURE',name,row.get('supported'),row.get('error',''),flush=True)
    return rows


def main():
    torch.set_num_threads(1)
    old=ROOT/'fixed_topology_guidance_vs_refinement'
    protocol=load(ROOT/'dynamic_update_rigid_projection/protocol.json')
    rows=[];context=None
    for phase,field in [('development','development'),('main','main_cases')]:
        for r in protocol[field]:
            key=f'{r["pid"]}_{r["seed"]}'
            p=old/'inputs'/phase/key/'case.pt'
            try:
                case=torch.load(p,map_location='cpu',weights_only=False)
                context=case['context']
                graph=rebuild(case['spec'],**context)
                # RDKit's torch pickle omits private molecule properties. Compare
                # every saved tensor and audit fresh mapping against declared cuts.
                fields=[]
                for field in GRAPH_FIELDS:
                    fields.extend(compare_values(case['graph'][field],graph[field],field))
                comparison=dict(equal=all(v['equal'] for v in fields),fields=fields,
                                saved_private_mapping_available=case['graph'].mol_info['fragmented'].HasProp('fragmentation_mapping'))
                assert comparison['equal'],[v for v in comparison['fields'] if not v['equal']]
                row=examine(graph,case['spec'])
                row.update(key=key,phase=phase,official_annotation_tensor_comparison=comparison,
                           source=str(p),source_sha256=sha256(p))
            except Exception as exc:
                row=dict(key=key,phase=phase,passed=False,error=repr(exc),traceback=traceback.format_exc())
            rows.append(row)
            dump(OUT/'audit'/f'{phase}_{key}.json',row)
            print('AUDIT',phase,key,row['passed'],row.get('error',''),flush=True)
    synthetic=fixtures(context)
    result=dict(saved_graphs_passed=all(r['passed'] for r in rows),saved_cases=len(rows),rows=rows,fixtures=synthetic,
                comparison_scope='Exact official Dataset annotation and processing under same explicitly supplied cuts; not equality to canonical cut selection.',
                cuda_available=torch.cuda.is_available(),torch_version=torch.__version__)
    dump(OUT/'audit/graph_audit.json',result)
    csvwrite(OUT/'audit/connection_reference_audit.csv',[dict(key=r['key'],phase=r['phase'],**b) for r in rows if r['passed'] for b in r['connections']])

if __name__=='__main__':main()
