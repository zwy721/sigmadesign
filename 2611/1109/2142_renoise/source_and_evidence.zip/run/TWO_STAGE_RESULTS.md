# Two-stage fixed-graph results

32 historical pressure cases per method; all denominators retained. HQ uses frozen coordinate-derived stereo; original-declared HQ is separate. No training or sampling repair was used. These cases are not an independent generalization set.

Original stereo definition complete: A 12/32, B 12/32, C_replay 12/32, C_official_seed 12/32, C_official_new 12/32, D 14/32, E 12/32.

|Method|HQ /32|Original-stereo HQ /32|PB /32|Internal pairs mean|Protein pairs mean|RMSD to A, Å|Logical NFE|
|---|---:|---:|---:|---:|---:|---:|---:|
|A|2|1|3|0.969|0.844|0.000|24|
|B|9|3|16|0.312|0.219|1.991|48|
|C_replay|11|3|15|0.281|0.219|3.989|48|
|C_official_seed|9|3|11|0.094|0.281|4.788|48|
|C_official_new|8|1|11|0.406|0.312|5.100|48|
|D|8|4|10|0.844|0.500|1.780|24|
|E|8|2|12|0.281|0.438|4.633|48|

D RMSD is available in 10/32 cases only, covering 38 atoms; mean per-molecule mapping coverage=4.29%. Its mapped RMSD must not be compared with full-molecule B/C/E drift.

Frozen development choice: B t_start=0.2, reverse noise_scale=0.0; D freeze threshold=0.2. C_replay is the historical initialization control; C_official_seed/new use IGSO3 official priors.

## Paired HQ changes versus A

|Method|Wins|Losses|Exact two-sided McNemar p|
|---|---:|---:|---:|
|B|8|1|0.0390625|
|C_replay|10|1|0.0117188|
|C_official_seed|8|1|0.0390625|
|C_official_new|7|1|0.0703125|
|D|6|0|0.03125|
|E|7|1|0.0703125|

P values are descriptive, unadjusted across six contrasts and correlated pockets; no independent confirmatory claim. D changes predicted chemistry, so its contrast is not an isolated denoising effect. E holds fixed chemistry and 24 extra NFE; it does not isolate freezing itself.

Geometry MAE in this study uses saved network reference geometry. Frozen HQ geometry instead uses its existing RDKit bounds/amide checks. These targets are explicitly separate. Protein collision counts use protein atoms only; cofactors remain in full PB and QC diagnostic outputs. Contacts are heavy-atom protein pairs within 4.5 Å.

Collision columns and trajectories use the original frozen predicted graph and unrounded network coordinates. HQ_derived_* columns use the serialized coordinate-derived QC graph. Stereo-sensitive RDKit bounds can differ: 9RT3_41005/C_official_new has1 original-graph severe pair versus5 derived-QC severe pairs at identical serialized coordinates. No threshold or endpoint was changed; see QUALITY_GRAPH_SCOPE_AUDIT.json. Original-stereo HQ applies the historical original-declaration gates to the frozen QC, without claiming network stereo prediction.

Full raw quality, errors, unavailable checks, path files and failures are retained under main/.
