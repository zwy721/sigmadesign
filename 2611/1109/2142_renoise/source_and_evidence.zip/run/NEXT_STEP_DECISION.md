# Next-step decision

1. Fixed-graph local second pass: B HQ=9/32 versus A=2/32, paired wins/losses=8/1, descriptive exact p=0.0390625. Do not extrapolate from this repeatedly inspected pressure set.
2. Collision recovery: B mean internal/protein severe pairs=0.312/0.219, A=0.969/0.844. Inspect both new and removed pair counts, not only HQ.
3. Local versus full resampling: B=9/32; C_replay=11/32, C_official_seed=9/32, C_official_new=8/32; E=8/32. No per-molecule best-of-N selection was used.
4. Early freezing: D=8/32 at24 logical NFE, with changed chemistry in 32/32 cases; B/C/E each cost48. This is an engineering tradeoff, not a fixed-chemistry causal comparison.
5. Pseudoforces and torque: see the paired same-input directional projections, deterministic rigid shadows and actual pair-distance changes. Outward force does not imply outward rigid displacement, and neither guarantees final HQ.
6. Input representation: saved chemistry/dummy references and actual masked auxiliary edges pass their audits. inter_fragments is unavailable in this checkpoint by design. Additive edge encoders would require a separate architecture/training study, not silently enabling missing weights.
7. Pose retention: B mean drift=1.991 Å; C/E and contact changes are reported separately. This study contains no crystal pose accuracy validation.
8. Efficiency: this run records synchronized A100 path wall time and NFE; historic CPU MMFF timing has different scopes. It does not establish that an extra neural pass is cheaper than terminal MMFF.
9. Framework implication: two-stage dynamic topology plus stable-graph recovery is testable, but favorable pressure-test counts alone do not justify a new training run. First confirm on untouched pockets/seeds under the frozen protocol.
10. Failure attribution: graph construction is audited, but out-of-training-distribution graph partitions and treating the .005 terminal state as a clean proxy remain limitations. Absent direct learned ligand-ligand spatial edges is a concrete checkpoint restriction. The present comparisons cannot uniquely separate input distribution mismatch from learned score capacity.

Recommended next action is an independent confirmatory cohort with the already frozen B/D settings and complete original-stereo reporting, before model/weight changes. Keep the historical MMFF route separate as an engineering reference.
