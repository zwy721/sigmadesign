# Recovery and acceptance notes

The original diagnostic counter included organic cofactors under the protein label. The frozen full HQ/PB evaluator was always unchanged. The run was interrupted during D development,36 completed B trajectories were retained, and diagnostics were recalculated from their coordinates.84 saved sample NFE from the interrupted D paths remain local.

The first eight-case B repeat then failed bitwise reproducibility. Exact initialization/noise matched; the first pseudoforce differed by roughly3e-7, consistent with nondeterministic reductions. The driver had omitted the historical deterministic-algorithm flags. No formal run had begun. All affected development/precheck outputs and the old freeze remain under superseded_nondeterministic/.

The corrected driver enables deterministic Torch algorithms, disables TF32 and sets CUBLAS_WORKSPACE_CONFIG=:4096:8, while retaining the historical stable-precision accumulation and all weights. Development and precheck were rerun, rather than loosening tolerances or choosing favorable repeats. The selected parameters stayed0.2/0/0.2.

A post-freeze quality-adapter assertion incorrectly equated original predicted-graph collision counts with coordinate-derived stereo QC counts. At9RT3_41005/C_official_new the same serialized coordinates have1 versus5 severe pairs because stereo changes RDKit distance bounds. Only the diagnostic assertion was removed and both scopes retained; frozen thresholds, checks and sampling outputs were unchanged. The original source/freeze and detailed bounds are preserved.

Full32 C_replay validation found4 cases beyond the historical tolerance, despite the8-case precheck passing. The new reference-chart first transform was algebraically equivalent but rounded differently from the historical current-state transform. Running unchanged1905 runtime reproduced every coordinate of all32x24 saved states bitwise. Only C_replay step0 was corrected to that historical operation order; other branch outputs were retained. Prior C outputs, precheck and freeze snapshots are preserved under superseded_replay_numerics/. No weights, seeds, time grids or development choice changed. C precheck and formal replay were repeated.

Method costs and all persisted research overhead are separate in analysis/RESEARCH_COMPUTE_ACCOUNTING.json.
