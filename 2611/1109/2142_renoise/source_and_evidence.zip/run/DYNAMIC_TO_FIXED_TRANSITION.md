# Dynamic-to-fixed state transition

A is read from dynamic_update_rigid_projection/{development/b6,full32/b32}/structures/*_Baseline/trajectory/step_23.npz. The exact predicted spec/context and unbound reference are taken from the audited 1905 saved case. No conformer is regenerated. Official initial-state construction recreates pos_0, T0 and R0; saved C/Q restore the physical final pose before any noise.

The state recovery gate verifies all 38 endpoints and three early freeze points. Internal distances, proper rotations and ordered chemistry stay fixed throughout B/C/E. Trace files retain fragment forces/torques, original pseudoforces, C/Q before/after and deterministic shadow coordinates.

C_replay preserves the historical step0 current-state chart explicitly. The first implementation used an algebraically equivalent reference chart, which failed full32 historical tolerance in four cases. A controlled run of unchanged1905 runtime reproduced all32×24 states bitwise; only C_replay step0 was corrected and its precheck/formal path repeated. All superseded results, prior source/freeze hashes and the diagnostic control remain local. Other branch outputs and all selected parameters stayed fixed.

B/E call the official forward_marginal on normalized fragment centers and proper rotations. R3 uses the official VP attenuation/variance; SO3 samples IGSO3 and left-multiplies the original rotation. Forward noise and reverse noise use independent purpose-keyed streams. t=0 is an explicit no-op boundary, not an evaluation of a singular translation score or a nonzero-minimum-sigma SO3 kernel.

C_replay restores the saved historical final-graph initialization, including fragment coordinate charts. Official C branches call sample_ref with original seed and seed+214200000. They are reported separately without choosing a favorable draw. Every stage-two fragment can move.

D restores the saved prefix before the first t≤threshold and reconstructs its last accepted graph directly from saved per-fragment reference coordinates. Later updates never execute. At the frozen 0.2 threshold it resumes at step13 and executes 11 remaining forwards; the reused prefix contributes13 logical NFE.

No identity classifier, connection model, true ligand identity/topology/pose, projection or force-field optimizer is called by stage-two sampling. Existing ligand-defined pocket conditioning is inherited; no reference docking-accuracy conclusion is made. Diagnostic evaluator minimizations operate on copies and are never used as outputs.

Initial development diagnostic scope was corrected before selection; then a missing deterministic-kernel setting was identified in precheck. Superseded runs remain under superseded_nondeterministic/ and interrupted_development/. The corrected run uses deterministic Torch kernels, CUBLAS_WORKSPACE_CONFIG=:4096:8, TF32 disabled and unchanged historical FP64 contraction accumulation with FP32 weights. Selection and precheck are rerun before formal sampling.
