"""Independent frozen-metric and degenerate-orientation regression checks."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import torch
from rdkit import Chem
from metrics import Metrics
from inputs import read_case,chemistry_hash,graph_hash,comparable_drift
from denovo_quality.geometry import evaluate_geometry
from denovo_quality.protein import evaluate_protein
from orientation import fit


def test_pair_counts_equal_frozen_evaluator_under_multiple_poses():
    c,v=read_case(dict(pid='2zwz',seed=42001),True);m=Metrics(c);rng=np.random.default_rng(2142)
    for x in [v['xyz'],v['xyz']+rng.normal(0,.7,v['xyz'].shape),v['xyz']+np.array([20.,0.,0.])]:
        mol=Chem.Mol(m.mol)
        for i,p in enumerate(x):mol.GetConformer().SetAtomPosition(i,p.tolist())
        g,_=evaluate_geometry(mol,m.fids,m.cfg['geometry'])
        p,_=evaluate_protein(mol,c['context']['pdb_path'],m.cfg['protein'])
        measured=m.snapshot(x)
        assert measured['severe_internal_pairs']==g['severe_internal_clash_pairs']
        # Protein details expose counts by component; match severe atom pairs.
        assert measured['severe_protein_pairs']==p['severe_clash_pairs']


def test_bonded_pairs_never_counted_as_internal_nonbonded_clashes():
    c,v=read_case(dict(pid='2zwz',seed=42001),True);m=Metrics(c)
    pairs=set(map(tuple,m.pairs))
    for b in m.mol.GetBonds():assert tuple(sorted([b.GetBeginAtomIdx(),b.GetEndAtomIdx()])) not in pairs


def test_chemistry_hash_separates_reference_coordinates():
    import copy
    c,_=read_case(dict(pid='2zwz',seed=42001),True);s=copy.deepcopy(c['spec']);s['fragments'][0]['coordinates'][0][0]+=.1
    assert chemistry_hash(s)==chemistry_hash(c['spec'])
    assert graph_hash(s)!=graph_hash(c['spec'])
    s['fragments'][0]['atoms'][0]['charge']+=1
    assert chemistry_hash(s)!=chemistry_hash(c['spec'])


def test_singleton_and_diatomic_reference_orientations_are_proper_and_reproducible():
    from scipy.spatial.transform import Rotation
    ref=Rotation.from_rotvec([.3,-.2,.4]).as_matrix()
    for x in [np.zeros((1,3)),np.array([[-1.,0,0],[1.,0,0]])]:
        y=x@ref.T+np.array([1.,2.,3.])
        t,r,error,a=fit(x,y,ref)
        assert error<1e-10 and np.max(np.abs(r-ref))<1e-10
        assert np.allclose(r.T@r,np.eye(3)) and np.linalg.det(r)>.999999


def test_required_graph_and_kernel_gate_results():
    g=load(OUT/'audit/graph_audit.json');r=load(OUT/'audit/runtime_gate.json')
    assert g['saved_graphs_passed'] and g['saved_cases']==38
    assert all(v['supported'] for v in g['fixtures'])
    assert r['passed'] and r['states']==152 and len(r['fixtures'])==9
    assert r['zero_time_noop']


def test_identity_mapping_does_not_align_away_pose_motion():
    c,v=read_case(dict(pid='2zwz',seed=42001),True)
    d=comparable_drift(c,v['xyz']+np.array([1.,0.,0.]),c,v['xyz'])
    assert abs(d['RMSD_to_stage1_A']-1.)<1e-12 and d['mapping_coverage']==1.


def test_incomplete_stereo_fixture_keeps_original_definition_incomplete():
    from oracle_graph import assemble
    v=torch.load(OUT/'audit/fixture_incomplete_stereo.pt',weights_only=False,map_location='cpu')
    mol=assemble(v['spec'])
    centers=Chem.FindMolChiralCenters(mol,includeUnassigned=True,useLegacyImplementation=False)
    assert centers and any(label=='?' for _,label in centers)
    assert all(a.GetChiralTag()==Chem.ChiralType.CHI_UNSPECIFIED for a in mol.GetAtoms())


def test_noncanonical_cuts_are_visible_and_kept_in_pressure_denominator():
    rows=load(OUT/'audit/noncanonical_cuts.json')
    assert {r['key'] for r in rows}=={'7ILZ_41012','7ILZ_41007'}
    declared={f'{r["pid"]}_{r["seed"]}' for r in load(OUT/'protocol.json')['main_cases']}
    assert len(declared)==32 and {r['key'] for r in rows}.issubset(declared)


def test_original_and_derived_stereo_can_change_local_collision_bounds():
    from denovo_quality.io import load_molecule
    r=dict(pid='9RT3',seed=41005);c,_=read_case(r);m=Metrics(c)
    f=OUT/'main/endpoints/9RT3_41005_C_official_new'
    original,_,_=load_molecule(dict(record_index=0,sdf_path=str(f/'raw.sdf'),chemistry_spec_path=str(f/'original_spec.json')))
    derived,_,_=load_molecule(dict(record_index=0,sdf_path=str(f/'derived.sdf'),chemistry_spec_path=str(f/'derived_spec.json')))
    a,_=evaluate_geometry(original,m.fids,m.cfg['geometry']);b,_=evaluate_geometry(derived,m.fids,m.cfg['geometry'])
    assert np.array_equal(original.GetConformer().GetPositions(),derived.GetConformer().GetPositions())
    assert a['severe_internal_clash_pairs']==1 and b['severe_internal_clash_pairs']==5
