# Compute budget comparison

Logical NFE counts per-molecule network applications. Actual GPU forwards count batched invocations. Historical first-pass cost is retained conceptually but is not charged as newly executed GPU work.

|Method|Total logical NFE/sample|New formal NFE/sample|Actual batched forwards|Full32 path wall s|
|---|---:|---:|---:|---:|
|A|24|0|0|reused|
|B|48|24|24|33.450|
|C_replay|48|24|24|34.375|
|C_official_seed|48|24|24|34.005|
|C_official_new|48|24|24|33.625|
|D|24|11|11|16.242|
|E|48|24|24|33.332|

New formal sample NFE: 4192; deterministic shadow updates consume no additional network calls. Edge-sensitivity forwards and synthetic acceptance forwards are diagnostic overhead, separate from formal method budgets.

Wall times synchronize CUDA and include graph work, metric calculation and evidence I/O. They measure A100 occupation under the recorded implementation, not pure kernel time or optimized sampler throughput. CPU evaluator elapsed seconds are preserved per record; these are wall durations, not process CPU-seconds, and include diagnostic MMFF/PoseBusters calculations on copies. None of those diagnostic coordinates are sampled outputs.

Superseded development/prechecks and the interrupted 84 sample NFE are retained and excluded from method quality denominators, but must be counted as research overhead. Historical stage-one and 1905/2058 MMFF costs come from different run scopes/hardware paths; no strict end-to-end speedup claim is supported.

Historical dynamic Baseline posthoc MMFF HQ=28/32 is an external reference only. The 2058 amide refinement HQ=23/32 starts from a different fixed-graph neural baseline. Neither is a new B/C/D/E output. A separate matched cost study is needed for deployment efficiency.

The six retained formal paths total 131 batched forwards and 185.029 synchronized path-wall seconds. Summed evaluator elapsed time across all224 formal records is 520.680 s; this is cumulative record time and may include reused A evaluations, rather than a fresh end-to-end duration.

## Persisted research overhead

|Phase|Sample NFE|Batched forwards|Path wall s|Summed evaluator elapsed s|
|---|---:|---:|---:|---:|
|development|1140|190|97.617|135.107|
|main|4192|131|185.029|520.680|
|precheck8|1048|131|62.622|152.725|
|precheck_repeat|1048|131|62.261|0.000|
|precheck_single|1048|1048|182.807|0.000|
|superseded_nondeterministic|1716|430|131.994|182.887|
|superseded_replay_numerics|1344|264|88.877|81.272|

Additional persisted work: interrupted development 84 sample NFE; unchanged historical-runtime control768 sample NFE /24 batched forwards; synthetic acceptance9 sample NFE; edge sensitivity16 sample NFE. These diagnostics and superseded paths are not quality-denominator additions. Some diagnostics have no separately timed boundary, so a complete CPU/GPU end-to-end total is unavailable. See analysis/RESEARCH_COMPUTE_ACCOUNTING.json.
