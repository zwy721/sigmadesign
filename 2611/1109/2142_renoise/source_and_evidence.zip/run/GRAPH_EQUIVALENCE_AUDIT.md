# Graph equivalence audit

All 38 saved final graphs pass exact tensor comparison with fresh official annotation for the same predicted chemistry, saved reference and prescribed fragment cuts; 164 connection references pass anchor/dummy uniqueness checks.

This verifies official graph construction conditional on the prescribed partition. It does not claim those partitions equal canonical torsional selection or all graphs lie within the pretraining distribution. The adapter changes cut selection only; official annotation and graph-processing functions remain unchanged.

Synthetic ETKDG-only fixtures supported: single_connection, multiport, double_connection, triple_connection, aromatic_fragment, single_atom, diatomic_symmetric, ring_multilink, incomplete_stereo. Single/double/triple connections, aromatic fragments, tiny/symmetric fragments, multi-link rings and incomplete stereo are explicitly exercised. Representability does not establish learned support for free rigid rotations across double/triple/ring connections.

Each actual connection has bidirectional ligand_torsional_bond edges. Two real-to-dummy chemistry edges carry bond order. Boundary/triangulation/anchor-dummy attrs are zero as in the official implementation; their geometry is encoded through reference positions. Both port lengths equal the saved unbound reference distance, never the stage-one terminal distance.

The official reference-distance encoder compares pos_t with pos_0 for boundary edges. The latter comes from ref_pos after pocket subtraction and the original 2.7 Å scale. No crystal pose or new energy minimization supplies these references.

RDKit serialization omits private fragmentation_mapping properties. Saved public tensors were therefore compared individually; fresh mappings were checked against explicit cuts and both port coordinate mappings. This is not treated as a chemistry failure.

Runtime state audit: 152 final/early-freeze states recovered within 0.0002 Å, plus nine synthetic single-step cases. Actual forward-edge audit: 4192 post-mask inputs match static typed edges; masked-node edges are absent, protein spatial edges satisfy the current 4 Å cutoff.

The checkpoint sets ligand_ligand_interactions=False and cutoff_fragment_interactions=-1. inter_fragments is absent by design, not accidentally omitted by the adapter. Its removal is a no-op sensitivity control, not a usable causal ablation. inter_complex and connection auxiliaries are retained and updated according to the official configuration.

Noncanonical predicted cut placement: 2 final pressure graphs (7ILZ_41012, 7ILZ_41007), including one cross-fragment double bond. Their explicit-cut features and actual port reference distances pass; canonical torsional selection would not choose those cuts. This is a partition/pretraining-distribution limitation, not an absent edge or fabricated distance. They remain in32; no learned support for these cuts is inferred.

Observed per-step edge index/entity and immutable input features are available; edge_attr was not independently serialized at every forward. See audit/, analysis/OBSERVED_MODEL_EDGES.csv and source/audit_graphs.py. Unsupported saved graphs: 0/38; unsupported synthetic fixtures: 0/9.
