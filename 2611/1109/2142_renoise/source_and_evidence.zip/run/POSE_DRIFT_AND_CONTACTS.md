# Pose drift and protein contacts

Distances are unaligned heavy-atom distances to the paired stage-one endpoint, not crystal RMSD. Contact retention counts identical ligand-atom/protein-atom pairs within4.5 Å.

|Method|Mean RMSD Å|Mean max displacement Å|Mean contact retention|In pocket /32|Changed chemistry /32|
|---|---:|---:|---:|---:|---:|
|A|0.000|0.000|1.000|32|0|
|B|1.991|3.786|0.544|31|0|
|C_replay|3.989|7.284|0.288|30|0|
|C_official_seed|4.788|8.711|0.231|32|0|
|C_official_new|5.100|9.083|0.194|32|0|
|D|1.780|2.096|unavailable|32|32|
|E|4.633|8.247|0.243|32|0|

D comparisons use only unchanged identity/local atom mapping: 10/32 cases, 38 mapped atoms, mean per-molecule coverage 4.29%. Its average describes that small mapped subset, not full-molecule drift. Contact retention is unavailable across changed chemistry rather than assigning false atom correspondences. Full C can move substantially because it reinitializes every fragment. HQ improvement alone cannot show improved docking or retained biological contacts.
