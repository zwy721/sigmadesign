"""Summarize paired evidence without changing frozen sampling or selection."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import collections,math,torch
from scipy.stats import binomtest
from inputs import key,read_case,source,graph_hash
from metrics import Metrics

METHODS=['A','B','C_replay','C_official_seed','C_official_new','D','E']


def mean(rows,k):
    vals=[r[k] for r in rows if r.get(k) is not None]
    return float(np.mean(vals)) if vals else None


def write(name,lines):
    (OUT/name).write_text('\n'.join(lines)+'\n')


def main():
    rows=load(OUT/'formal_results.json');assert len(rows)==224
    by={m:sorted([r for r in rows if r['method']==m],key=key) for m in METHODS}
    assert all(len(v)==32 for v in by.values())
    baseline={key(r):r for r in by['A']};groups={};paired={};flat=[]
    chosen=load(OUT/'development_selection.json')['selected']
    for m,v in by.items():
        groups[m]=dict(cases=32,HQ=sum(r['HQ_no_water'] is True for r in v),original_stereo_HQ=sum(r['HQ_original_stereo'] is True for r in v),
                      PB=sum(r['PB'] is True for r in v),HQ_unavailable=sum(r['HQ_no_water'] is None for r in v),
                      original_stereo_complete=sum(r['original_stereo_complete'] is True for r in v),
                      mean_internal_pairs=mean(v,'severe_internal_pairs'),mean_protein_pairs=mean(v,'severe_protein_pairs'),
                      bond_reference_MAE_A=mean(v,'cross_bond_reference_MAE_A'),angle_reference_MAE_deg=mean(v,'cross_angle_reference_MAE_deg'),
                      RMSD_A=mean(v,'RMSD_to_stage1_A'),contact_retention=mean(v,'contact_retention'),
                      graph_changed=sum(r['graph_changed_vs_A'] for r in v),mapping_coverage=mean(v,'mapping_coverage'),
                      mapped_RMSD_available_cases=sum(r.get('RMSD_to_stage1_A') is not None for r in v),
                      mapped_atom_count=sum(r.get('mapped_atoms',0) for r in v),
                      in_pocket=sum(r['checks'].get('in_target_pocket') is True for r in v),logical_NFE=v[0]['total_logical_NFE'])
        wins=[key(r) for r in v if r['HQ_no_water'] is True and baseline[key(r)]['HQ_no_water'] is not True]
        losses=[key(r) for r in v if r['HQ_no_water'] is not True and baseline[key(r)]['HQ_no_water'] is True]
        n=len(wins)+len(losses)
        paired[m]=dict(HQ_wins=wins,HQ_losses=losses,exact_mcnemar_p=float(binomtest(len(wins),n,.5).pvalue) if n else 1.,
                       internal_pairs_reduced=sum(r['severe_internal_pairs']<baseline[key(r)]['severe_internal_pairs'] for r in v),
                       protein_pairs_reduced=sum(r['severe_protein_pairs']<baseline[key(r)]['severe_protein_pairs'] for r in v))
        for r in v:
            out={k:x for k,x in r.items() if k not in ['full_quality','checks','declared_stereo']}
            out.update({f'check_{k}':x for k,x in r['checks'].items()})
            geom=r['full_quality']['modules']['geometry']
            out.update(abnormal_bonds=geom.get('abnormal_bond_count'),abnormal_angles=geom.get('abnormal_angle_count'),
                       abnormal_amide_torsions=geom.get('abnormal_amide_torsion_count'),unavailable_checks=r['full_quality']['unavailable_checks'],
                       evaluation_errors=r['full_quality']['errors'],HQ_derived_severe_internal_pairs=geom['severe_internal_clash_pairs'],
                       HQ_derived_severe_protein_pairs=r['full_quality']['modules']['protein']['severe_clash_pairs'])
            flat.append(out)
    csvwrite(OUT/'PER_MOLECULE_RESULTS.csv',flat)
    trajectories=[];initial=[];performance=[]
    for f in sorted((OUT/'main/paths').glob('*')):
        p=load(f/'path.json');trajectory=load(f/'trajectory.json');trajectories+=trajectory
        initial.append(dict(case=f.name,method=p['method'],**p['info']))
        performance.append(dict(folder=str(f),method=p['method'],batch_size=p['batch_size'],extra_NFE=p['extra_NFE'],
                                sample_NFE=p['new_executed_sample_NFE'],shared_batch_wall_seconds=p['shared_batch_wall_seconds'],
                                calls=p['GPU_calls'],step_wall_seconds=sum(t['wall_seconds'] for t in p['timings'])))
    csvwrite(OUT/'PER_STEP_COLLISION_TRAJECTORY.csv',trajectories);dump(OUT/'analysis/initial_resampling.json',initial)
    csvwrite(OUT/'analysis/COMPUTE_PER_PATH.csv',performance)
    summaries=[]
    for m in METHODS[1:]:
        v=[r for r in trajectories if r['method']==m];iv=[r for r in initial if r['method']==m]
        item=dict(method=m,steps=len(v),
                  initial_internal_mean=float(np.mean([r['after_resampling']['severe_internal_pairs'] for r in iv])),
                  initial_protein_mean=float(np.mean([r['after_resampling']['severe_protein_pairs'] for r in iv])))
        fields=['actual_internal_relieved','actual_internal_worsened','actual_internal_removed','actual_internal_new',
                'actual_protein_relieved','actual_protein_worsened','actual_protein_removed','actual_protein_new',
                'pseudoforce_internal_outward','pseudoforce_internal_inward','pseudoforce_protein_outward','pseudoforce_protein_inward']
        for k in fields:item[k]=sum(r[k] for r in v)
        item['mean_bond_error_improvement_per_step_A']=mean(v,'actual_bond_error_improvement_A')
        item['force_outward_internal_fraction']=item['pseudoforce_internal_outward']/max(item['pseudoforce_internal_outward']+item['pseudoforce_internal_inward'],1)
        item['force_outward_protein_fraction']=item['pseudoforce_protein_outward']/max(item['pseudoforce_protein_outward']+item['pseudoforce_protein_inward'],1)
        item['mean_total_path_wall_seconds']=mean([p for p in performance if p['method']==m],'shared_batch_wall_seconds')
        summaries.append(item)
    dump(OUT/'analysis/trajectory_summary.json',summaries)
    # Every actual group has one full32 batch; count wall once, not 32 times.
    perf={m:next(p for p in performance if p['method']==m) for m in METHODS[1:]}
    result=dict(selected=chosen,groups=groups,paired=paired,trajectories=summaries,performance=perf)
    dump(OUT/'summary.json',result)
    header=['# Two-stage fixed-graph results','',
            '32 historical pressure cases per method; all denominators retained. HQ uses frozen coordinate-derived stereo; original-declared HQ is separate. No training or sampling repair was used. These cases are not an independent generalization set.','',
            '|Method|HQ /32|Original-stereo HQ /32|PB /32|Internal pairs mean|Protein pairs mean|RMSD to A, Å|Logical NFE|',
            '|---|---:|---:|---:|---:|---:|---:|---:|']
    for m,g in groups.items():header.append(f'|{m}|{g["HQ"]}|{g["original_stereo_HQ"]}|{g["PB"]}|{g["mean_internal_pairs"]:.3f}|{g["mean_protein_pairs"]:.3f}|{g["RMSD_A"]:.3f}|{g["logical_NFE"]}|')
    header+=['',f'D RMSD is available in {groups["D"]["mapped_RMSD_available_cases"]}/32 cases only, covering {groups["D"]["mapped_atom_count"]} atoms; mean per-molecule mapping coverage={groups["D"]["mapping_coverage"]:.2%}. Its mapped RMSD must not be compared with full-molecule B/C/E drift.']
    header+=['',f'Frozen development choice: B t_start={chosen["tstart"]}, reverse noise_scale={chosen["noise_scale"]}; D freeze threshold={chosen["freeze"]}. C_replay is the historical initialization control; C_official_seed/new use IGSO3 official priors.',
             '', '## Paired HQ changes versus A','', '|Method|Wins|Losses|Exact two-sided McNemar p|','|---|---:|---:|---:|']
    header.insert(4,'Original stereo definition complete: '+', '.join(f'{m} {g["original_stereo_complete"]}/32' for m,g in groups.items())+'.')
    header.insert(5,'')
    for m,p in paired.items():
        if m!='A':header.append(f'|{m}|{len(p["HQ_wins"])}|{len(p["HQ_losses"])}|{p["exact_mcnemar_p"]:.6g}|')
    header+=['','P values are descriptive, unadjusted across six contrasts and correlated pockets; no independent confirmatory claim. D changes predicted chemistry, so its contrast is not an isolated denoising effect. E holds fixed chemistry and 24 extra NFE; it does not isolate freezing itself.',
             '', 'Geometry MAE in this study uses saved network reference geometry. Frozen HQ geometry instead uses its existing RDKit bounds/amide checks. These targets are explicitly separate. Protein collision counts use protein atoms only; cofactors remain in full PB and QC diagnostic outputs. Contacts are heavy-atom protein pairs within 4.5 Å.',
             '', 'Collision columns and trajectories use the original frozen predicted graph and unrounded network coordinates. HQ_derived_* columns use the serialized coordinate-derived QC graph. Stereo-sensitive RDKit bounds can differ: 9RT3_41005/C_official_new has1 original-graph severe pair versus5 derived-QC severe pairs at identical serialized coordinates. No threshold or endpoint was changed; see QUALITY_GRAPH_SCOPE_AUDIT.json. Original-stereo HQ applies the historical original-declaration gates to the frozen QC, without claiming network stereo prediction.',
             '', 'Full raw quality, errors, unavailable checks, path files and failures are retained under main/.']
    write('TWO_STAGE_RESULTS.md',header)
    audit=load(OUT/'audit/graph_audit.json');runtime=load(OUT/'audit/runtime_gate.json');observed=load(OUT/'analysis/observed_edge_audit.json')
    nconn=sum(len(r['connections']) for r in audit['rows']);fixtures=', '.join(f['name'] for f in audit['fixtures'])
    noncanonical=load(OUT/'audit/noncanonical_cuts.json')
    write('GRAPH_EQUIVALENCE_AUDIT.md',['# Graph equivalence audit','',
        f'All {audit["saved_cases"]} saved final graphs pass exact tensor comparison with fresh official annotation for the same predicted chemistry, saved reference and prescribed fragment cuts; {nconn} connection references pass anchor/dummy uniqueness checks.',
        '', 'This verifies official graph construction conditional on the prescribed partition. It does not claim those partitions equal canonical torsional selection or all graphs lie within the pretraining distribution. The adapter changes cut selection only; official annotation and graph-processing functions remain unchanged.',
        '',f'Synthetic ETKDG-only fixtures supported: {fixtures}. Single/double/triple connections, aromatic fragments, tiny/symmetric fragments, multi-link rings and incomplete stereo are explicitly exercised. Representability does not establish learned support for free rigid rotations across double/triple/ring connections.',
        '', 'Each actual connection has bidirectional ligand_torsional_bond edges. Two real-to-dummy chemistry edges carry bond order. Boundary/triangulation/anchor-dummy attrs are zero as in the official implementation; their geometry is encoded through reference positions. Both port lengths equal the saved unbound reference distance, never the stage-one terminal distance.',
        '', 'The official reference-distance encoder compares pos_t with pos_0 for boundary edges. The latter comes from ref_pos after pocket subtraction and the original 2.7 Å scale. No crystal pose or new energy minimization supplies these references.',
        '', 'RDKit serialization omits private fragmentation_mapping properties. Saved public tensors were therefore compared individually; fresh mappings were checked against explicit cuts and both port coordinate mappings. This is not treated as a chemistry failure.',
        '',f'Runtime state audit: {runtime["states"]} final/early-freeze states recovered within 0.0002 Å, plus nine synthetic single-step cases. Actual forward-edge audit: {len(observed["rows"])} post-mask inputs match static typed edges; masked-node edges are absent, protein spatial edges satisfy the current 4 Å cutoff.',
        '', 'The checkpoint sets ligand_ligand_interactions=False and cutoff_fragment_interactions=-1. inter_fragments is absent by design, not accidentally omitted by the adapter. Its removal is a no-op sensitivity control, not a usable causal ablation. inter_complex and connection auxiliaries are retained and updated according to the official configuration.',
        '',f'Noncanonical predicted cut placement: {len(noncanonical)} final pressure graphs ({", ".join(r["key"] for r in noncanonical)}), including one cross-fragment double bond. Their explicit-cut features and actual port reference distances pass; canonical torsional selection would not choose those cuts. This is a partition/pretraining-distribution limitation, not an absent edge or fabricated distance. They remain in32; no learned support for these cuts is inferred.',
        '', 'Observed per-step edge index/entity and immutable input features are available; edge_attr was not independently serialized at every forward. See audit/, analysis/OBSERVED_MODEL_EDGES.csv and source/audit_graphs.py. Unsupported saved graphs: 0/38; unsupported synthetic fixtures: 0/9.'])
    write('DYNAMIC_TO_FIXED_TRANSITION.md',['# Dynamic-to-fixed state transition','',
        'A is read from dynamic_update_rigid_projection/{development/b6,full32/b32}/structures/*_Baseline/trajectory/step_23.npz. The exact predicted spec/context and unbound reference are taken from the audited 1905 saved case. No conformer is regenerated. Official initial-state construction recreates pos_0, T0 and R0; saved C/Q restore the physical final pose before any noise.',
        '', 'The state recovery gate verifies all 38 endpoints and three early freeze points. Internal distances, proper rotations and ordered chemistry stay fixed throughout B/C/E. Trace files retain fragment forces/torques, original pseudoforces, C/Q before/after and deterministic shadow coordinates.',
        '', 'C_replay preserves the historical step0 current-state chart explicitly. The first implementation used an algebraically equivalent reference chart, which failed full32 historical tolerance in four cases. A controlled run of unchanged1905 runtime reproduced all32×24 states bitwise; only C_replay step0 was corrected and its precheck/formal path repeated. All superseded results, prior source/freeze hashes and the diagnostic control remain local. Other branch outputs and all selected parameters stayed fixed.',
        '', 'B/E call the official forward_marginal on normalized fragment centers and proper rotations. R3 uses the official VP attenuation/variance; SO3 samples IGSO3 and left-multiplies the original rotation. Forward noise and reverse noise use independent purpose-keyed streams. t=0 is an explicit no-op boundary, not an evaluation of a singular translation score or a nonzero-minimum-sigma SO3 kernel.',
        '', 'C_replay restores the saved historical final-graph initialization, including fragment coordinate charts. Official C branches call sample_ref with original seed and seed+214200000. They are reported separately without choosing a favorable draw. Every stage-two fragment can move.',
        '', 'D restores the saved prefix before the first t≤threshold and reconstructs its last accepted graph directly from saved per-fragment reference coordinates. Later updates never execute. At the frozen 0.2 threshold it resumes at step13 and executes 11 remaining forwards; the reused prefix contributes13 logical NFE.',
        '', 'No identity classifier, connection model, true ligand identity/topology/pose, projection or force-field optimizer is called by stage-two sampling. Existing ligand-defined pocket conditioning is inherited; no reference docking-accuracy conclusion is made. Diagnostic evaluator minimizations operate on copies and are never used as outputs.',
        '', 'Initial development diagnostic scope was corrected before selection; then a missing deterministic-kernel setting was identified in precheck. Superseded runs remain under superseded_nondeterministic/ and interrupted_development/. The corrected run uses deterministic Torch kernels, CUBLAS_WORKSPACE_CONFIG=:4096:8, TF32 disabled and unchanged historical FP64 contraction accumulation with FP32 weights. Selection and precheck are rerun before formal sampling.'])
    force=['# Pseudoforce and rigid-motion direction audit','',
        'Rows aggregate observations of pairs that are severe immediately before a step. Repeated observations of one pair are not independent samples. Molecular pairs exclude bonds and use the exact frozen local DG / nonlocal vdW thresholds; protein pairs use the frozen protein-only threshold.',
        '', '|Method|Internal outward pseudo-force fraction|Protein outward fraction|Old internal relieved/worsened|Internal removed/new|Protein removed/new|',
        '|---|---:|---:|---:|---:|---:|']
    for s in summaries:force.append(f'|{s["method"]}|{s["force_outward_internal_fraction"]:.3f}|{s["force_outward_protein_fraction"]:.3f}|{s["actual_internal_relieved"]}/{s["actual_internal_worsened"]}|{s["actual_internal_removed"]}/{s["actual_internal_new"]}|{s["actual_protein_removed"]}/{s["actual_protein_new"]}|')
    force+=['', 'Pseudo-force projection is (F_i−F_j) dotted with the pair separation unit vector, with protein fixed. It is not an atomic displacement or physical force: helper-node forces and torques also enter rigid mechanics, and the reverse kernel adds drift and possibly stochastic motion.',
            '', 'Every actual step is paired with a noise_scale=0 shadow update using the same predicted scores and no extra network forward. The selected formal scale is0, so actual and deterministic rigid motions should match. Translation/rotation changes and cross-bond error improvement are saved per step. Force norms alone cannot establish clash recovery.',
            '', '## Collision origins','']
    events=load(OUT/'analysis/event_collision_origins.json');accepted=[e for e in events if e['accepted']]
    force+=[f'Historical update inventory: {len(accepted)} accepted, {len(events)-len(accepted)} rejected, all retained. Among unchanged semantic atoms and unchanged pair eligibility, newly severe pairs={sum(e["unchanged_pair_new_severe"] for e in accepted)}, removed={sum(e["unchanged_pair_removed_severe"] for e in accepted)}. New-identity severe pairs={sum(e["new_identity_pair_severe"] for e in accepted)} are recorded separately. They are not assigned continuous distance deltas across different atoms.',
            '', 'Second-stage noise sources are separated in analysis/initial_resampling.json; per-step new/removed collisions are in PER_STEP_COLLISION_TRAJECTORY.csv. C initialization is not described as a continuous displacement of historical random atoms.',
            '', '## Read-only edge sensitivity','', 'Two predeclared precheck cases × B/C_official_seed are compared at identical initial state/time. Auxiliary, inter_fragments and inter_complex edge removals affect only diagnostic forwards, never saved paths or quality endpoints. inter_fragments is absent from the checkpoint and has zero active edges. Full force and deterministic-coordinate sensitivity is in audit/edge_sensitivity.json. These are sensitivity measurements, not causal quality effects.']
    write('PSEUDOFORCE_DIRECTION_AUDIT.md',force)
    drift=['# Pose drift and protein contacts','', 'Distances are unaligned heavy-atom distances to the paired stage-one endpoint, not crystal RMSD. Contact retention counts identical ligand-atom/protein-atom pairs within4.5 Å.','',
           '|Method|Mean RMSD Å|Mean max displacement Å|Mean contact retention|In pocket /32|Changed chemistry /32|', '|---|---:|---:|---:|---:|---:|']
    for m,v in by.items():
        contact=groups[m]['contact_retention'];ct=f'{contact:.3f}' if contact is not None else 'unavailable'
        drift.append(f'|{m}|{groups[m]["RMSD_A"]:.3f}|{mean(v,"max_atom_displacement_A"):.3f}|{ct}|{groups[m]["in_pocket"]}|{groups[m]["graph_changed"]}|')
    drift+=['',f'D comparisons use only unchanged identity/local atom mapping: {groups["D"]["mapped_RMSD_available_cases"]}/32 cases, {groups["D"]["mapped_atom_count"]} mapped atoms, mean per-molecule coverage {groups["D"]["mapping_coverage"]:.2%}. Its average describes that small mapped subset, not full-molecule drift. Contact retention is unavailable across changed chemistry rather than assigning false atom correspondences. Full C can move substantially because it reinitializes every fragment. HQ improvement alone cannot show improved docking or retained biological contacts.']
    write('POSE_DRIFT_AND_CONTACTS.md',drift)
    cost=['# Compute budget comparison','', 'Logical NFE counts per-molecule network applications. Actual GPU forwards count batched invocations. Historical first-pass cost is retained conceptually but is not charged as newly executed GPU work.','',
          '|Method|Total logical NFE/sample|New formal NFE/sample|Actual batched forwards|Full32 path wall s|', '|---|---:|---:|---:|---:|']
    cost.append('|A|24|0|0|reused|')
    for m in METHODS[1:]:
        p=perf[m];cost.append(f'|{m}|{groups[m]["logical_NFE"]}|{p["sample_NFE"]}|{p["calls"]}|{p["shared_batch_wall_seconds"]:.3f}|')
    newnfe=sum(p['sample_NFE'] for p in performance)
    cost+=['',f'New formal sample NFE: {newnfe}; deterministic shadow updates consume no additional network calls. Edge-sensitivity forwards and synthetic acceptance forwards are diagnostic overhead, separate from formal method budgets.',
           '', 'Wall times synchronize CUDA and include graph work, metric calculation and evidence I/O. They measure A100 occupation under the recorded implementation, not pure kernel time or optimized sampler throughput. CPU evaluator elapsed seconds are preserved per record; these are wall durations, not process CPU-seconds, and include diagnostic MMFF/PoseBusters calculations on copies. None of those diagnostic coordinates are sampled outputs.',
           '', 'Superseded development/prechecks and the interrupted 84 sample NFE are retained and excluded from method quality denominators, but must be counted as research overhead. Historical stage-one and 1905/2058 MMFF costs come from different run scopes/hardware paths; no strict end-to-end speedup claim is supported.',
           '', 'Historical dynamic Baseline posthoc MMFF HQ=28/32 is an external reference only. The 2058 amide refinement HQ=23/32 starts from a different fixed-graph neural baseline. Neither is a new B/C/D/E output. A separate matched cost study is needed for deployment efficiency.']
    cost += ['', f'The six retained formal paths total {sum(p["calls"] for p in perf.values())} batched forwards and {sum(p["shared_batch_wall_seconds"] for p in perf.values()):.3f} synchronized path-wall seconds. Summed evaluator elapsed time across all224 formal records is {sum(r["full_quality"]["seconds"] for r in rows):.3f} s; this is cumulative record time and may include reused A evaluations, rather than a fresh end-to-end duration.']
    accounting=load(OUT/'analysis/RESEARCH_COMPUTE_ACCOUNTING.json')
    cost += ['', '## Persisted research overhead', '', '|Phase|Sample NFE|Batched forwards|Path wall s|Summed evaluator elapsed s|', '|---|---:|---:|---:|---:|']
    for phase,v in sorted(accounting['phases'].items()):
        cost.append(f'|{phase}|{v["saved_sample_NFE"]}|{v["unique_batched_calls"]}|{v["unique_batch_wall_seconds"]:.3f}|{v["quality_CPU_seconds"]:.3f}|')
    cost += ['', f'Additional persisted work: interrupted development {accounting["interrupted_saved_sample_NFE"]} sample NFE; unchanged historical-runtime control768 sample NFE /24 batched forwards; synthetic acceptance9 sample NFE; edge sensitivity16 sample NFE. These diagnostics and superseded paths are not quality-denominator additions. Some diagnostics have no separately timed boundary, so a complete CPU/GPU end-to-end total is unavailable. See analysis/RESEARCH_COMPUTE_ACCOUNTING.json.']
    write('COMPUTE_BUDGET_COMPARISON.md',cost)
    # Decision answers generated from observed paired counts; no formal-data parameter selection.
    best=max(METHODS[1:],key=lambda m:groups[m]['HQ']);b=groups['B'];a=groups['A'];d=groups['D']
    decision=['# Next-step decision','',
       f'1. Fixed-graph local second pass: B HQ={b["HQ"]}/32 versus A={a["HQ"]}/32, paired wins/losses={len(paired["B"]["HQ_wins"])}/{len(paired["B"]["HQ_losses"])}, descriptive exact p={paired["B"]["exact_mcnemar_p"]:.6g}. Do not extrapolate from this repeatedly inspected pressure set.',
       f'2. Collision recovery: B mean internal/protein severe pairs={b["mean_internal_pairs"]:.3f}/{b["mean_protein_pairs"]:.3f}, A={a["mean_internal_pairs"]:.3f}/{a["mean_protein_pairs"]:.3f}. Inspect both new and removed pair counts, not only HQ.',
       f'3. Local versus full resampling: B={b["HQ"]}/32; C_replay={groups["C_replay"]["HQ"]}/32, C_official_seed={groups["C_official_seed"]["HQ"]}/32, C_official_new={groups["C_official_new"]["HQ"]}/32; E={groups["E"]["HQ"]}/32. No per-molecule best-of-N selection was used.',
       f'4. Early freezing: D={d["HQ"]}/32 at24 logical NFE, with changed chemistry in {d["graph_changed"]}/32 cases; B/C/E each cost48. This is an engineering tradeoff, not a fixed-chemistry causal comparison.',
       '5. Pseudoforces and torque: see the paired same-input directional projections, deterministic rigid shadows and actual pair-distance changes. Outward force does not imply outward rigid displacement, and neither guarantees final HQ.',
       '6. Input representation: saved chemistry/dummy references and actual masked auxiliary edges pass their audits. inter_fragments is unavailable in this checkpoint by design. Additive edge encoders would require a separate architecture/training study, not silently enabling missing weights.',
       f'7. Pose retention: B mean drift={b["RMSD_A"]:.3f} Å; C/E and contact changes are reported separately. This study contains no crystal pose accuracy validation.',
       '8. Efficiency: this run records synchronized A100 path wall time and NFE; historic CPU MMFF timing has different scopes. It does not establish that an extra neural pass is cheaper than terminal MMFF.',
       '9. Framework implication: two-stage dynamic topology plus stable-graph recovery is testable, but favorable pressure-test counts alone do not justify a new training run. First confirm on untouched pockets/seeds under the frozen protocol.',
       '10. Failure attribution: graph construction is audited, but out-of-training-distribution graph partitions and treating the .005 terminal state as a clean proxy remain limitations. Absent direct learned ligand-ligand spatial edges is a concrete checkpoint restriction. The present comparisons cannot uniquely separate input distribution mismatch from learned score capacity.',
       '', 'Recommended next action is an independent confirmatory cohort with the already frozen B/D settings and complete original-stereo reporting, before model/weight changes. Keep the historical MMFF route separate as an engineering reference.']
    write('NEXT_STEP_DECISION.md',decision)
    plot(trajectories,initial,groups)
    write('README.md',['# Two-stage fixed-graph re-denoising','',
        'Entry point: TWO_STAGE_RESULTS.md. Protocol: TWO_STAGE_PROTOCOL.md. Decisions and ten requested answers: NEXT_STEP_DECISION.md. Raw paired/step metrics are the two root CSVs. Detailed paths, traces and full QC stay local.',
        '', 'Reproduce with the recorded scientific Python environment and source/driver.py --stage all. Run tests with python -m pytest -q tests/. GPU execution needs NVIDIA device access and CUBLAS_WORKSPACE_CONFIG=:4096:8. Immutable run configuration and source hashes are in frozen_run.json; all historical inputs/weights are checked against frozen_historical_inputs.json.',
        '', 'This is an analysis of32 reused pressure cases, not an independent de novo or docking generalization benchmark. No training or external sampling repair occurred. GitHub publication has not been requested for this study.'])
    print('REPORTS WRITTEN',groups,flush=True)


def plot(rows,initial,groups):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for ax,metric,title in zip(axes,['severe_internal_pairs','severe_protein_pairs'],['Severe internal nonbonded pairs','Severe protein pairs']):
        for method in METHODS[1:]:
            vals=[r for r in rows if r['method']==method];steps=sorted({r['step'] for r in vals})
            y=[float(np.mean([r['after_resampling'][metric] for r in initial if r['method']==method]))]
            y +=[float(np.mean([r[metric] for r in vals if r['step']==s])) for s in steps]
            ax.plot(np.linspace(0,1,len(y)),y,label=method)
        ax.axhline(groups['A']['mean_internal_pairs' if metric=='severe_internal_pairs' else 'mean_protein_pairs'],ls='--',c='k',lw=1,label='A endpoint')
        ax.set(xlabel='Fraction of remaining reverse steps (different time ranges)',ylabel='Mean pairs / molecule',title=title)
        ax.grid(alpha=.2)
    axes[1].legend(fontsize=7);fig.tight_layout();fig.savefig(OUT/'COLLISION_TRAJECTORIES.png',dpi=180);fig.savefig(OUT/'COLLISION_TRAJECTORIES.pdf');plt.close(fig)

if __name__=='__main__':main()
