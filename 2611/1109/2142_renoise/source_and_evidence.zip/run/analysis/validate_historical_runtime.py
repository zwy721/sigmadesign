"""Controlled historical-runtime replay; original saved targets never overwritten."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import importlib.util,torch,time
from runtime import xyz,grid
from driver import state_for
from inputs import key,FIXED
from run_validation import load_official
from stable_precision import install


def main():
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8');torch.set_num_threads(2);torch.cuda.set_device(0)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.use_deterministic_algorithms(True)
    den=load_official(bootstrap.CHECKPOINT,OUT/'cache','cuda:0');install(den)
    spec=importlib.util.spec_from_file_location('historical_runtime',FIXED/'source/runtime.py');legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
    rows=load(OUT/'protocol.json')['main_cases'];states=[];cases=[];infos=[];g=grid()
    dest=OUT/'historical_runtime_validation';dest.mkdir(exist_ok=True)
    for r in rows:
        c,s,_,initial,info=state_for(r,'C_replay',den);states.append(s);cases.append(c);infos.append(info)
    eng=legacy.BatchEngine(den);start=time.perf_counter();errors=[]
    for step,t in enumerate(g[:-1]):
        trace={};eng.step(states,t,t-g[step+1],trace=trace)
        for i,(r,s) in enumerate(zip(rows,states)):
            folder=dest/key(r);folder.mkdir(exist_ok=True);(folder/'trajectory').mkdir(exist_ok=True)
            np.savez_compressed(folder/'trajectory'/f'step_{step:02d}.npz',xyz=xyz(s),C=s.C.cpu().numpy(),Q=s.Q.cpu().numpy(),pos=s.pos.cpu().numpy())
            old=np.load(FIXED/'primary32/paths'/f'{key(r)}_A'/'trajectory'/f'step_{step:02d}.npz')['xyz'];d=np.linalg.norm(xyz(s)-old,axis=-1)
            errors.append(dict(key=key(r),step=step,max_delta_A=float(d.max()),RMSD_A=float(np.sqrt(np.mean(d*d)))))
        torch.save(trace,dest/f'batched_trace_{step:02d}.pt')
        print('HISTORICAL CONTROL',step,max(r['max_delta_A'] for r in errors[-32:]),flush=True)
    elapsed=time.perf_counter()-start
    dump(dest/'verification.json',dict(passed=all(e['max_delta_A']<.025 and e['RMSD_A']<.005 for e in errors),
                                     runtime_source=str(FIXED/'source/runtime.py'),runtime_sha256=sha256(FIXED/'source/runtime.py'),
                                     sample_NFE=768,batch_calls=24,wall_seconds=elapsed,rows=errors))

if __name__=='__main__':main()
