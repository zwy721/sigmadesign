"""Document post-freeze evaluation-adapter correction; sampling stays immutable."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import numpy as np
from inputs import read_case,key
from metrics import Metrics
from denovo_quality.io import load_molecule
from denovo_quality.geometry import evaluate_geometry,bounds_matrix


def main():
    r=dict(pid='9RT3',seed=41005);c,_=read_case(r);m=Metrics(c)
    folder=OUT/'main/endpoints'/f'{key(r)}_C_official_new'
    mol,_,_=load_molecule(dict(record_index=0,sdf_path=str(folder/'raw.sdf'),chemistry_spec_path=str(folder/'original_spec.json')))
    derived,_,_=load_molecule(dict(record_index=0,sdf_path=str(folder/'derived.sdf'),chemistry_spec_path=str(folder/'derived_spec.json')))
    x=mol.GetConformer().GetPositions();y=derived.GetConformer().GetPositions();assert np.array_equal(x,y)
    g0,_=evaluate_geometry(mol,m.fids,m.cfg['geometry']);g1,_=evaluate_geometry(derived,m.fids,m.cfg['geometry'])
    b0=bounds_matrix(mol);b1=bounds_matrix(derived);changed=[]
    for i,j in m.pairs:
        if b0[j,i]!=b1[j,i]:changed.append(dict(atoms=[int(i),int(j)],original_lower_A=float(b0[j,i]),derived_lower_A=float(b1[j,i]),distance_A=float(np.linalg.norm(x[i]-x[j]))))
    before=load(OUT/'analysis/frozen_run_before_quality_scope_fix.json');after=load(OUT/'frozen_run.json')
    q=str(OUT/'source/quality.py')
    for f,digest in before['source_sha256'].items():
        if f!=q:assert sha256(f)==digest
    result=dict(reason='Original frozen graph vs coordinate-derived QC stereo can change RDKit local lower bounds.',
                case=key(r),method='C_official_new',original_graph_serialized_severe_internal=g0['severe_internal_clash_pairs'],
                derived_graph_serialized_severe_internal=g1['severe_internal_clash_pairs'],serialized_coordinates_identical=True,
                changed_lower_bounds=changed,sampling_sources_unchanged=True,primary_quality_thresholds_unchanged=True,
                development_selection_unchanged=sha256(OUT/'development_selection.json')==before['development_selection_sha256'],
                previous_quality_adapter_sha256=before['source_sha256'][q],new_quality_adapter_sha256=sha256(q),
                only_adapter_diagnostic_assertion_removed=True,formal_trajectories_rerun=False,
                existing_quality_results_modified=False)
    assert result['original_graph_serialized_severe_internal']==1 and result['derived_graph_serialized_severe_internal']==5
    after['source_sha256'][q]=sha256(q)
    dump(OUT/'frozen_run.json',after);dump(OUT/'QUALITY_GRAPH_SCOPE_AUDIT.json',result)
    print(result,flush=True)

if __name__=='__main__':main()
