"""Independent endpoint, graph, cost, denominator and provenance verification."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import collections,torch
from rdkit import Chem
from inputs import read_case,key,graph_hash,chemistry_hash,source
from metrics import Metrics
from denovo_quality.io import load_molecule
from denovo_quality.chemistry import evaluate_chemistry
from denovo_quality.geometry import evaluate_geometry
from denovo_quality.protein import evaluate_protein
from denovo_quality.common import conjunction


def main():
    rows=load(OUT/'formal_results.json');selection=load(OUT/'development_selection.json')['selected'];frozen=load(OUT/'frozen_run.json')
    assert len(rows)==224
    cfg=load(OUT/'quality_config.json');cases=load(OUT/'protocol.json')['main_cases'];expected={key(r) for r in cases};checks=[];failures=[];scope_differences=[]
    for method,items in __import__('itertools').groupby(sorted(rows,key=lambda r:r['method']),key=lambda r:r['method']):
        items=list(items);assert len(items)==32 and {key(r) for r in items}==expected
        for r in items:
            c,v=read_case(r,False,selection['freeze'] if method=='D' else None)
            if method=='A':x=v['xyz']
            else:
                folder=OUT/'main/paths'/f'{key(r)}_{method}';end=torch.load(folder/'endpoint.pt',weights_only=False,map_location='cpu');x=end['xyz']
                assert graph_hash(end['spec'])==graph_hash(c['spec'])==r['graph_hash']
                tr=load(folder/'trajectory.json');assert all(t['graph_hash']==r['graph_hash'] and t['N']==c['N'] for t in tr)
                path=load(folder/'path.json')
                for kind in ['internal','protein']:
                    expected_count=path['info']['after_resampling'][f'severe_{kind}_pairs']
                    expected_count+=sum(t[f'actual_{kind}_new']-t[f'actual_{kind}_removed'] for t in tr)
                    assert expected_count==r[f'severe_{kind}_pairs'],('collision pair conservation',method,key(r),kind)
                for f in sorted((folder/'trajectory').glob('trace_*.pt')):
                    trace=torch.load(f,weights_only=False,map_location='cpu');step=int(f.stem.split('_')[-1]);actual=np.load(folder/'trajectory'/f'step_{step:02d}.npz')['xyz']
                    if selection['noise_scale']==0. or method=='D':assert np.array_equal(actual,trace['deterministic_xyz'])
                # Internal pairwise distances match the frozen saved reference shape.
                ref=Chem.Mol(c['graph'].mol_info['original']).GetConformer().GetPositions()
                drift=max(float(np.abs(np.linalg.norm(x[g][:,None]-x[g][None,:],axis=-1)-np.linalg.norm(ref[g][:,None]-ref[g][None,:],axis=-1)).max()) for g in c['groups'])
                assert drift<.0002
            m=Metrics(c);snapshot=m.snapshot(x)
            assert all(snapshot[k]==r[k] for k in snapshot),('endpoint diagnostic',method,key(r))
            q=r['full_quality'];assert q['input_unchanged']
            folder=Path(r['folder'])
            derived,info,_=load_molecule(dict(record_index=0,sdf_path=str(folder/'derived.sdf'),chemistry_spec_path=str(folder/'derived_spec.json')))
            gd,_=evaluate_geometry(derived,m.fids,cfg['geometry']);pd,_=evaluate_protein(derived,c['context']['pdb_path'],cfg['protein'])
            assert gd['severe_internal_clash_pairs']==q['modules']['geometry']['severe_internal_clash_pairs']
            assert pd['severe_clash_pairs']==q['modules']['protein']['severe_clash_pairs']
            if r['severe_internal_pairs']!=gd['severe_internal_clash_pairs'] or r['severe_protein_pairs']!=pd['severe_clash_pairs']:
                scope_differences.append(dict(key=key(r),method=method,original_graph_raw_internal=r['severe_internal_pairs'],
                                             derived_graph_serialized_internal=gd['severe_internal_clash_pairs'],original_graph_raw_protein=r['severe_protein_pairs'],
                                             derived_graph_serialized_protein=pd['severe_clash_pairs']))
            assert r['HQ_no_water']==conjunction(q['checks'].get(k) for k in cfg['quality']['required_checks'])
            declared=dict(q['checks']);declared.update({k:r['declared_stereo'].get(k) for k in ['stereo_definition_complete','stereo_geometry_consistent']})
            assert r['HQ_original_stereo']==conjunction(declared.get(k) for k in cfg['quality']['required_checks'])
            if method!='D':
                base,_=read_case(r);assert chemistry_hash(c['spec'])==chemistry_hash(base['spec'])
                historical=load(source(r)/'declared_stereo.json')['native_final']['checks']['stereo_definition_complete']
                assert historical==r['original_stereo_complete']
            unavailable=[k for k,vv in q['checks'].items() if vv is None]
            if q['errors'] or unavailable:failures.append(dict(key=key(r),method=method,module_errors=q['errors'],unavailable_checks=unavailable))
            checks.append(dict(key=key(r),method=method,passed=True))
    assert sum(r['HQ_no_water'] is True for r in rows if r['method']=='A')==2
    assert sum(r['PB'] is True for r in rows if r['method']=='A')==3
    if selection['noise_scale']==0.:
        primary=load(ROOT/'fixed_topology_guidance_vs_refinement/summary.json')
        # Direct paired coordinate replay is stronger than aggregate historical HQ equality.
        for r in [r for r in rows if r['method']=='C_replay']:
            old=torch.load(ROOT/'fixed_topology_guidance_vs_refinement/primary32/paths'/f'{key(r)}_A'/'endpoint.pt',weights_only=False,map_location='cpu')['xyz']
            now=torch.load(OUT/'main/paths'/f'{key(r)}_C_replay'/'endpoint.pt',weights_only=False,map_location='cpu')['xyz'];d=np.linalg.norm(now-old,axis=-1)
            assert d.max()<.025 and np.sqrt(np.mean(d*d))<.005
            for step in range(24):
                old_step=np.load(ROOT/'fixed_topology_guidance_vs_refinement/primary32/paths'/f'{key(r)}_A'/'trajectory'/f'step_{step:02d}.npz')['xyz']
                now_step=np.load(OUT/'main/paths'/f'{key(r)}_C_replay'/'trajectory'/f'step_{step:02d}.npz')['xyz']
                assert np.array_equal(old_step,now_step),('C_replay historical bitwise',key(r),step)
    assert sha256(OUT/'quality_config.json')==sha256(ROOT/'fixed_topology_guidance_vs_refinement/quality_config.json')
    assert sha256(OUT/'development_selection.json')==frozen['development_selection_sha256']
    for f,digest in frozen['source_sha256'].items():assert sha256(f)==digest,('Frozen source changed',f)
    historical=load(OUT/'frozen_historical_inputs.json')
    for f,digest in historical.items():assert sha256(f)==digest,('Historical input changed',f)
    assert load(OUT/'precheck8_verification.json')['passed']
    assert load(OUT/'analysis/observed_edge_audit.json')['passed']
    dump(OUT/'failure_cases.json',dict(generation_failures=[],quality_errors_or_unavailable=failures))
    result=dict(passed=True,formal_cases_per_method=32,formal_rows=224,method_count=7,all_endpoint_checks=checks,
                historical_files_unchanged=len(historical),amended_frozen_sources_unchanged=True,
                sampling_sources_unchanged_since_initial_freeze=False,
                historical_C_replay_first_step_fix=load(OUT/'REPLAY_NUMERIC_SCOPE_AUDIT.json'),other_branch_results_preserved=True,
                quality_adapter_postfreeze_diagnostic_fix=load(OUT/'QUALITY_GRAPH_SCOPE_AUDIT.json'),quality_thresholds_unchanged=True,
                baseline_HQ_reproduced=2,baseline_PB_reproduced=3,no_sampling_optimizers_called=True,
                exact_deterministic_shadow_match=True,formal_graph_and_rigidity_passed=True,
                C_replay_all32_all24_historical_bitwise=True,
                unavailable_or_module_error_rows=len(failures),original_vs_derived_collision_scope_differences=scope_differences,
                selected=selection,GitHub_upload_performed=False)
    dump(OUT/'INDEPENDENT_VERIFICATION.json',result)
    print('VERIFIED',len(rows),'historical files',len(historical),flush=True)

if __name__=='__main__':main()
