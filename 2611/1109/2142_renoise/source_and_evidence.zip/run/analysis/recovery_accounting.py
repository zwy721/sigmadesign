"""Research overhead and numerical validation evidence, no result selection."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import collections


def main():
    phases=collections.defaultdict(lambda:dict(saved_sample_NFE=0,completed_paths=0,unique_batched_calls=0,unique_batch_wall_seconds=0.,quality_CPU_seconds=0.))
    seen=set()
    for p in OUT.rglob('path.json'):
        if 'cache' in p.parts:continue
        r=load(p);rel=p.relative_to(OUT);phase='superseded_nondeterministic' if rel.parts[0]=='superseded_nondeterministic' else rel.parts[0]
        v=phases[phase];v['saved_sample_NFE']+=r['new_executed_sample_NFE'];v['completed_paths']+=1
        token=(phase,r['method'],r['shared_batch_wall_seconds'],r['batch_size'])
        if token not in seen:
            seen.add(token);v['unique_batched_calls']+=r['GPU_calls'];v['unique_batch_wall_seconds']+=r['shared_batch_wall_seconds']
    for p in OUT.rglob('quality.json'):
        if p.parent.parent.name!='endpoints':continue
        r=load(p);rel=p.relative_to(OUT);phase='superseded_nondeterministic' if rel.parts[0]=='superseded_nondeterministic' else rel.parts[0]
        phases[phase]['quality_CPU_seconds']+=r['full_quality']['seconds']
    partial=sum(len(list(p.glob('trajectory/trace_*.pt'))) for p in (OUT/'interrupted_development').glob('*'))
    result=dict(phases=dict(phases),interrupted_saved_sample_NFE=partial,
                controlled_historical_runtime=load(OUT/'historical_runtime_validation/verification.json') if (OUT/'historical_runtime_validation/verification.json').exists() else None,
                synthetic_runtime_gate_sample_NFE=9,read_only_edge_sensitivity_sample_NFE=16,
                limitations='Counts are from persisted trace/path boundaries; a forward interrupted before trace flush may add unrecorded compute. Timings are synchronized occupied wall, not kernel-only GPU time.',
                superseded_reason='Protein/cofactor diagnostic scope fixed before selection; deterministic kernels corrected at precheck. Later narrow QC assertion and C_replay step0 corrections are versioned in their scope-audit ledgers; parameters, weights and other formal branch outputs are preserved.')
    dump(OUT/'analysis/RESEARCH_COMPUTE_ACCOUNTING.json',result)
    (OUT/'RECOVERY_NOTES.md').write_text('# Recovery and acceptance notes\n\n'
        'The original diagnostic counter included organic cofactors under the protein label. The frozen full HQ/PB evaluator was always unchanged. The run was interrupted during D development,36 completed B trajectories were retained, and diagnostics were recalculated from their coordinates.84 saved sample NFE from the interrupted D paths remain local.\n\n'
        'The first eight-case B repeat then failed bitwise reproducibility. Exact initialization/noise matched; the first pseudoforce differed by roughly3e-7, consistent with nondeterministic reductions. The driver had omitted the historical deterministic-algorithm flags. No formal run had begun. All affected development/precheck outputs and the old freeze remain under superseded_nondeterministic/.\n\n'
        'The corrected driver enables deterministic Torch algorithms, disables TF32 and sets CUBLAS_WORKSPACE_CONFIG=:4096:8, while retaining the historical stable-precision accumulation and all weights. Development and precheck were rerun, rather than loosening tolerances or choosing favorable repeats. The selected parameters stayed0.2/0/0.2.\n\n'
        'A post-freeze quality-adapter assertion incorrectly equated original predicted-graph collision counts with coordinate-derived stereo QC counts. At9RT3_41005/C_official_new the same serialized coordinates have1 versus5 severe pairs because stereo changes RDKit distance bounds. Only the diagnostic assertion was removed and both scopes retained; frozen thresholds, checks and sampling outputs were unchanged. The original source/freeze and detailed bounds are preserved.\n\n'
        'Full32 C_replay validation found4 cases beyond the historical tolerance, despite the8-case precheck passing. The new reference-chart first transform was algebraically equivalent but rounded differently from the historical current-state transform. Running unchanged1905 runtime reproduced every coordinate of all32x24 saved states bitwise. Only C_replay step0 was corrected to that historical operation order; other branch outputs were retained. Prior C outputs, precheck and freeze snapshots are preserved under superseded_replay_numerics/. No weights, seeds, time grids or development choice changed. C precheck and formal replay were repeated.\n\n'
        'Method costs and all persisted research overhead are separate in analysis/RESEARCH_COMPUTE_ACCOUNTING.json.\n')
    print(result,flush=True)

if __name__=='__main__':main()
