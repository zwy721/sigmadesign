"""Audit edges actually passed through the official model's mask pruning."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import collections,torch
from inputs import read_case,graph_hash
from sigmadock.oracle import HPARAMS


def multiset(edge,types,keep):
    return collections.Counter((int(a),int(b),int(t)) for a,b,t in zip(edge[0,keep],edge[1,keep],types[keep]))


def main():
    rows=[];aux=['ligand_bonds','ligand_torsional_bond','fragment_triangulation','ligand_anchor_dummy']
    auxids=np.array([HPARAMS.get_edge_idx(k) for k in aux]);chosen=load(OUT/'development_selection.json')['selected']
    for folder in sorted((OUT/'main/paths').glob('*')):
        pid,seed,method=folder.name.split('_',2);c,_=read_case(dict(pid=pid,seed=int(seed)),False,chosen['freeze'] if method=='D' else None)
        g=c['graph'];edges=g.edge_index.numpy();types=g.edge_entity.numpy();mask=g.mask.numpy()
        wanted=multiset(edges,types,np.isin(types,auxids)&mask[edges].all(axis=0))
        init=np.load(folder/'initial.npz');initialpos=init['pos'];initialC=init['C'];initialQ=init['Q'];fids=g.frag_idx_map.numpy()
        before=initialpos.copy();lastedges=None
        for step,f in enumerate(sorted((folder/'trajectory').glob('trace_*.pt'))):
            tr=torch.load(f,weights_only=False,map_location='cpu');e=tr['edge_index'].numpy();t=tr['edge_entity'].numpy()
            used=multiset(e,t,np.isin(t,auxids));assert used==wanted,('static typed edges',folder,step,wanted-used,used-wanted)
            assert mask[e].all(),'Masked node edge reached model'
            # Reconstruct actual full-node pose from saved initial chart and latent transforms.
            C=tr['C_before'].numpy();Q=tr['Q_before'].numpy();pos=initialpos.copy()
            for slot in range(c['N']):
                ids=fids==slot;R=Q[slot]@initialQ[slot].T
                pos[ids]=(initialpos[ids]-initialC[slot])@R.T+C[slot]
            inter=t==HPARAMS.get_edge_idx('inter_complex');ll=t==HPARAMS.get_edge_idx('inter_fragments')
            if inter.any():
                distances=np.linalg.norm(pos[e[0,inter]]-pos[e[1,inter]],axis=-1)*HPARAMS.general.dimensional_scale
                assert distances.max()<=4.0002,('spatial cutoff',folder,step,distances.max())
            else:distances=np.array([])
            assert not ll.any(),'Frozen checkpoint has no inter-fragment spatial encoder'
            material=np.vstack([e,t]).astype(np.int64).tobytes();current={(int(a),int(b),int(k)) for a,b,k in zip(*e,t)}
            row=dict(pid=pid,seed=int(seed),method=method,step=step,graph_hash=graph_hash(c['spec']),
                     observed_typed_edge_sha256=hashlib.sha256(material).hexdigest(),
                     effective_edge_counts={name:int((t==idx).sum()) for name,idx in HPARAMS.edge_entity.entity_indices.items()},
                     static_auxiliary_equal=True,masked_edges=0,inter_complex_max_distance_A=float(distances.max()) if len(distances) else None,
                     spatial_edge_set_changed_from_previous=len(current.symmetric_difference(lastedges)) if lastedges is not None else None)
            rows.append(row);lastedges=current
        print('OBSERVED EDGES',folder.name,flush=True)
    assert len(rows)==32*(5*24+11),len(rows)
    dump(OUT/'analysis/observed_edge_audit.json',dict(passed=True,rows=rows,
         observation='Traced post-mask edge index/type plus frozen static input features; edge attributes are not independently snapshotted per step.',
         inter_fragments_absence='checkpoint deliberately disables ligand_ligand_interactions; no new encoder enabled'))
    csvwrite(OUT/'analysis/OBSERVED_MODEL_EDGES.csv',rows)

if __name__=='__main__':main()
