"""Unmodified official forward, mechanics and SE(3) kernels; isolated RNG streams."""
from common import *
import copy,time,contextlib
import torch
from torch_geometric.data import Batch
from joint_sampler import NativeState
from random_frames import attach,replay_frames
from sigmadock.oracle import HPARAMS
SCALE=HPARAMS.general.dimensional_scale


def stream_seed(case,role,step=0):
    material=f'{case["pid"]}|{case["seed"]}|2142|{role}|{step}'
    return int.from_bytes(hashlib.sha256(material.encode()).digest()[:8],'little') % (2**63-1)

@contextlib.contextmanager
def random_stream(seed):
    with torch.random.fork_rng(devices=[0] if torch.cuda.is_available() else []):
        torch.manual_seed(seed)
        if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
        yield


def make_state(case,den,device='cuda:0',C=None,Q=None,step=0):
    with random_stream(stream_seed(case,'unused_constructor')):
        s=NativeState(den,case['graph'],case['groups'],device)
    if C is not None:
        s.C=torch.as_tensor(C,device=device,dtype=s.pos0.dtype).clone()
        s.Q=torch.as_tensor(Q,device=device,dtype=s.pos0.dtype).clone()
        s.pos=den._apply_transformations(s.pos0,s.batch,s.T0,s.R0,s.Q,s.C)
    s.base=s.batch.to_data_list()[0];s.case=case
    return attach(s,case,step)


def xyz(s):return s.physical()[s.pn:s.pn+sum(map(len,s.groups))].copy()


def forward_noise(s,t,role):
    if t==0:return dict(noop=True,seed=None)
    with random_stream(stream_seed(s.case,role)):
        v=s.den.diffuser.forward_marginal(s.C,s.Q,torch.full((len(s.C),),t,device=s.C.device))
    s.C,s.Q=v['T_t'].to(s.C.dtype),v['R_t'].to(s.Q.dtype)
    s.pos=s.den._apply_transformations(s.pos0,s.batch,s.T0,s.R0,s.Q,s.C)
    return dict(noop=False,seed=stream_seed(s.case,role),time=t)


def grid(t=1.,steps=24,device='cuda:0'):
    return (t**(1/3)+torch.arange(steps+1,device=device)/steps*(.005**(1/3)-t**(1/3)))**3


def invariants(s,reference):
    x=xyz(s);q=s.Q.detach().cpu().numpy()
    rigid=max(float(np.abs(np.linalg.norm(x[g][:,None]-x[g][None,:],axis=-1)-d).max()) for g,d in zip(s.groups,reference))
    orth=float(np.abs(q.transpose(0,2,1)@q-np.eye(3)).max());det=float(np.linalg.det(q).min())
    assert np.isfinite(x).all() and rigid<.0002 and orth<.0002 and det>.9998,(rigid,orth,det)
    return dict(internal_distance_delta_A=rigid,rotation_orthogonality_error=orth,minimum_determinant=det)


class Engine:
    def __init__(self,den):self.den=den;self.calls=0;self.timings=[]
    @torch.no_grad()
    def step(self,states,t,dt,noise_scale=0.,role='reverse',ablation=None):
        den=self.den;start=time.perf_counter();batch=Batch.from_data_list([s.base for s in states])
        batch=den._update_batch(batch,torch.cat([s.pos0 for s in states]),torch.cat([s.pos for s in states]))
        if ablation:
            ids=[HPARAMS.get_edge_idx(n) for n in ablation]
            keep=~torch.isin(batch.edge_entity,torch.tensor(ids,device=batch.x.device))
            batch.edge_index=batch.edge_index[:,keep];batch.edge_attr=batch.edge_attr[keep];batch.edge_entity=batch.edge_entity[keep]
        trace={};forward=copy.deepcopy(batch)
        with replay_frames(forward,states,states[0].step_index,trace):
            force,index=den._compute_forces(forward,t.expand(len(states)))
        self.calls+=1;details=[]
        for i,s in enumerate(states):
            s.batch.pos_0=s.pos0;s.batch.pos_t=s.pos
            keep=(index>=batch.ptr[i]) & (index<batch.ptr[i+1]);localindex=index[keep]-batch.ptr[i]
            f=force[keep].float();dynamics=den._compute_fragment_dynamics(s.batch,s.Q,s.R0,s.C,f,localindex)
            ff,tt,mass,inertia=dynamics;updates=den._predict_fragment_updates(*dynamics)
            scores=den._compute_scores(dict(T_t=s.C,R_t=s.Q),updates,t.expand(len(s.C)))
            seed=stream_seed(s.case,role,s.step_index)
            with random_stream(seed):
                c,q=den.diffuser.reverse(s.C,s.Q,scores['pred_T_score'],scores['pred_R_score'],t,dt,noise_scale=noise_scale)
            with random_stream(seed):
                dc,dq=den.diffuser.reverse(s.C,s.Q,scores['pred_T_score'],scores['pred_R_score'],t,dt,noise_scale=0.)
            p=den._apply_transformations(s.pos0,s.batch,s.T0,s.R0,q,c)
            dp=den._apply_transformations(s.pos0,s.batch,s.T0,s.R0,dq,dc)
            edgekeep=(trace['edge_index'][0]>=batch.ptr[i].cpu()) & (trace['edge_index'][0]<batch.ptr[i+1].cpu())
            details.append(dict(pseudoforce=f.cpu(),force_index=localindex.cpu(),fragment_force=ff.cpu(),fragment_torque=tt.cpu(),
                                mass=mass.cpu(),inertia=inertia.cpu(),C_before=s.C.cpu(),Q_before=s.Q.cpu(),C=c.cpu(),Q=q.cpu(),
                                deterministic_xyz=dp[s.pn:s.pn+sum(map(len,s.groups))].cpu().numpy()*SCALE+s.graph.pocket_com.cpu().numpy().reshape(3),
                                edge_index=trace['edge_index'][:,edgekeep]-batch.ptr[i].cpu(),edge_entity=trace['edge_entity'][edgekeep],
                                rng_seed=seed))
            if ablation:continue # force/read-only diagnostic: never advance trajectory
            s.C,s.Q,s.pos=c,q,p;s.step_index+=1
        torch.cuda.synchronize() if torch.cuda.is_available() else None
        self.timings.append(dict(batch=len(states),wall_seconds=time.perf_counter()-start,t=float(t),edges=batch.edge_index.shape[1]))
        return details
