"""Freeze a reviewable local delivery; no Git/GitHub operation."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
from datetime import datetime,timezone

NAMES=['TWO_STAGE_PROTOCOL.md','GRAPH_EQUIVALENCE_AUDIT.md','DYNAMIC_TO_FIXED_TRANSITION.md','TWO_STAGE_RESULTS.md',
       'PER_MOLECULE_RESULTS.csv','PER_STEP_COLLISION_TRAJECTORY.csv','PSEUDOFORCE_DIRECTION_AUDIT.md',
       'POSE_DRIFT_AND_CONTACTS.md','COMPUTE_BUDGET_COMPARISON.md','NEXT_STEP_DECISION.md']


def main():
    assert load(OUT/'INDEPENDENT_VERIFICATION.json')['passed']
    assert all((OUT/n).is_file() and (OUT/n).stat().st_size>0 for n in NAMES)
    frozen=load(OUT/'frozen_run.json')
    assert sha256(OUT/'protocol.json')==frozen['protocol_sha256']
    assert sha256(OUT/'quality_config.json')==frozen['quality_config_sha256']
    assert '9 passed' in (OUT/'logs/final_unit_tests.log').read_text()
    import csv
    with (OUT/'PER_MOLECULE_RESULTS.csv').open(newline='') as f:assert len(list(csv.DictReader(f)))==224
    with (OUT/'PER_STEP_COLLISION_TRAJECTORY.csv').open(newline='') as f:assert len(list(csv.DictReader(f)))==4192
    prior=OUT/'analysis/process_before_completion.json'
    if not prior.exists():dump(prior,load(OUT/'process.json'))
    dump(OUT/'process.json',dict(stage='complete',running=False,checked_UTC=datetime.now(timezone.utc).isoformat(),
          execution_session=36298,execution_exit_code=0,final_sampling_log=str(OUT/'logs/experiment_C_replay_corrected.log'),
          evidence='Foreground final sampling session returned exit0; independent verification and nine unit tests passed.',
          historical_process_record=str(prior)))
    task=ROOT/'2611/1109/2142_renoise'
    for n in NAMES+['README.md','summary.json','INDEPENDENT_VERIFICATION.json','frozen_run.json','failure_cases.json','COLLISION_TRAJECTORIES.png']:
        link=task/n
        if link.is_symlink():assert link.resolve()==OUT/n
        else:assert not link.exists();link.symlink_to(os.path.relpath(OUT/n,task))
    dump(OUT/'status.json',dict(stage='complete',execution_complete=True,UTC=datetime.now(timezone.utc).isoformat(),formal_rows=224,
                               GitHub_upload_performed=False))
    dump(OUT/'DELIVERY_VERIFICATION.json',dict(passed=True,required_deliverables=10,formal_methods=7,cases_per_method=32,
                                              paired_results=224,precheck_passed=True,independent_verification=True,
                                              archive_path=str(task),unit_tests_passed=9,trajectory_rows=4192,
                                              protocol_hash_unchanged=True,quality_config_hash_unchanged=True,
                                              GitHub_upload_performed=False))
    excluded={'ARTIFACT_MANIFEST.json'}
    files={str(p.relative_to(OUT)):dict(sha256=sha256(p),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*'))
           if p.is_file() and p.name not in excluded and 'cache' not in p.parts and '__pycache__' not in p.parts and p.suffix not in ['.log','.pyc']}
    dump(OUT/'ARTIFACT_MANIFEST.json',dict(entries=len(files),files=files,exclusions=['cache/','__pycache__/','*.log (execution outputs still append)','ARTIFACT_MANIFEST.json (self)']))
    assert all(sha256(OUT/f)==v['sha256'] for f,v in files.items())
    print('DELIVERY',len(files),'hashes verified',flush=True)

if __name__=='__main__':main()
