"""Historical collision sources with exact semantic correspondence, read only."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import copy,torch
from rdkit import Chem
from inputs import read_case,source,key,graph_hash
from metrics import Metrics
from oracle_graph import rebuild
from vocab_chemistry import VocabLibrary,assemble_slots,spec_from_slots


def atom_keys(c):
    keys={}
    for f in c['spec']['fragments']:
        for local,atom in enumerate(f['atom_ids']):
            keys[atom]=(f['slot'],f['vocab3684'],local,tuple(sorted(f['atoms'][local].items())))
    return keys


def severe(c,x,m):
    k=atom_keys(c);d,p=m.distances(x)
    out={}
    for pair,dist,limit in zip(m.pairs,d,m.limits):
        if dist<limit:out[('internal',*sorted([k[int(pair[0])],k[int(pair[1])]]))]=float(dist)
    for i,j in np.argwhere(p<m.plimits):out[('protein',k[int(i)],int(j))]=float(p[i,j])
    return out


def main():
    lib=VocabLibrary();rows=[]
    for r in load(OUT/'protocol.json')['main_cases']:
        c,_=read_case(r,False,.6);c=copy.copy(c);src=source(r);rec=load(src/'result.json')
        for e in rec['events']:
            folder=src/f'event_{e["step"]:02d}';v=np.load(folder/'before.npz');n=sum(map(len,c['groups']));pn=int((c['graph'].frag_idx_map==-1).sum());before=v['xyz'][pn:pn+n]
            m0=Metrics(c);pre=severe(c,before,m0)
            row=dict(key=key(r),step=e['step'],accepted=e['accepted'],before=m0.snapshot(before))
            if not e['accepted']:
                row.update(reason=e.get('reason'),retained_original_state=True);rows.append(row);continue
            mol,groups,cuts=assemble_slots(lib,e['proposed_labels'],e['proposed_connections'],oov=[None]*c['N']);conf=Chem.Conformer(mol.GetNumAtoms())
            for g,a in zip(groups,e['reference_transfer_orientation']):
                for i,x in zip(g,a['source_reference_coordinates']):conf.SetAtomPosition(int(i),list(x))
            mol.RemoveAllConformers();mol.AddConformer(conf)
            spec=spec_from_slots(mol,groups,cuts,e['proposed_labels'],'historical saved event reference; no embedding')
            new=dict(c,spec=spec,groups=groups,graph=rebuild(spec,**c['context']),labels=e['proposed_labels'],connections=e['proposed_connections'])
            after=np.load(folder/'proposal_transfer.npz')['actual_xyz'];m1=Metrics(new);post=severe(new,after,m1)
            oldkeys=atom_keys(c);newkeys=atom_keys(new);old_atoms=set(oldkeys.values());new_atoms=set(newkeys.values());common=old_atoms & new_atoms
            def comparable(k):return k[1] in common and (k[0]=='protein' or k[2] in common)
            pre_common={k:v for k,v in pre.items() if comparable(k)};post_common={k:v for k,v in post.items() if comparable(k)}
            # Identical semantic atoms can cease to be nonbonded when topology changes.
            # Track pair eligibility separately, not a fictitious geometric removal.
            allpre=set(('internal',*sorted([oldkeys[int(i)],oldkeys[int(j)]])) for i,j in m0.pairs)
            allpost=set(('internal',*sorted([newkeys[int(i)],newkeys[int(j)]])) for i,j in m1.pairs)
            eligible=(allpre & allpost)|set(k for k in set(pre_common)|set(post_common) if k[0]=='protein')
            pre_shared={k:v for k,v in pre_common.items() if k in eligible};post_shared={k:v for k,v in post_common.items() if k in eligible}
            row.update(after=m1.snapshot(after),unchanged_semantic_atoms=len(common),old_atoms=len(old_atoms),new_atoms=len(new_atoms),
                       unchanged_pair_new_severe=len(set(post_shared)-set(pre_shared)),unchanged_pair_removed_severe=len(set(pre_shared)-set(post_shared)),
                       new_identity_pair_severe=sum(not comparable(k) for k in post),retired_identity_pair_severe=sum(not comparable(k) for k in pre),
                       topology_eligibility_changed_old_severe=sum(k not in eligible for k in pre_common),
                       topology_eligibility_changed_new_severe=sum(k not in eligible for k in post_common))
            rows.append(row);c=new
        print('EVENT SOURCES',key(r),flush=True)
    dump(OUT/'analysis/event_collision_origins.json',rows);csvwrite(OUT/'analysis/EVENT_COLLISION_ORIGINS.csv',rows)

if __name__=='__main__':main()
