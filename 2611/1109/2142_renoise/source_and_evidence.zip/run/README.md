# Two-stage fixed-graph re-denoising

Entry point: TWO_STAGE_RESULTS.md. Protocol: TWO_STAGE_PROTOCOL.md. Decisions and ten requested answers: NEXT_STEP_DECISION.md. Raw paired/step metrics are the two root CSVs. Detailed paths, traces and full QC stay local.

Reproduce with the recorded scientific Python environment and source/driver.py --stage all. Run tests with python -m pytest -q tests/. GPU execution needs NVIDIA device access and CUBLAS_WORKSPACE_CONFIG=:4096:8. Immutable run configuration and source hashes are in frozen_run.json; all historical inputs/weights are checked against frozen_historical_inputs.json.

This is an analysis of32 reused pressure cases, not an independent de novo or docking generalization benchmark. No training or external sampling repair occurred. GitHub publication has not been requested for this study.
