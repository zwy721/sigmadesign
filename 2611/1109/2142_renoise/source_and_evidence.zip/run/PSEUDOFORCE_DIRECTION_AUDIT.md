# Pseudoforce and rigid-motion direction audit

Rows aggregate observations of pairs that are severe immediately before a step. Repeated observations of one pair are not independent samples. Molecular pairs exclude bonds and use the exact frozen local DG / nonlocal vdW thresholds; protein pairs use the frozen protein-only threshold.

|Method|Internal outward pseudo-force fraction|Protein outward fraction|Old internal relieved/worsened|Internal removed/new|Protein removed/new|
|---|---:|---:|---:|---:|---:|
|B|0.623|0.861|1661/545|477/188|563/65|
|C_replay|0.346|0.691|19332/9370|4820/4597|1590/521|
|C_official_seed|0.351|0.680|18724/9186|4771/4676|2051/923|
|C_official_new|0.341|0.710|19616/9823|4947/4792|1481/437|
|D|0.729|0.789|1942/272|857/77|91/51|
|E|0.351|0.684|19283/9686|4898/4634|1446/429|

Pseudo-force projection is (F_i−F_j) dotted with the pair separation unit vector, with protein fixed. It is not an atomic displacement or physical force: helper-node forces and torques also enter rigid mechanics, and the reverse kernel adds drift and possibly stochastic motion.

Every actual step is paired with a noise_scale=0 shadow update using the same predicted scores and no extra network forward. The selected formal scale is0, so actual and deterministic rigid motions should match. Translation/rotation changes and cross-bond error improvement are saved per step. Force norms alone cannot establish clash recovery.

## Collision origins

Historical update inventory: 121 accepted, 7 rejected, all retained. Among unchanged semantic atoms and unchanged pair eligibility, newly severe pairs=1, removed=0. New-identity severe pairs=6116 are recorded separately. They are not assigned continuous distance deltas across different atoms.

Second-stage noise sources are separated in analysis/initial_resampling.json; per-step new/removed collisions are in PER_STEP_COLLISION_TRAJECTORY.csv. C initialization is not described as a continuous displacement of historical random atoms.

## Read-only edge sensitivity

Two predeclared precheck cases × B/C_official_seed are compared at identical initial state/time. Auxiliary, inter_fragments and inter_complex edge removals affect only diagnostic forwards, never saved paths or quality endpoints. inter_fragments is absent from the checkpoint and has zero active edges. Full force and deterministic-coordinate sensitivity is in audit/edge_sensitivity.json. These are sensitivity measurements, not causal quality effects.
