# Two-stage fixed-graph re-denoising protocol

Status: completed. All seven methods retain32 cases (224 paired records). See `INDEPENDENT_VERIFICATION.json`; the preregistered prose is retained in `analysis/protocol_preregistered.md`.

The existing dynamic Baseline provides all 32 paired stage-one outputs, including failures. These are historical pressure cases, not an independent generalization set. The six development cases are `2zwz/4i5p/2wos × 42001/42002`, disjoint by pocket. No training, identity heads, topology search, new reference embedding, external forces, or repair is performed in stage two. Historical preprocessing produced the saved unbound reference geometry; those coordinates are reused unchanged. Crystal ligand identity/topology/pose are not read for graph reconstruction or sampling.

A is the saved dynamic endpoint. B uses official R3 and SO3 forward marginals at 0.2/0.4/0.6, then 24 cubic-spaced reverse steps ending at 0.005. The official rotation marginal left-multiplies an IGSO3 increment; independent Euler noise is never substituted. E follows the same procedure from A at t=1 for the same 24 additional NFE. E compares resampling depth, and cannot isolate the benefit of freezing chemistry.

C comprises historical Gaussian core-center/Haar rotation replay, official `sample_ref` under the original seed, and official `sample_ref` under `seed+214200000`. Official `sample_ref` rotations are IGSO3(t=1), not exactly Haar. There is no best-of-N selection. Historical replay uses the saved 1905 initial runtime state; its historical endpoint is a validation reference when noise_scale=0.

D freezes before the first step with t≤0.6/0.4/0.2 on the original grid. It reuses the exact historical prefix and performs no subsequent chemical update. Its total logical cost is 24 NFE. Compare D chemistry separately. For RMSD, use only unchanged fragment identity and local atom mappings, report coverage, and retain unavailable values.

B parameters are selected on six development cases by: maximum frozen coordinate-derived HQ, minimum total severe protein pairs, minimum mean unaligned RMSD to A, then declared grid order (time 0.2/0.4/0.6, noise 0/1). D uses the same ranking with mapped RMSD, unavailable after finite values. D retains historical noise_scale=0; B/C/E use the development-selected second-stage scale.

The frozen full HQ/PoseBusters evaluator may perform its existing diagnostic energy calculations on copies; these never modify or feed back into sampling endpoints. Both original-declared and coordinate-derived stereo results are reported. t=0 is an explicit application no-op, because the official SO3 kernel has positive minimum sigma. An 8-case repeat/batch1/batch8 gate precedes formal sampling.

## Frozen selection and acceptance

The six-case development selection is B `t_start=0.2`, `noise_scale=0`; D `t_freeze=0.2`. D freezes before step13 and executes the remaining11 forwards, retaining24 total logical NFE. B/C/E retain48 total logical NFE. Parameters were not selected on the32 formal cases. `protocol.json`, `development_selection.json` and their frozen hashes are unchanged.

All38 saved final graphs,152 recovered final/early-freeze states and nine synthetic graph fixtures pass prerequisite gates. Repeat runs are bitwise reproducible. Batch1/batch8 acceptance requires maximum coordinate difference below0.025 Å and RMSD below0.005 Å. The4192 formal model inputs pass the observed-edge audit. C_replay matches every historical coordinate for all32 cases and all24 steps bitwise.

## Recorded implementation corrections

`RECOVERY_NOTES.md` records a protein/cofactor diagnostic correction and deterministic-kernel flags fixed before formal sampling. Two later narrow corrections are versioned: the QC adapter now distinguishes original-graph collision bounds from stereo-derived QC bounds; C_replay step0 now uses the historical floating-point operation order. Superseded outputs, source versions and freeze snapshots are retained. The latter correction reran only C_replay; weights, time grids, seeds, development selection and all other formal branch outputs stayed fixed. See `QUALITY_GRAPH_SCOPE_AUDIT.json` and `REPLAY_NUMERIC_SCOPE_AUDIT.json`.

Original-graph/raw-coordinate collision trajectories and serialized stereo-derived HQ checks are separate evaluation scopes. D RMSD uses unchanged mapped fragments only, available in10/32 cases with mean per-case atom coverage4.29%; it is not a whole-molecule comparison. The checkpoint deliberately has no ligand–ligand spatial encoder. Two prescribed fragment cuts are noncanonical; feature construction passes, but learned support for these partitions is not established.
