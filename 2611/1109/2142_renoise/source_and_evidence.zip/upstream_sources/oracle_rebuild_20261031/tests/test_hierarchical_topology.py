import inspect
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bootstrap
import numpy as np
from rdkit import Chem

from hierarchical_topology import SearchConfig,PrefixChemistry,adjacency_key,option_groups,port_beam,skeleton_beam,stereo_compatible,hierarchical_search
from vocab_chemistry import assemble_slots,canonical


class ToyLibrary:
    def __init__(self,smiles):self.smiles=smiles
    def template(self,label,explicit=None):
        mol=Chem.MolFromSmiles(self.smiles[label]);return mol,np.zeros((mol.GetNumAtoms(),3))
    def sites(self,label,explicit=None):
        mol,_=self.template(label)
        return [dict(anchor_core=a.GetIdx(),capacity_bond_order_units=int(a.GetTotalNumHs()),
            carbon_stub_sanitize_validated_orders=[o for o in (1,2) if a.GetTotalNumHs()>=o]) for a in mol.GetAtoms() if a.GetTotalNumHs()]


def runtime(smiles,labels):
    lib=ToyLibrary(smiles);capacity={};allowed={}
    for i,label in enumerate(labels):
        for s in lib.sites(label):
            capacity[i,s['anchor_core']]=s['capacity_bond_order_units'];allowed[i,s['anchor_core']]=set(s['carbon_stub_sanitize_validated_orders'])
    return SimpleNamespace(lib=lib,labels=labels,oov=[None]*len(labels),capacity=capacity,allowed=allowed)


def e(i,j,a=0,b=0,order=1,score=1.,stereo=0):
    return dict(i=i,j=j,a=a,b=b,order=order,log_odds=score,search_score=score,stereo=stereo)


class HierarchicalSearchTests(unittest.TestCase):
    def test_global_capacity_backtracks_away_from_best_independent_bond(self):
        r=runtime(['C','O'],[0,1,0])
        groups={(0,1):[e(0,1,order=2,score=10),e(0,1,score=7)],(1,2):[e(1,2,score=8)]}
        candidates,audit=port_beam(r,[(0,1),(1,2)],groups,config=SearchConfig(port_width=8))
        self.assertTrue(candidates)
        self.assertEqual([x['order'] for x in candidates[0]['connections']],[1,1])
        self.assertEqual(canonical(assemble_slots(r.lib,r.labels,candidates[0]['connections'])[0],False),'COC')
        self.assertGreater(audit['capacity_rejected']+audit['forward_rejected'],0)

    def test_joint_assignment_preserves_regioisomers_and_collapses_atom_symmetry(self):
        r=runtime(['c1ccccc1','N','O'],[0,1,2]);chem=PrefixChemistry(r)
        ortho=[e(0,1,a=0),e(0,2,a=1)];para=[e(0,1,a=0),e(0,2,a=3)]
        rotated=[e(0,1,a=1),e(0,2,a=2)]
        self.assertNotEqual(chem.key(ortho),chem.key(para))
        self.assertEqual(chem.key(ortho),chem.key(rotated))
        groups={(0,1):[e(0,1,a=a,score=0) for a in range(6)],(0,2):[e(0,2,a=a,score=0) for a in range(6)]}
        candidates,_=port_beam(r,[(0,1),(0,2)],groups,config=SearchConfig(port_width=64))
        self.assertEqual(len({c['constitution'] for c in candidates}),3)

    def test_necessary_ez_conditions_are_expanded_and_validated(self):
        r=runtime(['CC'],[0,0]);pred=dict(pool=[e(0,1,a=1,b=1,order=2)],meta=np.array([[0,1,1,1]]),sp=np.array([[.8,.12,.08]]))
        groups=option_groups(r,pred)
        self.assertEqual({x['stereo'] for x in groups[0,1]},{0,1,2})
        candidates,_=port_beam(r,[(0,1)],groups,config=SearchConfig(port_width=16))
        self.assertEqual(len(candidates),2)
        self.assertEqual({c['connections'][0]['stereo'] for c in candidates},{1,2})
        self.assertNotEqual(candidates[0]['isomeric'],candidates[1]['isomeric'])
        no_ez=runtime(['C'],[0,0])
        options={(0,1):[e(0,1,order=2,stereo=s) for s in range(3)]}
        other,_=port_beam(no_ez,[(0,1)],options)
        self.assertEqual(len(other),1);self.assertEqual(other[0]['connections'][0]['stereo'],0)

    def test_skeleton_stage_does_not_fix_ports_and_obeys_tree_degree_bounds(self):
        r=runtime(['C','F'],[0,1,1,1]);groups={(i,j):[e(i,j)] for i in range(4) for j in range(i+1,4)}
        skeletons=skeleton_beam(r,groups,width=64,count=24)
        self.assertEqual(len(skeletons),1);self.assertEqual(skeletons[0]['pairs'],((0,1),(0,2),(0,3)))
        with self.assertRaises(TypeError):hierarchical_search(r,dict(pool=[]),oracle_edges=[])
        self.assertFalse({'truth','oracle_edges','target_xyz'}&set(inspect.signature(hierarchical_search).parameters))

    def test_complete_molecules_are_deterministic_and_unique_without_targets(self):
        r=runtime(['C','O','N'],[0,1,2]);pred=dict(pool=[e(i,j) for i in range(3) for j in range(i+1,3)])
        cfg=SearchConfig(skeleton_width=16,skeleton_count=8,port_width=16)
        a=hierarchical_search(r,pred,k=8,config=cfg);b=hierarchical_search(r,pred,k=8,config=cfg)
        self.assertEqual(a,b);self.assertFalse(a['truth_used'])
        self.assertEqual(len({c['constitution'] for c in a['candidates']}),len(a['candidates']))
        self.assertGreaterEqual(len({adjacency_key(c['connections']) for c in a['candidates']}),2)
        poisoned=dict(pred,oracle_edges=[dict(i=999)],target_xyz=[float('nan')],target_mol='forbidden')
        self.assertEqual(a,hierarchical_search(r,poisoned,k=8,config=cfg))

    def test_equal_budget_never_duplicates_short_candidate_pools(self):
        from evaluate_hierarchical_experiment import matched_prefixes
        methods=dict(ordinary=['a','b'],hierarchical=['c','d','e','f'])
        self.assertEqual(matched_prefixes(methods,8),dict(ordinary=['a','b'],hierarchical=['c','d']))
        self.assertEqual(matched_prefixes(methods,1),dict(ordinary=['a'],hierarchical=['c']))


if __name__=='__main__':unittest.main()
