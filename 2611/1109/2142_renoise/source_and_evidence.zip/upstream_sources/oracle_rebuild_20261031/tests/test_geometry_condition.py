import copy
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bootstrap
import numpy as np
from rdkit import Chem
from scipy.spatial.transform import Rotation

from geometry_condition_diagnostics import diagnostic_pose,choose_generated,evaluate_condition,rank_metrics
from hierarchical_topology import SearchConfig


class GeometryConditionTests(unittest.TestCase):
    def test_true_pose_fits_exact_known_rigid_frames_and_checks_atom_counts(self):
        xyz=np.array([[0.,0.,0.],[1.,0.,0.],[0.,2.,0.],[0.,0.,3.]])
        library=SimpleNamespace(template=lambda label,explicit:(None,xyz))
        R=Rotation.from_rotvec([.2,-.4,.1]).as_matrix();T=np.array([2.,-3.,9.])
        target=np.concatenate([xyz@R.T+T,xyz+np.array([-4.,3.,1.])])
        pose=diagnostic_pose(library,[0,0],[None,None],target,diagnostic_only=True)
        np.testing.assert_allclose(pose['R'][0],R,atol=1e-10);np.testing.assert_allclose(pose['T'][0],T,atol=1e-10)
        np.testing.assert_allclose(pose['reconstructed'],target,atol=1e-10)
        with self.assertRaisesRegex(ValueError,'atom count'):diagnostic_pose(library,[0,0],[None,None],target[:-1],diagnostic_only=True)
        with self.assertRaisesRegex(ValueError,'diagnostic only'):diagnostic_pose(library,[0,0],[None,None],target)

    def test_generated_branch_selection_ignores_truth_labels(self):
        group=dict(methods=dict(ordinary=['a','b']),candidates=[dict(key='a',success=True,scores=dict(heuristic=1.)),dict(key='b',success=True,scores=dict(heuristic=2.))])
        self.assertEqual(choose_generated(group),'b')
        poisoned=dict(group,labels=[dict(key='a',correct=True),dict(key='b',correct=False)],target_xyz=np.full((4,3),np.nan))
        self.assertEqual(choose_generated(poisoned),'b')

    def test_missing_ranks_are_censored_and_isomorphism_is_separate(self):
        truth=[dict(i=0,j=1,a=0,b=0,order=1)]
        wrong=[dict(i=0,j=1,a=1,b=0,order=1)]
        result=rank_metrics([dict(connections=wrong,constitution='CO')],truth,'CO')
        self.assertIsNone(result['first_exact_connections_rank'])
        self.assertEqual(result['first_correct_constitution_rank'],1)
        self.assertFalse(result['topk']['128']['exact_connections'])
        self.assertEqual(result['topk']['128']['actual_candidates'],1)

    def test_all_geometries_use_explicit_common_time_head_and_unchanged_beams(self):
        prediction=dict(pool=[],meta=np.empty((0,4),dtype=int),p=np.empty((0,3)),sp=np.empty((0,3)),decision=dict(connections=[]),assembled=None)
        runtime=SimpleNamespace(labels=[0],predict=Mock(return_value=prediction))
        fixture=dict(oracle_edges=[],target_mol=Chem.MolFromSmiles('C'))
        empty=dict(candidates=[],pool=[],skeletons=[],config=SearchConfig().__dict__)
        with patch('geometry_condition_diagnostics.hierarchical_search',return_value=empty) as search,patch('geometry_condition_diagnostics.port_beam',return_value=([],{})) as ports:
            for shift in [0.,10.,-30.]:
                evaluate_condition(runtime,T=np.array([[shift,0,0]]),R=np.eye(3)[None],t=.005,fixture=fixture,diagnostic_only=True)
            self.assertEqual(len(runtime.predict.call_args_list),3)
            for call in runtime.predict.call_args_list:
                self.assertEqual(call.args[2],.005);self.assertEqual(call.kwargs,dict(policy='wide',head='full'))
            for call in search.call_args_list:self.assertEqual(call.kwargs['config'],SearchConfig())
            for call in ports.call_args_list:
                self.assertEqual(call.kwargs['config'].port_width,256);self.assertEqual(call.kwargs['limit'],128)
        with self.assertRaisesRegex(ValueError,'diagnostic-only'):
            evaluate_condition(runtime,T=np.zeros((1,3)),R=np.eye(3)[None],t=.005,fixture=fixture)


if __name__=='__main__':unittest.main()
