import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bootstrap
import numpy as np
import torch
from rdkit import Chem

from trajectory_connections import ConnectionRuntime,load_connection,legal_topologies,run_trajectory,edge_key,is_fragment_tree
from vocab_chemistry import VocabLibrary,assemble_slots


class TrajectoryConnectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2);cls.lib=VocabLibrary()
        checkpoint=bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt'
        cls.checkpoint=load_connection(checkpoint,'cpu')
        label=cls.lib.mapping['core_smiles_to_class']['c1ccccc1']
        cls.runtime=ConnectionRuntime(cls.lib,cls.checkpoint,[label]*3,[None]*3,'cpu')
        cls.T=np.array([[0.,0.,0.],[3.,0.,0.],[0.,3.,0.]],dtype=np.float32)
        cls.R=np.repeat(np.eye(3,dtype=np.float32)[None],3,0)

    def test_generation_explicitly_rejects_oracle_repairs(self):
        with self.assertRaisesRegex(ValueError,'Oracle data forbidden'):
            run_trajectory(None,None,None,mode='closed',oracle_bundle=('truth',))
        with self.assertRaisesRegex(ValueError,'Oracle data forbidden'):
            run_trajectory(None,None,None,mode='closed',oracle_edges=[])
        with self.assertRaisesRegex(ValueError,'Explicit diagnostic oracle'):
            run_trajectory(None,None,None,mode='diagnostic_reset')

    def test_new_head_used_at_low_time_and_legacy_is_explicit(self):
        full=self.runtime.predict(self.T,self.R,.02)
        old=self.runtime.predict(self.T,self.R,.02,head='legacy_staged')
        self.assertEqual(full['head'],'full');self.assertEqual(old['head'],'legacy')
        self.assertTrue(all(not v.requires_grad for v in self.runtime.model.parameters()))
        wide=self.runtime.predict(self.T,self.R,.02,policy='wide')
        self.assertGreaterEqual(len(wide['meta']),len(full['meta']))

    def test_search_is_nested_unique_and_chemically_legal(self):
        prediction=self.runtime.predict(self.T,self.R,.6)
        many=legal_topologies(self.runtime,prediction,8)
        self.assertEqual(len(many),8)
        key=lambda x:tuple(sorted(edge_key(e) for e in x['connections']))
        self.assertEqual(len({key(x) for x in many}),8)
        self.assertEqual([key(x) for x in legal_topologies(self.runtime,prediction,1)],[key(many[0])])
        self.assertEqual([key(x) for x in legal_topologies(self.runtime,prediction,4)],[key(x) for x in many[:4]])
        for candidate in many:
            mol,groups,cuts=assemble_slots(self.lib,self.runtime.labels,candidate['connections'])
            self.assertEqual(len(Chem.GetMolFrags(mol)),1);self.assertEqual(len(groups),3)
            for e in candidate['connections']:
                self.assertIn(e['order'],self.runtime.allowed[e['i'],e['a']])
                self.assertIn(e['order'],self.runtime.allowed[e['j'],e['b']])

    def test_inference_has_no_dataset_or_target_dependency(self):
        from unittest.mock import patch
        with patch('torch.load',side_effect=AssertionError('Prediction attempted dataset access')):
            p=self.runtime.predict(self.T,self.R,.1)
            legal_topologies(self.runtime,p,4)

    def test_extra_interfragment_ring_rejected_by_cut_contract(self):
        tree=[dict(i=0,j=1,a=0,b=0,order=1),dict(i=1,j=2,a=1,b=0,order=1)]
        triangle=tree+[dict(i=0,j=2,a=1,b=1,order=1)]
        mol,_,_=assemble_slots(self.lib,self.runtime.labels,triangle)
        self.assertEqual(len(Chem.GetMolFrags(mol)),1)
        self.assertTrue(is_fragment_tree(3,tree));self.assertFalse(is_fragment_tree(3,triangle))
        p=self.runtime.predict(self.T,self.R,.6)
        p=dict(p,assembled=(mol,[],[]),decision=dict(connections=triangle))
        for candidate in legal_topologies(self.runtime,p,4):
            self.assertTrue(is_fragment_tree(3,candidate['connections']))

    def test_search_deduplicates_chemical_symmetry(self):
        from evaluate_topology_search import diverse_hypotheses
        p=self.runtime.predict(self.T,self.R,.6)
        hypotheses,considered=diverse_hypotheses(self.runtime,p,8)
        self.assertGreaterEqual(len(hypotheses),2)
        self.assertGreater(considered,len(hypotheses))
        self.assertEqual(len({h['constitution'] for h in hypotheses}),len(hypotheses))
        first=legal_topologies(self.runtime,p,1)[0]
        self.assertEqual(sorted(map(edge_key,hypotheses[0]['connections'])),sorted(map(edge_key,first['connections'])))

    def test_trajectory_feature_indices_preserve_molecular_boundaries(self):
        import tempfile
        from adapt_connection_trajectories import trajectory_table
        from robust_connection_data import CompileDataset,pack_records,candidate_features
        rows=[CompileDataset([pid])[0] for pid in ['10gs','11gs']]
        with tempfile.TemporaryDirectory() as temp:
            paths=[]
            for row in rows:
                path=Path(temp)/f"{row['id']}.pt"
                torch.save(dict(id=row['id'],mode='closed',seed=1,casf=False,source_split='train',
                    positions=np.array([float('nan')]),frames=[dict(step=0,t=.1,T=row['noise']['T0'].numpy(),R=row['noise']['R0'].numpy(),current_connections=[])]),path)
                paths.append(path)
            table=trajectory_table(paths,rows,torch.device('cpu'),Path(temp)/'features.pt')
            base=pack_records(rows,torch.device('cpu'))
            for i,row in enumerate(rows):
                mask=table['frame']==i
                single=pack_records([row],torch.device('cpu'))
                expected=candidate_features(single['chem'],row['noise']['T0'],row['noise']['R0'],torch.tensor([.1]),topk=64,cutoff=32.)
                torch.testing.assert_close(table['indices'][mask].long(),expected['indices']+base['ptr'][i])
                torch.testing.assert_close(table['x'][mask],expected['x'])


if __name__=='__main__':unittest.main()
