import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bootstrap
import numpy as np
import torch
from rdkit import Chem
from scipy.spatial.transform import Rotation

from topology_diversity import topology_search,skeleton_key,complete_key
from topology_reranker import extract_features,TopologyReranker,score_candidates,SCHEMA
from trajectory_connections import ConnectionRuntime,load_connection,is_fragment_tree
from vocab_chemistry import VocabLibrary


class TopologyRerankerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2);cls.lib=VocabLibrary()
        cls.ck=load_connection(bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt','cpu')
        root=bootstrap.PROJECT/'results/connection_trajectory_20261101'
        fixture=torch.load(root/'inputs/1r5y/fixture.pt',weights_only=False)
        folder=root/'search_a/1r5y_baseline_801_branch0'
        trajectory=torch.load(folder/'trajectory.pt',weights_only=False)
        cls.runtime=ConnectionRuntime(cls.lib,cls.ck,fixture['labels'],fixture['oov'],'cpu',policy='wide')
        cls.request=dict(spec=json.loads((folder/'chemistry.json').read_text()),connections=trajectory['frames'][-1]['current_connections'],
            frames=trajectory['frames'],positions=trajectory['positions'],pocket=fixture['context']['pocket'])
        cls.features=extract_features(cls.runtime,**cls.request)

    def test_ranking_features_ignore_target_annotations_and_dataset(self):
        request=copy.deepcopy(self.request)
        request['spec']['target_xyz']=[float('nan')]
        request['spec']['oracle_connections']=[dict(i=0,j=1,a=999,b=999,order=3)]
        for frame in request['frames']:frame['target_xyz']=np.full((1,3),float('nan'))
        with patch('torch.load',side_effect=AssertionError('Feature builder accessed dataset')):
            other=extract_features(self.runtime,**request)
        self.assertEqual(self.features,other)
        self.assertFalse(set(self.features)&{'target_xyz','true_connections','oracle','constitution_correct','connections_correct','id','seed','branch','candidate_origin'})
        with self.assertRaises(TypeError):extract_features(self.runtime,**self.request,target_xyz=[])

    def test_candidate_and_pocket_features_are_global_se3_invariant(self):
        request=copy.deepcopy(self.request);G=Rotation.from_rotvec([.2,-.3,.4]).as_matrix();shift=np.array([20.,-7.,3.])
        request['positions']=np.asarray(request['positions'])@G.T+shift
        for frame in request['frames']:
            frame['T']=np.asarray(frame['T'])@G.T+shift;frame['R']=G[None]@np.asarray(frame['R'])
        pocket=request['pocket'];conf=pocket.GetConformer()
        points=conf.GetPositions()@G.T+shift
        for i,xyz in enumerate(points):conf.SetAtomPosition(i,xyz.tolist())
        other=extract_features(self.runtime,**request)
        np.testing.assert_allclose([self.features[k] for k in self.features],[other[k] for k in self.features],atol=.002,rtol=.002)

    def test_inference_rejects_accidental_label_columns(self):
        names=sorted(self.features);torch.manual_seed(4);model=TopologyReranker(len(names),16).eval()
        saved=dict(feature_names=names,mean=torch.zeros(len(names)),scale=torch.ones(len(names)))
        score=score_candidates(model,saved,[self.features])
        self.assertTrue(np.isfinite(score).all())
        with self.assertRaisesRegex(ValueError,'Unexpected/missing'):
            score_candidates(model,saved,[dict(self.features,constitution_correct=True)])

    def test_tree_skeleton_signature_ignores_slot_renumbering(self):
        labels=[3,8,3,9];edges=[dict(i=0,j=1,order=1),dict(i=1,j=2,order=1),dict(i=2,j=3,order=2)]
        permutation=[2,0,3,1];other_labels=[0]*4
        for i,j in enumerate(permutation):other_labels[j]=labels[i]
        other_edges=[dict(i=permutation[e['i']],j=permutation[e['j']],order=e['order']) for e in edges]
        self.assertEqual(skeleton_key(labels,edges),skeleton_key(other_labels,other_edges))

    def test_diversity_explores_backbones_with_matched_k1(self):
        label=self.lib.mapping['core_smiles_to_class']['c1ccccc1']
        runtime=ConnectionRuntime(self.lib,self.ck,[label]*4,[None]*4,'cpu',policy='wide')
        T=np.array([[0,0,0],[3,0,0],[0,3,0],[3,3,0]],dtype=float);R=np.repeat(np.eye(3)[None],4,0)
        prediction=runtime.predict(T,R,.9);prediction=dict(prediction,assembled=None)
        prediction['pool']=[dict(e,log_odds=0.,confidence=.5) for e in prediction['pool']]
        result=topology_search(runtime,prediction,seed=33,k=8)
        self.assertEqual(complete_key(result['ordinary'][0]['connections']),complete_key(result['diverse'][0]['connections']))
        self.assertGreaterEqual(result['pool_skeletons'],2)
        self.assertGreaterEqual(len({c['skeleton'] for c in result['diverse']}),2)
        for method in ['ordinary','diverse']:
            keys=[complete_key(c['connections']) for c in result[method]]
            self.assertEqual(len(keys),len(set(keys)))
            self.assertTrue(all(is_fragment_tree(4,c['connections']) for c in result[method]))

    def test_training_loader_rejects_casf_even_with_train_role(self):
        from train_topology_reranker import load_split
        from validation import digest
        with tempfile.TemporaryDirectory() as name:
            root=Path(name);(root/'cohorts.json').write_text(json.dumps(dict(train=['1abc'],calibration=[])))
            folder=root/'train_a';folder.mkdir()
            contract=dict(role='train',schema=SCHEMA,source_sha256={'topology_reranker.py':digest(bootstrap.PROJECT/'topology_reranker.py')})
            (folder/'report.json').write_text(json.dumps(dict(contract=contract,groups=[dict(role='train',id='1abc',seed=1,source_casf=True,source_split='train')])))
            with self.assertRaisesRegex(ValueError,'CASF/non-training'):load_split(root,'train')

    def test_calibration_ties_retain_partial_connection_information(self):
        from train_topology_reranker import ranking_metrics
        records=[dict(label=dict(constitution_correct=False,connection_f1=.1)),
                 dict(label=dict(constitution_correct=False,connection_f1=.8))]
        groups=[dict(methods=dict(ordinary=[0,1],diverse=[0,1]))]
        worse=ranking_metrics([2.,1.],records,groups);better=ranking_metrics([1.,2.],records,groups)
        self.assertEqual(worse['accuracy'],0.);self.assertEqual(better['accuracy'],0.)
        self.assertEqual(worse['mrr'],better['mrr'])
        self.assertGreater(better['selected_connection_f1'],worse['selected_connection_f1'])

    def test_chemical_overlap_exclusion_remaps_candidate_indices(self):
        from train_topology_reranker import exclude_groups
        records=[dict(id='a'),dict(id='b'),dict(id='b')]
        groups=[dict(id='a',indices=[0],methods=dict(ordinary=[0],diverse=[0])),
                dict(id='b',indices=[1,2],methods=dict(ordinary=[2,None,1],diverse=[1,2]))]
        rows,kept=exclude_groups(records,groups,{'a'})
        self.assertEqual([r['id'] for r in rows],['b','b'])
        self.assertEqual(kept[0]['indices'],[0,1]);self.assertEqual(kept[0]['methods']['ordinary'],[1,None,0])


if __name__=='__main__':unittest.main()
