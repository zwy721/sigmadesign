import copy
import sys
import unittest
import tempfile
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bootstrap
import numpy as np
import torch

from connection_predictor import candidates,proposals,legal_decode
from evaluate_robust_connections import metadata,metric_row
from robust_connection_data import compile_chemistry,compile_targets,pack_records,candidate_features
from robust_connection_model import TimeConnectionPredictor,predict_probabilities,legal_decode_fast
from vocab_chemistry import VocabLibrary,explicit_oov


class RobustConnectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2);cls.lib=VocabLibrary()
        cls.record=torch.load(bootstrap.RECORDS/'1a30.pt',weights_only=False)
        r=cls.record;cls.oov=explicit_oov(r)
        cls.chem=compile_chemistry(cls.lib,r['labels'].tolist(),cls.oov)
        cls.row=dict(id='1a30',chem=cls.chem,target=compile_targets(cls.chem,r),oov=cls.oov,
            noise={k:r[k].clone() for k in ('T0','R0','C0','Q0','refR','offset')})
        cls.packed=pack_records([cls.row],torch.device('cpu'))
        cls.features=candidate_features(cls.packed['chem'],r['T0'],r['R0'],torch.zeros(1),topk=8,cutoff=16,half=False)
        state=torch.load(bootstrap.PROJECT/'results/stage3_training/best.pt',weights_only=False)['model']
        cls.model=TimeConnectionPredictor(state).eval()

    def test_vectorized_features_match_original(self):
        old=candidates(self.lib,self.record['labels'].tolist(),self.record['T0'].numpy(),self.record['R0'].numpy(),oov=self.oov)
        meta,_=metadata(self.packed,self.features)
        np.testing.assert_array_equal(meta,old['candidates'].numpy())
        torch.testing.assert_close(self.features['x'],old['x'],atol=2e-6,rtol=2e-6)

    def test_targets_and_reference_pose_cannot_change_features(self):
        changed=copy.deepcopy(self.record);changed['edges'].zero_();changed['anchors'].fill_(-999)
        for key in ('T0','R0','C0','Q0','refR','offset'):changed[key].fill_(float('nan'))
        other=compile_chemistry(self.lib,changed['labels'].tolist(),self.oov)
        for k in self.chem:torch.testing.assert_close(self.chem[k],other[k])
        targets=compile_targets(other,changed);self.assertEqual(int(targets['y'].sum()),0)
        packed=copy.deepcopy(self.packed);packed['y'].fill_(2)
        for value in packed['noise'].values():value.fill_(float('nan'))
        f=candidate_features(packed['chem'],self.record['T0'],self.record['R0'],torch.zeros(1),topk=8,cutoff=16,half=False)
        torch.testing.assert_close(f['x'],self.features['x'])
        p,_=predict_probabilities(self.model,self.packed,self.features)
        q,_=predict_probabilities(self.model,packed,f)
        torch.testing.assert_close(p,q)

    def test_pack_boundaries_and_se3_invariance(self):
        packed=pack_records([self.row,self.row],torch.device('cpu'));c=packed['chem'];a,b=c['pairs'].T
        self.assertTrue(torch.equal(c['port_mol'][a],c['port_mol'][b]))
        from scipy.spatial.transform import Rotation
        G=torch.tensor(Rotation.from_rotvec([.2,-.3,.6]).as_matrix(),dtype=torch.float32)
        r=self.record
        f=candidate_features(self.packed['chem'],r['T0']@G.T+30,G[None]@r['R0'],torch.zeros(1),topk=8,cutoff=16,half=False)
        torch.testing.assert_close(f['indices'],self.features['indices'])
        torch.testing.assert_close(f['x'],self.features['x'],atol=2e-5,rtol=2e-5)

    def test_zero_initial_residual_matches_legacy_and_frozen_base(self):
        f=self.features;c=self.packed['chem'];a,b=c['pairs'][f['indices']].T
        labels=torch.stack([c['labels'][c['slot'][a]],c['labels'][c['slot'][b]]],-1).clamp_min(0)
        labels[c['labels'][c['slot'][a]]<0,0]=3684
        labels[c['labels'][c['slot'][b]]<0,1]=3684
        with torch.no_grad():
            p,s=self.model(c,f,self.model.context(c),slice(None))
            old,os=self.model.legacy(labels,f['x'])
        torch.testing.assert_close(p,old);torch.testing.assert_close(s,os)
        self.assertTrue(all(not v.requires_grad for v in self.model.legacy.parameters()))

    def test_fast_decoder_matches_original_capacity_policy(self):
        f=self.features;p,sp=predict_probabilities(self.model,self.packed,f);meta,_=metadata(self.packed,f)
        old=candidates(self.lib,self.record['labels'].tolist(),self.record['T0'].numpy(),self.record['R0'].numpy(),oov=self.oov)
        proposed,_=proposals(self.model.legacy,old,torch.device('cpu'))
        baseline,_=legal_decode(self.lib,self.record['labels'].tolist(),proposed,oov=self.oov)
        fast,_=legal_decode_fast(self.lib,self.row,meta,p,sp,.65)
        key=lambda e:(e['i'],e['j'],e['a'],e['b'],e['order'])
        self.assertEqual(sorted(map(key,baseline['connections'])),sorted(map(key,fast['connections'])))

    def test_high_noise_pool_does_not_commit_or_force_a_tree(self):
        p,sp=predict_probabilities(self.model,self.packed,self.features);meta,_=metadata(self.packed,self.features)
        result=metric_row(self.lib,self.row,meta,p.numpy(),sp.numpy(),.1,commit=False)
        self.assertFalse(result['committed']);self.assertEqual(result['connections'],[])
        self.assertFalse(result['complete_legal']);self.assertGreater(result['retained_hypotheses'],0)
        result,_=legal_decode_fast(self.lib,self.row,meta,p*0+np.array([1.,0.,0.]),sp,.65)
        self.assertEqual(result['status'],'candidates_only');self.assertEqual(result['connections'],[])

    def test_noisy_frames_match_official_native_marginal(self):
        from robust_connection_data import make_official_diffuser,noisy_frames
        with tempfile.TemporaryDirectory() as folder:
            diffuser=make_official_diffuser(folder,'cpu');r=self.record
            times=torch.tensor([.2]);T,R=noisy_frames(self.packed,diffuser,times,seed=781)
            torch.manual_seed(781)
            expected=diffuser.forward_marginal(r['C0'],r['Q0'],times.expand(len(r['labels'])))
            Q=expected['R_t']
            torch.testing.assert_close(T,expected['T_t']*2.7-torch.einsum('nij,nj->ni',Q,r['offset']))
            torch.testing.assert_close(R,Q@r['refR'])
            changed=copy.deepcopy(self.packed)
            changed['noise']['T0'].fill_(float('nan'));changed['noise']['R0'].fill_(float('nan'))
            other,otherR=noisy_frames(changed,diffuser,times,seed=781)
            torch.testing.assert_close(T,other);torch.testing.assert_close(R,otherR)
            fresh,_=noisy_frames(self.packed,diffuser,times,seed=782)
            self.assertGreater(float((T-fresh).abs().max()),.1)
            clean,cleanR=noisy_frames(self.packed,diffuser,torch.zeros(1),seed=781)
            torch.testing.assert_close(clean,r['T0']);torch.testing.assert_close(cleanR,r['R0'])

    def test_rejected_identity_update_cannot_reuse_old_port_meaning(self):
        from evaluate_connection_alternation import proposal_identities
        result=dict(labels=[232,512],events=[dict(t=.04,identity_updates=[]),
            dict(t=.01,accepted=False,identity_updates=[dict(slot=0,old=232,new=713)])])
        self.assertEqual(proposal_identities(result),[713,512])
        self.assertEqual(result['labels'],[232,512])
        accepted=copy.deepcopy(result);accepted['labels'][0]=713;accepted['events'][-1]['accepted']=True
        self.assertEqual(proposal_identities(accepted),[713,512])


if __name__=='__main__':unittest.main()
