import copy
import json
import sys
import unittest
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import bootstrap
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
from sigmadock.chem.fragmentation import fragment_molecule, get_fragment_map
from sigmadock.chem.processing import get_atom_features, get_bond_features

from oracle_graph import OracleContractError, assemble, export_oracle


def fixture(smiles):
    mol = Chem.MolFromSmiles(smiles)
    with_h = Chem.AddHs(mol)
    if AllChem.EmbedMolecule(with_h, randomSeed=12) != 0:
        raise RuntimeError('Embedding failed')
    mol = Chem.RemoveHs(with_h)
    fragmented = fragment_molecule(Chem.Mol(mol), selection='canonical')
    n = mol.GetNumAtoms()
    groups = [[k for k in group if k < n] for group in Chem.GetMolFrags(fragmented)]
    cuts = [mol.GetBondBetweenAtoms(*b['bond']).GetIdx()
            for b in get_fragment_map(fragmented)['torsional_bonds']]
    return mol, export_oracle(mol, groups, cuts)


class OracleTests(unittest.TestCase):
    def test_chemistry_roundtrip(self):
        # Aromatic, charged, tetrahedral and E/Z cases catch more than atom counts.
        for smiles in ['c1ccccc1', 'CCOC(=O)c1ccccc1', 'C[NH2+]CC(=O)[O-]',
                       'C[C@H](O)CCc1ccccc1', 'CC/C=C/CCO', '[13CH3]CCO']:
            with self.subTest(smiles=smiles):
                original, spec = fixture(smiles)
                rebuilt = assemble(json.loads(json.dumps(spec)))
                self.assertEqual(Chem.MolToSmiles(original), Chem.MolToSmiles(rebuilt))
                np.testing.assert_array_equal(original.GetConformer().GetPositions(),
                                              rebuilt.GetConformer().GetPositions())
                for a, b in zip(original.GetAtoms(), rebuilt.GetAtoms()):
                    np.testing.assert_array_equal(get_atom_features(a), get_atom_features(b))
                for a, b in zip(original.GetBonds(), rebuilt.GetBonds()):
                    self.assertEqual((a.GetBeginAtomIdx(), a.GetEndAtomIdx()),
                                     (b.GetBeginAtomIdx(), b.GetEndAtomIdx()))
                    np.testing.assert_array_equal(get_bond_features(a), get_bond_features(b))

    def test_invalid_contracts_fail(self):
        _, spec = fixture('CCOC(=O)c1ccccc1')
        self.assertGreater(len(spec['connections']), 0)
        cases = []
        bad = copy.deepcopy(spec); bad['connections'].pop(); cases.append(bad)
        bad = copy.deepcopy(spec); bad['connections'].append(bad['connections'][0]); cases.append(bad)
        bad = copy.deepcopy(spec); bad['fragments'][0]['atom_ids'][0] = 999; cases.append(bad)
        bad = copy.deepcopy(spec); bad['fragments'][0]['coordinates'][0][0] = float('nan'); cases.append(bad)
        bad = copy.deepcopy(spec); bad['fragments'][0]['atoms'][0]['z'] = 7; cases.append(bad)
        bad = copy.deepcopy(spec)
        for frag in bad['fragments']: frag['ports'] = []
        cases.append(bad)
        for bad in cases:
            with self.assertRaises(OracleContractError):
                assemble(bad)

    def test_rebuild_does_not_mutate_input(self):
        _, spec = fixture('CCOC(=O)c1ccccc1')
        before = copy.deepcopy(spec)
        assemble(spec)
        self.assertEqual(spec, before)

    def test_identity_registry_roundtrip_and_missing_id(self):
        from template_library import resolve, split_templates
        _, spec = fixture('CCOC(=O)c1ccccc1')
        instance, library = split_templates(spec)
        self.assertFalse(any('atoms' in f or 'bonds' in f for f in instance['fragments']))
        self.assertEqual(spec, resolve(json.loads(json.dumps(instance)), json.loads(json.dumps(library))))
        unknown = copy.deepcopy(instance)
        unknown['fragments'][0]['identity'] = 'not-in-library'
        with self.assertRaises(OracleContractError):
            resolve(unknown, library)

    def test_official_stereo_and_no_target_pose_leak(self):
        from run_validation import official_graph
        from oracle_graph import oracle_from_official, rebuild
        from validation import compare_graphs
        from sigmadock.data import SigmaDataset
        official_fragmenter = SigmaDataset.fragment_and_annotate.__globals__['fragment_molecule']
        # These inputs have non-stereogenic SDF tags cleaned by official canonical
        # selection; reproducing atom count alone would miss the regression.
        for pid in ['2j7h', '3b1m']:
            sdf = bootstrap.INPUTS / pid / f'{pid}_LIG_ligand.sdf'
            pdb = bootstrap.INPUTS / pid / f'{pid}_LIG_pocket.pdb'
            graph, reference = official_graph(sdf, pdb, 0)
            spec = oracle_from_official(graph, reference)
            before = copy.deepcopy(spec)
            restored = rebuild(spec, pocket=graph.mol_info['pocket'],
                               pocket_com=graph.pocket_com.numpy(), pdb_path=pdb, ligand_path=sdf)
            self.assertTrue(compare_graphs(graph, restored)['exact'])
            no_files = rebuild(spec, pocket=graph.mol_info['pocket'],
                               pocket_com=graph.pocket_com.numpy(),
                               pdb_path='/not-present/oracle_pocket.pdb',
                               ligand_path='/not-present/oracle_ligand.sdf')
            self.assertTrue(compare_graphs(graph, no_files)['exact'])
            self.assertEqual(spec, before)
            target = graph.mol_info['original'].GetConformer()
            for k, point in enumerate(target.GetPositions()):
                target.SetAtomPosition(k, point + 1000.)
            # Metrics' target can move arbitrarily without changing the input spec.
            self.assertEqual(spec, oracle_from_official(graph, reference))
            self.assertIs(official_fragmenter,
                          SigmaDataset.fragment_and_annotate.__globals__['fragment_molecule'])
            import torch
            from serialization import save_graph
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / 'graph.pt'
                save_graph(restored, path)
                self.assertTrue(compare_graphs(restored, torch.load(path, weights_only=False))['exact'])


if __name__ == '__main__':
    unittest.main()
