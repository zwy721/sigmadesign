import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bootstrap
import numpy as np
import torch

from connection_predictor import candidates,legal_decode,targets
from joint_sampler import NativeState,chemical_graph
from pipeline_utils import molecule_metrics
from run_validation import load_official
from vocab_chemistry import (ChemistryRejected,VocabLibrary,assemble_slots,atom_correspondence,
                            canonical,explicit_oov,oracle_chiral,oracle_cip,true_connections)


class StagedChemistryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        cls.library=VocabLibrary()

    def test_real_vocab_stereo_and_geometry_contract(self):
        for pid in ['1a30','3b1m','3mss','4agn','4m0y','5tmn']:
            with self.subTest(pid=pid):
                r=torch.load(bootstrap.RECORDS/f'{pid}.pt',weights_only=False)
                original=torch.load(bootstrap.PROJECT/'results/acceptance'/pid/'official_graph.pt',weights_only=False).mol_info['original']
                mapping=atom_correspondence(r,original)
                cip=oracle_cip(r,original,mapping);chiral=oracle_chiral(r,original,mapping)
                mol,groups,cuts=assemble_slots(self.library,r['labels'].tolist(),true_connections(r),
                    oov=explicit_oov(r),cip=cip,chiral=chiral)
                self.assertEqual(canonical(mol),canonical(original))
                self.assertEqual(sum(map(len,groups)),original.GetNumHeavyAtoms())
                self.assertEqual(len(cuts),len(true_connections(r)))
                # Explicit atom stereo is 2D chemistry, invariant to crystal xyz.
                conf=original.GetConformer()
                for k,p in enumerate(conf.GetPositions()):conf.SetAtomPosition(k,(p+999).tolist())
                self.assertEqual(cip,oracle_cip(r,original,mapping))
                self.assertEqual(chiral,oracle_chiral(r,original,mapping))

    def test_invalid_connections_stay_outside_backbone(self):
        with self.assertRaises(ChemistryRejected):assemble_slots(self.library,[232,232],[])
        with self.assertRaises(ChemistryRejected):assemble_slots(self.library,[3684],[])
        with self.assertRaises(ChemistryRejected):assemble_slots(self.library,[-1],[])
        edges=[dict(i=0,j=j,a=0,b=0,order=1) for j in range(1,5)]
        with self.assertRaises(ChemistryRejected):assemble_slots(self.library,[232]*5,edges)
        proposal=[dict(i=0,j=1,a=0,b=0,order=1,stereo=0,confidence=.99,log_odds=4.)]
        decision,graph=legal_decode(self.library,[232]*3,proposal)
        self.assertEqual(decision['status'],'candidates_only');self.assertIsNone(graph)

    def test_connection_features_do_not_read_connection_targets(self):
        r=torch.load(bootstrap.RECORDS/'1a30.pt',weights_only=False)
        labels=r['labels'].tolist()
        x=candidates(self.library,labels,r['T0'].numpy(),r['R0'].numpy())
        changed=copy.deepcopy(r);changed['edges'].zero_();changed['anchors'].fill_(-100)
        y=targets(x,r);other=targets(x,changed)
        self.assertGreater(int((y['y']>0).sum()),0);self.assertEqual(int(other['y'].sum()),0)
        repeated=candidates(self.library,labels,r['T0'].numpy(),r['R0'].numpy())
        self.assertTrue(torch.equal(x['types'],repeated['types']))
        self.assertTrue(torch.equal(x['x'],repeated['x']))

    def test_atom_count_change_cannot_produce_fake_full_rmsd(self):
        from rdkit import Chem
        a,_,_=assemble_slots(self.library,[232],[])
        b,_,_=assemble_slots(self.library,[512],[])
        result=molecule_metrics(a,b,np.asarray(a.GetConformer().GetPositions()))
        self.assertFalse(result['stereo_chemical_exact']);self.assertIsNone(result['full_ligand_rmsd_A'])
        self.assertLess(result['mcs_target_coverage'],1.)

    def test_candidate_graph_keeps_alternative_legal_bond_order(self):
        from connection_predictor import proposals
        from joint_sampler import legal_hypothesis
        class PredictDouble(torch.nn.Module):
            def forward(self,types,x):
                return x.new_tensor([0.,1.,2.]).repeat(len(x),1),x.new_zeros(len(x),3)
        label=self.library.mapping['core_smiles_to_class']['c1ccccc1']
        x=candidates(self.library,[label,label],np.array([[0.,0.,0.],[3.,0.,0.]]),np.eye(3)[None].repeat(2,0))
        _,pool=proposals(PredictDouble(),x,torch.device('cpu'),threshold=.9)
        self.assertTrue(any(c['order']==1 for c in pool));self.assertTrue(any(c['order']==2 for c in pool))
        edges,(mol,groups,cuts)=legal_hypothesis(self.library,[label,label],pool)
        self.assertEqual(edges[0]['order'],1);self.assertEqual(len(groups),2)

    def test_variable_slot_count_resets_legacy_masks_and_targets(self):
        from identity_server import resize_slot_metadata
        entry=dict(wrong_type_mask=torch.ones(10,dtype=torch.bool),type_supervision_mask=torch.ones(10),
                   geometry_condition={'tokens':torch.arange(10)},atom_counts=torch.ones(10))
        resize_slot_metadata(entry,6)
        self.assertEqual(entry['wrong_type_mask'].shape,(6,))
        self.assertEqual(entry['type_supervision_mask'].shape,(6,))
        self.assertEqual(entry['atom_counts'].shape,(6,))
        self.assertEqual(len(entry['local_xyz']),6)
        self.assertNotIn('geometry_condition',entry)


class PoseTransferTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        cls.temp=tempfile.TemporaryDirectory()
        cls.den=load_official(bootstrap.CHECKPOINT,Path(cls.temp.name),torch.device('cpu'))
        cls.library=VocabLibrary()
        cls.context=torch.load(bootstrap.PROJECT/'results/acceptance/1a30/pocket_context.pt',weights_only=False)

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def test_pose_transfer_after_connectivity_change_and_atom_count_change(self):
        edges=[dict(i=0,j=1,a=1,b=0,order=1),dict(i=1,j=2,a=1,b=0,order=1)]
        graph,groups,_=chemical_graph(self.library,[232]*3,edges,self.context,[None]*3)
        with torch.inference_mode():
            old=NativeState(self.den,graph,groups,torch.device('cpu'))
            original=old.physical()
            desired=[original[old.pn+np.asarray(g)] for g in groups]
            same=NativeState(self.den,graph,groups,torch.device('cpu'),desired=desired)
            np.testing.assert_allclose(same.physical()[same.pn:same.pn+6],original[old.pn:old.pn+6],atol=2e-5)
            new_edges=[dict(i=0,j=2,a=1,b=0,order=1),dict(i=1,j=2,a=0,b=1,order=1)]
            new_graph,new_groups,_=chemical_graph(self.library,[232]*3,new_edges,self.context,[None]*3)
            transferred=NativeState(self.den,new_graph,new_groups,torch.device('cpu'),desired=desired)
            for i,g in enumerate(new_groups):
                np.testing.assert_allclose(transferred.physical()[transferred.pn+np.asarray(g)].mean(0),desired[i].mean(0),atol=2e-5)
            labels=[512,232,232]
            graph3,groups3,_=chemical_graph(self.library,labels,new_edges,self.context,[None]*3)
            _,template=self.library.template(512)
            desired3=[template-template.mean(0)+desired[0].mean(0),desired[1],desired[2]]
            changed=NativeState(self.den,graph3,groups3,torch.device('cpu'),desired=desired3)
            self.assertEqual(sum(map(len,groups3)),7)
            for i,g in enumerate(groups3):
                np.testing.assert_allclose(changed.physical()[changed.pn+np.asarray(g)].mean(0),desired3[i].mean(0),atol=2e-5)
            self.assertTrue(np.isfinite(changed.physical()).all())


if __name__=='__main__':unittest.main()
