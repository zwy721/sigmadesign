import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from scipy.spatial.transform import Rotation

from identity_server import match_geom_features
from prediction_data import identity_features
from prediction_metrics import identity_metrics
from train_identity_controls import IdentityHead


class PredictionTests(unittest.TestCase):
    def test_mask_inference_uses_current_frame_only(self):
        e=dict(Tt=torch.tensor([[3.,4.,5.],[5.,7.,9.]]),T0=torch.full((2,3),999.),source='pdbbind')
        pg={'empty':True};match_geom_features(e,pg)
        self.assertEqual(e['source'],'geom');self.assertIs(e['pg'],pg)
        torch.testing.assert_close(e['Tt'].mean(0),torch.zeros(3))
        torch.testing.assert_close(e['Tt'][1]-e['Tt'][0],torch.tensor([2.,3.,4.]))

    def test_frame_features_are_global_se3_invariant_and_label_free(self):
        rng=np.random.default_rng(32);T=rng.normal(size=(5,3));R=Rotation.random(5,random_state=rng).as_matrix()
        A=np.zeros((5,5),int);A[0,1]=A[1,0]=1;A[1,2]=A[2,1]=2
        x=identity_features(T,R,A,.6);G=Rotation.random(random_state=rng).as_matrix()
        other=identity_features(T@G.T+31,G[None]@R,A,.6)
        torch.testing.assert_close(x,other,atol=2e-6,rtol=2e-6)
        self.assertEqual(x.shape,(5,401))

    def test_metrics_cannot_count_preserved_oov_as_success(self):
        rows=[dict(labels=[-1],topk=[[7]]),dict(labels=[2,-1],topk=[[3,2],[9]]),dict(labels=[2],topk=[[2]])]
        m=identity_metrics(rows,[5]*4)
        self.assertEqual(m['known_slots'],2);self.assertEqual(m['oov_slots_excluded'],2)
        self.assertEqual(m['topk_accuracy']['1'],.5);self.assertEqual(m['topk_accuracy']['5'],1.)
        self.assertEqual(m['molecules_with_known_slots'],2);self.assertEqual(m['complete_in_vocab_correct'],1)

    def test_iterative_feedback_isolated_between_molecules(self):
        torch.manual_seed(10);torch.set_num_threads(1)
        model=IdentityHead(401,torch.zeros(3684,5),'iterative',torch.zeros(3684)).eval()
        x=torch.randn(5,401);a=torch.zeros(3,3);a[0,1]=a[1,0]=1;b=torch.zeros(2,2);b[0,1]=b[1,0]=1
        with torch.no_grad():
            together,_=model(x,torch.block_diag(a,b));single,_=model(x[:3],a)
        torch.testing.assert_close(together[:3],single,atol=2e-6,rtol=2e-6)

    def test_public_prediction_rejects_invalid_coordinate_frames(self):
        from predict_identity_control import predict
        request=dict(T=[[0.,0.,0.]],R=[np.eye(3).tolist()],adjacency=[[0]],t=.2)
        bad=copy.deepcopy(request);bad['R'][0][0][0]=-1
        with self.assertRaisesRegex(ValueError,'proper rotations'):predict(None,bad)
        bad=copy.deepcopy(request);bad['adjacency']=[[1]]
        with self.assertRaisesRegex(ValueError,'Invalid adjacency'):predict(None,bad)
        bad=copy.deepcopy(request);bad['t']=2
        with self.assertRaisesRegex(ValueError,'Invalid diffusion time'):predict(None,bad)


if __name__=='__main__':unittest.main()
