#!/usr/bin/env python3
"""Matched held-out scoring; truth labels enter only after inference scores."""
import argparse
import json
from pathlib import Path
import time

import bootstrap
import numpy as np

from prepare_reranker_experiment import ROOT
from run_validation import write_json
from topology_reranker import load_reranker,score_candidates
from validation import digest


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);model,saved=load_reranker(a.checkpoint)
    cohorts=json.loads((a.root/'cohorts.json').read_text());expected={(pid,s) for pid in cohorts['casf_holdout'] for s in cohorts['test_seeds']}
    reports=[(p,json.loads(p.read_text())) for p in sorted(a.root.glob('holdout_*/report.json'))]
    groups=[(p,g) for p,r in reports for g in r['groups']]
    if {(g['id'],g['seed']) for _,g in groups}!=expected or len(groups)!=len(expected):raise ValueError('Held-out candidate collection incomplete/duplicated')
    output=dict(rows=[],checkpoint_sha256=digest(a.checkpoint),cohorts_sha256=digest(a.root/'cohorts.json'),
        source_sha256={n:digest(bootstrap.PROJECT/n) for n in ['topology_reranker.py','evaluate_topology_reranking.py']},
        oracle_is_diagnostic_only=True,ground_truth_used_for_inference=False,identity_fixed=True)
    for path,group in groups:
        if not group['source_casf'] or group['enrichment']:raise ValueError('Invalid holdout/oracle-enriched pool')
        candidates={r['key']:r for r in group['candidates']};ok=[r for r in group['candidates'] if r['success']]
        before=time.time()
        inferred=score_candidates(model,saved,[r['features'] for r in ok]) if ok else []
        scoring_seconds=time.time()-before
        learned={r['key']:s for r,s in zip(ok,inferred)}
        # Deliberately load labels only after learned and analytic scores exist.
        labels={r['key']:r for r in json.loads(Path(group['labels_path']).read_text())}
        for search in ['ordinary','diverse']:
            for k in [1,4,8]:
                attempted=group['methods'][search][:k];keys=[key for key in attempted if candidates[key]['success']]
                available=[candidates[key] for key in keys]
                for method in ['heuristic','connection','geometry','pocket','reranker','oracle']:
                    def score(key):
                        if method=='oracle':return (labels[key]['constitution_correct'],labels[key]['connections_correct'])
                        return learned[key] if method=='reranker' else candidates[key]['scores'][method]
                    chosen=max(keys,key=score) if keys else None
                    row=candidates[chosen] if chosen else None;label=labels[chosen] if chosen else None
                    feat=row['features'] if row else None
                    output['rows'].append(dict(id=group['id'],seed=group['seed'],search=search,K=k,scorer=method,
                        selected=chosen,constitution_correct=bool(label and label['constitution_correct']),
                        connections_correct=bool(label and label['connections_correct']),chemical_valid=bool(chosen),
                        geometry_abnormal=not chosen or feat['bad_bond_fraction']>0 or feat['ligand_clash_fraction']>0,
                        pocket_clash=bool(chosen and feat['pocket_fraction_1.2A']>0),
                        candidate_coverage=any(labels[key]['constitution_correct'] for key in keys),
                        strict_candidate_coverage=any(labels[key]['connections_correct'] for key in keys),
                        attempted=len(attempted),completed=len(keys),
                        distinct_skeletons=len({candidates[key]['final_skeleton'] for key in keys}),
                        distinct_constitutions=len({candidates[key]['constitution'] for key in keys}),
                        sampling_seconds=sum(candidates[key]['seconds'] for key in attempted),shared_search_seconds=group['search_seconds'],
                        reranker_seconds=scoring_seconds if method=='reranker' else 0.,
                        backbone_evaluations=sum(candidates[key].get('backbone_evaluations',0) for key in keys),
                        oracle_diagnostic_only=method=='oracle'))
    summary={}
    for search in ['ordinary','diverse']:
        summary[search]={}
        for k in [1,4,8]:
            summary[search][str(k)]={}
            for scorer in ['heuristic','connection','geometry','pocket','reranker','oracle']:
                rows=[r for r in output['rows'] if r['search']==search and r['K']==k and r['scorer']==scorer]
                summary[search][str(k)][scorer]=dict(runs=len(rows),constitution_correct=sum(r['constitution_correct'] for r in rows),
                    connections_correct=sum(r['connections_correct'] for r in rows),chemical_valid=sum(r['chemical_valid'] for r in rows),
                    candidate_coverage=sum(r['candidate_coverage'] for r in rows),strict_candidate_coverage=sum(r['strict_candidate_coverage'] for r in rows),
                    geometry_abnormal=sum(r['geometry_abnormal'] for r in rows),pocket_clash=sum(r['pocket_clash'] for r in rows),
                    mean_completed_candidates=float(np.mean([r['completed'] for r in rows])),
                    mean_distinct_skeletons=float(np.mean([r['distinct_skeletons'] for r in rows])),
                    mean_backbone_evaluations=float(np.mean([r['backbone_evaluations'] for r in rows])),
                    median_sampling_seconds=float(np.median([r['sampling_seconds'] for r in rows])),
                    median_shared_search_seconds=float(np.median([r['shared_search_seconds'] for r in rows])))
    output['summary']=summary
    historical_path=a.root/'historical_features.json'
    if historical_path.exists():
        records=json.loads(historical_path.read_text())['records']
        inferred=score_candidates(model,saved,[r['features'] for r in records])
        # Historical labels are likewise read only after scoring.
        labels={r['key']:r for r in json.loads((a.root/'historical_labels.json').read_text())}
        groups={}
        for r,score in zip(records,inferred):groups.setdefault(r['group'],[]).append(dict(r,reranker_score=score))
        historical={}
        for k in [1,4,8]:
            chosen=[]
            for group,rr in groups.items():chosen.append(max([r for r in rr if r['branch']<k],key=lambda r:(r['reranker_score'],-r['branch'])))
            historical[str(k)]=dict(runs=len(groups),constitution_correct=sum(labels[r['key']]['constitution_correct'] for r in chosen),
                connections_correct=sum(labels[r['key']]['connections_correct'] for r in chosen),development_recheck_not_independent_holdout=True)
        output['historical_reranker']=historical
    write_json(a.output/'report.json',output);print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
