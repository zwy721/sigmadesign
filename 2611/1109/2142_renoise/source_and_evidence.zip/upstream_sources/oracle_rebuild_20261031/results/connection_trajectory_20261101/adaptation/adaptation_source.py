#!/usr/bin/env python3
"""Adapt only the time-conditioned head on non-CASF native reverse trajectories."""
import argparse
import copy
import json
from pathlib import Path
import time

import bootstrap
import numpy as np
import torch
from torch.nn import functional as F

from robust_connection_data import pack_records,candidate_features,noisy_frames,make_official_diffuser
from robust_connection_model import TimeConnectionPredictor,predict_probabilities
from run_validation import write_json
from train_robust_connections import GRID,raw_metrics
from trajectory_connections import load_connection
from validation import digest

ROOT=bootstrap.PROJECT/'results/connection_trajectory_20261101'
BASE=bootstrap.PROJECT/'results/connection_robust_20261101/training_v2/best.pt'


def trajectory_table(paths,rows,device,output):
    """Targets never enter feature construction; indices map to fixed chemistry."""
    contract=dict(files={str(p):digest(p) for p in paths},feature_policy='top64 / 32A at all t; no target candidate insertion',
        feature_source_sha256=digest(bootstrap.PROJECT/'robust_connection_data.py'))
    if output.exists():
        data=torch.load(output,weights_only=False)
        if data['contract']!=contract:raise ValueError('Trajectory table inputs changed')
        return data
    base=pack_records(rows,device);lookup={r['id']:i for i,r in enumerate(rows)};frames=[]
    for path in paths:
        trajectory=torch.load(path,weights_only=False)
        if trajectory['casf'] or trajectory['source_split']!='train':raise ValueError('CASF leak into adaptation')
        pid=trajectory['id']
        if pid not in lookup:raise ValueError('Trajectory not in requested cohort')
        for frame in trajectory['frames']:
            frames.append(dict(id=pid,source=trajectory['mode'],seed=trajectory['seed'],**frame))
    if not frames:raise ValueError('No completed trajectory frames')
    x=[];ix=[];times=[];frame_index=[]
    for start in range(0,len(frames),128):
        group=frames[start:start+128];base_ids=[lookup[f['id']] for f in group]
        packed=pack_records([rows[i] for i in base_ids],device)
        T=torch.as_tensor(np.concatenate([f['T'] for f in group]),device=device)
        R=torch.as_tensor(np.concatenate([f['R'] for f in group]),device=device)
        t=torch.tensor([f['t'] for f in group],device=device,dtype=torch.float32)
        f=candidate_features(packed['chem'],T,R,t,topk=64,cutoff=32.,half=True)
        local=f['indices'];m=packed['chem']['pair_mol'][local]
        pointers=torch.tensor(packed['ptr'][:-1],device=device)
        base_pointers=torch.tensor([base['ptr'][i] for i in base_ids],device=device)
        actual=local-pointers[m]+base_pointers[m]
        x.append(f['x'].cpu());ix.append(actual.cpu().int());times.append(f['t'].cpu())
        frame_index.append((m+start).cpu().int())
        print('FEATURES',start+len(group),'/',len(frames),flush=True)
    data=dict(contract=contract,x=torch.cat(x),indices=torch.cat(ix),t=torch.cat(times),frame=torch.cat(frame_index),
        frames=[dict(id=f['id'],source=f['source'],seed=f['seed'],t=f['t'],step=f['step'],
            true_bonds=rows[lookup[f['id']]]['target']['true_bonds']) for f in frames])
    output.parent.mkdir(parents=True,exist_ok=True);torch.save(data,output);return data


def table_to_device(data,device):
    return {k:(v.to(device).long() if k in ('indices','frame') else v.to(device)) if torch.is_tensor(v) else v for k,v in data.items()}


def calibrate(model,packed,table,clean_features):
    probabilities,_=predict_probabilities(model,packed,table)
    index=table['indices'];target=packed['y'][index].long().cpu();t=table['t'].cpu()
    frames=table['frames'];ft=np.asarray([f['t'] for f in frames]);grid=np.asarray(GRID)
    bins=np.abs(ft[:,None]-grid[None]).argmin(-1)
    frame_bins=torch.tensor(bins)[table['frame'].cpu()]
    metrics={};thresholds={};threshold_grid=[.1,.2,.35,.5,.65,.8,.9]
    for i,time_t in enumerate(GRID):
        if i==0:
            p,_=predict_probabilities(model,packed,clean_features)
            y=packed['y'][clean_features['indices']].long().cpu()
            actual=sum(r['target']['true_bonds'] for r in packed['rows'])
        else:
            selected=frame_bins==i;p=probabilities[selected];y=target[selected]
            actual=sum(f['true_bonds'] for j,f in enumerate(frames) if bins[j]==i)
        choices=[raw_metrics(p,y,actual,z) for z in threshold_grid]
        best=max(choices,key=lambda m:m['f1']);metrics[str(time_t)]=best;thresholds[str(time_t)]=best['threshold']
    score=float(np.mean([metrics[str(t)]['f1'] for t in GRID[1:]]))
    return metrics,thresholds,score


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--checkpoint',type=Path,default=BASE)
    p.add_argument('--device',default='cuda:0');p.add_argument('--epochs',type=int,default=30)
    p.add_argument('--batch-rows',type=int,default=65536);p.add_argument('--lr',type=float,default=.0002)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2);device=torch.device(a.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    if (a.output/'latest.pt').exists():raise ValueError('Choose a new adaptation output directory')
    cohorts=json.loads((a.root/'cohorts.json').read_text());train_ids=set(cohorts['train']);cal_ids=set(cohorts['calibration'])
    val_ids=set(json.loads((bootstrap.RECORDS.parent/'val_ids.json').read_text()))
    if train_ids&cal_ids or (train_ids|cal_ids)&val_ids:raise ValueError('Adaptation split overlap')
    cached=torch.load(bootstrap.PROJECT/'results/connection_robust_20261101/cache/train.pt',weights_only=False)
    row_by_id={r['id']:r for r in cached['rows']}
    train_rows=[row_by_id[x] for x in cohorts['train']];cal_rows=[row_by_id[x] for x in cohorts['calibration']]
    paths=sorted(a.root.glob('collect_*/*/trajectory.pt'))
    train_paths=[p for p in paths if p.parent.name.split('_')[0] in train_ids]
    cal_paths=[p for p in paths if p.parent.name.split('_')[0] in cal_ids]
    for label,ids,pp in [('train',train_ids,train_paths),('calibration',cal_ids,cal_paths)]:
        present={q.parent.name.split('_')[0] for q in pp}
        if present!=ids:raise ValueError(f'{label}: missing trajectory molecules {ids-present}')
    train=pack_records(train_rows,device);cal=pack_records(cal_rows,device)
    td=trajectory_table(train_paths,train_rows,device,a.output/'train_features.pt')
    cd=trajectory_table(cal_paths,cal_rows,device,a.output/'calibration_features.pt')
    td=table_to_device(td,device);cd=table_to_device(cd,device)
    frozen=load_connection(a.checkpoint,device);teacher=frozen['runtime_model'];saved=frozen['saved']
    if saved['contract']!=cached['contract']:raise ValueError('Source model/cache vocabulary or split contract differs')
    model=TimeConnectionPredictor(saved['legacy_state']).to(device);model.load_state_dict(saved['model'],strict=True)
    clean=candidate_features(cal['chem'],cal['noise']['T0'],cal['noise']['R0'],torch.zeros(len(cal_rows),device=device),half=False)
    baseline,thresholds,best=calibrate(teacher,cal,cd,clean)
    history=[dict(epoch=0,val=baseline,thresholds=thresholds,selection_score=best,low_noise_guard=True)]
    baseline_payload=dict(saved,thresholds=thresholds,epoch=0,history=history,calibration_molecules=cohorts['calibration'],
        source_checkpoint_sha256=digest(a.checkpoint),weights_changed=False)
    torch.save(baseline_payload,a.output/'baseline_calibrated.pt')
    best_epoch=0
    regularizers=[r for r in cached['rows'] if r['id'] not in cal_ids]
    rng=np.random.default_rng(7401);regularizers=[regularizers[i] for i in rng.choice(len(regularizers),512,replace=False)]
    reg=pack_records(regularizers,device);diffuser=make_official_diffuser(a.output,device)
    opt=torch.optim.AdamW([v for v in model.parameters() if v.requires_grad],lr=a.lr,weight_decay=.0001)
    y=train['y'][td['indices']].long();sy=train['stereo'][td['indices']].long()
    counts=torch.bincount(y,minlength=3).float();weights=(counts.max()/counts.clamp_min(1)).sqrt().clamp(max=30)
    frame_weight=torch.bincount(td['frame'],minlength=len(td['frames'])).float().clamp_min(1).reciprocal()[td['frame']]
    frame_weight=frame_weight/frame_weight.mean()
    context=model.context(train['chem']).detach();regcontext=model.context(reg['chem']).detach()
    source_hash={n:digest(bootstrap.PROJECT/n) for n in ['adapt_connection_trajectories.py','trajectory_connections.py','robust_connection_model.py']}
    protocol=dict(train_ids=cohorts['train'],calibration_ids=cohorts['calibration'],casf_intersection=0,
        train_trajectories=len(train_paths),calibration_trajectories=len(cal_paths),train_frames=len(td['frames']),calibration_frames=len(cd['frames']),
        train_feature_rows=len(y),candidate_policy='Top64/32A at all t; no target inserted',source_sha256=source_hash,
        source_checkpoint_sha256=digest(a.checkpoint),epochs=a.epochs,lr=a.lr,batch_rows=a.batch_rows,
        loss='Trajectory weighted CE + .5 forward-marginal CE + .5 clean/low-time teacher KL + .2 double-bond stereo CE',
        selection='Non-CASF cached trajectory bins; threshold calibration on same 24 calibration molecules; clean F1 guard -2pp',
        identity_updates=False,backbone_trained=False,teacher_frozen=True,regularizer_ids=[r['id'] for r in regularizers],
        trajectory_sources='Oracle and wrong-topology closed-loop native trajectories; pre-guard and tree-guard collector source hashes retained in collection reports',
        feature_contracts=dict(train=td['contract'],calibration=cd['contract']))
    write_json(a.output/'protocol.json',protocol)
    def payload(epoch):
        return dict(model=model.state_dict(),legacy_state=saved['legacy_state'],optimizer=opt.state_dict(),epoch=epoch,
            history=copy.deepcopy(history),thresholds=thresholds,contract=cached['contract'],architecture='TimeConnectionPredictor-v1',
            source_checkpoint_sha256=digest(a.checkpoint),source_sha256=source_hash,best_epoch=best_epoch,best_score=best)
    torch.save(payload(0),a.output/'best.pt');started=time.time()
    for epoch in range(1,a.epochs+1):
        model.train();torch.manual_seed(7500+epoch);order=torch.randperm(len(y),device=device)
        rt=torch.rand(len(regularizers),device=device)*.9
        rt[torch.rand_like(rt)<.25]=0.
        T,R=noisy_frames(reg,diffuser,rt,seed=7600+epoch)
        rf=candidate_features(reg['chem'],T,R,rt,topk=64,cutoff=32.,half=True)
        ry=reg['y'][rf['indices']].long();loss_sum=total=0.
        for start in range(0,len(y),a.batch_rows):
            selected=order[start:start+a.batch_rows];opt.zero_grad(set_to_none=True)
            chosen=torch.randint(len(ry),(min(len(selected)//2+1,32768),),device=device)
            with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=='cuda'):
                logits,stereo=model(train['chem'],td,context,selected)
                w=frame_weight[selected]
                ce=F.cross_entropy(logits,y[selected],weight=weights,reduction='none')
                loss=(ce*w).sum()/(weights[y[selected]]*w).sum().clamp_min(1e-8)
                extra,_=model(reg['chem'],rf,regcontext,chosen)
                with torch.no_grad():target,_=teacher(reg['chem'],rf,regcontext,chosen)
                loss=loss+.5*F.cross_entropy(extra,ry[chosen],weight=weights)
                low=rf['t'][chosen]<=.05
                if low.any():loss=loss+.5*F.kl_div(extra[low].float().log_softmax(-1),target[low].float().softmax(-1),reduction='batchmean')
                double=y[selected]==2
                if double.any():loss=loss+.2*F.cross_entropy(stereo[double],sy[selected][double])
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
            loss_sum+=float(loss.detach())*len(selected);total+=len(selected)
        model.eval();metrics,thresholds,score=calibrate(model,cal,cd,clean)
        guard=metrics['0.0']['f1']>=baseline['0.0']['f1']-.02
        history.append(dict(epoch=epoch,train_loss=loss_sum/max(1,total),val=metrics,thresholds=thresholds,
            selection_score=score,low_noise_guard=guard,elapsed_seconds=time.time()-started))
        if guard and score>best:best=score;best_epoch=epoch;torch.save(payload(epoch),a.output/'best.pt')
        torch.save(payload(epoch),a.output/'latest.pt');write_json(a.output/'history.json',history)
        write_json(a.output/'status.json',dict(status='running',epoch=epoch,best_epoch=best_epoch,best_score=best))
        print(json.dumps(history[-1]),flush=True)
    write_json(a.output/'status.json',dict(status='complete',epoch=a.epochs,best_epoch=best_epoch,best_score=best,elapsed_seconds=time.time()-started))


if __name__=='__main__':main()
