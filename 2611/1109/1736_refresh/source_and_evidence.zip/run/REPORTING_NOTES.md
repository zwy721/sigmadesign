# Reporting notes

The frozen generator preserves legacy `native_final` storage names. This analysis corrects the semantic terminal-stage label for Full_guidance to `local_projection`, since its last network step is followed by explicit projection. No coordinates, chemistry, scores, thresholds, weights, run configuration or frozen source is changed.

Additional audits distinguish exact identity-probability changes, unlocked discrete proposals, and actually selected chemistry/acceptance changes; see `PREDICTION_DIVERGENCE.csv`. `POSTHOC_REFERENCE_DRIFT.csv` describes the independent end-only reference. Projection caps, rigid invariants, seven historical rejections, and locked selected chemistry are checked in `additional_verification.json`. Seven rejected proposals have offline-only diagnostics and remain rejected.

Run after the frozen driver to reproduce these reporting corrections and additional checks:

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B dynamic_update_rigid_projection/analysis/rejected_events.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B dynamic_update_rigid_projection/analysis/final_checks.py
```
