# Dynamic update rigid projection

Completed controlled diagnostic from `2611/1109/1736_refresh/prompt.md`. No new training or 216-run formal comparison.

| Regime | Stage | HQ /32 | PB /32 | Bond MAE Å | Angle MAE ° | Same final chemistry /32 | Unavailable |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Baseline | native_final | 2 | 3 | 0.1736 | 12.22 | 32 | 0 |
| Baseline | posthoc_MMFF_repair | 28 | 28 | 0.0368 | 5.31 | 32 | 0 |
| Projection_locked | native_final | 3 | 4 | 0.1603 | 11.78 | 32 | 0 |
| Projection_closedloop | native_final | 3 | 6 | 0.1570 | 12.20 | 1 | 0 |
| Feasibility | native_final | 2 | 4 | 0.1603 | 11.88 | 0 | 0 |
| Full_guidance | local_projection | 8 | 11 | 0.0509 | 6.30 | 0 | 0 |

Read `UPDATE_GEOMETRY_AUDIT.md`, `RIGID_PROJECTION_METHOD.md`, `PROJECTION_ABLATION_RESULTS.md`, `QUALITY_BREAKDOWN.md`, `A100_PERFORMANCE.md`, and `NEXT_STEP_DECISION.md`. `completion_verification.json` checks all frozen inputs, weights, sources, stage gates and denominators.

Reproduce from workspace root using the historical Python environment and a free GPU:

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B -m pytest -q dynamic_update_rigid_projection/tests/
CUDA_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B dynamic_update_rigid_projection/source/driver.py --through complete
```

Completed immutable stages are reused only after hash verification. Raw molecular structures, graph tensors, native/projection trajectories, full QC details, model caches, logs and failure evidence remain local. GitHub delivery, when requested, should retain a compact set of reports/configs/code/tables/manifests.

Full_guidance 的终态位于最后一次显式投影之后，语义阶段为 `local_projection`；存储目录/QC组名 `native_final` 仅为历史接口兼容。最后一次网络输出另存于 `trajectory/step_23.npz` 和 `projections/step_23_full.npz`。

Additional terminal-stage semantics, divergence/motion audits and reproduction commands are in `REPORTING_NOTES.md`; run both analysis scripts after the frozen driver.
