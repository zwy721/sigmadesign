# Dynamic-update geometry audit

This isolated study leaves the current v5 orientation recovery, semantic edge random streams, original model files, weights, historical artifacts, and frozen HQ thresholds unchanged. `frozen_inputs.json` records the read-only inputs. No new training or 216-attempt formal comparison is authorized here.

## Where chemistry changes

At steps 5/10/15/20, current generated real-core coordinates and transported orientation anchors define T/R. The frozen identity head consumes centered generated T and R; sample-local categorical draws determine identities. The frozen connection head and unchanged `SearchConfig` generate complete legal graphs, including attachment atom indices, bond order, and stereo. `chemical_graph` assembles those predictions and reconstructs all model features, fragment masks, helper nodes, and cross-fragment chemical edges. Neither bound ligand angles nor true identities/connections are supplied.

Unchanged identities retain current core coordinates as placement targets. Changed identities place the new template about the old fragment centroid using the explicitly predicted template-to-world R. The current `orientation.construct_state` corrects the template/reference coordinate-chart mismatch before rigid reference transfer. Its resulting C/Q position the newly constructed graph. Only then is the maximum fragment fit tested against the frozen 0.5 Å acceptance bound. Failure retains the old complete graph and state. The next batched SigmaDock call recomputes dynamic edges from the new graph/current coordinates and consumes the new chemical edges and atom features.

## Recorded-state reconstruction

The previous current-method 32 stress samples contain 128 events: 121 accepted and seven rejected by reference-transfer fit. All 128 change both identity and connection; identity-only, connection-only, and no-change strata therefore have zero observations. Every event has before coordinates/T/R/C/Q, proposed reference targets, actual transferred core coordinates/C/Q, and subsequent native trajectory files.

Redrawing an RDKit reference with the same integer seed failed the exact reference audit (first attempted maximum atom discrepancy 0.149861 Å). This study reconstructs the complete predicted chemistry from the recorded identities, ports, order and stereo, installs the recorded reference core coordinates, rebuilds the official graph, and restores the recorded C/Q. It does not regenerate a replacement reference. All 121 accepted states reproduce the next historical network step with zero atom-coordinate difference; see `event_replay_verification.json`. Historical trajectories after a later accepted topology change are distinct from this study's locked-graph T2 continuation.

## Attribution and evaluation

Saved metrics distinguish the new graph's intended placement, actual reference transfer, explicit projection, and subsequent denoising. Comparing pre-update and post-update averages across different molecules alone is not a causal geometry comparison. The target/transfer comparison and A/B/C/D comparisons use identical new chemistry.

The old lightweight trajectory metric applies 0.6×VDW to all cross-fragment pairs beyond 1–3. Frozen HQ already uses topology-specific RDKit distance bounds for 1–4. The projector excludes 1–2/1–3 from nonbonded repulsion, uses 0.7×DG lower bounds for 1–4 and 0.6×VDW for longer pairs. This is a repulsive feasibility surrogate, not full MMFF energy. Both the legacy trajectory diagnostics and unchanged full HQ checks are reported; they must not be conflated.

Pockets are ligand-defined, and the six known pockets/32 diagnostic samples have been viewed previously. This is a controlled diagnostic, not untouched-pocket generalization or evidence of unrestricted free de novo generation.
