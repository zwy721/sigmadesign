# A100 performance

One physical A100 GPU, FP32 frozen weights/interfaces with the unchanged verified v5 higher-precision contraction path. Every time step uses one true PyG batched backbone forward, followed by original sample mechanics. Four CPU search workers, eight independent projection workers, and eight QC workers are used. Invariant protein data are cached.

| Regime | Batch | Generation wall s | Molecules/s | Backbone s | Molecule-steps/s backbone | Projection calls | Projection CPU-worker s | Peak GiB | OOM splits |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Baseline | 32 | 85.48 | 0.374 | 15.31 | 50.16 | 0 | 0.00 | 5.22 | 0 |
| Projection_locked | 32 | 86.52 | 0.370 | 15.46 | 49.68 | 121 | 5.14 | 5.22 | 0 |
| Projection_closedloop | 32 | 88.13 | 0.363 | 14.85 | 51.73 | 116 | 5.02 | 5.22 | 0 |
| Feasibility | 32 | 186.56 | 0.172 | 15.18 | 50.59 | 120 | 7.39 | 5.22 | 0 |
| Full_guidance | 32 | 99.11 | 0.323 | 15.18 | 50.60 | 768 | 31.28 | 5.22 | 0 |

Batch16/32 gate compares identical 32 recorded states over three continuation steps. Dynamic b4/b8 prechecks cover all five regimes before scaling. `batch16_32_gate.json`, `precheck8_verification.json`, batch timing files and comparison files preserve the original numerical gates (0.025 Å maximum atom, 0.005 Å RMSD, 0.0002 Å internal-distance).

Generation wall time includes identity queries, CPU connection search, candidate assembly, state transfer, projection waits, trajectory IO, and batched diffusion. It excludes later full QC/end-only reference repair. Backbone throughput measures network GPU event time only. CPU-worker seconds overlap and are not additive wall time; candidate scoring in Feasibility is listed separately in `PERFORMANCE.csv`. Baseline/locked modes still execute identity and connection prediction to observe divergence; recorded reference/decisions are replayed. Model initialization, development selection, event studies and prechecks are separate costs.

There remain CPU↔GPU state transfers at graph revisions and candidate construction. This is measured implementation overhead; no claim of a fully GPU-resident projector is made. These are sequential regime timings on a possibly shared server, not randomized performance trials. No performance threshold or quality criterion was relaxed.

Memory peaks above are cumulative process maxima up to each regime; CUDA peak counters were not reset per regime. VocabLibrary retains invariant template definitions; RDKit molecule copies and graph references are still reconstructed as needed.
