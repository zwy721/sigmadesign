import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import common
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
from oracle_graph import export_oracle
from projection import project,Terms
import pytest

CONFIG=dict(iterations=20,learning_rate=.02,step_translation_A=.04,step_rotation_rad=.02,max_translation_A=.4,max_rotation_rad=.24,weights=[1.,1.,20.,20.,.02])

@pytest.fixture
def example(tmp_path):
    h=Chem.AddHs(Chem.MolFromSmiles('CCCCCC'));AllChem.EmbedMolecule(h,randomSeed=871);AllChem.MMFFOptimizeMolecule(h);m=Chem.RemoveHs(h)
    groups=[[0,1],[2,3],[4,5]];cuts=[m.GetBondBetweenAtoms(1,2).GetIdx(),m.GetBondBetweenAtoms(3,4).GetIdx()]
    spec=export_oracle(m,groups,cuts,labels=[0,0,0]);x=m.GetConformer().GetPositions()
    pdb=tmp_path/'protein.pdb';pdb.write_text('ATOM      1  CA  ALA A   1      40.000  40.000  40.000  1.00 20.00           C\nEND\n')
    return spec,dict(pdb_path=str(pdb)),x,groups

def test_stretched_bond_and_rigidity(example):
    spec,ctx,x,groups=example;x=x.copy();direction=x[2]-x[1];x[groups[1]]+=direction/np.linalg.norm(direction)*.3
    t=Terms(spec,ctx,x,[1],CONFIG);r=project(spec,ctx,x,[1],CONFIG,'B')
    assert r['status']=='projected' and r['final_energy']<r['initial_energy']
    assert np.allclose(r['xyz'][groups[0]],x[groups[0]]) and np.allclose(r['xyz'][groups[2]],x[groups[2]])
    for g in groups:assert np.allclose(np.linalg.norm(r['xyz'][g][:,None]-r['xyz'][g][None,:],axis=-1),np.linalg.norm(x[g][:,None]-x[g][None,:],axis=-1),atol=1e-9)
    assert r['translation_max_A']<=CONFIG['max_translation_A']+1e-10
    assert r['rotation_max_rad']<=CONFIG['max_rotation_rad']+1e-10
    assert all(v['step_translation_A']<=CONFIG['step_translation_A']+1e-10 and v['step_rotation_rad']<=CONFIG['step_rotation_rad']+1e-10 for v in r['trace'])
    for q in r['R']:assert np.allclose(q.T@q,np.eye(3),atol=1e-10) and np.linalg.det(q)>.99999

def test_angle_distortion_reduces_energy(example):
    spec,ctx,x,groups=example;x=x.copy();x[groups[1],2]+=.3
    r=project(spec,ctx,x,[1],CONFIG,'B');assert r['status']=='projected' and r['final_energy']<r['initial_energy']

def test_topology_exclusions_and_onefour(example):
    spec,ctx,x,groups=example;t=Terms(spec,ctx,x,[0,1,2],CONFIG);top=Chem.GetDistanceMatrix(t.mol)
    assert t.pairs and all(top[int(i),int(j)]>=3 for i,j,_ in t.pairs)
    assert any(top[int(i),int(j)]==3 for i,j,_ in t.pairs)

def test_internal_collision_reduction(example):
    spec,ctx,x,groups=example;x=x.copy();x[groups[2]]+=x[0]-x[4]+np.array([.1,0,0])
    cfg=dict(CONFIG,weights=[0.,0.,30.,0.,.001]);r=project(spec,ctx,x,[2],cfg,'C')
    assert r['status']=='projected' and r['final_energy']<r['initial_energy']

def test_protein_overlap_no_new_pairs(example,tmp_path):
    spec,ctx,x,groups=example;p=x[4]+np.array([.3,0,0]);pdb=tmp_path/'clash.pdb'
    pdb.write_text(f'ATOM      1  CA  ALA A   1    {p[0]:8.3f}{p[1]:8.3f}{p[2]:8.3f}  1.00 20.00           C\nEND\n');ctx=dict(pdb_path=str(pdb))
    cfg=dict(CONFIG,weights=[0.,0.,0.,100.,.001]);r=project(spec,ctx,x,[2],cfg,'D');t=Terms(spec,ctx,x,[2],cfg)
    before=np.maximum(t.limits-np.linalg.norm(x[:,None]-t.protein[None],axis=-1),0);after=np.maximum(t.limits-np.linalg.norm(r['xyz'][:,None]-t.protein[None],axis=-1),0)
    assert np.sum(after*after)<=np.sum(before*before)+1e-8
    assert not np.any((before<=1e-6)&(after>1e-5))

def test_identity_and_invalid_fallback(example):
    spec,ctx,x,groups=example;r=project(spec,ctx,x,[1],CONFIG,'A');assert np.array_equal(x,r['xyz'])
    bad=x.copy();bad[0,0]=np.nan;r=project(spec,ctx,bad,[1],CONFIG,'D');assert r['status']=='fallback' and r['reason']
