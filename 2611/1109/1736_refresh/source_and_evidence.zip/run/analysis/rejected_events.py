"""Offline diagnostics only: never promote historical rejected proposals."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
import torch
from runtime import Geometry
from projection import project,metadata

def main():
    torch.set_num_threads(1);config=load(OUT/'frozen_projection.json')['config'];rows=[]
    for e in load(OUT/'event_inventory.json')['events']:
        if e['accepted']:continue
        folder=OUT/'events'/e['event_id'];saved=torch.load(folder/'event.pt',weights_only=False,map_location='cpu');x=np.load(folder/'stages.npz')['actual_xyz'];g=Geometry(saved['spec'],saved['case']['context'])
        r=project(saved['spec'],saved['case']['context'],x,e['changed_slots'],config,'D')
        out=OUT/'rejected_diagnostics'/e['event_id'];out.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(out/'T0_T1_offline_only.npz',rejected_proposal=x,offline_local_projection=r['xyz'])
        row=dict(event_id=e['event_id'],pid=e['pid'],seed=e['seed'],step=e['step'],historical_accepted=False,current_accepted=False,
            historical_rejection=e['reason'],maximum_reference_fit_RMSD_A=max(e['historical']['transfer_fit_rmsd_A']) if e['historical'].get('transfer_fit_rmsd_A') else max(a['actual_transfer_RMSD_A'] for a in e['historical']['reference_transfer_orientation']),
            T0=g.metrics(x),offline_T1=g.metrics(r['xyz']),projection=metadata(r),T2=None,
            interpretation='Rigid fragment motion cannot change intrinsic template/reference shape mismatch; no network continuation or acceptance change.')
        rows.append(row);dump(out/'diagnostic.json',row)
    assert len(rows)==7 and not any(r['current_accepted'] for r in rows)
    dump(OUT/'rejected_event_diagnostics.json',dict(accepted=0,rejected=7,rows=rows,frozen_projection_sha256=sha256(OUT/'frozen_projection.json'),source_sha256=sha256(__file__)))
    csvwrite(OUT/'REJECTED_EVENT_DIAGNOSTICS.csv',rows)
    print('Rejected-event offline diagnostics complete; all seven remain rejected.')

if __name__=='__main__':main()
