"""Supplement frozen run with complete discrete/probability divergence audit."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from common import *
from joint_sampler import topology_key
from rdkit import Chem
import csv

def finish_reports():
    # native_final is the legacy storage/QC group. Full-guidance terminal
    # coordinates are explicitly AFTER the final optimizer, so label them so.
    for name in ['PAIRED_GENERATION_RESULTS.csv','QUALITY_CHECKS.csv','QUALITY_BREAKDOWN.csv']:
        path=OUT/name
        with path.open(newline='') as h:
            reader=csv.DictReader(h);fields=reader.fieldnames;records=list(reader)
        for r in records:
            if r.get('mode')=='Full_guidance' and r.get('stage') in ['native_final','native_after_remaining_denoising']:r['stage']='local_projection'
        with path.open('w',newline='') as h:
            writer=csv.DictWriter(h,fieldnames=fields);writer.writeheader();writer.writerows(records)
    summary=load(OUT/'summary.json')
    for r in summary['full_generation']:
        r['terminal_state_stage']='local_projection' if r['mode']=='Full_guidance' else 'posthoc_MMFF_repair' if r['stage']=='posthoc_MMFF_repair' else 'native_after_remaining_denoising'
    dump(OUT/'summary.json',summary)
    for path in [OUT/'QUALITY_BREAKDOWN.md',OUT/'README.md',ROOT/'2611/1109/1736_refresh/README.md']:
        text=path.read_text().replace('| Full_guidance | native_final |','| Full_guidance | local_projection |')
        note='Full_guidance 的终态位于最后一次显式投影之后，语义阶段为 `local_projection`；存储目录/QC组名 `native_final` 仅为历史接口兼容。最后一次网络输出另存于 `trajectory/step_23.npz` 和 `projections/step_23_full.npz`。'
        if note not in text:text+='\n'+note+'\n'
        path.write_text(text)
    path=OUT/'A100_PERFORMANCE.md';text=path.read_text()
    note='Memory peaks above are cumulative process maxima up to each regime; CUDA peak counters were not reset per regime. VocabLibrary retains invariant template definitions; RDKit molecule copies and graph references are still reconstructed as needed.'
    if note not in text:path.write_text(text+'\n'+note+'\n')
    path=OUT/'PROJECTION_ABLATION_RESULTS.md';text=path.read_text()
    note='Seven historically rejected proposals were additionally projected offline with the same frozen D parameters (`REJECTED_EVENT_DIAGNOSTICS.csv`). All remain rejected, with no T2 continuation. Rigid fragment motion cannot remove intrinsic template/reference shape mismatch behind the original 0.5 Å fit rejection.'
    if note not in text:path.write_text(text+'\n'+note+'\n')
    path=OUT/'NEXT_STEP_DECISION.md';text=path.read_text()
    note='''## 中文决策结论

本轮仅在动态更新时投影的收益有限：固定化学图的完整生成 HQ 从 2/32 到 3/32；闭环投影也是 3/32。四候选重排仍为 2/32，生成耗时约为基线的 2.18 倍，当前规则不宜直接扩大。全程引导达到 8/32，耗时约为基线的 1.16 倍；但它包含末步显式投影，且最终化学图与基线全部不同，不能归因于网络自身学会修复，也不能作为固定图的因果比较。末端 MMFF 参考 28/32 使用更长优化和更宽运动约束，单独计分。

误差在新身份/端口的初始放置阶段已很大：键长 MAE 1.0444 Å，参考转移后 1.0559 Å。D 投影降至 0.7266 Å，后续网络降至 0.0952 Å；未投影续跑也达到 0.1008 Å。均值更支持“基线去噪追上了投影收益”，不支持“网络普遍破坏已修复的键长”。Step 20 的残余误差更大，但事件内容和接受筛选不同，尚不能证明更新时间的因果效应。

建议暂不启动辅助监督训练。优先在另行确认、独立开发选参的新实验中，区分端口/连接选择与新模板放置，检查更新时间及持续几何引导，并建立满足运动、蛋白和立体约束的可靠教师样本。当前候选的局部受限修复失败不等于化学图不存在可行构象。保留当前朝向恢复算法及全部冻结证据。
'''
    if '## 中文决策结论' not in text:path.write_text(text+'\n'+note)
    note='''# Reporting notes

The frozen generator preserves legacy `native_final` storage names. This analysis corrects the semantic terminal-stage label for Full_guidance to `local_projection`, since its last network step is followed by explicit projection. No coordinates, chemistry, scores, thresholds, weights, run configuration or frozen source is changed.

Additional audits distinguish exact identity-probability changes, unlocked discrete proposals, and actually selected chemistry/acceptance changes; see `PREDICTION_DIVERGENCE.csv`. `POSTHOC_REFERENCE_DRIFT.csv` describes the independent end-only reference. Projection caps, rigid invariants, seven historical rejections, and locked selected chemistry are checked in `additional_verification.json`. Seven rejected proposals have offline-only diagnostics and remain rejected.

Run after the frozen driver to reproduce these reporting corrections and additional checks:

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B dynamic_update_rigid_projection/analysis/rejected_events.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH="$PWD/.quality_deps:$PWD" ../.venv-cutoff-train/bin/python -B dynamic_update_rigid_projection/analysis/final_checks.py
```
'''
    (OUT/'REPORTING_NOTES.md').write_text(note)
    path=OUT/'README.md';text=path.read_text()
    extra='Additional terminal-stage semantics, divergence/motion audits and reproduction commands are in `REPORTING_NOTES.md`; run both analysis scripts after the frozen driver.'
    if extra not in text:path.write_text(text+'\n'+extra+'\n')

def main():
    protocol=load(OUT/'protocol.json');cases=protocol['main_cases'];config=load(OUT/'frozen_projection.json')['config'];rows=[];motion=[];posthoc=[]
    hist={(e['pid'],e['seed'],e['step']):e for e in load(OUT/'event_inventory.json')['events']}
    for mode in protocol['full_arms']:
        for case in cases:
            folder=OUT/'full32/b32/structures'/f'{case["pid"]}_{case["seed"]}_{mode}';rec=load(folder/'result.json');basefolder=folder.with_name(f'{case["pid"]}_{case["seed"]}_Baseline');base=load(basefolder/'result.json')
            first_probs=first_discrete=first_selected=None;max_prob=0.;rejects=0
            for e,old in zip(rec['events'],base['events']):
                step=e['step'];h=hist[(case['pid'],case['seed'],step)]
                if not h['accepted']:
                    assert not e['accepted'];rejects+=1
                x=np.load(folder/f'identity_{step:02d}.npz')['model_probabilities'];y=np.load(basefolder/f'identity_{step:02d}.npz')['model_probabilities'];delta=float(np.abs(x-y).max());max_prob=max(max_prob,delta)
                if delta>0 and first_probs is None:first_probs=step
                search=load(folder/f'search_{step:02d}.json');same=bool(search['candidates']) and topology_key(e['unlocked_proposed_labels'],search['candidates'][0]['connections'])==topology_key(h['new_labels'],h['new_connections'])
                if not same and first_discrete is None:first_discrete=step
                same_selected=e['accepted']==old['accepted'] and topology_key(e['new_labels'],e['new_connections'])==topology_key(old['new_labels'],old['new_connections'])
                if not same_selected and first_selected is None:first_selected=step
            if mode in ['Baseline','Projection_locked']:assert first_selected is None
            for projection in rec.get('projections',[]):
                assert projection.get('translation_max_A',0.)<=config['max_translation_A']+1e-8
                assert projection.get('rotation_max_rad',0.)<=config['max_rotation_rad']+1e-8
                assert projection.get('internal_distance_delta_A',0.)<1e-8
                for t in projection.get('trace',[]):
                    assert t['step_translation_A']<=config['step_translation_A']+1e-8 and t['step_rotation_rad']<=config['step_rotation_rad']+1e-8
                motion.append(dict(projection,pid=case['pid'],seed=case['seed'],mode=mode))
            rows.append(dict(pid=case['pid'],seed=case['seed'],mode=mode,first_exact_probability_divergence_step=first_probs,max_probability_delta=max_prob,
                first_unlocked_discrete_proposal_divergence_step=first_discrete,first_selected_chemistry_or_acceptance_divergence_step=first_selected,historical_rejections_preserved=rejects))
            if mode=='Baseline':
                read=lambda st:next(m for m in Chem.SDMolSupplier(str(folder/st/'raw.sdf'),removeHs=False) if m is not None)
                native,repaired=read('native_final'),read('posthoc_MMFF_repair');x=native.GetConformer().GetPositions();y=repaired.GetConformer().GetPositions()
                posthoc.append(dict(pid=case['pid'],seed=case['seed'],core_RMSD_A=float(np.sqrt(np.mean(np.sum((x-y)**2,axis=-1)))),max_atom_delta_A=float(np.linalg.norm(x-y,axis=-1).max()),stage='posthoc_MMFF_repair'))
    assert len(rows)==160
    csvwrite(OUT/'PREDICTION_DIVERGENCE.csv',rows);csvwrite(OUT/'PROJECTION_MOTION.csv',motion);csvwrite(OUT/'POSTHOC_REFERENCE_DRIFT.csv',posthoc)
    dump(OUT/'additional_verification.json',dict(passed=True,attempts=160,historical_rejections_held_per_regime=7,all_projection_caps_verified=True,all_internal_rigid_distances_verified=True,
        locked_selected_chemistry_identical=True,source_sha256=sha256(__file__),frozen_projection_sha256=sha256(OUT/'frozen_projection.json'),probability_scope='Exact numerical change, separate from discrete prediction and actual accepted chemistry change.'))
    finish_reports()
    print('Additional semantic-divergence and bounded-motion checks passed.')

if __name__=='__main__':main()
