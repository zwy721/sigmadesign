# Next-step decision

## Evidence and answers

1. Chemistry changes at complete predicted-graph construction; the new template placement and rigid reference transfer create T0. On the same new chemistry, intended-placement bond MAE is already 1.0444 Å, versus 1.0559 Å after transfer; mean transfer coordinate RMSD is 0.0920 Å. Most instantaneous bond error therefore exists before reference transfer, in the proposed identity/ports plus their placement. This does not distinguish connection ranking from template placement causally, but does not support blaming reference-frame transfer alone.
2. With identical chemistry, D changes mean cross-bond MAE from 1.0559 Å (T0) to 0.7266 Å (explicit projection T1). Its locked T2 is 0.0952 Å, versus 0.1008 Å for A. This is partial repair: most immediate bond error remains within the caps/protein safeguard. Reaching an optimizer iteration limit or a lower objective is not a geometry pass.
3. A→B tests bonds/angles jointly; B→C adds internal repulsion; C→D adds protein and pose prior jointly. The detailed table identifies these marginal changes. This experiment cannot rank bond-only versus angle-only causal contributions.
4. Every accepted projection is capped at 0.5 Å and 0.3 rad per fragment per invocation; exact SO(3), rigidity and protein safeguards apply. D mean core RMSD is 0.2872 Å and maximum single-atom displacement is 1.3618 Å. Rotation can move distal atoms more than the translation cap; the result is not universally negligible motion. Full-time repeated guidance can accumulate larger total motion.
5. D improves further from T1 0.7266 Å to T2 0.0952 Å; A also reaches 0.1008 Å without projection. The final mean same-graph advantage is only 0.0056 Å, much smaller than the immediate gain 0.3293 Å. This indicates baseline denoising catches up on average, rather than demonstrating that SigmaDock generally destroys a successful bond repair. Individual worsening and angle/collision behavior must be read separately from the saved trajectories.
6. Update-only locked Projection has HQ 3/32; all-step guidance has HQ 8/32; Baseline is 2/32. All-step guidance is an auxiliary closed-loop algorithm comparison with a larger intervention budget and potentially different chemistry, so this is not a fixed-graph attribution. See performance/drift and original predicted-stereo checks before choosing a regime.
7. Feasibility examined 484 retained legal candidates, of which 475 either failed transfer or remained outside the declared geometry diagnostic at their projected pose. These are local capped-search failures, not proofs that a chemical graph has no feasible embedding. Historical seven transfer rejects remain rejected in every regime.
8. Immediate errors are dominated by proposed chemistry/placement; small rigid projection cannot eliminate most of them, while denoising repairs much of the bond error. Locked A final bond MAE by steps 5/10/15/20 is [0.0665, 0.0898, 0.0724, 0.1903] Å (D: [0.0678, 0.0839, 0.0666, 0.177]). Treat any late-step excess as an association: identities and connection content differ across events. Reference transfer is a smaller incremental bond-error source in these saved states; full-generation candidate ranking, stereo/protein failures, and continuation residuals determine the final HQ bottleneck.
9. Do not start training from this diagnostic alone. If a frozen small-motion teacher produces repeatable same-graph gains that survive continuation and improve HQ without extra drift, it is a candidate for later auxiliary supervision. Otherwise prioritize the stage where the recorded errors persist. No new training is performed here.

## Limits and recommendation

All 128 updates are identity-plus-connection events. Other topology-type comparisons are unavailable, and timing strata are confounded by update content. The 32 previously viewed stress inputs across six ligand-defined pockets are not an independent generalization benchmark. Retain the current stable orientation algorithm; virtual anchors are unchanged and no additional virtual atoms are introduced. Preserve this evidence before proposing a new study or changing any frozen formal protocol.

## 中文决策结论

本轮仅在动态更新时投影的收益有限：固定化学图的完整生成 HQ 从 2/32 到 3/32；闭环投影也是 3/32。四候选重排仍为 2/32，生成耗时约为基线的 2.18 倍，当前规则不宜直接扩大。全程引导达到 8/32，耗时约为基线的 1.16 倍；但它包含末步显式投影，且最终化学图与基线全部不同，不能归因于网络自身学会修复，也不能作为固定图的因果比较。末端 MMFF 参考 28/32 使用更长优化和更宽运动约束，单独计分。

误差在新身份/端口的初始放置阶段已很大：键长 MAE 1.0444 Å，参考转移后 1.0559 Å。D 投影降至 0.7266 Å，后续网络降至 0.0952 Å；未投影续跑也达到 0.1008 Å。均值更支持“基线去噪追上了投影收益”，不支持“网络普遍破坏已修复的键长”。Step 20 的残余误差更大，但事件内容和接受筛选不同，尚不能证明更新时间的因果效应。

建议暂不启动辅助监督训练。优先在另行确认、独立开发选参的新实验中，区分端口/连接选择与新模板放置，检查更新时间及持续几何引导，并建立满足运动、蛋白和立体约束的可靠教师样本。当前候选的局部受限修复失败不等于化学图不存在可行构象。保留当前朝向恢复算法及全部冻结证据。
