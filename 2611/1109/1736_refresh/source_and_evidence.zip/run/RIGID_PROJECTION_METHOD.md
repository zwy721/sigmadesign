# Constrained rigid projection method

## Frozen setup

Nine profiles (5/10/20 iterations × three bounded weight/cap settings) were compared only on six disjoint development-pocket cases, containing 23 accepted update events and one rejected event. The minimum mean predeclared geometry-plus-displacement score selected `strong_20`. All 32 stress cases were excluded from parameter selection. `development_grid.json`, `development_selection.json`, `frozen_projection.json` retain every candidate and result.

Selected limits: 20 iterations; per-step translation 0.04 Å and actual relative rotation 0.02 rad; cumulative translation 0.5 Å and rotation 0.3 rad about each T0 real-core centroid. Cumulative limits restart only at a separately recorded projection invocation. Full-time guidance therefore has more invocations; its total drift is not bounded by a single invocation's cap.

## Variables and energy

Only changed identity slots and endpoints of changed connections may move. There is no neighbor expansion selected in this run. Rigid SO(3) matrix exponentials and translations move existing fragment nodes together; protein and unrelated fragments remain fixed. Real-core atoms alone define the objective. MMFF94s predicted-graph equilibrium parameters define cross-fragment bonds and angles. Bond errors are normalized by 0.15 Å; angle cosine errors by 0.25. Repulsive overlaps are squared and summed per real atom. The displacement prior separately normalizes translation by 0.5 Å and rotation by 0.3 rad.

Weights `[bond, angle, internal, protein, displacement]` are `[1.0, 1.0, 40.0, 40.0, 0.02]`. B enables only bonds/angles; C adds internal repulsion; D adds protein and displacement. The hard protein safeguard applies to all three to avoid new severe pairs or worsening maximum overlap. 1–2/1–3 pairs are excluded from repulsion; 1–4 use the frozen local DG lower bound; longer pairs use VDW bounds. This is not a full MMFF potential and does not include independent rotor-energy optimization.

## Solver and safety

Float64 CPU gradients drive bounded descent with five fixed backtracking factors. Each step must lower the enabled objective. SO(3) determinants/orthogonality, finite values, internal-distance preservation, step/cumulative motion and protein safety are checked. Unavailable MMFF parameters or numerical exceptions retain T0 and an explicit reason. A safe point can remain imperfect when caps or the protein guard prevent further descent; this is recorded, not treated as geometric success. Caches retain unchanged protein data; eight worker processes parallelize independent projections. State C/Q and existing helper nodes receive the same rigid transform without editing chemistry or reference transfer.

## Paired regimes and stage labels

All 121 accepted historical events receive A/B/C/D on identical complete chemistry/reference/T0. Seven historical rejects remain rejects. T2 locks that event graph until step 24. `native_before_update`, `native_after_graph_transfer` (T0), `local_projection` (T1), `native_after_remaining_denoising` (T2), and `posthoc_MMFF_repair` are separate evidence stages. T1 is an optimizer result. Complete C/Q/core trajectories are saved under `locked_events/`.

Full generation has 32 initializations per regime: Baseline replays recorded reference graphs and update decisions; Projection_locked uses exactly those chemical updates; Projection_closedloop reruns prediction after projection; Feasibility keeps at most four candidates from unchanged search beams and reranks by projected geometry; Full_guidance applies the same D projector to all fragments after each of 24 network steps (no additional update-time projector). All preserve historical rejected steps. `k=4` changes only final selection from the existing pool, not beam widths/check budget. Candidate raw/reference/after-projection metrics and rank are recorded. Closed-loop or reranking benefits are algorithm-level comparisons, not fixed-graph repair attribution.

Frozen full HQ/PoseBusters checks retain unavailable results and all failures. Existing coordinate-derived stereo scoring is supplemented by original predicted-chemistry stereo checks. End-only historical rigid MMFF repair is evaluated on the 32 Baseline outputs only as an independent reference.
