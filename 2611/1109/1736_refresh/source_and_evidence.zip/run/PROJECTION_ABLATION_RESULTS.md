# Locked-event projection ablation

121 accepted events × four arms = 484 continuations. Seven rejected events are retained separately; none are promoted. Every pair fixes identity, atom order, connection sites/order/stereo and the entire reference graph. T2 has no later identity/connection revisions.

| Arm | Stage | n | Bond MAE Å | Angle MAE ° | Legacy internal pairs | Frozen-QC internal pairs | Protein pairs |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A | T0 | 121 | 1.0559 | 40.26 | 44.347 | 47.397 | 3.942 |
| A | T1 | 121 | 1.0559 | 40.26 | 44.347 | 47.397 | 3.942 |
| A | T2 | 121 | 0.1008 | 8.73 | 0.579 | 0.719 | 1.926 |
| B | T0 | 121 | 1.0559 | 40.26 | 44.347 | 47.397 | 3.942 |
| B | T1 | 121 | 0.7185 | 36.76 | 44.835 | 48.050 | 3.504 |
| B | T2 | 121 | 0.0947 | 8.66 | 0.562 | 0.694 | 2.025 |
| C | T0 | 121 | 1.0559 | 40.26 | 44.347 | 47.397 | 3.942 |
| C | T1 | 121 | 0.7742 | 37.40 | 41.992 | 45.240 | 3.537 |
| C | T2 | 121 | 0.0948 | 8.65 | 0.504 | 0.636 | 2.025 |
| D | T0 | 121 | 1.0559 | 40.26 | 44.347 | 47.397 | 3.942 |
| D | T1 | 121 | 0.7266 | 36.83 | 41.636 | 45.000 | 3.322 |
| D | T2 | 121 | 0.0952 | 8.55 | 0.537 | 0.669 | 1.934 |

| Arm | T1 bond improved /121 | T2 bond better than paired A /121 | Mean T1 RMSD Å | Max translation Å | Max rotation rad | Fallback | No safe descent | Mean CPU s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B | 79 | 47 | 0.2538 | 0.5000 | 0.3000 | 0 | 42 | 0.0717 |
| C | 74 | 40 | 0.2431 | 0.5000 | 0.3000 | 0 | 47 | 0.0602 |
| D | 83 | 44 | 0.2872 | 0.5000 | 0.3000 | 0 | 38 | 0.0648 |

## Update timing

| Step | Arm | n | T0 bond Å | T1 bond Å | T2 bond Å | T2 angle ° |
| --- | --- | --- | --- | --- | --- | --- |
| 5 | A | 31 | 0.7018 | 0.7018 | 0.0665 | 6.59 |
| 5 | B | 31 | 0.7018 | 0.4783 | 0.0679 | 6.65 |
| 5 | C | 31 | 0.7018 | 0.5530 | 0.0675 | 6.53 |
| 5 | D | 31 | 0.7018 | 0.5398 | 0.0678 | 6.52 |
| 10 | A | 32 | 1.7991 | 1.7991 | 0.0898 | 7.48 |
| 10 | B | 32 | 1.7991 | 1.2843 | 0.0782 | 7.50 |
| 10 | C | 32 | 1.7991 | 1.4295 | 0.0844 | 7.48 |
| 10 | D | 32 | 1.7991 | 1.3530 | 0.0839 | 7.41 |
| 15 | A | 32 | 1.1059 | 1.1059 | 0.0724 | 8.49 |
| 15 | B | 32 | 1.1059 | 0.7154 | 0.0723 | 8.52 |
| 15 | C | 32 | 1.1059 | 0.7062 | 0.0673 | 8.62 |
| 15 | D | 32 | 1.1059 | 0.6634 | 0.0666 | 8.52 |
| 20 | A | 26 | 0.5022 | 0.5022 | 0.1903 | 13.10 |
| 20 | B | 26 | 0.5022 | 0.3125 | 0.1746 | 12.66 |
| 20 | C | 26 | 0.5022 | 0.3153 | 0.1743 | 12.64 |
| 20 | D | 26 | 0.5022 | 0.2562 | 0.1770 | 12.42 |

All 128 updates change both identity and connection. Other update-type strata have n=0 and cannot support comparisons. Step strata differ in molecules and update states; lateness associations do not establish that fewer remaining steps cause the errors.

T0→T1 isolates explicit projection. T1→T2 describes subsequent denoising, which can improve some quantities and worsen others. T0→T2 alone cannot attribute improvements to projection: compare with the paired A continuation. `PER_UPDATE_RESULTS.csv` gives paired values, frozen-QC internal clashes, unavailable equilibrium information, drift and fallback reasons. `PROJECTION_TRAJECTORY.csv` retains every measured denoising step; NPZ files retain coordinates/C/Q. B combines bonds and angles, so their individual causal contributions cannot be separated by this four-arm design. C−B tests adding internal repulsion; D−C jointly adds protein/displacement.

Seven historically rejected proposals were additionally projected offline with the same frozen D parameters (`REJECTED_EVENT_DIAGNOSTICS.csv`). All remain rejected, with no T2 continuation. Rigid fragment motion cannot remove intrinsic template/reference shape mismatch behind the original 0.5 Å fit rejection.
