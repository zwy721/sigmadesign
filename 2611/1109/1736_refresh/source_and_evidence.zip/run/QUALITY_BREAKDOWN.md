# Full-generation quality

Five regimes each attempt the same 32 initializations (160 total). Eight-case b4/b8 prechecks are separate (80 generated attempts; 40 b8 QC records). Baseline end-only MMFF repair adds 32 independent reference outputs. Failures and unavailable checks remain in each denominator.

| Regime | Stage | HQ /32 | PB /32 | Bond MAE Å | Angle MAE ° | Same final chemistry /32 | Unavailable |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Baseline | native_final | 2 | 3 | 0.1736 | 12.22 | 32 | 0 |
| Baseline | posthoc_MMFF_repair | 28 | 28 | 0.0368 | 5.31 | 32 | 0 |
| Projection_locked | native_final | 3 | 4 | 0.1603 | 11.78 | 32 | 0 |
| Projection_closedloop | native_final | 3 | 6 | 0.1570 | 12.20 | 1 | 0 |
| Feasibility | native_final | 2 | 4 | 0.1603 | 11.88 | 0 | 0 |
| Full_guidance | local_projection | 8 | 11 | 0.0509 | 6.30 | 0 | 0 |

| Regime | Stage | Check | Pass | Fail | Unavailable | n |
| --- | --- | --- | --- | --- | --- | --- |
| Baseline | native_final | chemical_valid | 32 | 0 | 0 | 32 |
| Baseline | native_final | fully_connected | 32 | 0 | 0 | 32 |
| Baseline | native_final | no_severe_internal_clash | 18 | 14 | 0 | 32 |
| Baseline | native_final | bond_geometry_valid | 19 | 13 | 0 | 32 |
| Baseline | native_final | angle_geometry_valid | 18 | 14 | 0 | 32 |
| Baseline | native_final | ring_geometry_valid | 32 | 0 | 0 | 32 |
| Baseline | native_final | torsion_geometry_valid | 19 | 13 | 0 | 32 |
| Baseline | native_final | no_severe_protein_clash | 17 | 15 | 0 | 32 |
| Baseline | native_final | in_target_pocket | 32 | 0 | 0 | 32 |
| Baseline | native_final | posebusters_all_pass | 3 | 29 | 0 | 32 |
| Baseline | native_final | stereo_definition_complete | 32 | 0 | 0 | 32 |
| Baseline | native_final | stereo_geometry_consistent | 32 | 0 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | chemical_valid | 32 | 0 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | fully_connected | 32 | 0 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | no_severe_internal_clash | 32 | 0 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | bond_geometry_valid | 31 | 1 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | angle_geometry_valid | 31 | 1 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | ring_geometry_valid | 32 | 0 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | torsion_geometry_valid | 32 | 0 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | no_severe_protein_clash | 29 | 3 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | in_target_pocket | 32 | 0 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | posebusters_all_pass | 28 | 4 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | stereo_definition_complete | 32 | 0 | 0 | 32 |
| Baseline | posthoc_MMFF_repair | stereo_geometry_consistent | 32 | 0 | 0 | 32 |
| Projection_locked | native_final | chemical_valid | 32 | 0 | 0 | 32 |
| Projection_locked | native_final | fully_connected | 32 | 0 | 0 | 32 |
| Projection_locked | native_final | no_severe_internal_clash | 16 | 16 | 0 | 32 |
| Projection_locked | native_final | bond_geometry_valid | 23 | 9 | 0 | 32 |
| Projection_locked | native_final | angle_geometry_valid | 17 | 15 | 0 | 32 |
| Projection_locked | native_final | ring_geometry_valid | 32 | 0 | 0 | 32 |
| Projection_locked | native_final | torsion_geometry_valid | 18 | 14 | 0 | 32 |
| Projection_locked | native_final | no_severe_protein_clash | 19 | 13 | 0 | 32 |
| Projection_locked | native_final | in_target_pocket | 32 | 0 | 0 | 32 |
| Projection_locked | native_final | posebusters_all_pass | 4 | 28 | 0 | 32 |
| Projection_locked | native_final | stereo_definition_complete | 32 | 0 | 0 | 32 |
| Projection_locked | native_final | stereo_geometry_consistent | 32 | 0 | 0 | 32 |
| Projection_closedloop | native_final | chemical_valid | 32 | 0 | 0 | 32 |
| Projection_closedloop | native_final | fully_connected | 32 | 0 | 0 | 32 |
| Projection_closedloop | native_final | no_severe_internal_clash | 20 | 12 | 0 | 32 |
| Projection_closedloop | native_final | bond_geometry_valid | 16 | 16 | 0 | 32 |
| Projection_closedloop | native_final | angle_geometry_valid | 24 | 8 | 0 | 32 |
| Projection_closedloop | native_final | ring_geometry_valid | 32 | 0 | 0 | 32 |
| Projection_closedloop | native_final | torsion_geometry_valid | 21 | 11 | 0 | 32 |
| Projection_closedloop | native_final | no_severe_protein_clash | 20 | 12 | 0 | 32 |
| Projection_closedloop | native_final | in_target_pocket | 32 | 0 | 0 | 32 |
| Projection_closedloop | native_final | posebusters_all_pass | 6 | 26 | 0 | 32 |
| Projection_closedloop | native_final | stereo_definition_complete | 28 | 4 | 0 | 32 |
| Projection_closedloop | native_final | stereo_geometry_consistent | 32 | 0 | 0 | 32 |
| Feasibility | native_final | chemical_valid | 32 | 0 | 0 | 32 |
| Feasibility | native_final | fully_connected | 32 | 0 | 0 | 32 |
| Feasibility | native_final | no_severe_internal_clash | 18 | 14 | 0 | 32 |
| Feasibility | native_final | bond_geometry_valid | 18 | 14 | 0 | 32 |
| Feasibility | native_final | angle_geometry_valid | 18 | 14 | 0 | 32 |
| Feasibility | native_final | ring_geometry_valid | 32 | 0 | 0 | 32 |
| Feasibility | native_final | torsion_geometry_valid | 20 | 12 | 0 | 32 |
| Feasibility | native_final | no_severe_protein_clash | 19 | 13 | 0 | 32 |
| Feasibility | native_final | in_target_pocket | 30 | 2 | 0 | 32 |
| Feasibility | native_final | posebusters_all_pass | 4 | 28 | 0 | 32 |
| Feasibility | native_final | stereo_definition_complete | 27 | 5 | 0 | 32 |
| Feasibility | native_final | stereo_geometry_consistent | 32 | 0 | 0 | 32 |
| Full_guidance | local_projection | chemical_valid | 32 | 0 | 0 | 32 |
| Full_guidance | local_projection | fully_connected | 32 | 0 | 0 | 32 |
| Full_guidance | local_projection | no_severe_internal_clash | 24 | 8 | 0 | 32 |
| Full_guidance | local_projection | bond_geometry_valid | 28 | 4 | 0 | 32 |
| Full_guidance | local_projection | angle_geometry_valid | 29 | 3 | 0 | 32 |
| Full_guidance | local_projection | ring_geometry_valid | 32 | 0 | 0 | 32 |
| Full_guidance | local_projection | torsion_geometry_valid | 28 | 4 | 0 | 32 |
| Full_guidance | local_projection | no_severe_protein_clash | 22 | 10 | 0 | 32 |
| Full_guidance | local_projection | in_target_pocket | 32 | 0 | 0 | 32 |
| Full_guidance | local_projection | posebusters_all_pass | 11 | 21 | 0 | 32 |
| Full_guidance | local_projection | stereo_definition_complete | 30 | 2 | 0 | 32 |
| Full_guidance | local_projection | stereo_geometry_consistent | 32 | 0 | 0 | 32 |

| Regime | Stage | Original predicted stereo defined /32 | Original predicted stereo consistent /32 |
| --- | --- | --- | --- |
| Baseline | native_final | 12 | 32 |
| Baseline | posthoc_MMFF_repair | 12 | 32 |
| Projection_locked | native_final | 12 | 32 |
| Projection_closedloop | native_final | 13 | 32 |
| Feasibility | native_final | 5 | 32 |
| Full_guidance | local_projection | 12 | 32 |

Historical HQ uses the frozen coordinate-derived stereo annotation; the original predicted-chemistry stereo checks above are separate and must not be replaced by the derived annotation. `PAIRED_GENERATION_RESULTS.csv` includes all final required checks, original declared stereo checks, exact failure/unavailable lists, chemistry equality, first prediction divergence, and projection costs. Full PoseBusters test dictionaries and geometry/protein/ring/torsion details remain in each `quality_complete.json`. No endpoint repair is included in native/guided HQ. Native/guided shared checkpoint use does not imply any learned repair.

Final atom RMSD is compared only for exactly matching ordered chemistry. Different final chemistry has no valid one-to-one atom-displacement comparison. Reported single-projection RMSDs describe explicit local motion, while full algorithm drift includes subsequent diffusion and changing identities. The legacy cross-fragment pair count is diagnostic; full HQ uses the separately frozen topology-aware check.

Full_guidance 的终态位于最后一次显式投影之后，语义阶段为 `local_projection`；存储目录/QC组名 `native_final` 仅为历史接口兼容。最后一次网络输出另存于 `trajectory/step_23.npz` 和 `projections/step_23_full.npz`。
