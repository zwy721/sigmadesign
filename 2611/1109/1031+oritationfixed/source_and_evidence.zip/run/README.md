# 动态片段朝向稳定性与因果验证

状态见[status.json](status.json)。按[原任务](prompt.md)继续，原360次结果保持只读；目前完成模板秩审计、两条退化拟合路径的复现和9项几何测试，正在执行严格动态预检。

[朝向数学与当前证据](ORIENTATION_ROOT_CAUSE.md) · [完整审计](orientation_audit.json) · [参考转移复现](reference_transfer_audit.json) · [独立数值分歧](numerical_divergence_audit.json) · [逐层定位](layer_numerical_audit.json) · [运行日志](complete_v5.log) · [进程记录](complete_v5_process.json)

正式B/C/E计划216次，动态重复/跨batch验收通过后才启动。官方docking配对核验和C-old小规模消融分别记录分母。没有修改历史权重或使用真实配体决定生成片段朝向。
