# 复现与阶段边界

从工作区根目录运行。科学环境为`../.venv-cutoff-train/bin/python`，额外评价依赖在`.quality_deps/`。真实输入来自历史只读`pose_generation_four_arm_comparison/paired_final/`；84套Oracle输入另有逐字节相同副本及`oracle_input_inventory.json`。

```bash
export CUDA_VISIBLE_DEVICES=0
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONDONTWRITEBYTECODE=1
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=2
export PYTHONPATH="$PWD/.quality_deps:$PWD"
../.venv-cutoff-train/bin/python -B \
  pose_orientation_stability_and_causal_validation/source/progress.py \
  --through complete --namespace v5
```

`--through audit`只做模板/历史实例审计；`gates`做8个压力样本预检；`full-gates`完成C/E各32样本和batch=1/4/8/16/32、重复回放、无更新控制及batch=64探索；`complete`在所有必要门槛通过后追加官方接口小检验、216次B/C/E、24次旧/新朝向消融、144次配对真实图docking、12次NativeState已知参考和12次原始官方参考。各分母独立。严格禁止直接绕过门槛调用正式运行。

同一namespace只复用相同核心源代码下已完成的结构记录。改变任何核心数值代码后必须使用新namespace，保留先前失败；正式开始后`formal_start.json`冻结全部源代码、协议、输入和动态验证摘要。不要在原输出目录里替换协议或模型。

v1/v2为初次扩大诊断与中止记录；v3保留两条朝向路径修复后的独立数值失败；v4追加经同状态单因素审计的FP64消息求和，以及身份头确定性执行设置。没有更改离散采样阈值、删除失败或重抽种子。

`complete_v5_process.json`记录启动PID、命令和启动源代码哈希；`complete_v5.log`为当前执行日志。活性需同时检查宿主机PID及GPU进程，不能只依赖状态JSON。正式统计和报告使用原生终态；质量模块的MMFF优化仅作诊断，不作为生成终态或修复收益。

v4的32样本扩大验证仍有一条坐标RMSD超限；v5采用固定行数32的GPU线性矩阵块，先在保存的32个更新后状态上通过batch=1/4/8/16/32前向逐位一致诊断，再重新验证完整轨迹。
