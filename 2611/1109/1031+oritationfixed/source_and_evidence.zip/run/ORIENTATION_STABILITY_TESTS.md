# 连续朝向的几何验证

当前纯几何测试：**9/9通过**。真实动态轨迹的独立验收状态以`DYNAMIC_REPLAY_VERIFICATION.md`及对应JSON为准，几何单元测试不能替代动态验收。

| 检查 | 验证内容 |
|---|---|
| 单原子 | 不虚构主轴，保留运输后的参考朝向，平移正确 |
| 两原子 | 严格对齐主轴；与一组可行绕轴旋转比较，选择SO(3)距离最小解 |
| 非退化和平面 | 保留原有proper Kabsch，避免反射 |
| 反平行与全局变换 | 明确平局规则并检查SE(3)等变 |
| 近共线阈值 | 平滑过渡，额外拟合误差≤1e-7 Å |
| 微小坐标扰动 | 退化滚转不出现无物理意义的翻转 |
| 局部坐标约定改变 | 先运输参考，再比较同域旋转 |
| 101步旋转运输 | 时间连续性和准确重建 |
| 参考图坐标变换 | 全局旋转同时作用于参考坐标图约定 |

原验收门槛保持最大原子差0.025 Å、RMSD 0.005 Å、内部距离差0.0002 Å；动态身份/逐键连接及接受决策必须完全一致。未排除两原子或失败样本。

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 \
../.venv-cutoff-train/bin/python -B -m pytest -q -p no:cacheprovider \
pose_orientation_stability_and_causal_validation/tests/test_orientation.py
```

模板审计包含全部3684模板、72套原始初始图的396槽位。原始7ILZ失败及准确参考形状转移复现分别见`orientation_audit.json`与`reference_transfer_audit.json`。
