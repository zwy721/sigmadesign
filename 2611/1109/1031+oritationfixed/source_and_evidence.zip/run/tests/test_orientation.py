import sys
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from orientation import fit, distance


def test_single_atom_keeps_reference_without_inventing_axis():
    ref=Rotation.from_rotvec([.3,-.4,.2]).as_matrix()
    t,r,e,a=fit([[1.,2.,3.]],[[4.,5.,6.]],ref)
    assert np.allclose(r,ref,atol=1e-14) and e<1e-14
    assert a['mode']=='unresolved_axis'


def test_diatomic_fit_selects_geodesically_nearest_feasible_rotation():
    x=np.array([[-1.,0.,0.],[1.,0.,0.]])
    ref=Rotation.from_rotvec([.4,-.7,.2]).as_matrix()
    target_axis=np.array([.2,.5,-.8]);target_axis/=np.linalg.norm(target_axis)
    y=x[:,0,None]*target_axis+[2.,3.,4.]
    t,r,e,a=fit(x,y,ref)
    assert e<1e-13
    assert np.allclose(x@r.T+t,y,atol=1e-13)
    for roll in np.linspace(-np.pi,np.pi,101):
        candidate=Rotation.from_rotvec(target_axis*roll).as_matrix()@r
        assert distance(ref,r)<=distance(ref,candidate)+1e-12
    assert a['mode']=='rank_one'


def test_full_rank_and_planar_frames_keep_original_kabsch():
    rng=np.random.default_rng(77)
    for planar in [False,True]:
        x=rng.normal(size=(9,3))
        if planar:x[:,2]=0
        expected=Rotation.random(random_state=12).as_matrix()
        y=x@expected.T+[1.,2.,3.]
        _,r,e,a=fit(x,y,np.eye(3))
        assert a['mode']=='kabsch' and np.array_equal(r,np.asarray(a['old_rotation']))
        assert np.allclose(r,expected,atol=1e-12) and e<1e-12


def test_antipodal_and_global_rigid_transform_equivariance():
    x=np.array([[-1.,0.,0.],[1.,0.,0.]])
    for antipodal in [False,True]:
        ref=Rotation.from_rotvec([.2,.4,.7]).as_matrix()
        y=-x@ref.T if antipodal else x@Rotation.from_rotvec([.8,.6,-.2]).as_matrix().T
        y+=np.array([1.,2.,3.])
        t,r,e,_=fit(x,y,ref)
        g=Rotation.from_rotvec([-.4,.1,.9]).as_matrix();shift=np.array([3.,-2.,5.])
        tt,rr,ee,_=fit(x,y@g.T+shift,g@ref)
        assert np.allclose(rr,g@r,atol=1e-12)
        assert np.allclose(tt,t@g.T+shift,atol=1e-12)
        assert abs(ee-e)<1e-12


def test_near_linear_rank_transition_is_continuous_and_preserves_fit():
    ref=Rotation.from_rotvec([.5,.2,.4]).as_matrix()
    actual=Rotation.from_rotvec([-.1,.7,-.4]).as_matrix()
    rotations=[]
    for epsilon in np.geomspace(1e-7,1e-4,1001):
        x=np.array([[-1.,0.,0.],[0.,epsilon,0.],[1.,0.,0.]])
        y=x@actual.T+[2.,3.,4.]
        _,r,error,a=fit(x,y,ref)
        assert error<=a['old_fit_RMSD_A']+1.00001e-7
        assert a['orthogonality_max_error']<1e-12
        rotations.append(r)
    assert max(distance(a,b) for a,b in zip(rotations,rotations[1:]))<.08


def test_diatomic_tiny_coordinate_perturbation_does_not_flip_roll():
    ref=Rotation.from_rotvec([.5,.2,.4]).as_matrix()
    x=np.array([[-1.,0.,0.],[1.,0.,0.]])
    y=x@ref.T+[2.,3.,4.]
    _,r,_,_=fit(x,y,ref)
    for eps in [-1e-6,1e-6]:
        z=y.copy();z[0,1]+=eps
        _,rr,e,_=fit(x,z,ref)
        assert distance(r,rr)<1e-5 and e<1e-6


def test_reference_is_transported_when_local_template_convention_changes():
    x=np.array([[-1.,0.,0.],[1.,0.,0.]])
    r=Rotation.from_rotvec([.5,.2,.4]).as_matrix()
    g=Rotation.from_rotvec([-.3,.7,.1]).as_matrix()
    local_shift=np.array([2.,-3.,1.])
    changed=x@g.T+local_shift
    y=x@r.T+[4.,5.,6.]
    transported=r@g.T
    t,rr,e,_=fit(changed,y,transported)
    assert distance(rr,transported)<1e-12 and e<1e-12
    assert np.allclose(changed@rr.T+t,y,atol=1e-12)


def test_generated_rotation_transport_is_continuous_over_many_steps():
    x=np.array([[-1.,0.,0.],[1.,0.,0.]])
    anchor=Rotation.from_rotvec([.5,.2,.4]).as_matrix()
    last=anchor
    for step in range(101):
        world=Rotation.from_rotvec(np.array([.003,-.001,.002])*step).as_matrix()
        reference=world@anchor
        target=x@reference.T+np.array([2.,3.,4.])
        _,r,e,_=fit(x,target,reference)
        assert distance(r,reference)<1e-12 and e<1e-12
        assert distance(last,r)<.004
        last=r


def test_rank_one_reference_chart_transport_under_global_frame_change():
    template=np.array([[-1.,0.,0.],[1.,0.,0.]])
    local=Rotation.from_rotvec([-.3,.7,.1]).as_matrix()
    world=Rotation.from_rotvec([.5,.2,.4]).as_matrix()
    source=template@local.T+[3.,4.,5.]
    target=template@world.T+[1.,2.,3.]
    _,mapping,_,_=fit(template,source,np.eye(3))
    t,r,e,_=fit(source,target,world@mapping.T)
    g=Rotation.from_rotvec([-.4,.6,.1]).as_matrix();shift=np.array([5.,3.,1.])
    _,mm,_,_=fit(template,source@g.T+shift,g)
    tt,rr,ee,_=fit(source@g.T+shift,target@g.T+shift,(g@world)@mm.T)
    assert np.allclose(rr,g@r@g.T,atol=1e-12)
    assert np.allclose((source@g.T+shift)@rr.T+tt,target@g.T+shift,atol=1e-12)
    assert e<1e-12 and ee<1e-12
