"""Adapter integrity: frozen weights and actual official restoration."""
import sys
from pathlib import Path
import types

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import common
import torch
from sigmadock.net.so3 import SO3_Embedding
from stable_precision import install,uninstall,original_precision


def test_adapter_preserves_state_dict_and_restores_official_functions():
    torch.manual_seed(19)
    model=torch.nn.Sequential(torch.nn.Linear(33,17),torch.nn.SiLU(),torch.nn.Linear(17,3)).eval()
    den=types.SimpleNamespace(model=model)
    baseline={k:v.clone() for k,v in model.state_dict().items()}
    original_reduce=SO3_Embedding._reduce_edge
    x=torch.randn(7,33);official=model(x).detach().clone()
    install(den)
    assert set(baseline)==set(model.state_dict())
    assert all(torch.equal(v,model.state_dict()[k]) for k,v in baseline.items())
    assert torch.allclose(model(x),official,rtol=2e-6,atol=2e-7)
    with original_precision(den):
        assert SO3_Embedding._reduce_edge is original_reduce
        assert torch.equal(model(x),official)
    assert SO3_Embedding._reduce_edge is not original_reduce
    uninstall(den)
    assert SO3_Embedding._reduce_edge is original_reduce
    assert torch.equal(model(x),official)


def test_fixed_row_linear_handles_empty_and_noncontiguous_feature_axes():
    torch.manual_seed(29)
    model=torch.nn.Linear(33,11).eval();den=types.SimpleNamespace(model=model)
    install(den)
    try:
        for n in [0,1,7,31,32,33,65]:
            x=torch.randn(2,n,33).transpose(0,1)
            expected=torch.nn.functional.linear(x.double(),model.weight.double(),model.bias.double()).float()
            actual=model(x)
            assert actual.shape==(n,2,11) and actual.dtype==torch.float32
            assert torch.allclose(actual,expected,rtol=2e-6,atol=2e-7)
    finally:uninstall(den)
