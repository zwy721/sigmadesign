"""Same FP32 weights and interfaces, higher-precision contraction accumulation.

Changes are confined to this process. Official source and checkpoint files are
not modified. This suppresses batch-shape-dependent FP32 GEMM rounding.
"""
import contextlib
import sys
import types
import torch
import torch.nn.functional as F


class ContractTorch:
    def __getattr__(self, name):
        return getattr(torch, name)

    @staticmethod
    def einsum(equation, *values):
        tensors = values[0] if len(values) == 1 and isinstance(values[0], (list, tuple)) else values
        if tensors and all(torch.is_tensor(x) and x.is_floating_point() for x in tensors):
            return torch.einsum(equation, *[x.double() for x in tensors]).to(tensors[0].dtype)
        return torch.einsum(equation, *values)

    @staticmethod
    def bmm(a, b, **kwargs):
        return torch.bmm(a.double(), b.double(), **kwargs).to(a.dtype)

    @staticmethod
    def matmul(a, b, **kwargs):
        return torch.matmul(a.double(), b.double(), **kwargs).to(a.dtype)


def install(den):
    if getattr(den, '_stable_precision_installed', False):
        return
    saved_modules = []
    for name, module in tuple(sys.modules.items()):
        if name.startswith('sigmadock.net.') and getattr(module, 'torch', None) is torch:
            saved_modules.append((module, torch))
            module.torch = ContractTorch()
    saved_linears = []
    for module in den.model.modules():
        if isinstance(module, torch.nn.Linear):
            saved_linears.append((module, module.forward))
            module._accumulation_weight = module.weight.detach().double()
            module._accumulation_bias = module.bias.detach().double() if module.bias is not None else None
            def forward(self, value):
                # Fixed row shape prevents batch-size dependent GEMM choices,
                # including rare FP64 differences straddling an FP32 half-ulp.
                # Still one batched GPU operation; no per-molecule forward.
                shape=value.shape
                flat=value.double().reshape(-1,shape[-1]);n=len(flat);tile=32
                extra=(-n)%tile
                if extra:flat=F.pad(flat,(0,0,0,extra))
                x=flat.reshape(-1,tile,shape[-1])
                weight=self._accumulation_weight.T.unsqueeze(0).expand(len(x),-1,-1)
                output=torch.bmm(x,weight).reshape(-1,self.out_features)[:n]
                if self._accumulation_bias is not None:output=output+self._accumulation_bias
                return output.reshape(*shape[:-1],self.out_features).to(value.dtype)
            module.forward = types.MethodType(forward, module)
    # Same-state step-5 audit isolates the remaining batch-shape discrepancy
    # to message aggregation. Preserve FP32 interfaces and exact weight values.
    from sigmadock.net.so3 import SO3_Embedding
    original_reduce = SO3_Embedding._reduce_edge
    def reduce(self, index, num_nodes):
        output = torch.zeros(num_nodes, self.num_coefficients, self.num_channels,
                             device=self.embedding.device, dtype=torch.float64)
        output.index_add_(0, index, self.embedding.double())
        self.set_embedding(output.to(self.embedding.dtype))
    SO3_Embedding._reduce_edge = reduce
    den._stable_precision_saved = (saved_modules, saved_linears, original_reduce)
    den._stable_precision_installed = True


def uninstall(den):
    if not getattr(den, '_stable_precision_installed', False):
        return
    modules, linears, original_reduce = den._stable_precision_saved
    from sigmadock.net.so3 import SO3_Embedding
    SO3_Embedding._reduce_edge = original_reduce
    for module, value in modules:
        module.torch = value
    for module, forward in linears:
        module.forward = forward
    den._stable_precision_installed = False


@contextlib.contextmanager
def original_precision(den):
    active = getattr(den, '_stable_precision_installed', False)
    if active:
        uninstall(den)
    try:
        yield
    finally:
        if active:
            install(den)
