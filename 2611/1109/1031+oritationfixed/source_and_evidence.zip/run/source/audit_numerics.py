"""Locate the first strict v3 divergence without changing or rounding decisions."""
from common import *
import torch


def main():
    a=OUT/'gates/v3/fixed_serial/structures/9T4A_41003_C'
    b=OUT/'gates/v3/fixed_repeat_a/structures/9T4A_41003_C'
    import run_experiment as rx
    case=torch.load(ROOT/'pose_generation_four_arm_comparison/paired_final/main/initial/9T4A_41003/case.pt',weights_only=False)
    rng=np.random.default_rng();rng.bit_generator.state=case['id_rng_state']
    identities=[];uniforms={}
    for step in [5,10]:
        x=np.load(a/f'identity_{step:02d}.npz');y=np.load(b/f'identity_{step:02d}.npz')
        qx=rx.history_module('run').softmax(x['logits'].astype(float))
        qy=rx.history_module('run').softmax(y['logits'].astype(float))
        draw=rng.random(len(qx));uniforms[step]=draw.tolist()
        pickx=np.array([np.searchsorted(np.cumsum(p),u,side='right') for p,u in zip(qx,draw)])
        picky=np.array([np.searchsorted(np.cumsum(p),u,side='right') for p,u in zip(qy,draw)])
        rows=[]
        for i,(v,w) in enumerate(zip(pickx,picky)):
            if v!=w:
                boundary=min(v,w)
                rows.append(dict(slot=i,serial_label=int(v),batched_label=int(w),shared_uniform=draw[i],
                    serial_CDF_at_boundary=float(qx[i,:boundary+1].sum()),batch_CDF_at_boundary=float(qy[i,:boundary+1].sum())))
        identities.append(dict(step=step,max_T_delta_A=float(np.max(np.abs(x['T']-y['T']))),
            max_R_element_delta=float(np.max(np.abs(x['R']-y['R']))),
            max_logit_delta=float(np.max(np.abs(x['logits']-y['logits']))),
            identical_T_R=bool(np.array_equal(x['T'],y['T']) and np.array_equal(x['R'],y['R'])),
            max_probability_delta=float(np.max(np.abs(qx-qy))),different_draws=rows))
    first=np.load(a/'identity_00.npz');second=np.load(b/'identity_00.npz')
    identity_identical=dict(step=0,identical_inputs=bool(np.array_equal(first['T'],second['T']) and np.array_equal(first['R'],second['R'])),
        max_logit_delta=float(np.max(np.abs(first['logits']-second['logits']))))
    network=[]
    for step in range(10):
        x=torch.load(OUT/'gates/v3/fixed_serial/network_outputs/9T4A_41003_C'/f'step_{step:02d}.pt',weights_only=False)
        y=torch.load(OUT/'gates/v3/fixed_repeat_a/network_outputs/7ILZ_41008_C'/f'step_{step:02d}.pt',weights_only=False)
        start,end=map(int,y['node_ptr'][2:4]);keep=(y['force_index']>=start)&(y['force_index']<end)
        assert torch.equal(x['force_index'],y['force_index'][keep]-start)
        # Four stress cases each have six slots.
        fstart=int(y['num_fragments'][:2].sum());fend=fstart+int(y['num_fragments'][2])
        network.append(dict(step=step,
            force_max_delta=float((x['pseudoforce']-y['pseudoforce'][keep]).abs().max()),
            input_C_max_delta=float((x['C_before']-y['C_before'][fstart:fend]).abs().max()),
            input_Q_max_delta=float((x['Q_before']-y['Q_before'][fstart:fend]).abs().max()),
            output_position_max_delta_model_units=float((x['pos']-y['pos'][start:end]).abs().max())))
    result=dict(identical_input_identity_observation=identity_identical,identity_steps=identities,network_steps=network,
        conclusion='Independent rounding/nondeterminism remains after both orientation fixes; do not attribute this failure solely to SVD',
        original_thresholds_unchanged=True,formal_started=False)
    dump(OUT/'numerical_divergence_audit.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
