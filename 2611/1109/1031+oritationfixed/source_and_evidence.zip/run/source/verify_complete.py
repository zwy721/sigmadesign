"""Final evidence/denominator integrity; completion is never inferred from PID."""
from common import *
from datetime import datetime,timezone
from reporting import records


REQUIRED=['ORIENTATION_ROOT_CAUSE.md','ORIENTATION_STABILITY_TESTS.md','DYNAMIC_REPLAY_VERIFICATION.md',
    'REVISED_BCE_COMPARISON.md','PER_GENERATION_RESULTS.csv','DYNAMIC_UPDATE_GEOMETRY.csv',
    'OLD_VS_NEW_ORIENTATION.csv','POSE_RECONSTRUCTION_ERROR.csv','OFFICIAL_SIGMADOCK_DOCKING_CHECK.md',
    'A100_THROUGHPUT_REPORT.md','NEXT_STEP_DECISION.md']


def check_files(files):
    bad=[]
    for name,expected in files.items():
        path=Path(name);path=path if path.is_absolute() else ROOT/path
        if not path.is_file():bad.append(dict(file=str(path),reason='missing'))
        elif sha256(path)!=expected:bad.append(dict(file=str(path),reason='hash_changed'))
    return dict(checked=len(files),passed=not bad,failures=bad)


def main():
    config=load(OUT/'protocol.json');frozen=load(OUT/'formal_start.json')
    sources=check_files({str(OUT/'source'/n):h for n,h in frozen['source_sha256'].items()})
    prior=check_files(load(OUT/'prior_run_fingerprints.json'))
    original=check_files(load(ROOT/'pose_generation_four_arm_comparison/paired_final/input_audit.json')['frozen_files'])
    historical=check_files(load(ROOT/'pose_generation_four_arm_comparison/paired_final/historical_fingerprints.json'))
    weights=check_files({v['path']:v['sha256'] for v in config['weights'].values()})
    primary=records(OUT,'main');aux={role:records(OUT,role) for role in ['ablation','docking','known']}
    denominators=dict(primary=len(primary),arms={a:sum(r['arm']==a for r in primary) for a in config['arms']},
        ablation=len(aux['ablation']),paired_docking=len(aux['docking']),known_native=len(aux['known']),
        known_original=len(load(OUT/'known/legacy_reference_summary.json')['rows']))
    expected=dict(primary=216,arms={a:72 for a in config['arms']},ablation=24,paired_docking=144,known_native=12,known_original=12)
    qc=[]
    for r in primary+sum(aux.values(),[]):
        path=Path(r['folder'])/'quality_complete.json'
        q=load(path) if path.exists() else None
        qc.append(dict(attempt_id=r['attempt_id'],available=q is not None,input_unchanged=q.get('input_unchanged') if q else None,
            raw_structure_available=(Path(r['folder'])/'native_final/raw.sdf').exists(),
            failed_attempt=r.get('status') not in ['complete','native_complete']))
    missing=[name for name in REQUIRED if not (OUT/name).is_file() or (OUT/name).stat().st_size==0]
    verification=dict(UTC=datetime.now(timezone.utc).isoformat(),prior=prior,original=original,historical=historical,
        frozen_source=sources,weights=weights,denominators=denominators,expected=expected,
        denominator_match=denominators==expected,quality_attempts=len(qc),quality_missing=sum(not r['available'] for r in qc),
        QC_inputs_unchanged=all(r['input_unchanged'] for r in qc if r['available']),QC_unavailable_and_failures=qc,
        missing_deliverables=missing,protocol_unchanged=sha256(OUT/'protocol.json')==frozen['protocol_sha256'],
        dynamic_gate_unchanged=sha256(OUT/'dynamic_replay_verification.json')==frozen['dynamic_verification_sha256'])
    verification['passed']=all(d['passed'] for d in [prior,original,historical,sources,weights]) and denominators==expected and not missing and verification['QC_inputs_unchanged'] and verification['protocol_unchanged'] and verification['dynamic_gate_unchanged'] and verification['quality_missing']==0
    dump(OUT/'completion_verification.json',verification)
    assert verification['passed'],'Do not mark complete: final evidence integrity failed'
    status=load(OUT/'status.json');status.update(stage='complete',execution_complete=True,
        primary_attempts_completed=216,completion_UTC=verification['UTC'],final_verification='completion_verification.json')
    status.pop('error',None);status.pop('traceback',None)
    dump(OUT/'status.json',status)
    print('ALL REQUIRED EVIDENCE VERIFIED',denominators)


if __name__=='__main__':main()
