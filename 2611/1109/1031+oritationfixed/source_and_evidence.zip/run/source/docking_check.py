"""Actual official sampler vs frozen NativeState path on matched Oracle inputs."""
from common import *
import contextlib
import copy
import time
import torch
from torch_geometric.data import Batch
from rdkit import Chem
from oracle_graph import assemble
from runtime import state_from, SCALE
from random_frames import replay_frames
from stable_precision import original_precision
from sigmadock.diff.sampling import sampler
from run_validation import docking as legacy_docking
import run_experiment as rx

PRIOR=ROOT/'pose_generation_four_arm_comparison/paired_final'


def cases_for(role):
    origin='main' if role=='docking' else 'known'
    cases=[torch.load(p,weights_only=False) for p in sorted((PRIOR/origin/'oracle_inputs').glob('*.pt'))]
    for case in cases:case['role']=role
    return sorted(cases,key=lambda c:len(c['graph'].x))


def rmsd(mol,target,xyz):
    truth=Chem.RemoveHs(Chem.Mol(target))
    matches=mol.GetSubstructMatches(truth,uniquify=False,useChirality=False,maxMatches=4096)
    y=truth.GetConformer().GetPositions()
    return min((float(np.sqrt(np.mean(np.sum((xyz[list(m)]-y)**2,axis=-1)))) for m in matches),default=None)


def official_batch(cases,den,tag='A_official_paired'):
    records=[]
    pending=[]
    for c in cases:
        folder=OUT/c['role']/'structures'/f'{c["pid"]}_{c["seed"]}_{tag}'
        if (folder/'result.json').exists():records.append(load(folder/'result.json'))
        else:pending.append(c)
    if not pending:return records
    assert len(pending)==len(cases),'Resume at a complete batch boundary'
    states=[state_from(c,den) for c in cases]
    graphs=[]
    for c in cases:
        data=c['graph'].clone();del data.mol_info;graphs.append(data)
    batch=Batch.from_data_list(graphs).to('cuda:0')
    audit={};force_records=[];reverse_records=[];step=[0]
    original_initial=den._get_initial_states
    original_ref=den.diffuser.sample_ref
    original_forces=den._compute_forces
    original_reverse=den.diffuser.reverse
    def get_initial(data):
        result=original_initial(data)
        audit['sampler_initial_reference']=tuple(v.detach().cpu().clone() for v in result)
        return result
    def sample_ref(n,device):
        pos0,T0,R0,num=audit['sampler_initial_reference']
        reference=R0.to(device)
        C=torch.cat([s.C for s in states]);Q=[];offset=0
        for s in states:
            count=len(s.C)
            Q.append(s.Q@s.R0.transpose(-1,-2)@reference[offset:offset+count])
            offset+=count
        values=C,torch.cat(Q)
        audit['supplied_reference_draw']=tuple(v.detach().cpu().clone() for v in values)
        return values
    def forces(*args,**kwargs):
        data=kwargs.get('batch',args[0] if args else None)
        with replay_frames(data,states,step[0],None):
            output,index=original_forces(*args,**kwargs)
        force_records.append(dict(step=step[0],pseudoforce=output.detach().cpu().clone(),force_index=index.detach().cpu().clone(),
            pos_before=data.pos_t.detach().cpu().clone()))
        step[0]+=1
        return output,index
    def reverse(*args,**kwargs):
        result=original_reverse(*args,**kwargs)
        reverse_records.append(tuple(v.detach().cpu().clone() for v in result))
        return result
    den._get_initial_states=get_initial;den.diffuser.sample_ref=sample_ref
    den._compute_forces=forces;den.diffuser.reverse=reverse
    started=time.perf_counter()
    try:
        with original_precision(den),torch.inference_mode():
            sampled,trajectory,_=sampler(den,batch,num_steps=25,t_min=.005,rho=3.,noise_scale=0.,noise_decay=2.,
                solver='euler',discretization='edm',use_true_scores=False,verbose=False)
    finally:
        den._get_initial_states=original_initial;den.diffuser.sample_ref=original_ref
        den._compute_forces=original_forces;den.diffuser.reverse=original_reverse
    elapsed=time.perf_counter()-started
    assert len(force_records)==len(reverse_records)==24
    output_folder=OUT/cases[0]['role']/'official_network_outputs'/f'{cases[0]["pid"]}_{cases[0]["seed"]}'
    output_folder.mkdir(parents=True,exist_ok=True)
    torch.save(dict(initial=audit,forces=force_records,reverse_states=reverse_records),output_folder/'paired_original_sampler.pt')
    hist=history_module('run')
    for i,(case,state) in enumerate(zip(cases,states)):
        folder=OUT/case['role']/'structures'/f'{case["pid"]}_{case["seed"]}_{tag}'
        folder.mkdir(parents=True,exist_ok=True)
        start,end=int(batch.ptr[i]),int(batch.ptr[i+1])
        n=sum(map(len,case['groups']))
        xyz=sampled.pos_t[start+state.pn:start+state.pn+n].cpu().numpy()*SCALE+case['graph'].pocket_com.cpu().numpy().reshape(3)
        mol=assemble(case['spec'])
        for j,point in enumerate(xyz):mol.GetConformer().SetAtomPosition(j,point.tolist())
        original_pos=force_records[0]['pos_before'][start:end].numpy()
        init_difference=float(np.max(np.linalg.norm((original_pos-state.pos.cpu().numpy())*SCALE,axis=-1)))
        rec=dict(attempt_id=f'{case["role"]}_{case["pid"]}_{case["seed"]}_{tag}',arm='A_official',phase=case['role'],
            receptor_id=case['pid'],seed=case['seed'],strategy=tag,N=case['N'],oracle=True,status='native_complete',
            labels=case['labels'],connections=[],groups=case['groups'],spec=case['spec'],folder=str(folder),
            manifest=[],events=[],guidance=[],pose_NFE=24,repair_errors={},
            docking_RMSD_A=rmsd(mol,case['target'],xyz),batch_wall_seconds=elapsed,
            initialization_max_atom_difference_to_NativeState_A=init_difference,
            official_sampler_source_unchanged=True,original_FP32_backbone=True,
            paired_initial_draw_injection=True,paired_semantic_edge_uniforms=True,
            pairing_limitations='Official sampler receives an explicit reference-distribution draw, reparameterized for its own fragment basis, and replayed edge uniforms. Its batched mechanics, iterative coordinate updates and FP32 reductions remain original; zero-update internal noise, if encountered, is not claimed paired.',
            final_geometry=rx.Geometry(case['spec'],case['context']).metrics(xyz))
        hist.save_stage(folder,'native_final',mol,case['spec'],rec,case['context'])
        torch.save(dict(mol=mol,spec=case['spec'],context=case['context'],groups=case['groups']),folder/'postprocess_input.pt')
        pose_folder=folder/'trajectory';pose_folder.mkdir(exist_ok=True)
        for k,row in enumerate(force_records):
            point=row['pos_before'][start+state.pn:start+state.pn+n].numpy()*SCALE+case['graph'].pocket_com.cpu().numpy().reshape(3)
            np.savez_compressed(pose_folder/f'before_{k:02d}.npz',xyz=point)
        np.savez_compressed(pose_folder/'final.npz',xyz=xyz)
        dump(folder/'result.json',rec);records.append(rec)
    print('OFFICIAL PAIRED BATCH',len(cases),round(elapsed,2),flush=True)
    return records


def legacy_reference(den):
    """Original twelve one-sample reference calls, separate from batched study."""
    rows=[]
    with original_precision(den):
        for case in cases_for('known'):
            path=OUT/'known/legacy_official'/f'{case["pid"]}_{case["seed"]}.json'
            if path.exists():rows.append(load(path));continue
            xyz,_,info=legacy_docking(den,case['graph'],seed=case['seed'],steps=25,device='cuda:0',noise_scale=0.,save=path.with_suffix('.pt'))
            row=dict(pid=case['pid'],seed=case['seed'],available=True,
                raw_atom_order_RMSD_A=float(np.sqrt(np.mean(np.sum((xyz.numpy()-case['target'].GetConformer().GetPositions())**2,axis=-1)))),
                seconds=info['seconds'],original_global_RNG=True,original_FP32_sampler=True,excluded_from_primary=True)
            dump(path,row);rows.append(row)
    dump(OUT/'known/legacy_reference_summary.json',dict(rows=rows,requested=12,under2=sum(r['raw_atom_order_RMSD_A']<2 for r in rows)))
    return rows
