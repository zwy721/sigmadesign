"""Dataset-free GEOM probabilities. Only current generated poses enter the head."""
import os,sys,json,contextlib,argparse,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
LEGACY=ROOT.parent/'core497_joint_experiments_20261019/training3684'
def main():
 p=argparse.ArgumentParser();p.add_argument('--assets',type=Path,required=True);a=p.parse_args()
 import torch
 torch.set_num_threads(1)
 torch.use_deterministic_algorithms(True)
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 ck=LEGACY/'runs/geom_ipa3684_100ep_20261029_cuda01234_bs372_fast/best_loss.pt'
 saved=torch.load(ck,map_location='cpu',weights_only=False);cfg=saved['config']
 cfg['joint_options']['connection_graph']='none';cfg['train']['packed_geom']=False;cfg['train']['prepared_geom']=False
 a.assets.mkdir(parents=True,exist_ok=True);cp=a.assets/'config.json';cp.write_text(json.dumps(cfg));os.environ['CUTOFF_TRAIN_CONFIG']=str(cp)
 sys.path=[str(LEGACY)]+[x for x in sys.path if Path(x or '.').resolve() not in {ROOT.parent/'oracle_rebuild_20261031',Path(__file__).resolve().parent}]
 with contextlib.redirect_stdout(sys.stderr):
  import runtime
  for nm in ['mapping.json','templates.json','properties.json']:
   if not (a.assets/nm).exists():shutil.copyfile(runtime.ASSETS/nm,a.assets/nm)
  if not (a.assets/'diffusion_cache').exists():shutil.copytree(runtime.ASSETS/'diffusion_cache',a.assets/'diffusion_cache')
  runtime.ASSETS=a.assets
  from data import input_graph
  from geom_data import initialize
  from model3684 import ConnectionIPA3684
  model=ConnectionIPA3684('cuda:0');model.load_state_dict(saved['model'],strict=True);model.eval();model.requires_grad_(False);pg=initialize()['pg']
  assert not len(pg['pos'])
 print(json.dumps(dict(ready=True,K=cfg['K'],protein_conditioned=False,connection_prior_used=False)),flush=True)
 for line in sys.stdin:
  try:
   r=json.loads(line)
   if r.get('close'):break
   assert set(r)<= {'T','R','t','seed','close'}
   with contextlib.redirect_stdout(sys.stderr):
    T=torch.tensor(r['T'],dtype=torch.float32);T-=T.mean(0);R=torch.tensor(r['R'],dtype=torch.float32);n=len(T);tokens=torch.full((n,),cfg['MASK'],dtype=torch.long)
    e=dict(id='target_free',source='geom',pg=pg,origin=torch.zeros(3),tokens=tokens,labels=tokens.clone(),Tt=T,Rt=R,t=float(r['t']),seed=r['seed'],mode='all_mask',oov_templates=[None]*n,pose_supervision=False,geometry_training=False,edges=torch.zeros(n,n,dtype=torch.long),anchors=torch.full((n,n,2),-100,dtype=torch.long),stereo=torch.full((n,n),-100,dtype=torch.long))
    e['graph']=input_graph(e);assert not e['graph']['case']['native_anchor_pairs']
    with torch.inference_mode():logits=model._run([e])[0]['logits'].float().cpu()
   print(json.dumps(dict(logits=logits.tolist(),protein_conditioned=False,connection_prior_used=False)),flush=True)
  except Exception as exc:
   import traceback;traceback.print_exc(file=sys.stderr);print(json.dumps(dict(error=repr(exc))),flush=True)
if __name__=='__main__':main()
