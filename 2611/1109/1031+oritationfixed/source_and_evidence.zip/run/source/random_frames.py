"""Replayable uniform auxiliary directions with the unchanged official frame code.

No official source is edited. Only the random tensor supplied to rand_like in
the frame constructor is replaced, by a stable edge-keyed pseudorandom draw.
"""
import contextlib
import hashlib
import json
import random
import types
import numpy as np
import torch
import sigmadock.net.model as official_model
from sigmadock.net.edge_rot_mat import init_edge_rot_mat as official_frame


def capture_rng():
    return dict(python=random.getstate(), numpy=np.random.get_state(), cpu=torch.get_rng_state(),
                cuda=torch.cuda.get_rng_state_all())


def restore_rng(saved):
    random.setstate(saved['python'])
    np.random.set_state(saved['numpy'])
    torch.set_rng_state(saved['cpu'])
    torch.cuda.set_rng_state_all(saved['cuda'])


def attach(state, case, step=0):
    spec = case['spec']
    value = f'{case["pid"]}|{case["seed"]}'
    state.replay_key = int.from_bytes(hashlib.sha256(value.encode()).digest()[:8], 'little')
    graph = state.graph
    n = len(graph.x)
    keys = [None]*n
    def token(value):
        return int.from_bytes(hashlib.sha256(json.dumps(value, sort_keys=True).encode()).digest()[:8], 'little')
    for i in range(state.pn):
        keys[i] = token(['protein', i])
    for slot, group in enumerate(case['groups']):
        identity = case['labels'][slot] if case['labels'][slot] >= 0 else spec['fragments'][slot]['identity']
        for local, atom in enumerate(group):
            keys[state.pn+atom] = token(['core', slot, identity, local])
    edge = graph.edge_index.cpu().numpy()
    entities = graph.edge_entity.cpu().numpy()
    neighborhoods = [[] for _ in range(n)]
    for a, b, kind in zip(edge[0], edge[1], entities):
        if keys[a] is None and keys[b] is not None:
            neighborhoods[a].append((int(keys[b]), int(kind)))
        if keys[b] is None and keys[a] is not None:
            neighborhoods[b].append((int(keys[a]), int(kind)))
    repeated = {}
    fragment = graph.frag_idx_map.cpu().numpy()
    node_entity = graph.node_entity.cpu().numpy()
    for i in range(n):
        if keys[i] is not None:
            continue
        slot = int(fragment[i])
        identity = case['labels'][slot] if case['labels'][slot] >= 0 else spec['fragments'][slot]['identity']
        material = ['helper', slot, identity, int(node_entity[i]), sorted(set(neighborhoods[i]))]
        base = json.dumps(material, sort_keys=True)
        ordinal = repeated.get(base, 0)
        repeated[base] = ordinal+1
        keys[i] = token([material, ordinal])
    assert len(set(keys)) == n, 'Semantic node IDs must be distinct within a graph'
    state.replay_node_keys = np.array(keys, dtype=np.uint64)
    state.replay_semantic_ids = True
    state.step_index = step
    return state


def mix64(x):
    """Unsigned counter mixing; overflow is intentional and platform independent."""
    with np.errstate(over='ignore'):
        x = x + np.uint64(0x9e3779b97f4a7c15)
        x = (x ^ (x >> np.uint64(30)))*np.uint64(0xbf58476d1ce4e5b9)
        x = (x ^ (x >> np.uint64(27)))*np.uint64(0x94d049bb133111eb)
    return x ^ (x >> np.uint64(31))


def directions(data, states, step):
    # Called after official forward has pruned masked-node edges.
    edge = data.edge_index.detach().cpu().numpy()
    entities = data.edge_entity.detach().cpu().numpy().astype(np.uint64)
    owners = data.batch[data.edge_index[0]].detach().cpu().numpy()
    ptr = data.ptr.detach().cpu().numpy()
    keys = np.empty(len(entities), dtype=np.uint64)
    for i, state in enumerate(states):
        choose = owners == i
        src = (edge[0, choose]-ptr[i]).astype(np.int64)
        dst = (edge[1, choose]-ptr[i]).astype(np.int64)
        if hasattr(state, 'replay_node_keys'):
            src, dst = state.replay_node_keys[src], state.replay_node_keys[dst]
        else:
            src, dst = src.astype(np.uint64), dst.astype(np.uint64)
        local = mix64(src) ^ mix64(dst+np.uint64(0x7f4a7c15)) ^ mix64(entities[choose]+np.uint64(0x133111eb))
        # Include chemistry attributes to distinguish parallel typed edges.
        attr = data.edge_attr[torch.as_tensor(choose, device=data.edge_attr.device)].detach().cpu().numpy()
        for col in range(attr.shape[1]):
            local ^= mix64(attr[:, col].astype(np.int64).astype(np.uint64)+np.uint64(127+col))
        salt = mix64(np.array([state.replay_key], dtype=np.uint64))[0] ^ mix64(np.array([step], dtype=np.uint64))[0]
        keys[choose] = mix64(local ^ salt)
    values = np.stack([(mix64(keys ^ np.uint64(c)) >> np.uint64(40)).astype(np.float32)/np.float32(2**24)
                       for c in [0x243f6a88, 0x85a308d3, 0x13198a2e]], -1)
    assert np.isfinite(values).all() and (values >= 0).all() and (values < 1).all()
    return torch.as_tensor(values, device=data.edge_index.device, dtype=data.pos_t.dtype)


def frame_with_uniform(edge_vectors, uniform, *args, **kwargs):
    class TorchProxy:
        def __getattr__(self, name):
            return getattr(torch, name)

        @staticmethod
        def rand_like(value, **options):
            assert value.shape == uniform.shape
            return uniform.to(device=value.device, dtype=value.dtype)
    env = dict(official_frame.__globals__)
    env['torch'] = TorchProxy()
    copied = types.FunctionType(official_frame.__code__, env, official_frame.__name__, official_frame.__defaults__, official_frame.__closure__)
    return copied(edge_vectors, *args, **kwargs)


@contextlib.contextmanager
def replay_frames(data, states, step, trace=None):
    previous = official_model.init_edge_rot_mat
    holder = [data]
    hook = None
    if data is None:
        def capture(module, args):
            holder[0] = args[0]
        hook = states[0].den.model.register_forward_pre_hook(capture)
    def replacement(vectors, *args, **kwargs):
        active_data = holder[0]
        uniform = directions(active_data, states, step)
        result = frame_with_uniform(vectors, uniform, *args, **kwargs)
        if trace is not None:
            trace['edge_index'] = active_data.edge_index.detach().cpu().clone()
            trace['edge_entity'] = active_data.edge_entity.detach().cpu().clone()
            trace['edge_uniform'] = uniform.detach().cpu().clone()
            trace['edge_rot_mat'] = result.detach().cpu().clone()
        return result
    official_model.init_edge_rot_mat = replacement
    try:
        yield
    finally:
        official_model.init_edge_rot_mat = previous
        if hook is not None:
            hook.remove()
