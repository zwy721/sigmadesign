"""Same-state single/batched backbone audit at first v3 force discrepancy."""
from common import *
import copy
import torch
from torch_geometric.data import Batch
import run_experiment as rx
from runtime import state_from
from random_frames import attach,replay_frames
from stable_precision import install
from run_validation import load_official
import orientation


def rebuild_state(case,den,lib,namespace='v3',role='fixed_serial'):
    folder=OUT/'gates'/namespace/role/'structures'/f'{case["pid"]}_{case["seed"]}_C'
    e=load(folder/'event_05/event.json')
    if e['accepted']:
        graph,groups,spec=rx.chemical_graph(lib,e['proposed_labels'],e['proposed_connections'],case['context'],[None]*case['N'],seed=case['seed'])
        p=np.load(folder/'event_05/proposal_transfer.npz')
        desired=[p['target_xyz'][g].astype(np.float32 if e['old_labels'][i]==e['proposed_labels'][i] else np.float64) for i,g in enumerate(groups)]
        c=dict(case,graph=graph,groups=groups,spec=spec,labels=e['proposed_labels'],connections=e['proposed_connections'],desired=desired,R=p['R'])
        state=state_from(c,den)
        error=float(np.max(np.abs(state.physical()[state.pn:state.pn+len(p['actual_xyz'])]-p['actual_xyz'])))
        assert error<1e-5,('Exact reconstruction failed',error)
    else:
        c=case;state=state_from(c,den);p=np.load(folder/'event_05/before.npz')
        trace=torch.load(OUT/'gates'/namespace/role/'network_outputs'/f'{case["pid"]}_{case["seed"]}_C'/'step_04.pt',weights_only=False)
        state.C=trace['C'].to('cuda:0');state.Q=trace['Q'].to('cuda:0');state.pos=trace['pos'].to('cuda:0')
        error=None
    attach(state,c,step=5)
    return state,error


def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--probe',choices=['none','edge_sum','attention_softmax','tiled_linear'],default='none');p.add_argument('--fixture',choices=['v3','v4'],default='v3');p.add_argument('--fine',action='store_true');args=p.parse_args()
    torch.set_num_threads(2);torch.cuda.set_device(0);torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    den=load_official(bootstrap.CHECKPOINT,OUT/'cache/official','cuda:0');install(den);lib=rx.VocabLibrary()
    from precision_diagnostic import install_reduction_probe
    install_reduction_probe(args.probe,den)
    keys=[('9T4A',41003),('7ILZ',41008),('9RT3',41010),('9T4A',41004)] if args.fixture=='v3' else [('9RT3',41010),('9T4A',41012),('9RT3',41012),('9T4A',41002)]
    target=0 if args.fixture=='v3' else 2
    cases=[torch.load(ROOT/'pose_generation_four_arm_comparison/paired_final/main/initial'/f'{p}_{s}'/'case.pt',weights_only=False) for p,s in keys]
    states=[];errors=[]
    for c in cases:
        s,e=rebuild_state(c,den,lib,args.fixture,'fixed_serial' if args.fixture=='v3' else 'full_C_b1');states.append(s);errors.append(e)
    t=((1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3)[5]
    stages={};context={};active=[0]
    def save(name,value):
        if isinstance(value,tuple):
            for j,v in enumerate(value):save(name+f'::{j}',v)
            return
        tensor=value if torch.is_tensor(value) else getattr(value,'embedding',None)
        if tensor is not None:stages.setdefault(name,{})[active[0]]=tensor.detach().cpu().clone()
    def node(data,t):
        value=old_node(data,t);save('node_embedding',value);return value
    def edge(data,*args,**kwargs):
        context[active[0]]=dict(edge_index=data.edge_index.detach().cpu().clone(),edge_entity=data.edge_entity.detach().cpu().clone(),nodes=len(data.x))
        value=old_edge(data,*args,**kwargs);save('edge_embedding',value);return value
    old_node=den.model.compute_node_embedding;old_edge=den.model.compute_edge_embedding
    den.model.compute_node_embedding=node;den.model.compute_edge_embedding=edge
    def pre(module,args):
        d=args[0];context[active[0]]=dict(edge_index=d.edge_index.detach().cpu(),edge_entity=d.edge_entity.detach().cpu(),nodes=len(d.x))
    handles=[den.model.register_forward_pre_hook(pre)]
    for name,module in [('edge_degree',den.model.edge_degree_embedding)]+[(f'block_{i}',m) for i,m in enumerate(den.model.blocks)]+[('norm',den.model.norm),('force_block',den.model.force_block)]:
        handles.append(module.register_forward_hook(lambda m,a,v,name=name:save(name,v)))
    if args.fine:
        for name,module in den.model.blocks[2 if args.fixture=='v4' else 3].named_modules():
            if name:
                handles.append(module.register_forward_pre_hook(lambda m,a,name=name:save('fine.'+name+'__input',a[0])))
                handles.append(module.register_forward_hook(lambda m,a,v,name=name:save('fine.'+name,v)))
    forces=[]
    with torch.inference_mode():
        for i,part in enumerate([[states[target]],states]):
            active[0]=i
            b=Batch.from_data_list([s.base for s in part]);b=den._update_batch(b,torch.cat([s.pos0 for s in part]),torch.cat([s.pos for s in part]))
            with replay_frames(b,part,5,None):f,index=den._compute_forces(b,t.expand(len(part)))
            offset=0 if i==0 else sum(len(s.pos) for s in states[:target]);end=offset+len(states[target].pos)
            keep=(index>=offset)&(index<end);forces.append(f[keep].cpu())
    for h in handles:h.remove()
    n=len(states[target].pos);offset=sum(len(s.pos) for s in states[:target]);rows=[]
    # Node-stage ordering is explicit; edge-stage ordering is separately keyed.
    ea=context[0];eb=context[1]
    mask=(eb['edge_index'][0]>=offset)&(eb['edge_index'][0]<offset+n)&(eb['edge_index'][1]>=offset)&(eb['edge_index'][1]<offset+n)
    edges_equal=torch.equal(ea['edge_index'],eb['edge_index'][:,mask]-offset) and torch.equal(ea['edge_entity'],eb['edge_entity'][mask])
    for name,values in stages.items():
        a,b=values[0],values[1]
        if name=='edge_embedding':
            assert edges_equal;b=b[mask]
        elif name.startswith('fine.'):
            if a.ndim and a.shape[0]==n and b.shape[0]==eb['nodes']:b=b[offset:offset+n]
            elif a.ndim and a.shape[0]==len(ea['edge_entity']) and b.shape[0]==len(eb['edge_entity']):b=b[mask]
            else:
                rows.append(dict(stage=name,single_shape=list(a.shape),batch_shape=list(b.shape),comparison_available=False,
                    reason='Intermediate per-edge-type/flattened axis requires a separate explicit index map'))
                continue
        else:b=b[offset:offset+n]
        assert a.shape==b.shape,(name,a.shape,b.shape)
        rows.append(dict(stage=name,shape=list(a.shape),max_delta=float((a-b).abs().max()),exact_equal=torch.equal(a,b)))
    name='layer_numerical_audit'+('' if args.fixture=='v3' else '_v4')+('' if args.probe=='none' else '_'+args.probe)+('_fine' if args.fine else '')
    dump(OUT/(name+'.json'),dict(probe=args.probe,fixture=args.fixture,source='saved exact first accepted graph at step5',
        reconstructed_core_max_errors_A=errors,within_sample_edges_equal=edges_equal,stages=rows,
        force_max_delta=float((forces[0]-forces[1]).abs().max()),first_different_stage=next((r['stage'] for r in rows if r.get('exact_equal') is False),None)))
    print(json.dumps(rows,indent=2),flush=True)


if __name__=='__main__':main()
