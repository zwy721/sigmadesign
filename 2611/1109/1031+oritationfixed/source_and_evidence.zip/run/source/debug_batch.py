from common import *
import copy
import torch
from runtime import BatchEngine, state_from
from run_validation import load_official

torch.set_num_threads(2)
torch.cuda.set_device(0)
torch.use_deterministic_algorithms(True)
torch.backends.cuda.matmul.allow_tf32 = False
den = load_official(bootstrap.CHECKPOINT, OUT/'cache/official', 'cuda:0')
paths = sorted((OUT/'dev/initial').glob('*/case.pt'))[:4]
cases = [torch.load(p, weights_only=False) for p in paths]
grid = (1.+torch.arange(25, device='cuda:0')/24*(.005**(1/3)-1.))**3
serial = [state_from(c, den) for c in cases]
packed = [state_from(c, den) for c in cases]
single = [state_from(c, den) for c in cases]
rows = []
for step, t in enumerate(grid[:-1]):
    with torch.no_grad():
        for s in serial:
            s.step(t, grid[step]-grid[step+1])
        for s in single:
            BatchEngine(den).step([s], t, grid[step]-grid[step+1])
        BatchEngine(den).step(packed, t, grid[step]-grid[step+1])
    row = dict(step=step, t=float(t), single=[float((a.pos-b.pos).abs().max()) for a,b in zip(serial,single)],
               packed=[float((a.pos-b.pos).abs().max()) for a,b in zip(serial,packed)])
    rows.append(row)
    print(row, flush=True)
dump(OUT/'batch_debug.json', rows)
