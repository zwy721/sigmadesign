"""Paths and serialization for the isolated five-arm diagnostic."""
import csv
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
ROOT = next(p for p in OUT.parents if (p/'denovo_quality').is_dir())
HISTORY = ROOT / '2611/1105/1345_diversity'
PROJECT = ROOT.parent / 'oracle_rebuild_20261031'
os.environ.setdefault('MPLCONFIGDIR', str(OUT / 'cache/matplotlib'))
os.environ.setdefault('WANDB_MODE', 'disabled')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PROJECT))
import bootstrap
sys.path.insert(0, str(OUT/'source'))
import numpy as np
from denovo_quality.common import clean, load_config, sha256, write_json


def load(path):
    return json.loads(Path(path).read_text())


def dump(path, value):
    write_json(path, clean(value))


def csvwrite(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(clean(v), ensure_ascii=False) if isinstance(v, (dict, list, tuple)) else clean(v) for k, v in row.items()})


def history_module(name):
    saved_path = sys.path.copy()
    spec = importlib.util.spec_from_file_location('frozen_diversity_' + name, HISTORY / 'source' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    # Historical modules import their own common by its unqualified name.
    saved = sys.modules.get('common')
    hist_spec = importlib.util.spec_from_file_location('common', HISTORY / 'source/common.py')
    hist_common = importlib.util.module_from_spec(hist_spec)
    hist_spec.loader.exec_module(hist_common)
    sys.modules['common'] = hist_common
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path[:] = saved_path
        if saved is not None:
            sys.modules['common'] = saved
        else:
            sys.modules.pop('common', None)
    return module


def install_pb():
    history_module('common').install_pb()


def set_status(stage, **kwargs):
    path = OUT / 'status.json'
    status = load(path) if path.exists() else {}
    if stage != 'failed':
        status.pop('error', None)
        status.pop('traceback', None)
    status.update(stage=stage, execution_complete=False, **kwargs)
    dump(path, status)
