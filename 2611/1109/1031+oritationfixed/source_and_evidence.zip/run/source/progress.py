"""Ordered orientation/dynamic gates; primary runs cannot bypass them."""
from common import *
import argparse
import copy
import time
import traceback
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import torch
import run_experiment as rx
from run_validation import load_official
from stable_precision import install
import orientation

PRIOR=ROOT/'pose_generation_four_arm_comparison/paired_final'
TOLERANCES=dict(max_atom_delta_A=.025,coordinate_RMSD_A=.005,internal_distance_delta_A=.0002)
NAMESPACE=''


def all_cases():
    settings=load(PRIOR/'effective_protocol.json')
    cases=[]
    for pid in settings['cohort']:
        for seed in settings['seeds']:
            case=torch.load(PRIOR/'main/initial'/f'{pid}_{seed}'/'case.pt',weights_only=False)
            case['role']='main';cases.append(case)
    return sorted(cases,key=lambda c:(len(c['graph'].x),c['pid'],c['seed']))


def choose_cases(cases,n):
    # Explicit, fixed coverage set; no quality outcome is used for selection.
    first=[('7ILZ',41008),('12AV',41001),('9RT3',41001),('9SYL',41001),('9T4A',41001),('9T51',41001)]
    table={(c['pid'],c['seed']):c for c in cases}
    selected=[table[k] for k in first]
    selected.extend(c for c in cases if (c['pid'],c['seed']) not in first)
    return selected[:n]


def execute(cases,arm,role,size,den,client,pool,lib,method='fixed',suppress=False):
    if NAMESPACE and role.startswith('gates/'):
        role=role.replace('gates/',f'gates/{NAMESPACE}/',1)
    rows=[]
    for start in range(0,len(cases),size):
        part=copy.deepcopy(cases[start:start+size])
        for case in part:case['role']=role
        rows.extend(rx.run_batch(part,arm,den,client,pool,lib,orientation_method=method,suppress_updates=suppress))
    return rows


def compare(left,right,label):
    if NAMESPACE:label=NAMESPACE+'_'+label
    a={(r['receptor_id'],r['seed']):r for r in left}
    checks=[]
    for r in right:
        s=a[r['receptor_id'],r['seed']]
        same=rx.topology_key(s['labels'],s['connections'])==rx.topology_key(r['labels'],r['connections'])
        decisions=[(e['proposed_labels'],rx.topology_key(e['old_labels'],e.get('proposed_connections',[])),e['accepted'],e.get('reason')) for e in s['events']]
        other=[(e['proposed_labels'],rx.topology_key(e['old_labels'],e.get('proposed_connections',[])),e['accepted'],e.get('reason')) for e in r['events']]
        coordinates=[]
        for step in range(24):
            x=np.load(Path(s['folder'])/'trajectory'/f'step_{step:02d}.npz')
            y=np.load(Path(r['folder'])/'trajectory'/f'step_{step:02d}.npz')
            if x['xyz'].shape!=y['xyz'].shape:
                coordinates.append(dict(step=step,shape_equal=False,passed=False));continue
            d=np.linalg.norm(x['xyz']-y['xyz'],axis=-1)
            coordinates.append(dict(step=step,shape_equal=True,max_atom_A=float(d.max()),RMSD_A=float(np.sqrt(np.mean(d*d))),
                passed=float(d.max())<=.025 and float(np.sqrt(np.mean(d*d)))<=.005))
        checks.append(dict(pid=r['receptor_id'],seed=r['seed'],final_chemistry_equal=same,all_discrete_decisions_equal=decisions==other,
            coordinate_steps=coordinates,passed=same and decisions==other and all(c['passed'] for c in coordinates)))
    result=dict(label=label,passed=all(r['passed'] for r in checks),compared=len(checks),tolerances=TOLERANCES,checks=checks)
    dump(OUT/'diagnostics/comparisons'/f'{label}.json',result)
    print('COMPARE',label,result['passed'],flush=True)
    return result


def gates(den,client,pool,lib,cases):
    table={(c['pid'],c['seed']):c for c in cases}
    initial=[table[k] for k in [('7ILZ',41008),('9RT3',41010),('9T4A',41003),('9T4A',41004),('9RT3',41012),('12AV',41001),('9SYL',41001),('9T51',41001)]]
    dump(OUT/'dynamic_gate_inputs.json',dict(selection='Explicit previously failed cases used as diagnostic stress tests; not a random generalization set',
        preliminary=[dict(pid=c['pid'],seed=c['seed'],N=c['N']) for c in initial],tolerances=TOLERANCES))
    set_status('preliminary_dynamic_replay')
    old_a=execute(initial,'C','gates/old_repeat_a',4,den,client,pool,lib,method='old')
    old_b=execute(initial,'C','gates/old_repeat_b',4,den,client,pool,lib,method='old')
    compare(old_a,old_b,'old_repeat')
    fixed_a=execute(initial,'C','gates/fixed_repeat_a',4,den,client,pool,lib)
    fixed_b=execute(initial,'C','gates/fixed_repeat_b',4,den,client,pool,lib)
    repeated=compare(fixed_a,fixed_b,'fixed_repeat')
    serial=execute(initial,'C','gates/fixed_serial',1,den,client,pool,lib)
    batch=compare(serial,fixed_a,'fixed_b1_b4')
    dump(OUT/'preliminary_dynamic_verification.json',dict(passed=repeated['passed'] and batch['passed'],
        repeat=repeated,serial_batch=batch,old_method_reproducibility_required=False,
        orientation_sha256=sha256(OUT/'source/orientation.py'),namespace=NAMESPACE,
        core_sha256={n:sha256(OUT/'source'/n) for n in ['orientation.py','runtime.py','run_experiment.py','random_frames.py','stable_precision.py','identity_server.py']}))
    assert repeated['passed'] and batch['passed'],'Fixed dynamic repeat/serial-batch gate failed; preserve and localize before formal sampling'
    print('PRELIMINARY DYNAMIC GATES PASSED',flush=True)


def full_gates(den,client,pool,lib,cases):
    assert load(OUT/'preliminary_dynamic_verification.json')['passed']
    chosen=choose_cases(cases,32)
    results=[]
    for arm in ['C','E_connection_only']:
        set_status('dynamic_batch_gate',arm=arm,batch_size=1)
        baseline=execute(chosen,arm,f'gates/full_{arm}_b1',1,den,client,pool,lib)
        for size in [4,8,16,32]:
            set_status('dynamic_batch_gate',arm=arm,batch_size=size)
            packed=execute(chosen,arm,f'gates/full_{arm}_b{size}',size,den,client,pool,lib)
            comparison=compare(baseline,packed,f'{arm}_b1_b{size}')
            results.append(comparison)
            assert comparison['passed'],f'Dynamic {arm} batch={size} failed; no formal run'
        again=execute(chosen,arm,f'gates/full_{arm}_b32_repeat',32,den,client,pool,lib)
        repeated=compare(packed,again,f'{arm}_b32_repeat')
        results.append(repeated)
        assert repeated['passed'],'Full-size repeated dynamic replay failed'
    control=choose_cases(cases,4)
    b=execute(control,'B','gates/no_update_B',4,den,client,pool,lib)
    c=execute(control,'C','gates/no_update_C',4,den,client,pool,lib,suppress=True)
    # Deliberately suppress changes in this diagnostic fixture, never in formal C.
    for x,y in zip(b,c):
        for step in range(24):
            xx=np.load(Path(x['folder'])/'trajectory'/f'step_{step:02d}.npz')['xyz']
            yy=np.load(Path(y['folder'])/'trajectory'/f'step_{step:02d}.npz')['xyz']
            assert np.array_equal(xx,yy),'Queries/unused proposals changed the no-update trajectory'
    set_status('dynamic_batch64_gate')
    big=choose_cases(cases,64);eligible64=True;extra=[]
    for arm in ['C','E_connection_only']:
        reference=execute(big,arm,f'gates/b64_reference_{arm}',32,den,client,pool,lib)
        candidate=execute(big,arm,f'gates/b64_candidate_{arm}',64,den,client,pool,lib)
        r=compare(reference,candidate,f'{arm}_b32_b64')
        extra.append(r);eligible64=eligible64 and r['passed']
    verification=dict(passed=True,required_sizes=[1,4,8,16,32],cases_per_arm=32,comparisons=results,
        batch64_eligible=eligible64,batch64_comparisons=extra,no_update_control_passed=True,
        no_update_control_is_suppressed_updates_fixture=True,original_tolerances=TOLERANCES,
        all_discrete_decisions_identical=True,primary_denominator_excluded=True,
        namespace=NAMESPACE,core_sha256={n:sha256(OUT/'source'/n) for n in ['orientation.py','runtime.py','run_experiment.py','random_frames.py','stable_precision.py','identity_server.py']})
    dump(OUT/'dynamic_replay_verification.json',verification)
    set_status('dynamic_gates_passed',batch64_eligible=eligible64)
    return verification


def main():
    global NAMESPACE
    parser=argparse.ArgumentParser();parser.add_argument('--through',choices=['audit','gates','full-gates','complete'],default='gates');parser.add_argument('--namespace',default='');args=parser.parse_args()
    NAMESPACE=args.namespace
    torch.set_num_threads(2)
    if args.through=='audit':
        from audit_orientation import main as audit
        audit();return
    assert load(OUT/'orientation_audit.json')['passed']
    torch.cuda.set_device(0);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    lib=rx.VocabLibrary();den=load_official(bootstrap.CHECKPOINT,OUT/'cache/official','cuda:0');install(den)
    with ProcessPoolExecutor(4,mp_context=get_context('spawn'),initializer=rx.cpu_init) as pool:
        client=rx.Client()
        try:
            if args.through in ['full-gates','complete']:
                preliminary=OUT/'preliminary_dynamic_verification.json'
                core={n:sha256(OUT/'source'/n) for n in ['orientation.py','runtime.py','run_experiment.py','random_frames.py','stable_precision.py','identity_server.py']}
                if not preliminary.exists() or load(preliminary).get('core_sha256')!=core or not load(preliminary).get('passed'):
                    gates(den,client,pool,lib,all_cases())
                verified=OUT/'dynamic_replay_verification.json'
                if not verified.exists() or not load(verified).get('passed') or load(verified).get('core_sha256')!=core:
                    full_gates(den,client,pool,lib,all_cases())
                if args.through=='complete':
                    import formal
                    formal.smoke(den,client,pool,lib)
                    formal.run(den,client,pool,lib,all_cases())
                    from reporting import tables
                    tables()
            else:gates(den,client,pool,lib,all_cases())
        finally:client.close()


if __name__=='__main__':
    sys.modules.setdefault('progress',sys.modules[__name__])
    try:main()
    except Exception as exc:
        set_status('failed',error=repr(exc),traceback=traceback.format_exc());raise
