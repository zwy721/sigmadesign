"""Closest proper rotation with an explicit reference for unresolved roll.

Coordinates use row vectors: y = x @ R.T + t. Rank-one Procrustes fits
constrain R*a=b. The shortest world rotation from R_previous*a to b,
left-composed with R_previous, is the geodesically closest feasible R.
"""
import numpy as np
from scipy.spatial.transform import Rotation

RELATIVE_COVARIANCE_TOLERANCE = 1e-10
FIT_NUMERICAL_BUDGET_A = 1e-7


def proper(rotation):
    u, _, vt = np.linalg.svd(np.asarray(rotation, dtype=np.float64))
    correction = np.eye(3)
    correction[-1, -1] = np.linalg.det(u @ vt)
    return u @ correction @ vt


def distance(a, b):
    return float(np.linalg.norm(Rotation.from_matrix(proper(a).T @ proper(b)).as_rotvec()))


def align_axis(a, b, reference):
    """Shortest SO(3) rotation a->b, with a covariant antipodal tie break."""
    a, b = a / np.linalg.norm(a), b / np.linalg.norm(b)
    cross = np.cross(a, b)
    norm, cosine = float(np.linalg.norm(cross)), float(np.clip(a @ b, -1., 1.))
    if norm > 1e-14:
        return Rotation.from_rotvec(cross / norm * np.arctan2(norm, cosine)).as_matrix()
    if cosine > 0:
        return np.eye(3)
    options = reference - np.outer(a, a @ reference)
    axis = options[:, int(np.argmax(np.linalg.norm(options, axis=0)))]
    axis /= np.linalg.norm(axis)
    return Rotation.from_rotvec(axis * np.pi).as_matrix()


def fit(source, target, reference, *, relative_tolerance=RELATIVE_COVARIANCE_TOLERANCE):
    source, target = np.asarray(source, dtype=np.float64), np.asarray(target, dtype=np.float64)
    assert source.shape == target.shape and source.ndim == 2 and source.shape[1] == 3
    assert len(source) and np.isfinite(source).all() and np.isfinite(target).all()
    reference = proper(reference)
    center0, center1 = source.mean(0), target.mean(0)
    a, b = source-center0, target-center1
    h = a.T @ b
    u, singular, vt = np.linalg.svd(h)
    correction = np.eye(3)
    correction[-1, -1] = np.linalg.det(vt.T @ u.T)
    original = vt.T @ correction @ u.T
    rmsd = lambda r: float(np.sqrt(np.mean(np.sum((a @ r.T-b)**2, axis=-1))))
    original_error = rmsd(original)
    scale = float(singular[0])
    ratio = float(singular[1]/scale) if scale else 0.
    mode, fraction = 'kabsch', 0.
    rotation = original
    # A zero centered covariance means positions do not supply any orientation.
    if scale <= 1e-24:
        rotation, mode, fraction = reference, 'unresolved_axis', 1.
    elif ratio < relative_tolerance:
        axis_source, axis_target = u[:, 0], vt[0]
        candidate = align_axis(reference @ axis_source, axis_target, reference) @ reference
        # Smoothly remove the special treatment at the numerical-rank boundary.
        # For exact rank one all these rotations align the observed axis exactly.
        source_singular=np.linalg.svd(a,compute_uv=False)
        exact_rank_one=(len(source)==2 or len(source_singular)<2 or source_singular[1]<=1e-14*max(source_singular[0],1e-30))
        # Exact rank one must never retain a fraction of an arbitrary SVD roll.
        # The smooth blend is only for genuinely near-linear, not rank-one data.
        fraction = 1. if exact_rank_one else float((1-ratio/relative_tolerance)**2)
        delta = Rotation.from_matrix(original.T @ candidate).as_rotvec()
        rotation = original @ Rotation.from_rotvec(fraction*delta).as_matrix()
        # Preserve the least-squares atom fit to below FP32 coordinate resolution.
        if rmsd(rotation) > original_error+FIT_NUMERICAL_BUDGET_A:
            low, high = 0., fraction
            for _ in range(48):
                mid=(low+high)/2
                trial=original @ Rotation.from_rotvec(mid*delta).as_matrix()
                if rmsd(trial) <= original_error+FIT_NUMERICAL_BUDGET_A:
                    low=mid
                else:
                    high=mid
            fraction=low
            rotation=original @ Rotation.from_rotvec(fraction*delta).as_matrix()
        mode='rank_one' if ratio < 1e-14 else 'numerically_near_linear'
    translation = center1-center0 @ rotation.T
    error = rmsd(rotation)
    assert np.max(np.abs(rotation.T @ rotation-np.eye(3))) < 1e-10
    assert np.linalg.det(rotation) > .9999999999
    assert error <= original_error+FIT_NUMERICAL_BUDGET_A+1e-12
    audit=dict(mode=mode, singular_values=singular.tolist(), second_to_first_ratio=ratio,
        relative_covariance_tolerance=relative_tolerance, reference_rotation=reference.tolist(),
        old_rotation=original.tolist(), rotation=rotation.tolist(),
        old_fit_RMSD_A=original_error, fit_RMSD_A=error,
        fit_excess_A=error-original_error, reference_distance_rad=distance(reference,rotation),
        old_reference_distance_rad=distance(reference,original), special_fraction=fraction,
        orthogonality_max_error=float(np.max(np.abs(rotation.T@rotation-np.eye(3)))),
        determinant=float(np.linalg.det(rotation)))
    return translation, rotation, error, audit


def initialize(state, case, library, prescribed=None, source='initial_generated_pose'):
    """Anchor the template/world map to the generated state, without true poses."""
    q=state.Q.detach().cpu().numpy()
    xyz=state.physical()
    rotations, diagnostics=[],[]
    prescribed=case['R'] if prescribed is None else prescribed
    for slot, group in enumerate(state.groups):
        _, template=library.template(int(case['labels'][slot]), None)
        _, r, _, audit=fit(template,xyz[state.pn+np.asarray(group)],prescribed[slot])
        audit.update(slot=slot,label=int(case['labels'][slot]),reference_source=source)
        rotations.append(r);diagnostics.append(audit)
    state.orientation_anchor_Q=q.copy()
    state.orientation_anchor_R=np.asarray(rotations)
    state.orientation_anchor_diagnostics=diagnostics
    state.orientation_source=source
    return state


def frames(state, library, labels, oov, *, method='fixed'):
    xyz=state.physical()
    q=state.Q.detach().cpu().numpy()
    centers, rotations, errors, audits=[],[],[],[]
    for slot, group in enumerate(state.groups):
        _, template=library.template(int(labels[slot]),oov[slot])
        reference=proper(q[slot] @ state.orientation_anchor_Q[slot].T) @ state.orientation_anchor_R[slot]
        target=xyz[state.pn+np.asarray(group)]
        t,r,error,audit=fit(template,target,reference)
        if method=='old':
            r=np.asarray(audit['old_rotation'])
            t=target.mean(0)-template.mean(0)@r.T
            error=audit['old_fit_RMSD_A']
        audit.update(slot=slot,label=int(labels[slot]),method=method,
            source_coordinates=template.tolist(),target_coordinates=target.tolist(),
            reference_source=state.orientation_source,
            reference_transport='Q_current @ Q_anchor.T @ template_to_world_anchor',
            template_to_world_rotation=r.tolist())
        centers.append(t);rotations.append(r);errors.append(error);audits.append(audit)
    return np.asarray(centers),np.asarray(rotations),errors,audits


def construct_state(den,graph,groups,device,library,labels,*,desired,preferred,reference_chart=None):
    """Fix the second rank-deficient fit inside NativeState reference transfer.

    preferred maps template coordinates to wanted world coordinates. The source
    fit inside NativeState uses the freshly embedded graph reference instead.
    Compose with the inverse template->reference map before using the prior.
    Its initially unresolved reference roll is a stored coordinate-chart choice,
    not a binding-pose measurement. Transform that chart with a global frame change.
    """
    import joint_sampler
    original=joint_sampler.rigid_fit
    pn=int((graph.frag_idx_map==-1).sum())
    reference_chart=np.eye(3) if reference_chart is None else proper(reference_chart)
    priors=[];maps=[]
    for slot,group in enumerate(groups):
        _,template=library.template(int(labels[slot]),None)
        source=graph.ref_pos.cpu().numpy()[pn+np.asarray(group)]
        _,local_to_reference,_,mapping_audit=fit(template,source,reference_chart)
        priors.append(proper(preferred[slot])@local_to_reference.T)
        maps.append(mapping_audit)
    audits=[]
    def continuous(source,target,legacy_preferred=None):
        slot=len(audits)
        t,r,error,audit=fit(source,target,priors[slot])
        old_t,old_r,old_error=original(source,target,legacy_preferred)
        if audit['mode']=='kabsch':
            t,r,error=old_t,old_r,old_error
        audit.update(slot=slot,label=int(labels[slot]),source_dtype=str(np.asarray(source).dtype),
            target_dtype=str(np.asarray(target).dtype),source_reference_coordinates=np.asarray(source).tolist(),
            wanted_coordinates=np.asarray(target).tolist(),template_to_reference=maps[slot],
            corrected_reference_to_world=priors[slot].tolist(),legacy_preferred=np.asarray(legacy_preferred).tolist(),
            legacy_rotation=old_r.tolist(),legacy_RMSD_A=old_error,
            actual_transfer_rotation=np.asarray(r).tolist(),actual_transfer_RMSD_A=error,
            reference_chart_rotation=reference_chart.tolist())
        audits.append(audit)
        return t,r,error
    joint_sampler.rigid_fit=continuous
    try:
        state=joint_sampler.NativeState(den,graph,groups,device,desired=desired,preferred=preferred)
    finally:
        joint_sampler.rigid_fit=original
    assert len(audits)==len(groups)
    state.reference_transfer_orientation=audits
    return state
