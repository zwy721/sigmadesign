"""Cheap same-state batch-shape check before repeating complete trajectories."""
from common import *
import argparse,copy
import torch
from torch_geometric.data import Batch
from progress import all_cases,choose_cases
from audit_layers import rebuild_state
from stable_precision import install
from precision_diagnostic import install_reduction_probe
from run_validation import load_official
from random_frames import replay_frames
import run_experiment as rx


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--probe',choices=['none','tiled_linear'],default='none');args=parser.parse_args()
    torch.set_num_threads(2);torch.cuda.set_device(0);torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    den=load_official(bootstrap.CHECKPOINT,OUT/'cache/official','cuda:0');install(den);install_reduction_probe(args.probe,den)
    lib=rx.VocabLibrary();cases=choose_cases(all_cases(),32)
    states=[];errors=[]
    for c in cases:
        s,e=rebuild_state(c,den,lib,'v4','full_C_b1');states.append(s);errors.append(e)
    t=((1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3)[5]
    arrays={};rows=[]
    with torch.inference_mode():
        for size in [1,4,8,16,32]:
            output=[]
            for start in range(0,len(states),size):
                part=states[start:start+size]
                b=Batch.from_data_list([s.base for s in part]);b=den._update_batch(b,torch.cat([s.pos0 for s in part]),torch.cat([s.pos for s in part]))
                with replay_frames(b,part,5,None):forces,index=den._compute_forces(b,t.expand(len(part)))
                for i in range(len(part)):
                    keep=(index>=b.ptr[i])&(index<b.ptr[i+1]);output.append(forces[keep].cpu().numpy())
            arrays[size]=output
            if size==1:continue
            checks=[dict(pid=c['pid'],seed=c['seed'],max_force_delta=float(np.max(np.abs(x-y))),exact_equal=bool(np.array_equal(x,y))) for c,x,y in zip(cases,arrays[1],output)]
            rows.append(dict(batch_size=size,checks=checks,all_exact=all(r['exact_equal'] for r in checks),max_force_delta=max(r['max_force_delta'] for r in checks)))
            print(size,rows[-1]['all_exact'],rows[-1]['max_force_delta'],flush=True)
    dump(OUT/f'same_state_32_forward_{args.probe}.json',dict(cases=32,step=5,probe=args.probe,
        note='Same saved post-update physical states, not full dynamic trajectory acceptance',reconstruction_errors_A=errors,rows=rows))


if __name__=='__main__':main()
