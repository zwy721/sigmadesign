"""Unchanged HQ_no_water on saved native outputs; no endpoint repair stage."""
from common import *
import traceback
import torch


def evaluate(folder):
    from denovo_quality.common import object_hash, versions
    from denovo_quality.pipeline import task
    from denovo_quality.io import load_molecule
    from denovo_quality.chemistry import evaluate_chemistry
    torch.set_num_threads(1)
    folder=Path(folder)
    if (folder/'quality_complete.json').exists():return load(folder/'quality_complete.json')
    rec=load(folder/'result.json')
    install_pb()
    cfg=load_config(OUT/'quality_config.json')
    deps=versions()
    compute=object_hash({str(p):sha256(p) for p in list((ROOT/'denovo_quality').glob('*.py'))+[Path(__file__),OUT/'source/common.py']})
    metrics=[task((row,cfg,str(OUT/rec['phase']/'quality'),compute,deps,False)) for row in rec['manifest'] if row['group']=='native_final']
    declared={}
    try:
        original,info,_=load_molecule(dict(sdf_path=str(folder/'native_final/raw.sdf'),
            chemistry_spec_path=str(folder/'native_final/original_spec.json'),record_index=0))
        details,checks=evaluate_chemistry(original,info)
        declared=dict(checks=checks,details=details)
    except Exception as exc:
        declared=dict(unavailable=True,reason=repr(exc),traceback=traceback.format_exc())
    dump(folder/'declared_stereo.json',declared)
    result=dict(attempt_id=rec['attempt_id'],metrics=metrics,declared_stereo=declared,
        input_unchanged=all(m.get('input_unchanged',False) for m in metrics),repair_applied=False)
    rec['status']='complete' if len(metrics)==1 else 'QC_unavailable'
    dump(folder/'result.json',rec);dump(folder/'quality_complete.json',result)
    return result
