"""Evidence tables; absent attempts and unavailable checks remain explicit."""
from common import *
from collections import Counter,defaultdict
import itertools
import orientation

PRIOR=ROOT/'pose_generation_four_arm_comparison/paired_final'
CHECKS=['high_quality','no_severe_internal_clash','no_severe_protein_clash','bond_geometry_valid',
    'angle_geometry_valid','posebusters_all_pass','ring_geometry_valid','torsion_geometry_valid',
    'stereo_definition_complete','stereo_geometry_consistent','in_target_pocket']
GEOMETRY=['cross_bond_MAE_A','cross_angle_MAE_deg','cross_bonds_error_gt_0_15A',
    'cross_angles_error_gt_15deg','severe_cross_internal_pairs','severe_protein_pairs']


def records(root,role):
    return [load(p) for p in sorted((root/role/'structures').glob('*/result.json'))]


def flatten(rec,origin='new'):
    folder=Path(rec['folder']);qc=folder/'quality_complete.json'
    q=load(qc) if qc.exists() else {};m=next((m for m in q.get('metrics',[]) if m.get('metadata',{}).get('group')=='native_final'),{})
    checks=m.get('checks',{});modules=m.get('modules',{});g=modules.get('geometry',{})
    d=q.get('declared_stereo',{})
    events=rec.get('events',[])
    row=dict(origin=origin,attempt_id=rec['attempt_id'],phase=rec['phase'],arm=rec['arm'],strategy=rec['strategy'],
        pid=rec['receptor_id'],seed=rec['seed'],N=rec['N'],status=rec['status'],QC_available=bool(m),
        accepted_updates=sum(e['accepted'] for e in events),
        accepted_identity_updates=sum(e['accepted'] and e['old_labels']!=e['proposed_labels'] for e in events),
        accepted_connection_only_updates=sum(e['accepted'] and e['old_labels']==e['proposed_labels'] for e in events),
        degenerate_orientation_events=sum(bool(e.get('degenerate_slots')) for e in events),
        docking_RMSD_A=rec.get('docking_RMSD_A'),failure_stage=rec.get('failure_stage'),error=rec.get('error'),
        unavailable_checks=m.get('unavailable_checks',[]),quality_errors=m.get('errors',{}),folder=str(folder))
    row.update({k:checks.get(k) for k in CHECKS});row.update(rec.get('final_geometry',{}))
    for k in ['abnormal_bond_count','abnormal_angle_count','abnormal_ring_count','abnormal_amide_torsion_count',
              'severe_internal_clash_pairs','cross_fragment_abnormal_bond_count','within_fragment_abnormal_bond_count']:
        row[k]=g.get(k)
    row['declared_stereo_unavailable']=d.get('unavailable',not bool(d))
    row['declared_stereo_checks']=d.get('checks',{})
    row['input_unchanged']=q.get('input_unchanged')
    return row


def event_rows(recs,origin='new'):
    rows=[];orientation_rows=[];recon=[]
    with (OUT/'diagnostics/template_rank_audit.csv').open(newline='') as handle:
        template_rank={int(r['label']):int(r['rank']) for r in csv.DictReader(handle)}
    for r in recs:
        base=dict(origin=origin,phase=r['phase'],arm=r['arm'],strategy=r['strategy'],pid=r['receptor_id'],seed=r['seed'],N=r['N'])
        for e in r.get('events',[]):
            kind='identity_change' if e['old_labels']!=e['proposed_labels'] else 'connection_only'
            inferred=[i for i,label in enumerate(e['old_labels']) if template_rank.get(label,3)<2]
            row=dict(base,step=e['step'],accepted=e['accepted'],reason=e.get('reason'),proposal_type=kind,
                accepted_type=kind if e['accepted'] else 'no_accepted_update',
                degenerate=bool(e['degenerate_slots']) if 'degenerate_slots' in e else None,
                inferred_template_rank_deficient_slots=inferred,
                degeneration_scope='Measured live fit' if 'degenerate_slots' in e else 'Historical live SVD unavailable; template structural rank only',
                degenerate_slots=e.get('degenerate_slots',[]),old_labels=e['old_labels'],proposed_labels=e['proposed_labels'],
                old_connections=e.get('old_connections'),proposed_connections=e.get('proposed_connections'),
                transfer_target_RMSD_A=e.get('transfer_target_RMSD_A'),
                transfer_target_max_atom_delta_A=e.get('transfer_target_max_atom_delta_A'),
                slot_centroid_transfer_RMSD_A=e.get('slot_centroid_transfer_RMSD_A'),
                transfer_fit_rmsd_A=e.get('transfer_fit_rmsd_A'),random_key=e.get('sample_random_key'))
            for stage in ['before','proposed_topology_before_transfer','proposed_topology_after_transfer','after_transfer','after_next_network']:
                for k,v in e.get(stage,{}).items():row[stage+'__'+k]=v
            for k,v in r.get('final_geometry',{}).items():row['final__'+k]=v
            end_step=min(e['step']+4,23)
            end=next((t['metrics'] for t in r.get('trajectory',[]) if t['step']==end_step),{})
            row['fixed_topology_segment_end_step']=end_step
            for k,v in end.items():row['segment_end__'+k]=v
            # Only same-topology stages support direct coordinate/metric attribution.
            for metric in GEOMETRY:
                pre=e.get('proposed_topology_before_transfer',{}).get(metric)
                post=e.get('proposed_topology_after_transfer',{}).get(metric)
                if pre is not None and post is not None:row['transfer_delta__'+metric]=post-pre
                a=e.get('after_transfer',{}).get(metric);b=e.get('after_next_network',{}).get(metric)
                if a is not None and b is not None:row['next_network_delta__'+metric]=b-a
                if a is not None and end.get(metric) is not None:row['segment_motion_delta__'+metric]=end[metric]-a
            rows.append(row)
            for a in e.get('orientation',[]):
                old=np.asarray(a['old_rotation']);new=np.asarray(a['rotation'])
                orientation_rows.append(dict(base,step=e['step'],accepted=e['accepted'],proposal_type=kind,
                    slot=a['slot'],label=a['label'],mode=a['mode'],singular_values=a['singular_values'],
                    old_to_fixed_SO3_rad=orientation.distance(old,new),old_to_reference_SO3_rad=a['old_reference_distance_rad'],
                    fixed_to_reference_SO3_rad=a['reference_distance_rad'],old_fit_RMSD_A=a['old_fit_RMSD_A'],
                    fixed_fit_RMSD_A=a['fit_RMSD_A'],fit_excess_A=a['fit_excess_A'],
                    orthogonality_max_error=a['orthogonality_max_error'],determinant=a['determinant']))
        for a in r.get('pose_reconstruction',[]):
            entry=dict(base,stage='network_reconstruction',**a)
            trace=Path(r['folder'])/'trajectory'/f'step_{a["step"]:02d}.npz'
            if trace.exists():
                q=np.load(trace)['Q'];det=np.linalg.det(q)
                entry.update(Q_determinant_min=float(det.min()),Q_determinant_max=float(det.max()))
            recon.append(entry)
        for e in r.get('events',[]):
            for a in e.get('reference_transfer_orientation',[]):
                source=np.asarray(a['source_reference_coordinates']);wanted=np.asarray(a['wanted_coordinates'])
                rotation=np.asarray(a['actual_transfer_rotation']);actual=(source-source.mean(0))@rotation.T+wanted.mean(0)
                distances=lambda x:np.linalg.norm(x[:,None]-x[None],axis=-1)
                recon.append(dict(base,stage='reference_shape_transfer',step=e['step'],slot=a['slot'],label=a['label'],accepted=e['accepted'],
                    mode=a['mode'],transfer_fit_RMSD_A=a['actual_transfer_RMSD_A'],
                    reference_vs_wanted_internal_distance_delta_A=float(np.max(np.abs(distances(source)-distances(wanted)))),
                    rigid_reconstruction_internal_distance_delta_A=float(np.max(np.abs(distances(source)-distances(actual)))),
                    interpretation='Reference/target conformer difference is separate from rigid reconstruction numerical drift'))
    return rows,orientation_rows,recon


def mean(rows,key):
    a=[r[key] for r in rows if r.get(key) is not None]
    return float(np.mean(a)) if a else None


def strata(rows,dimensions):
    bins=defaultdict(list)
    for r in rows:bins[tuple(r.get(k) for k in dimensions)].append(r)
    out=[]
    for keys,group in sorted(bins.items(),key=lambda x:str(x[0])):
        entry=dict(zip(dimensions,keys));entry['attempts']=len(group)
        for k in CHECKS:
            entry[k+'_pass']=sum(r.get(k) is True for r in group)
            entry[k+'_unavailable']=sum(r.get(k) is None for r in group)
        for k in GEOMETRY:entry[k+'_mean']=mean(group,k)
        out.append(entry)
    return out


def paired(rows,left='B',right='C'):
    a={(r['pid'],r['seed']):r for r in rows if r['arm']==left}
    b={(r['pid'],r['seed']):r for r in rows if r['arm']==right}
    result=[]
    for key in ['high_quality']+GEOMETRY:
        values=defaultdict(list);missing=0
        for sample in sorted(set(a)&set(b)):
            x,y=a[sample].get(key),b[sample].get(key)
            if x is None or y is None:missing+=1;continue
            values[sample[0]].append(float(y)-float(x))
        pocket=[float(np.mean(v)) for v in values.values()]
        result.append(dict(left=left,right=right,metric=key,paired=sum(map(len,values.values())),unavailable_pairs=missing,
            mean_paired_delta=float(np.mean([v for g in values.values() for v in g])) if pocket else None,
            per_pocket_mean_delta={k:float(np.mean(v)) for k,v in values.items()},
            pocket_sign_flip_two_sided_p=(sum(abs(np.mean(np.array(pocket)*s))>=abs(np.mean(pocket))-1e-14 for s in itertools.product([-1,1],repeat=len(pocket)))/2**len(pocket)) if pocket else None,
            caveat='Six previously examined pockets; exploratory paired sign-flip, not a population generalization test'))
    return result


def tables():
    primary=records(OUT,'main');aux=records(OUT,'ablation')+records(OUT,'docking')+records(OUT,'known')
    rows=[flatten(r) for r in primary];extra=[flatten(r) for r in aux]
    if rows:csvwrite(OUT/'PER_GENERATION_RESULTS.csv',rows)
    if extra:csvwrite(OUT/'AUXILIARY_GENERATION_RESULTS.csv',extra)
    events,ori,recon=event_rows(primary+aux)
    if events:csvwrite(OUT/'DYNAMIC_UPDATE_GEOMETRY.csv',events)
    if ori:csvwrite(OUT/'OLD_VS_NEW_ORIENTATION.csv',ori)
    if recon:csvwrite(OUT/'POSE_RECONSTRUCTION_ERROR.csv',recon)
    historical=records(PRIOR,'main')
    old_events,_,_=event_rows([r for r in historical if r['arm']=='C'],origin='historical_original_C')
    if old_events:csvwrite(OUT/'diagnostics/HISTORICAL_C_UPDATE_GEOMETRY.csv',old_events)
    summary=dict(primary_completed=len(primary),expected_primary=216,
        arms=strata(rows,['arm']),by_pocket=strata(rows,['arm','pid']),by_N=strata(rows,['arm','N']),
        by_accepted_count=strata(rows,['arm','accepted_updates']),
        by_identity_count=strata(rows,['arm','accepted_identity_updates']),
        paired=paired(rows)+paired(rows,'B','E_connection_only'),
        failures=[r for r in rows if r['status']!='complete'],QC_unavailable=sum(not r['QC_available'] for r in rows))
    dump(OUT/'summary.json',summary)
    for dim in ['by_pocket','by_N','by_accepted_count','by_identity_count']:
        if summary[dim]:csvwrite(OUT/'diagnostics'/f'{dim}.csv',summary[dim])
    return summary


if __name__=='__main__':tables()
