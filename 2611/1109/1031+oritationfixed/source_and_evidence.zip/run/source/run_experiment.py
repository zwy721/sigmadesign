"""Frozen paired diagnostic supervisor; resumable only with intact inputs."""
from common import *
import argparse
import copy
import math
import shutil
import subprocess
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from multiprocessing import get_context
import torch
from rdkit import Chem, RDLogger
from scipy.spatial.transform import Rotation
from runtime import BatchEngine, Geometry, state_from, SCALE
from joint_sampler import NativeState, chemical_graph, topology_key
from oracle_graph import assemble, oracle_from_official
from run_validation import load_official, official_graph, seed_all
from vocab_chemistry import VocabLibrary, ChemistryRejected
import orientation

RDLogger.DisableLog('rdApp.*')
ARMS = ['A', 'B', 'C', 'D', 'E_connection_only']
_LIB = _HEAD = None


def plan():
    history = load(HISTORY/'frozen_plan.json')
    settings = dict(version=1, training=False, physical_gpu=0, steps=24, noise_scale=0.,
                    cohort=history['cohort'], seeds=history['seeds'], arms=ARMS,
                    per_arm_attempts=72, primary_attempts=360,
                    dev_pockets=['2zwz', '4i5p', '2wos'], dev_seeds=[42001, 42002],
                    preflight_seeds=[43001], strategy='alternating_categorical',
                    revision_steps=[5, 10, 15, 20], history_plan_sha256=sha256(HISTORY/'frozen_plan.json'),
                    weights=history['weights'], N_prior=history['N_prior'], search_config=history['search_config'],
                    batch_sizes=[1, 4, 8, 16, 32], precision='FP32; BF16 exploratory only, never selected without full quality validation',
                    consistency=dict(max_atom_delta_A=.025, coordinate_RMSD_A=.005, internal_distance_delta_A=.0002),
                    guidance_candidates=[
                        dict(name='gentle', weights=[1., .5, 10., 10.], step=.02, max_translation_A=.05, max_rotation_rad=.02, start_t=.3),
                        dict(name='balanced', weights=[1., 1., 20., 20.], step=.04, max_translation_A=.08, max_rotation_rad=.03, start_t=.3),
                        dict(name='repulsion', weights=[1., 1., 40., 40.], step=.04, max_translation_A=.08, max_rotation_rad=.03, start_t=.3)],
                    guidance_selection='Minimum mean dev native score: (bondMAE/.15)^2+(angleMAE/15)^2+10*any_internal_clash+10*any_protein_clash; ties keep earlier candidate; no formal metrics read',
                    guidance_references='Full predicted graph MMFF94s equilibrium bonds and angles; unavailable retained; no bound ligand geometry',
                    known_docking_reference_ids='1a30,1r5y,2j7h,2wvt,3b1m,3f3e,3mss,3ryj,4agn,4f9w,4m0y,5tmn'.split(','),
                    known_docking_reference_seeds=[41001],
                    independent_validation='No additional untouched pocket cohort established locally; six primary pockets are previously viewed diagnostics',
                    frozen_QC_config_sha256=sha256(HISTORY/'quality_config.json'),
                    frozen_PB_config_sha256=sha256(HISTORY/'posebusters_no_water.json'),
                    repairs='Frozen rigid and B1 local-flex from native_final independently',
                    approved_changes=['alternating_categorical dynamic protocol', '72-attempt fixed-identity connection-only E arm', 'three dev pockets for D selection'])
    settings.update(version=3, base_protocol_sha256=sha256(OUT/'protocol.json'),
                    prompt_check_sha256=sha256(OUT/'prompt_check.md'),
                    stochastic_replay='Stable sample+step+semantic typed-edge uniform directions; no whole-chemistry salt; shared edges retain their auxiliary directions after topology changes',
                    original_FP32_known_reference_attempts=12, total_primary_and_all_references=384,
                    numerical_path='FP32 weights and interfaces, FP64 linear/einsum/bmm contraction accumulation; one batched backbone forward and per-sample official mechanics',
                    A_stereo='Frozen historical geometry-derived HQ plus original declared-chemistry stereo checks separately',
                    known_reference_attempts=12, total_primary_plus_known_attempts=372)
    bases = settings['guidance_candidates']
    settings['guidance_candidates'] = [dict(base, name=base['name']+f'_t{start}', start_t=start)
                                       for base in bases for start in [.1, .3, .6]]
    path = OUT/'effective_protocol.json'
    if path.exists():
        assert load(path) == settings, 'Protocol changed'
    else:
        dump(path, settings)
    return settings


def audit(settings):
    target = OUT/'input_audit.json'
    if target.exists():
        old = load(target)
        for name, digest in old['frozen_files'].items():
            assert sha256(name) == digest, name
        return old
    files = {}
    for p in list((PROJECT).glob('*.py')) + list((HISTORY/'source').glob('*.py')) + list((ROOT/'denovo_quality').glob('*.py')):
        files[str(p)] = sha256(p)
    for item in settings['weights'].values():
        assert sha256(item['path']) == item['sha256']
        files[item['path']] = item['sha256']
    for name in ['quality_config.json', 'posebusters_no_water.json', 'frozen_plan.json', 'summary.json', 'delivery_fingerprints.json']:
        p = HISTORY/name
        files[str(p)] = sha256(p)
    # Hash all historical study files once; future verification uses this read-only snapshot.
    historical = {str(p): sha256(p) for p in HISTORY.rglob('*') if p.is_file()}
    dump(OUT/'historical_fingerprints.json', historical)
    for pid in settings['cohort']:
        folder = ROOT/'fbdd_efficiency_generalization_20261103/independent_inputs'/pid
        for name in [f'{pid}_LIG_ligand.sdf', 'source_preparation.json']:
            p = folder/name
            files[str(p)] = sha256(p)
        p = ROOT/'2611/1105/1039+no_water_test/pockets'/f'{pid}_no_water.pdb'
        files[str(p)] = sha256(p)
    for name in ['quality_config.json', 'posebusters_no_water.json']:
        shutil.copyfile(HISTORY/name, OUT/name)
    gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=index,name,memory.total,memory.used', '--format=csv,noheader'], text=True)
    result = dict(passed=True, UTC=datetime.now(timezone.utc).isoformat(), frozen_files=files,
                  historical_files=len(historical), historical_fingerprints_sha256=sha256(OUT/'historical_fingerprints.json'),
                  gpu_inventory=gpu, torch=torch.__version__, official_import=bootstrap.verify_imports(),
                  ligand_defined_pockets=True, BCD_true_ligand_graph_or_coordinates=False,
                  cofactors='Historical model parser excludes unsupported HETATM; preserved non-water environment used by QC/guidance',
                  official_weights_frozen=True)
    dump(target, result)
    return result


def context(pid, role):
    from sigmadock.chem.parsing import get_protein, structure_to_rdkit
    if role == 'main':
        path = ROOT/'2611/1105/1039+no_water_test/pockets'/f'{pid}_no_water.pdb'
    else:
        original = PROJECT/'results/connection_trajectory_20261101/inputs'/pid/f'{pid}_LIG_pocket.pdb'
        path = OUT/'inputs/dev'/f'{pid}_LIG_pocket.pdb'
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            lines = [line for line in original.read_text().splitlines(keepends=True)
                     if not (line.startswith(('ATOM  ', 'HETATM')) and line[17:20].strip() in {'HOH', 'WAT', 'DOD'})]
            path.write_text(''.join(lines))
    pocket = structure_to_rdkit(get_protein(path))
    return dict(pocket=pocket, pocket_com=pocket.GetConformer().GetPositions().mean(0).astype('float32'),
                pdb_path=str(path), ligand_path=None)


def cpu_init():
    global _LIB, _HEAD
    torch.set_num_threads(1)
    from trajectory_connections import load_connection
    _LIB = VocabLibrary()
    _HEAD = load_connection(load(HISTORY/'frozen_plan.json')['weights']['connection']['path'], 'cpu')


def search_job(job):
    from trajectory_connections import ConnectionRuntime
    from hierarchical_topology import hierarchical_search, SearchConfig
    started = time.perf_counter()
    runtime = ConnectionRuntime(_LIB, _HEAD, job['labels'], [None]*len(job['labels']), 'cpu', policy='wide', head='full')
    pred = runtime.predict(job['T'], job['R'], job['t'], policy='wide', head='full')
    search = hierarchical_search(runtime, pred, k=1, config=SearchConfig())
    assert not search['truth_used']
    search['seconds'] = time.perf_counter()-started
    search['raw_head_complete'] = pred['assembled'] is not None
    if job.get('return_probabilities'):
        search['classifier_probabilities'] = pred['p'].tolist()
        search['classifier_metadata'] = pred['meta'].tolist()
    if job.get('output'):
        dump(job['output'], search)
    return search


def prepare_case(pid, seed, role, lib, pool):
    started = time.perf_counter()
    ctx = context(pid, role)
    n = int(np.random.default_rng(seed+912711).choice([3, 4, 5, 6]))
    centers = np.random.default_rng(seed).normal(0, 2.7, (n, 3)) + ctx['pocket_com']
    R = Rotation.random(n, random_state=seed).as_matrix()
    rng = np.random.default_rng(seed+17331)
    prior = np.array([p['train_occurrences']*(p['n_heavy'] >= 2 and bool(p['candidate_sites'])) for p in lib.properties], float)
    prior /= prior.sum()
    labels = rng.choice(len(prior), n, p=prior).tolist()
    hist = history_module('run')
    T, desired = hist.frames_for(lib, labels, centers, R)
    folder = OUT/role/'initial'/f'{pid}_{seed}'
    folder.mkdir(parents=True, exist_ok=True)
    job = dict(labels=labels, T=T, R=R, t=1., output=str(folder/'search.json'))
    search = pool.submit(search_job, job).result() if pool is not None else search_job(job)
    if not search['candidates']:
        raise ChemistryRejected('No legal initial graph within frozen budget')
    connections = search['candidates'][0]['connections']
    graph, groups, spec = chemical_graph(lib, labels, connections, ctx, [None]*n, seed=seed)
    result = dict(pid=pid, seed=seed, role=role, context=ctx, N=n, labels=labels, connections=connections,
                  graph=graph, groups=groups, spec=spec, desired=desired, R=R, id_rng_state=rng.bit_generator.state,
                  initial_search_seconds=search['seconds'], preparation_seconds=time.perf_counter()-started)
    torch.save(result, folder/'case.pt')
    np.savez_compressed(folder/'initial.npz', T=T, R=R, xyz=np.concatenate(desired))
    dump(folder/'input_hashes.json', dict(labels=labels, connections=connections,
         graph_spec_sha256=hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest(),
         initial_npz_sha256=sha256(folder/'initial.npz'), pocket_sha256=sha256(ctx['pdb_path']),
         ligand_information_used=False, case_sha256=sha256(folder/'case.pt')))
    return result


def prepare_all(pids, seeds, role, lib, pool):
    cases, pending = {}, {}
    for pid in pids:
        context(pid, role)  # Prepare common pocket files before independent workers.
    for pid in pids:
        for seed in seeds:
            folder = OUT/role/'initial'/f'{pid}_{seed}'
            if (folder/'failure.json').exists():
                cases[pid, seed] = load(folder/'failure.json')
                continue
            if (folder/'case.pt').exists():
                stored = load(folder/'input_hashes.json')
                assert sha256(folder/'case.pt') == stored['case_sha256']
                cases[pid, seed] = torch.load(folder/'case.pt', weights_only=False)
                continue
            pending[pool.submit(prepare_initial_job, (pid, seed, role))] = (pid, seed, folder)
    for future in as_completed(pending):
        pid, seed, folder = pending[future]
        try:
            case = future.result()
            cases[pid, seed] = case
            print('PREPARED', role, pid, seed, case['N'], flush=True)
        except Exception as exc:
            case = dict(pid=pid, seed=seed, role=role, preparation_failed=True,
                        error=repr(exc), traceback=traceback.format_exc())
            dump(folder/'failure.json', case)
            cases[pid, seed] = case
    return [cases[pid, seed] for pid in pids for seed in seeds]


def prepare_initial_job(args):
    return prepare_case(*args, _LIB, None)


def oracle_case(pid, seed, role, template=None):
    if role == 'main':
        sdf = ROOT/'fbdd_efficiency_generalization_20261103/independent_inputs'/pid/f'{pid}_LIG_ligand.sdf'
        ctx = context(pid, role)
        pdb = Path(ctx['pdb_path'])
    elif role in ['dev', 'preflight']:
        sdf = PROJECT/'results/connection_trajectory_20261101/inputs'/pid/f'{pid}_LIG_ligand.sdf'
        ctx = context(pid, 'dev')
        pdb = Path(ctx['pdb_path'])
    else:
        sdf = bootstrap.INPUTS/pid/f'{pid}_LIG_ligand.sdf'
        pdb = bootstrap.INPUTS/pid/f'{pid}_LIG_pocket.pdb'
        # Known CASF baseline uses its original official input environment.
    graph, reference = official_graph(sdf, pdb, seed=seed)
    spec = oracle_from_official(graph, reference)
    groups = [f['atom_ids'] for f in spec['fragments']]
    if role not in ['main', 'dev', 'preflight']:
        from sigmadock.chem.parsing import get_protein, structure_to_rdkit
        pocket = structure_to_rdkit(get_protein(pdb))
        ctx = dict(pocket=pocket, pocket_com=graph.pocket_com.numpy().reshape(3), pdb_path=str(pdb), ligand_path=str(sdf))
    return dict(pid=pid, seed=seed, role=role, context=ctx, graph=graph, groups=groups, spec=spec,
                labels=[-1]*len(groups), connections=[], N=len(groups), oracle=True,
                reference_sdf=str(sdf), target=Chem.Mol(graph.mol_info['original']))


class Client:
    def __init__(self):
        self.log = (OUT/'identity_server.log').open('a')
        self.proc = subprocess.Popen([sys.executable, '-B', str(OUT/'source/identity_server.py'),
                                     '--assets', str(OUT/'cache/identity')], stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=self.log, text=True, bufsize=1)
        line = self.proc.stdout.readline()
        assert line and json.loads(line).get('ready'), line

    def query(self, T, R, t, seed, folder, step):
        hist = history_module('run')
        return hist.Client.query(self, T, R, t, seed, folder, step, hist.STRATEGIES['alternating_categorical'])

    def close(self):
        if self.proc.poll() is None:
            self.proc.stdin.write('{"close":true}\n')
            self.proc.stdin.flush()
            self.proc.wait(timeout=60)
        self.log.close()


def run_batch(cases, arm, den, client, pool, lib, guidance=None, tag=None, orientation_method='fixed', suppress_updates=False, capture=True):
    hist = history_module('run')
    active, records = [], []
    role = cases[0]['role']
    for case in cases:
        folder = OUT/role/'structures'/f'{case["pid"]}_{case["seed"]}_{tag or arm}'
        if (folder/'result.json').exists():
            records.append(load(folder/'result.json'))
            continue
        folder.mkdir(parents=True, exist_ok=True)
        rec = dict(attempt_id=f'{role}_{case["pid"]}_{case["seed"]}_{tag or arm}', arm=arm, phase=role,
                   strategy=tag or arm,
                   receptor_id=case['pid'], seed=case['seed'], N=case.get('N'), status='failed',
                   manifest=[], events=[], guidance=[], trajectory=[], pose_NFE=0, folder=str(folder),
                   initial_labels=case.get('labels'), initial_connections=case.get('connections'),
                   oracle=case.get('oracle', False), initial_input_path=str(OUT/role/'initial'/f'{case["pid"]}_{case["seed"]}'/'input_hashes.json'))
        if case.get('preparation_failed'):
            rec.update(failure_stage='initial_graph', error=case['error'])
            dump(folder/'result.json', rec)
            records.append(rec)
            continue
        state = state_from(case, den)
        if not case.get('oracle'):
            orientation.initialize(state, case, lib)
        initial_physical=state.physical()
        state.internal_distance_reference=[np.linalg.norm(initial_physical[state.pn+np.asarray(g)][:,None]-initial_physical[state.pn+np.asarray(g)][None,:],axis=-1) for g in state.groups]
        item = dict(case=copy.deepcopy(case), state=state, record=rec, folder=folder,
                    geometry=Geometry(case['spec'], case['context']), rng=np.random.default_rng())
        if case.get('id_rng_state'):
            item['rng'].bit_generator.state = case['id_rng_state']
        rec['orientation_method'] = orientation_method
        rec['diagnostic_suppress_updates'] = suppress_updates
        rec['initial_transfer_fit_rmsd_A'] = state.transfer_errors
        rec['orientation_initialization'] = getattr(state, 'orientation_anchor_diagnostics', [])
        rec['initial_reference_transfer_orientation'] = getattr(state,'reference_transfer_orientation',[])
        rec['initial_xyz_sha256'] = hashlib.sha256(state.physical().tobytes()).hexdigest()
        np.savez_compressed(folder/'initial_state.npz', pos=state.pos.cpu().numpy(), C=state.C.cpu().numpy(), Q=state.Q.cpu().numpy())
        if arm == 'C':
            _, _, stats = client.query(np.array([x.mean(0) for x in case['desired']])-case['context']['pocket_com'], case['R'], 1., case['seed'], folder, 0)
            rec['initial_identity_observer'] = stats
        active.append(item)
    engine = BatchEngine(den)
    grid = (1.+torch.arange(25, device='cuda:0')/24*(.005**(1/3)-1.))**3
    started = time.perf_counter()
    for step, t in enumerate(grid[:-1]):
        if arm in ['C', 'E_connection_only'] and step in [5, 10, 15, 20]:
            futures = []
            for item in active:
                case, state, rec = item['case'], item['state'], item['record']
                T, R, fit, orientation_audit = orientation.frames(state, lib, case['labels'], [None]*case['N'], method=orientation_method)
                event_folder = item['folder']/f'event_{step:02d}'
                event_folder.mkdir(exist_ok=True)
                before_xyz = state.physical()
                np.savez_compressed(event_folder/'before.npz', xyz=before_xyz, C=state.C.cpu().numpy(), Q=state.Q.cpu().numpy(), T=T, R=R,
                    anchor_Q=state.orientation_anchor_Q, anchor_R=state.orientation_anchor_R)
                dump(event_folder/'orientation.json', orientation_audit)
                proposed = case['labels'].copy()
                if arm == 'C':
                    raw, q, stats = client.query(T-case['context']['pocket_com'], R, float(t), case['seed'], item['folder'], step)
                    proposed = [int(item['rng'].choice(len(p), p=p)) for p in q]
                event = dict(step=step, t=float(t), old_labels=case['labels'].copy(), proposed_labels=proposed,
                             old_connections=copy.deepcopy(case['connections']), accepted=False,
                             orientation=orientation_audit,
                             degenerate_slots=[a['slot'] for a in orientation_audit if a['mode']!='kabsch'],
                             before=item['geometry'].metrics(state.physical()[state.pn:state.pn+item['geometry'].mol.GetNumAtoms()]))
                future = pool.submit(search_job, dict(labels=proposed, T=T, R=R, t=float(t),
                                                       output=str(item['folder']/f'search_{step:02d}.json')))
                futures.append((item, T, R, proposed, event, future))
            for item, T, R, proposed, event, future in futures:
                case, state = item['case'], item['state']
                try:
                    search = future.result()
                    event['search_seconds'] = search['seconds']
                    if not search['candidates']:
                        raise ChemistryRejected('No legal graph within frozen search budget')
                    nc = search['candidates'][0]['connections']
                    event['proposed_connections'] = nc
                    if suppress_updates:
                        event['reason'] = 'diagnostic_suppress_updates'
                    elif topology_key(proposed, nc) == topology_key(case['labels'], case['connections']):
                        event['reason'] = 'same_chemistry'
                    else:
                        graph, groups, spec = chemical_graph(lib, proposed, nc, case['context'], [None]*case['N'], seed=case['seed'])
                        previous = state.physical()
                        wanted = []
                        for i, label in enumerate(proposed):
                            old = previous[state.pn+np.asarray(state.groups[i])]
                            if label == case['labels'][i]:
                                wanted.append(old.copy())
                            else:
                                _, template = lib.template(label)
                                wanted.append((template-template.mean(0))@R[i].T+old.mean(0))
                        with torch.no_grad():
                            if orientation_method=='fixed':
                                replacement=orientation.construct_state(den,graph,groups,'cuda:0',lib,proposed,desired=wanted,preferred=R)
                            else:
                                replacement = NativeState(den, graph, groups, 'cuda:0', desired=wanted, preferred=R)
                        event['reference_transfer_orientation'] = getattr(replacement,'reference_transfer_orientation',[])
                        initial_physical=replacement.physical()
                        replacement.internal_distance_reference=[np.linalg.norm(initial_physical[replacement.pn+np.asarray(g)][:,None]-initial_physical[replacement.pn+np.asarray(g)][None,:],axis=-1) for g in groups]
                        new_case = dict(case, spec=spec, labels=proposed, connections=nc, groups=groups)
                        orientation.initialize(replacement, new_case, lib, prescribed=R,
                            source='explicit proposed-template to wanted-world map used by historical shape transfer')
                        event['new_orientation_anchor'] = replacement.orientation_anchor_diagnostics
                        event['reference_frame_transport'] = dict(
                            prescription='wanted_i=(new_template_i-mean) @ proposal_R_i.T + old_center_i',
                            template_to_wanted_world_rotation=R.tolist(),
                            note='New template axes are anchored to the explicit construction map; no comparison of different local-frame R matrices.')
                        proposed_geometry = Geometry(spec, case['context'])
                        wanted_array = np.empty((proposed_geometry.mol.GetNumAtoms(),3))
                        for group,value in zip(groups,wanted):wanted_array[group]=value
                        event['proposed_topology_before_transfer'] = proposed_geometry.metrics(wanted_array)
                        after_array = replacement.physical()[replacement.pn:replacement.pn+proposed_geometry.mol.GetNumAtoms()]
                        event['proposed_topology_after_transfer'] = proposed_geometry.metrics(after_array)
                        event['transfer_target_RMSD_A'] = float(np.sqrt(np.mean(np.sum((after_array-wanted_array)**2,axis=-1))))
                        event['transfer_target_max_atom_delta_A'] = float(np.linalg.norm(after_array-wanted_array,axis=-1).max())
                        np.savez_compressed(item['folder']/f'event_{step:02d}'/'proposal_transfer.npz',
                            target_xyz=wanted_array, actual_xyz=after_array, R=R,
                            C=replacement.C.cpu().numpy(),Q=replacement.Q.cpu().numpy())
                        if max(replacement.transfer_errors, default=0) > .5:
                            raise ChemistryRejected('Reference transfer fit exceeds frozen 0.5 A bound')
                        replacement.base = replacement.batch.to_data_list()[0]
                        from random_frames import attach
                        attach(replacement, new_case, step=step)
                        old_centers = np.array([previous[state.pn+np.asarray(g)].mean(0) for g in state.groups])
                        actual = replacement.physical()
                        new_centers = np.array([actual[replacement.pn+np.asarray(g)].mean(0) for g in replacement.groups])
                        event['slot_centroid_transfer_RMSD_A'] = float(np.sqrt(np.mean(np.sum((new_centers-old_centers)**2, axis=-1))))
                        event['transfer_fit_rmsd_A'] = replacement.transfer_errors
                        event['accepted'] = True
                        case.update(graph=graph, groups=groups, spec=spec, labels=proposed, connections=nc)
                        item.update(state=replacement, geometry=Geometry(spec, case['context']))
                except (ChemistryRejected, ValueError, RuntimeError, AssertionError) as exc:
                    if isinstance(exc, torch.OutOfMemoryError):
                        raise
                    event.update(reason=repr(exc), fallback='retain_last_legal_graph')
                state = item['state']
                event['after_transfer'] = item['geometry'].metrics(state.physical()[state.pn:state.pn+item['geometry'].mol.GetNumAtoms()])
                event['sample_random_key'] = str(state.replay_key)
                event['new_labels'] = item['case']['labels']
                event['new_connections'] = item['case']['connections']
                dump(item['folder']/f'event_{step:02d}'/'event_before_network.json',event)
                item['record']['events'].append(event)
        before_positions = [item['state'].physical() for item in active]
        network_trace = {'_edge_detail':False} if capture else None
        with torch.no_grad():
            engine.step([x['state'] for x in active], t, grid[step]-grid[step+1], trace=network_trace)
        if capture:
            network_folder=OUT/role/'network_outputs'/f'{cases[0]["pid"]}_{cases[0]["seed"]}_{tag or arm}'
            network_folder.mkdir(parents=True,exist_ok=True)
            torch.save(network_trace,network_folder/f'step_{step:02d}.pt')
        for item, before_pos in zip(active, before_positions):
            state, rec = item['state'], item['record']
            xyz = state.physical()[state.pn:state.pn+item['geometry'].mol.GetNumAtoms()]
            metrics = item['geometry'].metrics(xyz)
            internal_delta=max((float(np.max(np.abs(np.linalg.norm(xyz[np.asarray(g)][:,None]-xyz[np.asarray(g)][None,:],axis=-1)-reference))) for g,reference in zip(state.groups,state.internal_distance_reference)),default=0.)
            rec.setdefault('pose_reconstruction',[]).append(dict(step=step,max_internal_distance_delta_A=internal_delta,
                Q_orthogonality_max_error=float(np.max(np.abs(state.Q.cpu().numpy().transpose(0,2,1)@state.Q.cpu().numpy()-np.eye(3)))),
                reference='actual state initialization after latest accepted graph transfer'))
            assert internal_delta<=.0002,'Internal rigid distances exceed original 0.0002 A gate'
            rec['pose_NFE'] += 1
            rec['trajectory'].append(dict(step=step, t=float(t), neural_motion_RMSD_A=float(np.sqrt(np.mean(np.sum((state.physical()-before_pos)**2, axis=-1)))), metrics=metrics))
            if capture:
                trace_folder=item['folder']/'trajectory'
                trace_folder.mkdir(exist_ok=True)
                np.savez_compressed(trace_folder/f'step_{step:02d}.npz',xyz=xyz,C=state.C.cpu().numpy(),Q=state.Q.cpu().numpy(),
                    labels=np.array(item['case']['labels']),random_key=np.array(str(state.replay_key)))
            if rec['events'] and rec['events'][-1]['step'] == step:
                rec['events'][-1]['after_next_network'] = metrics
                dump(item['folder']/f'event_{step:02d}'/'event.json',rec['events'][-1])
            if arm == 'D' and guidance and float(t) <= guidance['start_t']:
                with torch.profiler.record_function('geometry_guidance_gradients'):
                    event = item['geometry'].guide(state, guidance)
                rec['guidance'].append(dict(step=step, t=float(t), **event))
    wall = time.perf_counter()-started
    dump(OUT/role/'batches'/f'{cases[0]["pid"]}_{cases[0]["seed"]}_{tag or arm}.json',
         dict(arm=arm, batch=len(active), wall_seconds=wall, forward_calls=engine.calls,
              timings=engine.timings, oom=engine.oom))
    for item in active:
        case, state, rec, folder = item['case'], item['state'], item['record'], item['folder']
        xyz = state.physical()[state.pn:state.pn+item['geometry'].mol.GetNumAtoms()]
        mol = assemble(case['spec'])
        for i, x in enumerate(xyz):
            mol.GetConformer().SetAtomPosition(i, x.tolist())
        hist.save_stage(folder, 'native_final', mol, case['spec'], rec, case['context'])
        rec.update(status='native_complete', failure_stage=None, labels=case['labels'], connections=case['connections'],
                   groups=case['groups'], spec=case['spec'], context_pdb=case['context']['pdb_path'],
                   final_geometry=item['geometry'].metrics(xyz), batch_wall_seconds=wall,
                   allocated_batch_wall_seconds=wall/max(len(active), 1), batch_forward_calls=engine.calls,
                   repair_errors={})
        if case.get('oracle'):
            target = Chem.RemoveHs(Chem.Mol(case['target']))
            matches = mol.GetSubstructMatches(target, uniquify=False, useChirality=False, maxMatches=4096)
            truth = target.GetConformer().GetPositions()
            rec['docking_RMSD_A'] = min((float(np.sqrt(np.mean(np.sum((xyz[list(match)]-truth)**2, axis=-1)))) for match in matches), default=None)
            rec['reference_sdf'] = case['reference_sdf']
        torch.save(dict(mol=mol, spec=case['spec'], context=case['context'], groups=case['groups']), folder/'postprocess_input.pt')
        dump(folder/'result.json', rec)
        records.append(rec)
    print('BATCH COMPLETE', role, tag or arm, len(cases), round(wall, 2), flush=True)
    return records


def postprocess(folder):
    """Frozen CPU repairs and full unchanged no-water QC; failures retained."""
    from denovo_quality.common import object_hash, versions
    from denovo_quality.pipeline import task
    torch.set_num_threads(1)
    folder = Path(folder)
    if (folder/'quality_complete.json').exists():
        return load(folder/'quality_complete.json')
    rec = load(folder/'result.json')
    inp = torch.load(folder/'postprocess_input.pt', weights_only=False)
    mol, spec, ctx = inp['mol'], inp['spec'], inp['context']
    hist = history_module('run')
    fids = np.empty(mol.GetNumAtoms(), dtype=int)
    for i, g in enumerate(inp['groups']):
        fids[g] = i
    for stage, fun in [('rigid_repair', lambda: hist.repair(mol, fids, ctx['pdb_path'])),
                       ('local_flex_repair', lambda: hist.opt.repair(mol, fids, ctx['pdb_path'], local=load(hist.OLD/'fixed_parameters.json')['local']))]:
        try:
            fixed, meta = fun()
            dump(folder/stage/'repair.json', meta)
            hist.save_stage(folder, stage, fixed, spec, rec, ctx)
        except Exception as exc:
            rec['repair_errors'][stage] = dict(error=repr(exc), traceback=traceback.format_exc())
    if rec.get('oracle'):
        from denovo_quality.io import load_molecule
        from denovo_quality.chemistry import evaluate_chemistry
        declared = {}
        for stage in ['native_final', 'rigid_repair', 'local_flex_repair']:
            try:
                original, info, _ = load_molecule(dict(sdf_path=str(folder/stage/'raw.sdf'), chemistry_spec_path=str(folder/stage/'original_spec.json'), record_index=0))
                details, checks = evaluate_chemistry(original, info)
                declared[stage] = dict(checks=checks, details=details)
            except Exception as exc:
                declared[stage] = dict(unavailable=True, reason=repr(exc))
        dump(folder/'A_DECLARED_STEREO.json', declared)
    install_pb()
    cfg = load_config(OUT/'quality_config.json')
    deps = versions()
    compute = object_hash({str(p): sha256(p) for p in list((ROOT/'denovo_quality').glob('*.py')) + [Path(__file__), Path(__file__).parent/'common.py']})
    metrics = []
    for row in rec['manifest']:
        metrics.append(task((row, cfg, str(OUT/rec['phase']/'quality'), compute, deps, False)))
    rec['status'] = 'complete' if not rec['repair_errors'] else 'repair_incomplete'
    dump(folder/'result.json', rec)
    dump(folder/'quality_complete.json', dict(attempt_id=rec['attempt_id'], metrics=metrics,
         repair_errors=rec['repair_errors'], input_unchanged=all(r.get('input_unchanged', False) for r in metrics)))
    return dict(attempt_id=rec['attempt_id'], QC=len(metrics))


def benchmark(den, cases, settings):
    selected = [c for c in cases if not c.get('preparation_failed')][:4]
    assert len(selected) >= 3, 'Insufficient distinct valid benchmark graphs'
    grid = (1.+torch.arange(25, device='cuda:0')/24*(.005**(1/3)-1.))**3
    consistency = load(OUT/'replay_validation.json')
    assert consistency['passed']
    for name, digest in consistency['source_sha256'].items():
        assert sha256(OUT/'source'/name) == digest, f'Acceptance source changed: {name}'
    rows = []
    for size in settings['batch_sizes']:
        states = [state_from(selected[i%len(selected)], den) for i in range(size)]
        engine = BatchEngine(den)
        torch.cuda.reset_peak_memory_stats()
        try:
            for step in range(2):
                engine.step(states, grid[step], grid[step]-grid[step+1])
            engine.timings.clear()
            started = time.perf_counter()
            for step in range(2, 6):
                engine.step(states, grid[step], grid[step]-grid[step+1])
            elapsed = time.perf_counter()-started
            forward = sum(x['forward_ms'] for x in engine.timings)/1000
            rows.append(dict(batch_size=size, elapsed_seconds=elapsed, molecule_steps_per_second=size*4/elapsed,
                             network_molecule_steps_per_second=size*4/forward, forward_seconds=forward,
                             peak_allocated_bytes=torch.cuda.max_memory_allocated(), OOM_splits=engine.oom,
                             numerical_accepted=size in consistency['eligible_batch_sizes']))
        except torch.OutOfMemoryError as exc:
            rows.append(dict(batch_size=size, failed=repr(exc)))
        del states
        torch.cuda.empty_cache()
    eligible = [r for r in rows if not r.get('failed') and not r.get('OOM_splits') and r['numerical_accepted']]
    chosen = max(eligible, key=lambda r:r['molecule_steps_per_second'])['batch_size']
    # Profile actual collated neural forward plus official mechanics, not nvidia-smi utilization.
    profstates = [state_from(selected[i%len(selected)], den) for i in range(chosen)]
    activities = [torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]
    with torch.profiler.profile(activities=activities, record_shapes=True, profile_memory=True) as prof:
        engine = BatchEngine(den)
        for step in range(3):
            engine.step(profstates, grid[step], grid[step]-grid[step+1])
    prof.export_chrome_trace(str(OUT/'performance_trace.json'))
    (OUT/'profiler_summary.txt').write_text(prof.key_averages().table(sort_by='self_cuda_time_total', row_limit=30))
    bf16 = dict(selected=False, reason='Formal remains FP32; mixed precision requires full quality validation')
    try:
        ss = [state_from(selected[0], den)]
        BatchEngine(den).step(ss, grid[0], grid[0]-grid[1], bf16=True)
        bf16['one_step_finite'] = bool(torch.isfinite(ss[0].pos).all())
    except Exception as exc:
        bf16['error'] = repr(exc)
    result = dict(passed=True, selected_batch_size=chosen, actual_gpu=torch.cuda.get_device_name(0),
                  total_memory_bytes=torch.cuda.get_device_properties(0).total_memory, rows=rows, consistency=consistency,
                  BF16=bf16, precision='FP32 weights/interfaces with FP64 contractions', selection='Highest measured warmed molecule-step throughput among numerical-accepted sizes',
                  benchmark_scope='Denoising step incl collate/dynamic edges/forward/mechanics; full generation separately reported')
    dump(OUT/'performance_benchmark.json', result)
    lines = ['# A100批量推理基准', '', f'实测设备：{result["actual_gpu"]}；总显存{result["total_memory_bytes"]/2**30:.2f} GiB。',
             f'批处理完整24步一致性通过；选择batch={chosen}，使用FP32权重/接口与FP64收缩累积。', '',
             '|batch|完整分子步/秒|纯网络分子步/秒|峰值GiB|', '|---|---:|---:|---:|']
    for r in rows:
        if not r.get('failed'):
            lines.append(f'|{r["batch_size"]}|{r["molecule_steps_per_second"]:.2f}|{r["network_molecule_steps_per_second"]:.2f}|{r["peak_allocated_bytes"]/2**30:.2f}|')
    lines.extend(['', '基准预热2步后测量4步，覆盖不同分子图大小。每一步一次PyG Batch主干前向；动态边、质量、惯性及SE(3)更新使用原官方函数。CPU搜索、身份查询、图重建、引导和QC的完整成本另列，不能把纯网络吞吐称为完整生成吞吐。', '',
                  'Profiler原始追踪：performance_trace.json；算子摘要：profiler_summary.txt；逐样本完整轨迹一致性：batch_consistency.json。BF16仅探索，未据单步有限值宣称质量等价，正式保持FP32。'])
    (OUT/'PERFORMANCE_BENCHMARK.md').write_text('\n'.join(lines)+'\n')
    return chosen


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--through', choices=['audit', 'benchmark', 'complete'], default='complete')
    args = parser.parse_args()
    torch.set_num_threads(2)
    torch.cuda.set_device(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True)
    settings = plan()
    set_status('input_audit')
    audit(settings)
    if args.through == 'audit':
        return
    set_status('prepare_development_inputs')
    with ProcessPoolExecutor(4, mp_context=get_context('spawn'), initializer=cpu_init) as pool:
        lib = VocabLibrary()
        dev = prepare_all(settings['dev_pockets'], settings['dev_seeds'], 'dev', lib, pool)
        den = load_official(bootstrap.CHECKPOINT, OUT/'cache/official', 'cuda:0')
        from stable_precision import install
        install(den)
        set_status('batch_performance_benchmark')
        size = load(OUT/'performance_benchmark.json')['selected_batch_size'] if (OUT/'performance_benchmark.json').exists() else benchmark(den, dev, settings)
        if args.through == 'benchmark':
            return
        client = Client()
        try:
            from supervise import complete_experiment
            complete_experiment(settings, den, lib, pool, client, dev, size)
        finally:
            client.close()


if __name__ == '__main__':
    sys.modules.setdefault('run_experiment', sys.modules[__name__])
    try:
        main()
    except Exception as exc:
        set_status('failed', error=repr(exc), traceback=traceback.format_exc())
        raise
