"""Ordered stochastic, graph, single-step and full-trajectory acceptance gates."""
from common import *
import copy
import contextlib
import time
import torch
from runtime import BatchEngine, state_from, SCALE
from random_frames import capture_rng, restore_rng, replay_frames, official_frame, frame_with_uniform
from run_validation import load_official


def extract(value):
    if torch.is_tensor(value):
        return value
    if hasattr(value, 'embedding') and torch.is_tensor(value.embedding):
        return value.embedding
    if isinstance(value, (tuple, list)):
        return next((v for x in value if (v := extract(x)) is not None), None)
    return None


@contextlib.contextmanager
def layer_trace(den, trace):
    hooks = []
    trace['layers'] = {}
    for name, module in den.model.named_modules():
        if name in ['edge_degree_embedding', 'norm', 'force_block'] or (name.startswith('blocks.') and name.count('.') == 1):
            def hook(mod, args, result, name=name):
                value = extract(result)
                if value is not None:
                    trace['layers'][name] = value.detach().cpu().clone()
            hooks.append(module.register_forward_hook(hook))
    try:
        yield
    finally:
        for hook in hooks:
            hook.remove()


@contextlib.contextmanager
def mechanics_trace(den, trace):
    original_forces = den._compute_forces
    original_dynamics = den._compute_fragment_dynamics
    def forces(*args, **kwargs):
        out, index = original_forces(*args, **kwargs)
        trace['pseudoforce'], trace['force_index'] = out.detach().cpu().clone(), index.detach().cpu().clone()
        return out, index
    def dynamics(*args, **kwargs):
        values = original_dynamics(*args, **kwargs)
        for key, value in zip(['fragment_force', 'fragment_torque', 'mass', 'inertia'], values):
            trace[key] = value.detach().cpu().clone()
        return values
    den._compute_forces, den._compute_fragment_dynamics = forces, dynamics
    try:
        yield
    finally:
        den._compute_forces, den._compute_fragment_dynamics = original_forces, original_dynamics


def original_step(state, t, dt, controlled=True, capture=True):
    trace = {}
    frames = replay_frames(None, [state], state.step_index, trace) if controlled else contextlib.nullcontext()
    layers = layer_trace(state.den, trace) if capture else contextlib.nullcontext()
    mechanics = mechanics_trace(state.den, trace) if capture else contextlib.nullcontext()
    with torch.no_grad(), frames, layers, mechanics:
        state.step(t, dt)
        if controlled and state.step_index > 0:
            state.pos = state.den._apply_transformations(state.pos0, state.batch, state.T0, state.R0, state.Q, state.C)
    state.step_index += 1
    if capture:
        trace.update(C=state.C.detach().cpu().clone(), Q=state.Q.detach().cpu().clone(), pos=state.pos.detach().cpu().clone())
    return trace


def maximum(left, right):
    if left.shape != right.shape:
        return None
    return float((left.double()-right.double()).abs().max()) if left.numel() else 0.


def graph_audit(case, den, grid):
    left, right = state_from(case, den), state_from(case, den)
    saved = capture_rng()
    torch.save(dict(case=case, rng=saved), OUT/'diagnostics/replay_checks/native_repeated_input.pt')
    restore_rng(saved)
    a = original_step(left, grid[0], grid[0]-grid[1], controlled=False)
    restore_rng(saved)
    b = original_step(right, grid[0], grid[0]-grid[1], controlled=False)
    repeat = {k: maximum(a[k], b[k]) for k in ['pseudoforce', 'fragment_force', 'fragment_torque', 'C', 'Q', 'pos']}
    repeat_pass = all(x is not None and x <= 1e-7 for x in repeat.values())
    left, right = state_from(case, den), state_from(case, den)
    saved = capture_rng()
    restore_rng(saved)
    a = original_step(left, grid[0], grid[0]-grid[1], controlled=False)
    restore_rng(saved)
    b = {}
    with layer_trace(den, b):
        BatchEngine(den).step([right], grid[0], grid[0]-grid[1], controlled=False, trace=b)
    batch1 = {k: maximum(a[k], b[k]) for k in ['pseudoforce', 'fragment_force', 'fragment_torque', 'C', 'Q', 'pos']}
    # Prove the copied frame code gives exactly the official result for identical random uniforms.
    vectors = torch.tensor([[1., 2., 3.], [0., 0., 0.], [-.2, .4, -.8]], device='cuda:0')
    saved = capture_rng()
    expected = official_frame(vectors)
    restore_rng(saved)
    uniform = torch.rand_like(vectors)
    actual = frame_with_uniform(vectors, uniform)
    frame_error = maximum(expected, actual)
    result = dict(native_repeat_passed=repeat_pass, native_repeat_max_abs=repeat,
                  batch1_paired_global_rng_max_abs=batch1,
                  official_constructor_identical_uniform_max_abs=frame_error,
                  complete_cpu_cuda_rng_restored=True,
                  batch1_paired_rng_layer_max_abs={k:maximum(a['layers'][k], b['layers'][k]) for k in a['layers'] if k in b['layers']},
                  passed=repeat_pass and all(x is not None and x <= 1e-6 for x in batch1.values()) and frame_error <= 1e-7)
    dump(OUT/'rng_replay_audit.json', result)
    assert result['passed'], 'Native repeat or batch1 formula mismatch'
    return result


def compare_trace(serial, packed, i, states):
    ptr = packed['node_ptr']
    start, end = int(ptr[i]), int(ptr[i+1])
    edge = packed['edge_index']
    mask = (edge[0] >= start) & (edge[0] < end)
    pe = edge[:, mask]-start
    se = serial['edge_index']
    def order(e, entity):
        return np.lexsort((entity.numpy(), e[1].numpy(), e[0].numpy()))
    ps = order(pe, packed['edge_entity'][mask])
    ss = order(se, serial['edge_entity'])
    if pe.shape != se.shape or not torch.equal(pe[:, ps], se[:, ss]):
        return dict(graph_edges_equal=False)
    result = dict(graph_edges_equal=True)
    for key in ['edge_uniform', 'edge_rot_mat']:
        result[key] = maximum(serial[key][ss], packed[key][mask][ps])
    fi = packed['force_index']
    chosen = (fi >= start) & (fi < end)
    si, pi = torch.argsort(serial['force_index']), torch.argsort(fi[chosen])
    result['pseudoforce'] = maximum(serial['pseudoforce'][si], packed['pseudoforce'][chosen][pi])
    offset = sum(len(s.C) for s in states[:i])
    n = len(states[i].C)
    for key in ['fragment_force', 'fragment_torque', 'C', 'Q']:
        result[key] = maximum(serial[key], packed[key][offset:offset+n])
    result['pos'] = maximum(serial['pos'], packed['pos'][start:end])
    result['layers'] = {name:maximum(value, packed['layers'][name][start:end]) for name, value in serial['layers'].items() if name in packed['layers']}
    return result


def validate(den, cases, sizes=(1, 4, 8, 16, 32)):
    from datetime import datetime
    folder = OUT/'diagnostics/replay_checks'/datetime.now().strftime('run_%Y%m%d_%H%M%S')
    folder.mkdir(parents=True, exist_ok=True)
    grid = (1.+torch.arange(25, device='cuda:0')/24*(.005**(1/3)-1.))**3
    rng = graph_audit(cases[0], den, grid)
    from stable_precision import install
    install(den)
    tolerances = load(OUT/'protocol.json')['consistency']
    reports = []
    for size in sizes:
        selected = [cases[i%len(cases)] for i in range(size)]
        serial = [state_from(c, den) for c in selected]
        packed = [state_from(c, den) for c in selected]
        initial = [s.physical().copy() for s in serial]
        rows = []
        stage_passed = True
        coordinate_passed = True
        first_failure_saved = False
        worst_max = worst_rms = worst_internal = 0.
        for step, t in enumerate(grid[:-1]):
            # Full layer traces for the first step; physical trajectory metrics for every step.
            traces = [original_step(s, t, grid[step]-grid[step+1], capture=(step == 0)) for s in serial]
            trace = {}
            with layer_trace(den, trace) if step == 0 else contextlib.nullcontext():
                BatchEngine(den).step(packed, t, grid[step]-grid[step+1], trace=trace if step == 0 else None)
            comparisons = []
            for i, (case, left, right, init) in enumerate(zip(selected, serial, packed, initial)):
                delta = np.linalg.norm(left.physical()-right.physical(), axis=-1)
                max_error, rms = float(delta.max()), float(np.sqrt(np.mean(delta**2)))
                internal = 0.
                xyz = right.physical()
                for group in case['groups']:
                    indices = right.pn+np.asarray(group)
                    x, y = xyz[indices], init[indices]
                    internal = max(internal, float(np.max(np.abs(np.linalg.norm(x[:, None]-x[None], axis=-1)-np.linalg.norm(y[:, None]-y[None], axis=-1)))))
                row = dict(sample=i, pid=case['pid'], seed=case['seed'], max_atom_A=max_error, RMSD_A=rms, internal_delta_A=internal)
                if step == 0:
                    row['stages'] = compare_trace(traces[i], trace, i, packed)
                    stages = row['stages']
                    assert stages['graph_edges_equal'] and stages['edge_uniform'] == 0., 'Stable edge identity mismatch'
                    if any(stages[k] is None or stages[k] > 1e-4 for k in ['edge_rot_mat', 'pseudoforce', 'fragment_force', 'fragment_torque']):
                        stage_passed = False
                        if not first_failure_saved:
                            torch.save(dict(serial=traces, packed=trace, cases=selected), folder/f'first_mismatch_b{size}_step{step}.pt')
                            dump(folder/f'first_mismatch_b{size}_step{step}.json', stages)
                            first_failure_saved = True
                comparisons.append(row)
                worst_max, worst_rms, worst_internal = max(worst_max, max_error), max(worst_rms, rms), max(worst_internal, internal)
                if max_error > tolerances['max_atom_delta_A'] or rms > tolerances['coordinate_RMSD_A'] or internal > tolerances['internal_distance_delta_A']:
                    coordinate_passed = False
                    if not first_failure_saved:
                        torch.save(dict(serial_states=[dict(C=s.C.cpu(), Q=s.Q.cpu(), pos=s.pos.cpu()) for s in serial],
                                        packed_states=[dict(C=s.C.cpu(), Q=s.Q.cpu(), pos=s.pos.cpu()) for s in packed], cases=selected), folder/f'first_mismatch_b{size}_step{step}.pt')
                        dump(folder/f'first_mismatch_b{size}_step{step}.json', dict(step=step, sample=row))
                        first_failure_saved = True
            rows.append(dict(step=step, comparisons=comparisons))
        result = dict(batch_size=size, passed=stage_passed and coordinate_passed, single_step_passed=stage_passed,
                      coordinate_passed=coordinate_passed, single_step_absolute_limit=1e-4, complete_steps=24, worst_max_atom_A=worst_max,
                      worst_RMSD_A=worst_rms, worst_internal_distance_delta_A=worst_internal,
                      compared_case_order=[f'{c["pid"]}_{c["seed"]}' for c in selected], steps=rows)
        dump(folder/f'batch_{size}.json', result)
        reports.append({k:v for k,v in result.items() if k != 'steps'})
        print('REPLAY ACCEPTANCE', size, result['passed'], worst_max, worst_rms, worst_internal, flush=True)
        del serial, packed
        torch.cuda.empty_cache()
    eligible = [r['batch_size'] for r in reports if r['passed']]
    result = dict(passed=1 in eligible and 4 in eligible, all_batch_sizes_passed=len(eligible)==len(reports),
                  eligible_batch_sizes=eligible, prompt_check_sha256=sha256(OUT/'prompt_check.md'), tolerances=tolerances,
                  rng_audit=rng, batches=reports, formula='Official NativeState.step vs batched implementation; identical stable-edge uniforms',
                  detail_directory=str(folder), fixed_reference_reconstruction=True,
                  source_sha256={p.name:sha256(p) for p in [Path(__file__), OUT/'source/runtime.py', OUT/'source/random_frames.py', OUT/'source/stable_precision.py']},
                  contraction_accumulation='FP64 contractions with unchanged FP32 weights/interfaces; per-sample official mechanics; shared reference reconstruction',
                  stable_random_input='Unsigned counter hash keyed by pid, seed, step, semantic protein/slot/core/helper source/destination, edge type and attributes. No whole-graph salt; original frame construction unchanged')
    dump(OUT/'replay_validation.json', result)
    assert result['passed'], 'Required batch1/batch4 acceptance failed; no formal run allowed'
    return result


if __name__ == '__main__':
    torch.set_num_threads(2)
    torch.cuda.set_device(0)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    set_status('validate_stochastic_replay')
    cases = [torch.load(p, weights_only=False) for p in sorted((OUT/'dev/initial').glob('*/case.pt'))]
    den = load_official(bootstrap.CHECKPOINT, OUT/'cache/official', 'cuda:0')
    validate(den, cases)
