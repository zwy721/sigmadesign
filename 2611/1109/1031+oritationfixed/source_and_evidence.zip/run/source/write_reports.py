"""Readable reports from complete evidence; never substitutes for gate execution."""
from reporting import *
from datetime import datetime,timezone


def number(x,digits=4):
    return '不可用' if x is None else f'{x:.{digits}f}'


def mdtable(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+
        ['| '+' | '.join(map(str,r))+' |' for r in rows])


def write(name,lines):
    (OUT/name).write_text('\n\n'.join(lines)+'\n')


def dynamic():
    v=load(OUT/'dynamic_replay_verification.json');assert v['passed']
    rows=[]
    for r in v['comparisons']+v['batch64_comparisons']:
        valid=[step for c in r['checks'] for step in c['coordinate_steps'] if step.get('shape_equal')]
        rows.append([r['label'],r['compared'],r['passed'],all(c['all_discrete_decisions_equal'] for c in r['checks']),
            number(max((x['max_atom_A'] for x in valid),default=None),7),number(max((x['RMSD_A'] for x in valid),default=None),7)])
    previous=(OUT/'DYNAMIC_REPLAY_VERIFICATION.md').read_text()
    dump(OUT/'diagnostics/preliminary_report_snapshot.json',dict(text=previous))
    write('DYNAMIC_REPLAY_VERIFICATION.md',['# 严格动态回放验收',
        '**必要动态门槛全部通过。** C/E各32套固定输入；正式216次的分母不包括预检、批量重放或64探索。',
        mdtable(['比较','样本','通过','离散决策完全一致','最大原子差 Å','最大RMSD Å'],rows),
        '原门槛：最大原子差0.025 Å、RMSD 0.005 Å、内部距离差0.0002 Å；身份、逐键连接及接受决策要求完全相同。每个网络步另外检查内部距离；不通过即中止。没有放宽门槛、跳过更新、删除失败或重抽样。',
        f'C无更新控制与B的24步坐标逐位一致：{v["no_update_control_passed"]}。该控制显式计算提议后抑制更新，只作流程隔离检验，不代替正式C。batch=64进入性能选择资格：{v["batch64_eligible"]}。',
        '历史失败全部保留：v1扩大回放失败；v2诊断中止；v3修复朝向后仍有独立网络/身份数值差异。v4追加FP64消息求和及身份头确定性，32样本仍有1条轨迹RMSD超限。v5再用固定行数32的批量线性矩阵块，消除FP64 GEMM形状相关的末位舍入差异。权重、线性公式与FP32接口保持相同；相同状态32样本单步检查不能替代本项完整轨迹验收。相应逐层单因素审计见layer_numerical_audit*.json；身份观察见identity_determinism_observation.json。不能把独立数值修正作用都归为SVD效果。',
        f'完整逐样本/逐步证据：dynamic_replay_verification.json、diagnostics/comparisons/及gates/{v["namespace"]}/。核心源代码哈希写入验收JSON，正式启动逐项复核。'])


def bce():
    s=tables();assert s['primary_completed']==216
    recs=records(OUT,'main');rows=[flatten(r) for r in recs];events,_,_=event_rows(recs)
    group={a:[r for r in rows if r['arm']==a] for a in ['B','C','E_connection_only']}
    table=[]
    for arm,g in group.items():
        assert len(g)==72
        table.append([arm,f'{sum(r["high_quality"] is True for r in g)}/72',number(mean(g,'cross_bond_MAE_A')),
            number(mean(g,'cross_angle_MAE_deg'),2),sum((r.get('severe_cross_internal_pairs') or 0)>0 for r in g),
            sum((r.get('severe_protein_pairs') or 0)>0 for r in g),sum(r['accepted_updates'] for r in g)])
    checks=[]
    for k in CHECKS:
        checks.append([k]+[f'{sum(r.get(k) is True for r in g)}/72; 不可用{sum(r.get(k) is None for r in g)}' for g in group.values()])
    ablation=[flatten(r) for r in records(OUT,'ablation')]
    at=[]
    for method in ['C_old','C_fixed']:
        g=[r for r in ablation if r['strategy']==method]
        at.append([method,len(g),sum(r['high_quality'] is True for r in g),number(mean(g,'cross_bond_MAE_A')),
            number(mean(g,'cross_angle_MAE_deg'),2),sum(r['accepted_updates'] for r in g)])
    et=[]
    for arm in ['C','E_connection_only']:
        for step in [5,10,15,20]:
            for kind in ['identity_change','connection_only']:
                g=[e for e in events if e['arm']==arm and e['step']==step and e['proposal_type']==kind and e['accepted']]
                if not g:continue
                et.append([arm,step,kind,len(g),number(mean(g,'transfer_delta__cross_bond_MAE_A')),
                    number(mean(g,'segment_motion_delta__cross_bond_MAE_A')),
                    sum((e.get('after_transfer__cross_bonds_error_gt_0_15A') or 0)>0 and e.get('segment_end__cross_bonds_error_gt_0_15A')==0 for e in g)])
    old=load(OUT/'historical_C_event_summary.json')
    pocket=[]
    for r in s['by_pocket']:
        pocket.append([r['arm'],r['pid'],r['attempts'],r['high_quality_pass'],number(r['cross_bond_MAE_A_mean']),number(r['cross_angle_MAE_deg_mean'],2)])
    write('REVISED_BCE_COMPARISON.md',['# 修正后的B/C/E配对对照',
        '主分母固定为B/C/E各72，总216：六个既往诊断口袋，各原始种子41001–41012。各组复用逐字节相同的初始输入，24步去噪，第5/10/15/20步允许动态提议；权重、合法搜索、0.5 Å转移接受门槛与HQ_no_water协议保持冻结。全部终态为原生输出，没有端点修复。',
        '本轮朝向修复覆盖slot_frames及参考转移两条路径；独立数值修正为消息求和精度与身份头确定性设置。B/C/E和下述旧/新消融共同使用这些数值设置；不能将历史C与新C的差值全部解释为朝向算法的因果作用。',
        mdtable(['组','HQ','跨片段键MAE Å','角MAE °','有严重内碰撞','有严重蛋白碰撞','接受更新数'],table),
        '## 评价与不可用项',mdtable(['检查','B','C','E'],checks),
        f'原始异常键/角、环与酰胺异常、原始化学立体检查、失败阶段、不可用项和所有质量模块明细分别保存在PER_GENERATION_RESULTS.csv及各结构quality_complete.json、declared_stereo.json。QC不可用尝试数：{s["QC_unavailable"]}；失败记录数：{len(s["failures"])}。立体几何推导的HQ与原始声明立体定义分开保存，MMFF优化仅作诊断。',
        '## C-old与C-fixed消融',
        '每方法12次（六口袋×种子41001/41008），共24次，独立于216分母；共同使用稳定初始构造和同一数值路径，旧方法仅在动态slot恢复及转移拟合使用历史算法。此消融不等同于重新运行整个历史旧封装。',
        mdtable(['方法','尝试','HQ通过','键MAE Å','角MAE °','接受更新'],at),
        '## 更新阶段分解',
        '先区分换身份/仅连接与是否接受，再比较新拓扑目标→参考转移后的同拓扑几何、以及转移后→下次更新前的固定拓扑运动。旧图到新图的键集合会改变，该阶段MAE变化不能单独当成坐标转移误差。',
        mdtable(['组','更新步','接受类型','事件数','转移Δ键MAE Å','固定图运动Δ键MAE Å','段末清除跨键异常事件'],et),
        f'历史C共{old["events"]}次事件，模板结构秩退化与几何恶化的共现分层在historical_C_event_summary.json。历史原始SVD张量不可用的事件明确标记，仅依据当时身份推断模板秩；共现不证明朝向是唯一原因。',
        '## 分层与配对限制',
        mdtable(['组','口袋','尝试','HQ通过','键MAE Å','角MAE °'],pocket),
        '按N、实际接受次数和身份更新次数的全分层见diagnostics/by_N.csv、by_accepted_count.csv、by_identity_count.csv；配对差及六口袋符号翻转统计见summary.json。更新次数是处理后的变量，这些分层仅作诊断，不产生身份变化的无混杂因果估计。此前检查过的六口袋不是独立泛化集；所有原始失败保留在分母。'])


def docking():
    rows=[flatten(r) for r in records(OUT,'docking')];table=[]
    for method in ['A_native','A_official_paired']:
        g=[r for r in rows if r['strategy']==method];assert len(g)==72
        table.append([method,len(g),sum(r.get('docking_RMSD_A') is not None and r['docking_RMSD_A']<2 for r in g),
            number(mean(g,'docking_RMSD_A'),2),sum(r['high_quality'] is True for r in g),number(mean(g,'cross_bond_MAE_A')),
            number(mean(g,'cross_angle_MAE_deg'),2),sum((r.get('severe_cross_internal_pairs') or 0)>0 for r in g),
            sum((r.get('severe_protein_pairs') or 0)>0 for r in g)])
    legacy=load(OUT/'known/legacy_reference_summary.json')
    known=[flatten(r) for r in records(OUT,'known')]
    initial=max(r['initialization_max_atom_difference_to_NativeState_A'] for r in records(OUT,'docking') if r['arm']=='A_official')
    paired=load(OUT/'docking_numerical_comparison.json') if (OUT/'docking_numerical_comparison.json').exists() else None
    write('OFFICIAL_SIGMADOCK_DOCKING_CHECK.md',['# 原始官方SigmaDock与NativeState真实图docking',
        '六口袋各12原始种子，每路径72，共144次辅助尝试，独立于216次B/C/E。真实身份/拓扑与已有配体结构属于Oracle条件，此结果不代表自由de novo能力。受体、图、初始分布、25点时间网格（24次更新）、RMSD无对齐规则及尽可能匹配的辅助流保持可比。',
        mdtable(['路径','尝试','RMSD<2 Å','平均RMSD Å','HQ','键MAE Å','角MAE °','严重内碰撞尝试','严重蛋白碰撞尝试'],table),
        f'官方路径实际调用未修改源码的sampler；运行时仅注入与NativeState相同的初始参考分布抽样和逐语义边均匀数。最大初始原子差{initial:.9g} Å。官方FP32主干、批量力学和迭代坐标更新保留；NativeState使用已验证的精度适配、按样本力学和固定参考重建。不是逐个机制分离的因果消融。',
        '若遇到零更新内部随机噪声，不声称该流完全配对；图构建在同一输入下对照。匹配只在原子/语义边存在时定义。官方函数计算真分数用于记录损失，use_true_scores=False，不以真分数驱动采样。',
        json.dumps(paired,ensure_ascii=False,indent=2) if paired else '单步/24步数值比较尚未写出，见原始network_outputs及official_network_outputs；不得据此宣称数值路径等价。',
        f'另外保留12个已知参考：原始官方原全局随机流、原始原子顺序RMSD成功{legacy["under2"]}/{legacy["requested"]}；新NativeState参考成功{sum(r.get("docking_RMSD_A") is not None and r["docking_RMSD_A"]<2 for r in known)}/{len(known)}。这两项的随机流/部分输入准备条件不同于六口袋配对路径，不能把已知参考11/12直接作为六口袋期望值。',
        '逐尝试见AUXILIARY_GENERATION_RESULTS.csv。所有不可用项与原始立体声明单列；没有对原生HQ引入端点修复，也没有重新训练。'])


def performance():
    d=load(OUT/'performance_benchmark.json');rows=[]
    for r in d['rows']:
        rows.append([r['batch_size'],r['eligible'],number(r.get('molecule_steps_per_second'),2),
            number(r.get('network_molecule_steps_per_second'),2),number(r.get('peak_allocated_bytes',0)/2**30,2)])
    batches=[load(p) for p in (OUT/'main/batches').glob('*.json')]
    wall=sum(b['wall_seconds'] for b in batches)
    forward=sum(t['forward_ms']/1000 for b in batches for t in b['timings'])
    files=list((OUT/'main/structures').glob('*/initial_state.npz'))+list((OUT/'main/structures').glob('*/quality_complete.json'))
    start=min(p.stat().st_mtime for p in files);end=max(p.stat().st_mtime for p in files)
    scope=dict(primary_attempts=216,molecule_steps=216*24,batch_generation_wall_seconds=wall,
        forward_region_GPU_event_seconds=forward,primary_initialization_to_last_QC_seconds=end-start,
        primary_end_to_end_molecules_per_second=216/(end-start),
        start_UTC=datetime.fromtimestamp(start,timezone.utc).isoformat(),end_UTC=datetime.fromtimestamp(end,timezone.utc).isoformat())
    dump(OUT/'end_to_end_performance.json',scope)
    write('A100_THROUGHPUT_REPORT.md',['# A100批量推理与端到端性能',
        f'设备：{d["actual_GPU"]}，显存{d["total_memory_bytes"]/2**30:.2f} GiB；动态门槛通过后选择batch={d["selected_batch_size"]}。每步主干一次真正PyG Batch前向，CPU4进程搜索、16进程QC；没有为每个样本复制完整GPU主干。',
        mdtable(['batch','动态资格','去噪分子步/秒','网络区域分子步/秒','峰值分配GiB'],rows),
        '基准为2步预热+4步测量，去噪时延包含图/边与力学，不包含初始化、连接搜索和QC。网络区域采用CUDA事件计时，其中仍可能含辅助方向构造与同步间隙，不能直接当成纯GPU核占用。历史19.15分子步/秒、13.30 GiB、2.80倍加速为旧静态基线；本轮新增稳定累积，性能单独实测。',
        f'216条正式生成的批次计时合计{wall:.2f}秒，网络区域{forward:.2f}秒；从第一条初始化到最后一条QC完成约{end-start:.2f}秒，端到端{216/(end-start):.4f}分子/秒。预检、消融和docking不混入该分母；QC并行执行，不能将各分子CPU秒直接相加为墙钟耗时。',
        '完整数据：performance_benchmark.json、end_to_end_performance.json、main/batches/。若存在profiler_summary.txt/performance_trace.json，其热点用于区分核计算、同步及CPU图构建；未通过动态资格的64不因速度被选用。'])


def main():
    dynamic();bce();docking();performance()


if __name__=='__main__':main()
