"""Frozen post-gate BCE, paired orientation ablation and docking study."""
from common import *
import copy
import shutil
import time
from datetime import datetime,timezone
from concurrent.futures import ProcessPoolExecutor,as_completed
from multiprocessing import get_context
import torch
import run_experiment as rx
from runtime import state_from,BatchEngine
import orientation
from qc import evaluate
from docking_check import cases_for,official_batch,legacy_reference

PRIOR=ROOT/'pose_generation_four_arm_comparison/paired_final'


def configuration():
    prior=load(PRIOR/'effective_protocol.json')
    config=dict(version=1,prompt_sha256=sha256(OUT/'prompt.md'),prior_run=str(PRIOR.relative_to(ROOT)),
        cohort=prior['cohort'],seeds=prior['seeds'],arms=['B','C','E_connection_only'],primary_attempts=216,per_arm=72,
        steps=24,noise_scale=0.,revision_steps=[5,10,15,20],N_prior=prior['N_prior'],weights=prior['weights'],
        initial_inputs='Byte-identical cached inputs from prior paired_final; no newly selected input draws',
        orientation=dict(relative_covariance_tolerance=orientation.RELATIVE_COVARIANCE_TOLERANCE,
            near_linear_extra_fit_resolution_A=orientation.FIT_NUMERICAL_BUDGET_A,
            rank_one='Closest SO(3) rotation satisfying axis alignment to transported generated-state reference',
            nondegenerate='Original proper Kabsch',identity_transport='Explicit new-template to wanted-world shape-transfer map'),
        original_consistency=dict(max_atom_delta_A=.025,coordinate_RMSD_A=.005,internal_distance_delta_A=.0002,discrete_decisions='exact'),
        numerical_path='FP32 weights/interfaces; FP64 contractions with fixed-row-32 tiled linear GEMMs and FP64 message sums; per-sample official mechanics and fixed-reference reconstruction',
        linear_row_tile=32,
        identity_execution='Same frozen identity head with deterministic CUDA algorithms and TF32 disabled; no logit quantization or categorical-threshold change',
        ablation=dict(cohort=prior['cohort'],seeds=[41001,41008],orientation_methods=['old','fixed'],per_method=12,
            total_attempts=24,batch_size=4,primary_denominator_excluded=True),
        docking=dict(cohort=prior['cohort'],seeds=prior['seeds'],modes=['NativeState_shared_numerics','official_sampler_FP32_paired_init_and_aux'],
            per_mode=72,total=144,primary_denominator_excluded=True,
            known_original_sampler_reference_attempts=12,known_NativeState_reference_attempts=12,
            RMSD='Same receptor-frame heavy-atom symmetry matching max4096; no alignment for paired modes; legacy reference additionally original raw atom order'),
        evaluation='Unchanged HQ_no_water and original chemistry stereo separately; no endpoint repair in this study',
        quality_config_sha256=sha256(OUT/'quality_config.json'),PB_config_sha256=sha256(OUT/'posebusters_no_water.json'),
        independence='Previously examined diagnostic cohort; no independent generalization claim',
        no_training=True,physical_gpu=0,CPU_search_workers=4,CPU_QC_workers=16)
    path=OUT/'protocol.json'
    if path.exists():assert load(path)==config,'Frozen protocol changed'
    else:dump(path,config)
    return config


def benchmark(den,cases):
    gate=load(OUT/'dynamic_replay_verification.json')
    assert gate['passed']
    path=OUT/'performance_benchmark.json'
    if path.exists():return load(path)['selected_batch_size']
    rows=[]
    for size in [32,64]:
        if size==64 and not gate['batch64_eligible']:
            rows.append(dict(batch_size=size,eligible=False,reason='Dynamic gate failed, retained evidence; excluded from performance selection'))
            continue
        # Same 64 unique inputs for both sizes: two chunks of 32 versus one
        # chunk of 64. Different graph-size mixtures must not choose the winner.
        states=[state_from(c,den) for c in cases[:64]]
        parts=[states[start:start+size] for start in range(0,len(states),size)]
        engine=BatchEngine(den)
        grid=(1.+torch.arange(25,device='cuda:0')/24*(.005**(1/3)-1.))**3
        for step in range(2):
            for part in parts:engine.step(part,grid[step],grid[step]-grid[step+1])
        torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();engine.timings=[]
        start=time.perf_counter()
        for step in range(2,6):
            for part in parts:engine.step(part,grid[step],grid[step]-grid[step+1])
        torch.cuda.synchronize();elapsed=time.perf_counter()-start
        forward=sum(t['forward_ms'] for t in engine.timings)/1000
        rows.append(dict(batch_size=size,eligible=True,unique_inputs=len(states),wall_seconds=elapsed,molecule_steps_per_second=len(states)*4/elapsed,
            network_molecule_steps_per_second=len(states)*4/forward,peak_allocated_bytes=torch.cuda.max_memory_allocated(),
            OOM_splits=engine.oom))
    best=max((r for r in rows if r.get('eligible')),key=lambda r:r['molecule_steps_per_second'])['batch_size']
    dump(path,dict(passed=True,rows=rows,selected_batch_size=best,actual_GPU=torch.cuda.get_device_name(0),
        total_memory_bytes=torch.cuda.get_device_properties(0).total_memory,scope='Same 64 unique graphs as two chunks32 or one chunk64; two warmup plus four denoising steps; excludes initialization, CPU search and QC',
        prerequisite='Full dynamic gate; no batch size eligible solely because of speed'))
    prof_states=[state_from(c,den) for c in cases[:best]]
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA],
                                record_shapes=True,profile_memory=True) as prof:
        engine=BatchEngine(den)
        for step in range(2):engine.step(prof_states,grid[step],grid[step]-grid[step+1])
    prof.export_chrome_trace(str(OUT/'performance_trace.json'))
    (OUT/'profiler_summary.txt').write_text(prof.key_averages().table(sort_by='self_cuda_time_total',row_limit=30))
    return best


def prepare_inputs(cases):
    for case in cases:
        name=f'{case["pid"]}_{case["seed"]}'
        origin=PRIOR/'main/initial'/name;dest=OUT/'main/initial'/name
        dest.mkdir(parents=True,exist_ok=True)
        for file in ['case.pt','initial.npz','input_hashes.json','search.json']:
            assert (origin/file).exists()
            if (dest/file).exists():assert sha256(dest/file)==sha256(origin/file)
            else:shutil.copyfile(origin/file,dest/file)
    return [dict(pid=c['pid'],seed=c['seed'],N=c['N'],case_sha256=sha256(OUT/'main/initial'/f'{c["pid"]}_{c["seed"]}'/'case.pt')) for c in cases]


def freeze(config,inputs):
    path=OUT/'formal_start.json'
    if path.exists():
        previous=load(path)
        assert previous['protocol_sha256']==sha256(OUT/'protocol.json')
        for name,digest in previous['source_sha256'].items():assert sha256(OUT/'source'/name)==digest,name
        return
    (OUT/'frozen_source').mkdir(exist_ok=True)
    sources={}
    for path in (OUT/'source').glob('*.py'):
        shutil.copyfile(path,OUT/'frozen_source'/path.name);sources[path.name]=sha256(path)
    dump(OUT/'formal_start.json',dict(UTC=datetime.now(timezone.utc).isoformat(),protocol_sha256=sha256(OUT/'protocol.json'),
        dynamic_verification_sha256=sha256(OUT/'dynamic_replay_verification.json'),source_sha256=sources,initial_inputs=inputs))


def wait_qc(futures,phase):
    done=0
    for f in as_completed(futures):
        f.result();done+=1
        if done%12==0 or done==len(futures):print('QC',phase,done,'/',len(futures),flush=True)


def smoke(den,client,pool,lib):
    """Interface and QC check, excluded from every primary/paired denominator."""
    set_status('official_sampler_interface_smoke')
    cases=copy.deepcopy(cases_for('docking')[:2])
    for c in cases:c['role']='smoke'
    native=rx.run_batch(copy.deepcopy(cases),'A',den,client,pool,lib,tag='A_native')
    official=official_batch(cases,den)
    with ProcessPoolExecutor(2,mp_context=get_context('spawn')) as quality_pool:
        quality=[f.result() for f in [quality_pool.submit(evaluate,r['folder']) for r in native+official]]
    assert all(len(q['metrics'])==1 and q['input_unchanged'] for q in quality),'Sampler smoke QC missing or input altered'
    dump(OUT/'official_sampler_smoke.json',dict(passed=True,attempts=len(native+official),excluded_from_primary=True,
        maximum_initial_pair_difference_A=max(r['initialization_max_atom_difference_to_NativeState_A'] for r in official)))


def run(den,client,pool,lib,cases):
    verified=load(OUT/'dynamic_replay_verification.json')
    assert verified['passed']
    for name,digest in verified['core_sha256'].items():assert sha256(OUT/'source'/name)==digest,('Core changed since dynamic verification',name)
    config=configuration();inputs=prepare_inputs(cases);size=benchmark(den,cases)
    freeze(config,inputs)
    from progress import execute,choose_cases
    with ProcessPoolExecutor(config['CPU_QC_workers'],mp_context=get_context('spawn')) as quality_pool:
        all_primary=[];jobs=[]
        for arm in config['arms']:
            for start in range(0,len(cases),size):
                set_status('formal_BCE',current_arm=arm,primary_attempts_completed=len(all_primary),selected_batch_size=size)
                records=execute(cases[start:start+size],arm,'main',size,den,client,pool,lib)
                all_primary.extend(records)
                jobs.extend(quality_pool.submit(evaluate,r['folder']) for r in records)
        wait_qc(jobs,'primary')
        assert len(all_primary)==216
        set_status('paired_orientation_ablation',primary_attempts_completed=216)
        chosen=[c for c in cases if c['seed'] in config['ablation']['seeds']]
        jobs=[]
        for method in ['old','fixed']:
            for start in range(0,len(chosen),4):
                part=copy.deepcopy(chosen[start:start+4])
                for case in part:case['role']='ablation'
                records=rx.run_batch(part,'C',den,client,pool,lib,tag='C_'+method,orientation_method=method)
                jobs.extend(quality_pool.submit(evaluate,r['folder']) for r in records)
        wait_qc(jobs,'old_fixed_ablation')
        set_status('official_docking_check',primary_attempts_completed=216)
        jobs=[]
        for role in ['docking','known']:
            oracle=cases_for(role)
            for start in range(0,len(oracle),size):
                part=oracle[start:start+size]
                records=rx.run_batch(copy.deepcopy(part),'A',den,client,pool,lib,tag='A_native')
                jobs.extend(quality_pool.submit(evaluate,r['folder']) for r in records)
                if role=='docking':
                    originals=official_batch(part,den)
                    jobs.extend(quality_pool.submit(evaluate,r['folder']) for r in originals)
        legacy_reference(den)
        wait_qc(jobs,'docking_and_reference')
    set_status('final_reporting',primary_attempts_completed=216)
    print('FORMAL AND AUXILIARY SAMPLING COMPLETE',flush=True)
