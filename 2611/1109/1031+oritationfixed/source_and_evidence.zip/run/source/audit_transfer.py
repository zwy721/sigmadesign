"""Reproduce the second gauge failure from saved actual transfer tensors."""
from common import *
import torch
import orientation
import run_experiment as rx
from pipeline_utils import rigid_fit


def main():
    case=torch.load(ROOT/'pose_generation_four_arm_comparison/paired_final/main/initial/9T4A_41004/case.pt',weights_only=False)
    base=OUT/'gates'
    a=base/'full_C_b1/structures/9T4A_41004_C/event_20'
    b=base/'full_C_b4/structures/9T4A_41004_C/event_20'
    event=load(a/'event.json')
    lib=rx.VocabLibrary()
    # Reuse the actual saved reference, not a newly embedded same-chemistry pose.
    from oracle_graph import rebuild
    spec=load(a.parent/'result.json')['spec']
    graph=rebuild(spec,**case['context'])
    groups=[f['atom_ids'] for f in spec['fragments']]
    pn=int((graph.frag_idx_map==-1).sum())
    x,y=np.load(a/'proposal_transfer.npz'),np.load(b/'proposal_transfer.npz')
    rows=[]
    for slot,label in enumerate(event['new_labels']):
        source=graph.ref_pos.cpu().numpy()[pn+np.asarray(groups[slot])]
        _,template=lib.template(label)
        _,local,_,mapping=orientation.fit(template,source,np.eye(3))
        old_rotations=[];new_rotations=[];old_error=[];new_error=[]
        for data in [x,y]:
            target=data['target_xyz'][groups[slot]]
            # Historical unchanged identities passed float32 copies; changed ones
            # were constructed from float64 template coordinates.
            if event['old_labels'][slot]==label:target=target.astype('float32')
            _,old,e=rigid_fit(source,target,data['R'][slot])
            _,new,ee,audit=orientation.fit(source,target,data['R'][slot]@local.T)
            old_rotations.append(old);new_rotations.append(new);old_error.append(e);new_error.append(ee)
        rows.append(dict(slot=slot,label=label,heavy_atoms=len(source),same_identity=event['old_labels'][slot]==label,
            reference_rank_ratio=mapping['second_to_first_ratio'],
            recorded_Q_max_difference=float(np.max(np.abs(x['Q'][slot]-y['Q'][slot]))),
            reproduced_old_rotation_max_difference=float(np.max(np.abs(old_rotations[0]-old_rotations[1]))),
            corrected_rotation_max_difference=float(np.max(np.abs(new_rotations[0]-new_rotations[1]))),
            recorded_vs_reproduced_old_max_error=float(max(np.max(np.abs(x['Q'][slot]-old_rotations[0])),np.max(np.abs(y['Q'][slot]-old_rotations[1])))),
            old_fit_RMSD_A=old_error,corrected_fit_RMSD_A=new_error))
    exact=rows[3]['recorded_vs_reproduced_old_max_error']<1e-5
    result=dict(passed=exact and rows[3]['corrected_rotation_max_difference']<.01,
        exact_saved_reference_reproduction_passed=exact,pid='9T4A',seed=41004,step=20,rows=rows,
        explanation='The legacy constructor fits float32 reference and unchanged float32 wanted coordinates with an in-place 1e-8 prior perturbation; that perturbation can be lost in float32. Its preferred template-to-world R also belongs to a different source convention. Compose inverse template-to-reference mapping before constrained rank-deficient fitting.',
        fix='Only rank-deficient reference-transfer fit changes. Nondegenerate constructor fit remains historical. Initial reference chart is explicitly recorded and transforms with a global coordinate-frame change.')
    dump(OUT/'reference_transfer_audit.json',result)
    csvwrite(OUT/'diagnostics/reference_transfer_reproduction.csv',rows)
    print(json.dumps(result,indent=2))
    assert result['passed'],'Reference-transfer reproduction failed; do not treat as proven cause'


if __name__=='__main__':main()
