"""Compare paired saved original/native outputs; no GPU rerun or alignment."""
from common import *
import torch


def main():
    cases=[torch.load(p,weights_only=False) for p in sorted((OUT/'docking/oracle_inputs').glob('*.pt'))]
    cases=sorted(cases,key=lambda c:len(c['graph'].x))
    size=load(OUT/'performance_benchmark.json')['selected_batch_size']
    single=[];motion=[]
    for start in range(0,len(cases),size):
        part=cases[start:start+size];first=part[0];anchor=f'{first["pid"]}_{first["seed"]}'
        native=torch.load(OUT/'docking/network_outputs'/f'{anchor}_A_native/step_00.pt',weights_only=False)
        original=torch.load(OUT/'docking/official_network_outputs'/anchor/'paired_original_sampler.pt',weights_only=False)['forces'][0]
        for i,c in enumerate(part):
            key=f'{c["pid"]}_{c["seed"]}'
            a=OUT/'docking/structures'/f'{key}_A_native'
            b=OUT/'docking/structures'/f'{key}_A_official_paired'
            lo,hi=map(int,native['node_ptr'][i:i+2])
            choose=lambda index:(index>=lo)&(index<hi)
            ix=native['force_index'][choose(native['force_index'])]-lo
            iy=original['force_index'][choose(original['force_index'])]-lo
            row=dict(pid=c['pid'],seed=c['seed'],force_indices_equal=torch.equal(ix,iy))
            if row['force_indices_equal']:
                d=(native['pseudoforce'][choose(native['force_index'])]-original['pseudoforce'][choose(original['force_index'])]).numpy()
                row.update(force_comparison_available=True,max_pseudoforce_vector_delta=float(np.linalg.norm(d,axis=-1).max()),
                    pseudoforce_component_RMS_delta=float(np.sqrt(np.mean(d*d))))
            else:row.update(force_comparison_available=False,reason='Network force node indices differ')
            initial=np.load(a/'initial_state.npz')['pos']
            position=original['pos_before'][lo:hi].numpy()
            from sigmadock.oracle import HPARAMS
            delta=(initial-position)*HPARAMS.general.dimensional_scale
            row['initial_full_node_max_delta_A']=float(np.linalg.norm(delta,axis=-1).max())
            single.append(row)
            for step in range(24):
                x=np.load(a/'trajectory'/f'step_{step:02d}.npz')['xyz']
                y=np.load(b/'trajectory'/('final.npz' if step==23 else f'before_{step+1:02d}.npz'))['xyz']
                entry=dict(pid=c['pid'],seed=c['seed'],step=step,atom_shapes_equal=x.shape==y.shape)
                if x.shape==y.shape:
                    d=np.linalg.norm(x-y,axis=-1)
                    entry.update(coordinate_RMSD_A=float(np.sqrt(np.mean(d*d))),maximum_atom_delta_A=float(d.max()))
                else:entry['unavailable_reason']='Heavy atom axes differ'
                motion.append(entry)
    assert len(single)==72 and len(motion)==72*24
    csvwrite(OUT/'diagnostics/DOCKING_SINGLE_STEP_NETWORK.csv',single)
    csvwrite(OUT/'diagnostics/DOCKING_PAIRED_TRAJECTORY.csv',motion)
    final=[r for r in motion if r['step']==23]
    result=dict(requested_pairs=72,single_step_available=sum(r['force_comparison_available'] for r in single),
        maximum_initial_node_delta_A=max(r['initial_full_node_max_delta_A'] for r in single),
        maximum_first_step_pseudoforce_vector_delta=max((r['max_pseudoforce_vector_delta'] for r in single if r['force_comparison_available']),default=None),
        mean_final_path_coordinate_RMSD_A=float(np.mean([r['coordinate_RMSD_A'] for r in final if r['atom_shapes_equal']])),
        maximum_final_path_coordinate_RMSD_A=max((r['coordinate_RMSD_A'] for r in final if r['atom_shapes_equal']),default=None),
        unavailable_trajectory_rows=sum(not r['atom_shapes_equal'] for r in motion),
        force_units='Model pseudoforce, not kcal/mol force',
        interpretation='First forces share physical inputs; later path differences combine precision, mechanics and coordinate reconstruction. No rigid alignment, no claim of fully identical auxiliary noise.')
    dump(OUT/'docking_numerical_comparison.json',result)
    print(result)


if __name__=='__main__':main()
