"""CPU audit of template rank, the saved failure and exact gauge freedom."""
from common import *
import orientation
from vocab_chemistry import VocabLibrary
import torch
from scipy.spatial.transform import Rotation

PRIOR=ROOT/'pose_generation_four_arm_comparison/paired_final'


def main():
    lib=VocabLibrary()
    templates=[]
    for label in range(len(lib.ids)):
        _,xyz=lib.template(label)
        sv=np.linalg.svd(xyz-xyz.mean(0),compute_uv=False)
        sv=np.pad(sv,(0,3-len(sv)))
        rank=int(sum(sv>max(1e-12,float(sv[0])*1e-10)))
        templates.append(dict(label=label,heavy_atoms=len(xyz),singular_values=sv.tolist(),rank=rank))
    csvwrite(OUT/'diagnostics/template_rank_audit.csv',templates)
    usage=[]
    for path in sorted((PRIOR/'main/initial').glob('*/case.pt')):
        case=torch.load(path,weights_only=False)
        for slot,label in enumerate(case['labels']):
            usage.append(dict(pid=case['pid'],seed=case['seed'],slot=slot,**templates[label]))
    csvwrite(OUT/'diagnostics/initial_fragment_rank_audit.csv',usage)
    name='7ILZ_41008_C'
    original=np.load(PRIOR/'main/structures'/name/'identity_05.npz')
    replay=np.load(PRIOR/'causal_replay/structures'/name/'identity_05.npz')
    slot=5;label=221
    _,x=lib.template(label)
    a=x@original['R'][slot].T+original['T'][slot]
    b=x@replay['R'][slot].T+replay['T'][slot]
    ref=original['R'][slot]
    ta,ra,ea,aa=orientation.fit(x,a,ref)
    tb,rb,eb,ab=orientation.fit(x,b,ref)
    axis=(a[1]-a[0]);axis/=np.linalg.norm(axis)
    rolled=Rotation.from_rotvec(axis*1.7).as_matrix()@ref
    t_rolled=a.mean(0)-x.mean(0)@rolled.T
    np.savez_compressed(OUT/'diagnostics/saved_failure_gauge_example.npz',template=x,old_a_xyz=a,old_b_xyz=b,
        old_a_R=original['R'][slot],old_b_R=replay['R'][slot],reference_R=ref,fixed_a_R=ra,fixed_b_R=rb,
        fixed_a_translation=ta,fixed_b_translation=tb,equivalent_rolled_R=rolled)
    result=dict(passed=True,templates=len(templates),rank_zero=sum(r['rank']==0 for r in templates),
        rank_one=sum(r['rank']==1 for r in templates),initial_slots=len(usage),
        initial_rank_one=sum(r['rank']==1 for r in usage),saved_example=dict(pid='7ILZ',seed=41008,step=5,slot=slot,label=label,
        old_R_element_max_difference=float(np.max(np.abs(original['R'][slot]-replay['R'][slot]))),
        old_R_SO3_difference_rad=orientation.distance(original['R'][slot],replay['R'][slot]),
        reconstructed_atom_max_difference_A=float(np.linalg.norm(a-b,axis=-1).max()),
        fixed_R_SO3_difference_rad=orientation.distance(ra,rb),
        equivalent_roll_coordinate_error_A=float(np.linalg.norm(x@rolled.T+t_rolled-a,axis=-1).max()),
        original_fit=aa,replay_fit=ab),
        caution='Saved failure positions reconstructed from exported T/R and the same template, not claimed as original unrounded atom tensors. Live replay separately saves actual tensors.',
        method=dict(relative_covariance_threshold=orientation.RELATIVE_COVARIANCE_TOLERANCE,
            near_degenerate_fit_numerical_budget_A=orientation.FIT_NUMERICAL_BUDGET_A,
            exact_rank_one='Closest geodesic rotation under exact primary-axis alignment',
            near_linear='Continuous SO(3) transition to Kabsch within 1e-7 A fit-resolution budget; actual residual recorded',
            full_rank_or_planar='Unmodified Kabsch proper rotation with exact fixed atom correspondence',
            symmetry='Fixed atom mapping, not permutation-invariant rematching; symmetry alone does not lower labelled coordinate rank',
            identity_transport='Anchor in the explicitly constructed proposed-template-to-world map; transport with generated mechanical Q, never bound ligand coordinates'))
    assert result['saved_example']['equivalent_roll_coordinate_error_A']<1e-8
    assert result['saved_example']['fixed_R_SO3_difference_rad']<1e-4
    dump(OUT/'orientation_audit.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['saved_example','method']},indent=2))


if __name__=='__main__':main()
