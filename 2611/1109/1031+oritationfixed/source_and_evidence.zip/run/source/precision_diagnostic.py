"""Controlled accumulation-only probes; not installed in formal sampling."""
import torch


def install_reduction_probe(mode,den=None):
    from sigmadock.net.so3 import SO3_Embedding
    if mode=='edge_sum':
        def reduce(self,index,num_nodes):
            value=torch.zeros(num_nodes,self.num_coefficients,self.num_channels,device=self.embedding.device,dtype=torch.float64)
            value.index_add_(0,index,self.embedding.double())
            self.set_embedding(value.to(self.embedding.dtype))
        SO3_Embedding._reduce_edge=reduce
    elif mode=='attention_softmax':
        import sigmadock.net.transformer_block as module
        import types
        original=module.torch_geometric.utils.softmax
        class Utils:
            def __getattr__(self,key):return getattr(module_original.utils,key)
            @staticmethod
            def softmax(value,*args,**kwargs):return original(value.double(),*args,**kwargs).to(value.dtype)
        module_original=module.torch_geometric
        module.torch_geometric=types.SimpleNamespace(utils=Utils())
    elif mode=='tiled_linear':
        import types
        import torch.nn.functional as F
        def forward(self,value):
            shape=value.shape
            flat=value.double().reshape(-1,shape[-1]);n=len(flat);tile=32
            extra=(-n)%tile
            if extra:flat=F.pad(flat,(0,0,0,extra))
            x=flat.reshape(-1,tile,shape[-1]);w=self._accumulation_weight.T.unsqueeze(0).expand(len(x),-1,-1)
            result=torch.bmm(x,w).reshape(-1,self.out_features)[:n]
            if self._accumulation_bias is not None:result=result+self._accumulation_bias
            return result.reshape(*shape[:-1],self.out_features).to(value.dtype)
        for module in den.model.modules():
            if isinstance(module,torch.nn.Linear):module.forward=types.MethodType(forward,module)
    elif mode!='none':raise ValueError(mode)
