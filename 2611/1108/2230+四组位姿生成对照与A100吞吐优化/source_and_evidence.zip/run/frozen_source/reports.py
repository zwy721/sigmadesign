"""Attempt-denominated reports; absent metrics remain unavailable."""
from common import *
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo

ARMS = ['A', 'B', 'C', 'D', 'E_connection_only']
STAGES = ['native_final', 'rigid_repair', 'local_flex_repair']
CHECKS = ['high_quality', 'chemical_valid', 'fully_connected', 'no_severe_internal_clash',
          'no_severe_protein_clash', 'bond_geometry_valid', 'angle_geometry_valid',
          'stereo_definition_complete', 'stereo_geometry_consistent', 'posebusters_all_pass']


def mean(values):
    valid = [v for v in values if v is not None]
    return float(np.mean(valid)) if valid else None


def fmt(value):
    return 'NA' if value is None else f'{value:.4f}'


def counts(values):
    return dict(passed=sum(v is True for v in values), failed=sum(v is False for v in values),
                unavailable=sum(v is None for v in values), denominator=len(values))


def write(name, lines):
    (OUT/name).write_text('\n'.join(lines)+'\n')


def gather(settings):
    rows, raw, events, guidance, breakdown = [], {}, [], [], []
    for arm in ARMS:
        for pid in settings['cohort']:
            for seed in settings['seeds']:
                folder = OUT/'main/structures'/f'{pid}_{seed}_{arm}'
                path = folder/'result.json'
                record = load(path) if path.exists() else {}
                row = dict(arm=arm, receptor_id=pid, seed=seed, attempt_id=record.get('attempt_id'),
                           status=record.get('status', 'pending'), failure_stage=record.get('failure_stage'), error=record.get('error'),
                           N=record.get('N'), pose_NFE=record.get('pose_NFE'),
                           guidance_part_of_generation=(arm == 'D'),
                           batch_wall_seconds=record.get('batch_wall_seconds'),
                           allocated_batch_wall_seconds=record.get('allocated_batch_wall_seconds'),
                           docking_RMSD_A=record.get('docking_RMSD_A'),
                           accepted_updates=sum(e['accepted'] for e in record.get('events', [])),
                           rejected_updates=sum(not e['accepted'] and e.get('reason') != 'same_chemistry' for e in record.get('events', [])))
                quality = load(folder/'quality_complete.json') if (folder/'quality_complete.json').exists() else None
                by = {m['metadata']['group']:m for m in quality['metrics']} if quality else {}
                stereo = load(folder/'A_DECLARED_STEREO.json') if (folder/'A_DECLARED_STEREO.json').exists() else {}
                for stage in STAGES:
                    q = by.get(stage, {})
                    for key in CHECKS:
                        row[stage+'_'+key] = q.get('checks', {}).get(key)
                    gm = q.get('modules', {}).get('geometry', {})
                    row[stage+'_abnormal_cross_bonds'] = gm.get('cross_fragment_abnormal_bond_count')
                    row[stage+'_abnormal_angles'] = gm.get('abnormal_angle_count')
                    row[stage+'_failed_checks'] = q.get('failed_checks') if q else None
                    row[stage+'_unavailable_checks'] = q.get('unavailable_checks') if q else None
                    for key in ['stereo_definition_complete', 'stereo_geometry_consistent']:
                        row[stage+'_A_declared_'+key] = stereo.get(stage, {}).get('checks', {}).get(key) if arm == 'A' else None
                    if stage != 'native_final':
                        rp = folder/stage/'repair.json'
                        rm = load(rp) if rp.exists() else {}
                        for key in ['success', 'heavy_RMSD_no_alignment_A', 'max_atom_displacement_A', 'seconds']:
                            row[stage+'_'+key] = rm.get(key)
                    for check in q.get('failed_checks', []):
                        breakdown.append(dict(arm=arm, stage=stage, attempt_id=record['attempt_id'], check=check, result='failed'))
                    for check in q.get('unavailable_checks', []):
                        breakdown.append(dict(arm=arm, stage=stage, attempt_id=record['attempt_id'], check=check, result='unavailable'))
                row.update(record.get('final_geometry', {}))
                rows.append(row)
                raw[arm, pid, seed] = record
                for event in record.get('events', []):
                    events.append(dict(arm=arm, receptor_id=pid, seed=seed, attempt_id=record['attempt_id'], **event))
                for event in record.get('guidance', []):
                    guidance.append(dict(arm=arm, receptor_id=pid, seed=seed, attempt_id=record['attempt_id'], **event))
    return rows, raw, events, guidance, breakdown


def pairwise(rows, left, right):
    a = {(r['receptor_id'],r['seed']):r for r in rows if r['arm']==left}
    b = {(r['receptor_id'],r['seed']):r for r in rows if r['arm']==right}
    pairs = []
    for key in a:
        x, y = a[key], b[key]
        row = dict(receptor_id=key[0], seed=key[1], left_arm=left, right_arm=right,
                   left_status=x['status'], right_status=y['status'],
                   left_HQ=x['native_final_high_quality'], right_HQ=y['native_final_high_quality'])
        row['HQ_difference_right_minus_left'] = int(row['right_HQ'])-int(row['left_HQ']) if row['left_HQ'] is not None and row['right_HQ'] is not None else None
        for field in ['cross_bond_MAE_A', 'cross_angle_MAE_deg', 'severe_cross_internal_pairs', 'severe_protein_pairs']:
            row['left_'+field], row['right_'+field] = x.get(field), y.get(field)
            row[field+'_difference_right_minus_left'] = y[field]-x[field] if x.get(field) is not None and y.get(field) is not None else None
        pairs.append(row)
    return pairs


def root_cause():
    replay = load(OUT/'replay_validation.json') if (OUT/'replay_validation.json').exists() else {}
    first = load(OUT/'diagnostics/initial_batch_check/batch_consistency.json')
    lines = ['# 串行与批量差异根因报告', '',
             '本报告依据开发输入和受控重放；不通过改变坐标门槛、删除样本或跳过失败配置推进。旧失败记录保留在diagnostics/。', '',
             '## 1. 未配对的网络内部随机数', '',
             '官方eval前向仍调用init_edge_rot_mat中的torch.rand_like。恢复完整Python、NumPy、CPU与CUDA RNG后，原生单样本的伪力、片段力/矩、T/R和坐标重复差为0；恢复相同RNG后原始batch=1与NativeState.step单步也完全一致。旧流程仅固定扩散noise_scale=0，未配对边坐标基。', '',
             '## 2. 刚体检查基线和累积数值误差', '',
             f'旧检查报告内部距离差{first["max_internal_distance_delta_A"]:.6f}Å，其比较对象是desired坐标，包含初始化形状转移残差，不能解释为去噪破坏刚体。',
             '修正为实际初始化坐标后，另一次原生串行与batch=1完全相同，却在第24步共同出现0.000212669Å内部距离漂移；该输入最后的Q.T@Q最大偏差约2.35e-6。逐步应用近似正交FP32旋转累积了数值缩放误差。当前两条路径均用同一官方刚体公式从固定参考重建坐标，避免累计乘法误差。', '',
             '## 3. 批量尺寸相关的FP32收缩归约', '',
             '在边集合、辅助方向和边旋转矩阵完全相同后，首个逐位差出现在edge_degree_embedding，约1e-7；经过后续网络块和归一化放大。保留的batch=8单步记录中，伪力最大差约8.96e-5、片段矩最大差约2.12e-4；完整轨迹差可能超过原门槛，不能只依据单步看似很小的误差宣布通过。',
             '数值修正保留FP32参数和接口，在当前进程中对线性层/einsum/bmm等收缩使用FP64累积，并将官方小矩阵刚体更新按样本执行。主干仍是每时间步一次真正的PyG Batch前向；官方源文件和checkpoint均不改写。原始FP32失败路径及首次差异的分层张量、坐标和输入保留。该路径不是历史串行结果的位级复现，正式各组共同采用它，另列原始官方FP32 sampler参照。', '',
             '## 4. 共同随机流的语义边标识修正', '',
             '此前实现还将整张化学图摘要混入样本随机键，导致动态改图后共有边也换用辅助方向，未满足改图对照的共同随机流要求。该运行原始产物完整保留在父目录，不作为最终配对结论。',
             '本paired_final运行改用样本/种子/步骤与语义节点-类型边标识：蛋白节点索引，片段槽位/模板身份/核心原子索引，辅助节点的片段身份、角色和核心邻接关系。不使用整图随机盐。新增回归验证了前序片段改变身份和原子数后，未变片段的共有边仍使用完全相同的辅助随机方向；实际更新的共有边随机输入检查见causal_replay_verification.json及transfer_observations。',
             '## 验收结果', '', '|batch|通过|24步最大坐标差Å|最大RMSDÅ|最大内部距离差Å|', '|---|---|---:|---:|---:|']
    for r in replay.get('batches', []):
        lines.append(f'|{r["batch_size"]}|{r["passed"]}|{r["worst_max_atom_A"]:.9f}|{r["worst_RMSD_A"]:.9f}|{r["worst_internal_distance_delta_A"]:.9f}|')
    lines.extend(['', '原门槛保持最大坐标差0.025Å、RMSD 0.005Å、内部距离差0.0002Å。额外逐层/力矩诊断的绝对限值1e-4也未放宽；辅助方向逐边相同，官方坐标基构建函数在相同uniform输入下结果完全相同。',
                  '具体证据：本运行rng_replay_audit_original_FP32.json、replay_validation.json及detail_directory下全部步骤；父目录../diagnostics/replay_checks/first_mismatch_b1_step23.pt与各run目录的first_mismatch_*.pt/json。父目录的冻结代码和原失败输入原样保留；本运行只使用复制的初始输入，重新选择开发参数、验收和执行正式对照。'])
    write('ROOT_CAUSE_REPORT.md', lines)


def protocol_report(settings):
    write('FOUR_ARM_EXPERIMENT_PROTOCOL.md', ['# 冻结四组主对照与连接子对照协议', '',
        '|组|输入图与更新|生成过程|', '|---|---|---|',
        '|A|真实配体化学图固定|官方权重去噪；Oracle化学输入参照|',
        '|B|首次预测的合法图固定|无引导|', '|C|alternating_categorical动态身份及连接|5/10/15/20步更新与合法性回退|',
        '|D|与B逐原子逐键相同的图固定|开发集选定的扩散内几何引导|',
        '|E_connection_only|身份固定，仅动态连接|隔离连接更新因素|', '',
        '正式六口袋×12种子×5组＝360次预定尝试，每组72。A最多六个真实复合物，每个12次初始化；A不属于B/C/D/E的同分子配对。输入失败保留在预定分母内。另有12个已知CASF复合物×1种子的数值路径参照与原官方FP32 sampler参照，分别报告，不合入360分母。',
        '开发口袋2zwz/4i5p/2wos，种子42001/42002，三组权重/步长×开启t≤0.1/0.3/0.6，共九候选×六输入；只按预定义开发分数选择，正式结果不参与选择。预检独立使用43001种子和两个开发口袋，各组两次共10次，不并入正式统计。',
        'B/C/D/E共享初始身份/N、图、T/R和稳定边标识随机方向；A明确使用真实身份和拓扑。所有口袋沿用历史定义，存在配体定义口袋的条件，不宣称完全无Oracle信息。模型不支持的辅因子节点不强行加入，非水环境用于原QC与引导。',
        '权重冻结。统一数值路径为FP32权重/接口与FP64收缩累积，官方刚体力学逐样本执行，坐标从固定参考重建；网络前向真正按batch执行。原始FP32官方采样另列。所有组24步，noise_scale=0，给定N先验为3/4/5/6均匀分布。',
        '原生/引导终态与独立刚性、局部柔性修复分别报告；D的native_final包含扩散内引导。历史HQ_no_water配置与两项水检查排除规则不变。A额外报告相对原始化学图的立体一致性，不能以几何重标后的标签替代该诊断。',
        '协议详见effective_protocol.json；原始未完成计划protocol.json保留。guidance_selection.json记录开发选择与冻结时间，formal_start.json保存正式启动的代码与配置指纹。'])


def generate(final=False):
    settings = load(OUT/'effective_protocol.json')
    rows, raw, events, guidance, failures = gather(settings)
    assert len(rows) == 360
    csvwrite(OUT/'PER_GENERATION_RESULTS.csv', rows)
    for right, name in [('C','PAIRWISE_B_C_RESULTS.csv'), ('D','PAIRWISE_B_D_RESULTS.csv'), ('E_connection_only','PAIRWISE_B_E_RESULTS.csv')]:
        csvwrite(OUT/name, pairwise(rows, 'B', right))
    csvwrite(OUT/'CONNECTION_UPDATE_TRAJECTORY.csv', events)
    csvwrite(OUT/'GEOMETRY_GUIDANCE_TRAJECTORY.csv', guidance)
    csvwrite(OUT/'QUALITY_FAILURE_RECORDS.csv', failures)
    summary = []
    for arm in ARMS:
        subset = [r for r in rows if r['arm']==arm]
        for stage in STAGES:
            item = dict(arm=arm, stage=stage, attempts=len(subset), pending=sum(r['status']=='pending' for r in subset),
                        HQ=counts([r[stage+'_high_quality'] for r in subset]),
                        protein_clash_pass=counts([r[stage+'_no_severe_protein_clash'] for r in subset]),
                        internal_clash_pass=counts([r[stage+'_no_severe_internal_clash'] for r in subset]))
            summary.append(item)
    dump(OUT/'summary.json', dict(final=final, primary_attempts=360, formal_outputs=sum(r.get('pose_NFE')==24 for r in rows),
         technical_pending=sum(r['status']=='pending' for r in rows), stages=summary,
         guidance_configuration=load(OUT/'guidance_selection.json')['selected'] if (OUT/'guidance_selection.json').exists() else None))
    state = '正式运行与评价已完成' if final else '中间快照，尚未完成'
    lines = ['# 四组主对照与连接子对照结果', '', f'状态：**{state}**。每组预定72次；失败和不可评估均保留，以下为已完成QC快照。', '',
             'A为真实化学图参照；B固定预测图；C更新身份与连接；D固定图加扩散内引导；E固定身份、只更新连接。B/C/D/E共享初始化。D终态包含约束，刚性/柔性修复独立评分。', '',
             '|组|阶段|HQ/72|HQ失败|HQ不可评估|无严重蛋白碰撞/72|无严重内碰撞/72|', '|---|---|---:|---:|---:|---:|---:|']
    for r in summary:
        lines.append(f'|{r["arm"]}|{r["stage"]}|{r["HQ"]["passed"]}/72|{r["HQ"]["failed"]}|{r["HQ"]["unavailable"]}|{r["protein_clash_pass"]["passed"]}/72|{r["internal_clash_pass"]["passed"]}/72|')
    lines += ['', '|组|原生键长MAEÅ|原生键角MAE°|原生严重跨片段碰撞对均值|原生严重蛋白碰撞对均值|', '|---|---:|---:|---:|---:|']
    for arm in ARMS:
        sr = [r for r in rows if r['arm']==arm]
        lines.append(f'|{arm}|{fmt(mean([r.get("cross_bond_MAE_A") for r in sr]))}|{fmt(mean([r.get("cross_angle_MAE_deg") for r in sr]))}|{fmt(mean([r.get("severe_cross_internal_pairs") for r in sr]))}|{fmt(mean([r.get("severe_protein_pairs") for r in sr]))}|')
    lines += ['', 'MAE为对可评价样本的均值，缺失数量可从逐尝试CSV中复核；HQ分母仍为全部72次。阈值0.15Å/15°的MMFF平衡几何诊断与历史HQ中的bounds几何检查含义不同，均分别保留。',
              'B/C比较是身份与连接联合更新的整体影响；B/E进一步隔离连接更新，不能将二者混称同一个因素。A/B同时改变输入化学分布，不能用其质量差直接认定位姿网络失效。六个口袋曾被查看，重复种子不能当作72个独立受体进行显著性宣称。',
              '逐样本结果：PER_GENERATION_RESULTS.csv；配对比较：PAIRWISE_B_C_RESULTS.csv、PAIRWISE_B_D_RESULTS.csv、PAIRWISE_B_E_RESULTS.csv；完整更新/引导事件另列。']
    write('FOUR_ARM_COMPARISON.md', lines)
    docking_lines = ['# 真实化学图docking参照', '', f'状态：{state}。主A组预定6个真实复合物×12初始化＝72次，不是72个不同复合物。', '',
                     '|口袋|尝试|RMSD可评估|RMSD<2Å/全部12|均值Å|', '|---|---:|---:|---:|---:|']
    for pid in settings['cohort']:
        rs = [r for r in rows if r['arm']=='A' and r['receptor_id']==pid]
        vals = [r['docking_RMSD_A'] for r in rs if r['docking_RMSD_A'] is not None]
        docking_lines.append(f'|{pid}|12|{len(vals)}|{sum(v<2 for v in vals)}/12|{fmt(mean(vals))}|')
    known = [load(p) for p in (OUT/'known/structures').glob('*/result.json')]
    known_vals = [r['docking_RMSD_A'] for r in known if r.get('docking_RMSD_A') is not None]
    baseline = load(OUT/'known_official_baseline.json') if (OUT/'known_official_baseline.json').exists() else {}
    original_vals = [r['docking_RMSD_A'] for r in baseline.get('rows', []) if r.get('available')]
    docking_lines += ['', f'已知CASF参照：统一数值路径RMSD可评估{len(known_vals)}/12，<2Å={sum(v<2 for v in known_vals)}/12，均值{fmt(mean(known_vals))}Å。',
                      f'未修改的官方FP32 sampler：可评估{len(original_vals)}/12，<2Å={sum(v<2 for v in original_vals)}/12，均值{fmt(mean(original_vals))}Å。二者随机辅助方向序列不同，不视为相同随机数条件下的逐分子优劣结论。',
                      'RMSD在受体坐标系中计算，不对配体重新刚性对齐；主A与统一数值路径参照最多枚举4096个化学同构匹配。官方原始sampler另报原始原子顺序RMSD。身份/拓扑为Oracle条件，参考结合坐标只用于评价。', '',
                      '|A阶段|真实图立体定义完整/72|真实图立体一致/72|立体一致不可评估|', '|---|---:|---:|---:|']
    for stage in STAGES:
        sr = [r for r in rows if r['arm']=='A']
        c = counts([r[stage+'_A_declared_stereo_geometry_consistent'] for r in sr])
        docking_lines.append(f'|{stage}|{sum(r[stage+"_A_declared_stereo_definition_complete"] is True for r in sr)}/72|{c["passed"]}/72|{c["unavailable"]}|')
    docking_lines += ['', '以上真实图立体检查使用保存的original_spec与raw.sdf，独立于历史HQ的几何重标标签；原生、刚性及柔性各自报告，不以重标后的自洽性证明恢复了真实立体。']
    write('DOCKING_BASELINE_RESULTS.md', docking_lines)
    fail_lines = ['# 质量失败与不可评估分解', '', f'状态：{state}；一分子可同时失败多个检查，以下计数不可相加解释为失败分子数。', '',
                  '|组|阶段|检查|通过|失败|不可评估|分母|', '|---|---|---|---:|---:|---:|---:|']
    for arm in ARMS:
        sr = [r for r in rows if r['arm']==arm]
        for stage in STAGES:
            for check in CHECKS:
                c = counts([r[stage+'_'+check] for r in sr])
                fail_lines.append(f'|{arm}|{stage}|{check}|{c["passed"]}|{c["failed"]}|{c["unavailable"]}|72|')
    fail_lines += ['', '逐记录失败/不可评估项、几何、异常和修复不收敛记录见PER_GENERATION_RESULTS.csv与QUALITY_FAILURE_RECORDS.csv；完整模块错误和PoseBusters逐项结果保留在本地quality/cache及quality_complete.json。未放宽水以外的检查。']
    write('QUALITY_FAILURE_BREAKDOWN.md', fail_lines)
    batches = [load(p) for p in (OUT/'main/batches').glob('*.json')]
    perf_lines = ['# GPU与完整运行成本', '', f'状态：{state}；主干批量前向与完整工作流成本分开。', '',
                  '|组|批次数|主干批量前向次数|分子×步数|批次墙钟秒|累计网络前向秒|完整生成分子/秒|', '|---|---:|---:|---:|---:|---:|---:|']
    for arm in ARMS:
        br = [b for b in batches if b['arm']==arm]
        wall = sum(b['wall_seconds'] for b in br)
        forwards = sum(b['forward_calls'] for b in br)
        forward_time = sum(t['forward_ms']/1000 for b in br for t in b['timings'])
        outputs = sum(r.get('pose_NFE')==24 for r in rows if r['arm']==arm)
        perf_lines.append(f'|{arm}|{len(br)}|{forwards}|{outputs*24}|{wall:.2f}|{forward_time:.2f}|{fmt(outputs/wall if wall else None)}|')
    perf_lines += ['', '批次墙钟包含网络、动态图、刚体更新、日志、动态身份查询/搜索/坐标转移及D引导，表内“完整生成”吞吐不含此前一次性的初始图准备、后续CPU修复/QC和最终写盘；端到端总成本应再结合这些独立记录，不能把本表当成含QC吞吐。',
                   'CPU搜索由4个spawn worker处理，CPU修复/QC由16个spawn worker处理；没有CUDA fork或为每个QC worker加载GPU模型。动态更新窗口仍等待CPU合法搜索，所有GPU同步和CPU等待均属于实际成本。',
                   'performance_trace.json保存开发基准的CPU/CUDA profiler；performance_benchmark.json保存预热后batch=1/4/8/16/32吞吐、显存及数值验收资格。仅网络前向时间占比不能等同于GPU总体利用率；不以nvidia-smi瞬时利用率冒充完整性能分析。BF16未获完整质量等价验证，未用于正式结果。',
                   '完整原始batch时序、CPU搜索seconds、每次引导seconds、QC seconds与修复seconds均保留，可复核开销和NFE。']
    write('GPU_UTILIZATION_REPORT.md', perf_lines)
    native = {a:next(s for s in summary if s['arm']==a and s['stage']=='native_final')['HQ'] for a in ARMS}
    write('NEXT_STEP_DECISION.md', ['# 下一步决策与研究问题', '', f'状态：{state}。',
        f'A/B/C/D/E原生或引导终态HQ分别为{native["A"]["passed"]}/72、{native["B"]["passed"]}/72、{native["C"]["passed"]}/72、{native["D"]["passed"]}/72、{native["E_connection_only"]["passed"]}/72；不可评估数另见主表，不能补成通过。',
        '1. 官方能力：主A真实图和已知CASF/原官方FP32参照的RMSD及HQ见DOCKING_BASELINE_RESULTS.md。少量诊断复合物不能建立原论文整体性能或证明所有任务正常。',
        '2. 固定预测图：查看B的原始键长、角度、内部与蛋白碰撞分解，判断在不动态改图时是否已存在问题。',
        '3. 动态更新：B/C是身份与连接联合效应，B/E隔离连接更新。结合逐事件before、after_transfer和after_next_network，区分图变换、坐标转移和后续神经运动。',
        '4. 几何引导：B/D共享输入与图，比较配对HQ和连续几何指标；D包含显式引导，收益不能归功于未经约束的神经网络。',
        '5. 改善来源：分开检查键长、键角、内部排斥和蛋白碰撞，特别保留键长改善但碰撞恶化的记录。',
        '6. 刚性修正可解决的错误：原生、rigid_repair、local_flex_repair各保留全分母、优化不收敛及位移，不能用修复后HQ替代原生能力。',
        '7. 是否微调：本轮只提供冻结权重的控制诊断；先依据固定图/动态更新/引导效应确定瓶颈，再提出独立开发和未见口袋验证，不能由A/B分布差直接决定重新训练整个网络。',
        '8. 吞吐：预热batch基准与实际各组墙钟、网络NFE见PERFORMANCE_BENCHMARK.md与GPU_UTILIZATION_REPORT.md；单GPU，不能套用历史训练batch模板。',
        '未建立额外从未参与开发或查看的独立口袋集合，本轮六口袋均属已查看诊断集，不能宣称独立泛化。未启动新模型训练或修改官方权重。'])
    protocol_report(settings)
    root_cause()
    write('REPRODUCE.md', ['# 复现与进度检查', '', '从原工作区根目录执行；需要现有权重、词表、GEOM/旧实验输入及官方源码布局。', '', '```bash',
        'export CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8',
        'export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2',
        'export PYTHONPATH="$PWD/.quality_deps:$PWD"',
        '../.venv-cutoff-train/bin/python -B pose_generation_four_arm_comparison/source/validate_replay.py',
        '../.venv-cutoff-train/bin/python -B pose_generation_four_arm_comparison/source/launch.py --through complete',
        'cat pose_generation_four_arm_comparison/status.json',
        'tail -n 30 pose_generation_four_arm_comparison/experiment.log', '```', '',
        '同目录再次运行会校验并恢复已有输入与结果，不重新抽样失败记录。独立重跑需在保持项目布局的新副本中进行；正式启动代码快照保存在frozen_source/，formal_start.json约束恢复时的源码和配置。',
        '旧失败诊断保留，不覆盖为成功；prompt_check原文和哈希作为本轮修正来源。报告和全部结果通过日期任务的“完整实验目录”访问。'])
    if final:
        required = load(OUT/'status.json')['expected_deliverables']+['ROOT_CAUSE_REPORT.md', 'REPRODUCE.md']
        assert all((OUT/name).is_file() for name in required)
        assert all(r['status'] != 'pending' for r in rows)


def fingerprint_delivery():
    # Exclude still-flushing process logs and regenerable cache, not scientific failures.
    paths = [p for p in OUT.rglob('*') if p.is_file() and 'cache' not in p.relative_to(OUT).parts
             and p.name != 'delivery_manifest.json' and p.suffix not in ['.log', '.tmp']]
    dump(OUT/'delivery_manifest.json', dict(complete=True, scientific_scope='Frozen five-arm primary plus separate known reference',
         files={p.relative_to(OUT).as_posix():dict(bytes=p.stat().st_size,sha256=sha256(p)) for p in paths}))


if __name__ == '__main__':
    generate(final=False)
