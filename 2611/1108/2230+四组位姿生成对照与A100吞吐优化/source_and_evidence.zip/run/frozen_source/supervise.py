"""Development-only parameter selection, paired formal execution and final audit."""
from common import *
import copy
import math
import shutil
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from multiprocessing import get_context
import torch
import run_experiment as rx


def chunks(items, size):
    for start in range(0, len(items), size):
        yield items[start:start+size]


def oracle_cases(pids, seeds, role):
    result = []
    for pid in pids:
        for seed in seeds:
            path = OUT/role/'oracle_inputs'/f'{pid}_{seed}.pt'
            failure = path.with_suffix('.failure.json')
            if path.exists():
                result.append(torch.load(path, weights_only=False))
                continue
            if failure.exists():
                result.append(load(failure))
                continue
            try:
                case = rx.oracle_case(pid, seed, role)
                path.parent.mkdir(parents=True, exist_ok=True)
                torch.save(case, path)
                result.append(case)
            except Exception as exc:
                case = dict(pid=pid, seed=seed, role=role, oracle=True, preparation_failed=True,
                            error=repr(exc), traceback=traceback.format_exc())
                dump(failure, case)
                result.append(case)
    return result


def score(record):
    if record.get('status') not in ['native_complete', 'complete', 'repair_incomplete']:
        return 1e12
    m = record['final_geometry']
    if m['cross_bond_MAE_A'] is None or m['cross_angle_MAE_deg'] is None:
        return 1e12
    return (m['cross_bond_MAE_A']/.15)**2+(m['cross_angle_MAE_deg']/15)**2+10*(m['severe_cross_internal_pairs']>0)+10*(m['severe_protein_pairs']>0)


def choose_guidance(settings, den, lib, pool, client, dev, size):
    path = OUT/'guidance_selection.json'
    if path.exists():
        selection = load(path)
        assert selection['effective_protocol_sha256'] == sha256(OUT/'effective_protocol.json')
        return selection['selected']
    set_status('development_guidance_selection', candidates=len(settings['guidance_candidates']), dev_attempts_per_candidate=len(dev))
    baseline = []
    for batch in chunks(dev, size):
        baseline += rx.run_batch(batch, 'B', den, client, pool, lib, tag='B_development')
    rows = []
    for config in settings['guidance_candidates']:
        records = []
        for batch in chunks(dev, size):
            records += rx.run_batch(batch, 'D', den, client, pool, lib, guidance=config, tag='D_development_'+config['name'])
        row = dict(name=config['name'], config=config, attempts=len(records), mean_score=float(np.mean([score(r) for r in records])),
                   baseline_mean_score=float(np.mean([score(r) for r in baseline])),
                   sample_scores=[dict(pid=r['receptor_id'], seed=r['seed'], score=score(r)) for r in records])
        rows.append(row)
        dump(OUT/'guidance_development_results.json', rows)
        print('GUIDANCE DEV', config['name'], row['mean_score'], flush=True)
    selected = min(rows, key=lambda r:r['mean_score'])['config']
    selection = dict(selected=selected, development_only=True, test_results_read=False,
                     dev_pockets=settings['dev_pockets'], dev_seeds=settings['dev_seeds'],
                     effective_protocol_sha256=sha256(OUT/'effective_protocol.json'),
                     frozen_UTC=datetime.now(timezone.utc).isoformat(), results=rows)
    dump(path, selection)
    return selected


def connection_device_audit(settings, lib, pool, dev):
    path = OUT/'connection_cpu_gpu_audit.json'
    if path.exists():
        assert load(path)['passed']
        return
    from trajectory_connections import load_connection, ConnectionRuntime
    from hierarchical_topology import hierarchical_search, SearchConfig
    head = load_connection(settings['weights']['connection']['path'], 'cuda:0')
    checks = []
    for case in dev[:2]:
        arrays = np.load(OUT/'dev/initial'/f'{case["pid"]}_{case["seed"]}'/'initial.npz')
        job = dict(labels=case['labels'], T=arrays['T'], R=arrays['R'], t=1., return_probabilities=True)
        cpu = pool.submit(rx.search_job, job).result()
        runtime = ConnectionRuntime(lib, head, case['labels'], [None]*case['N'], 'cuda:0', policy='wide', head='full')
        pred = runtime.predict(arrays['T'], arrays['R'], 1., policy='wide', head='full')
        gpu = hierarchical_search(runtime, pred, k=1, config=SearchConfig())
        cp = {tuple(m):p for m,p in zip(cpu['classifier_metadata'], cpu['classifier_probabilities'])}
        gp = {tuple(m):p for m,p in zip(pred['meta'].tolist(), pred['p'].tolist())}
        assert set(cp) == set(gp)
        error = max(float(np.max(np.abs(np.array(cp[k])-np.array(gp[k])))) for k in cp)
        def topology(search):
            c = search['candidates'][0]['connections'] if search['candidates'] else []
            return rx.topology_key(case['labels'], c)
        checks.append(dict(pid=case['pid'], seed=case['seed'], max_probability_delta=error,
                           same_initial_legal_graph=topology(cpu)==topology(gpu)))
    result = dict(passed=all(c['same_initial_legal_graph'] and c['max_probability_delta']<1e-4 for c in checks),
                  checks=checks, scope='Two development initial graph decodes; does not claim bitwise CPU/GPU equality on all unseen dynamic cases')
    dump(path, result)
    assert result['passed'], 'CPU/GPU initial connection decode mismatch'
    del head
    torch.cuda.empty_cache()


def verify_pairing(role, expected):
    checks = []
    for pid, seed in expected:
        base = OUT/role/'structures'
        rows = {arm:load(base/f'{pid}_{seed}_{arm}'/'result.json') for arm in rx.ARMS}
        predicted = [rows[a] for a in ['B', 'C', 'D', 'E_connection_only']]
        if not all(r.get('initial_xyz_sha256') for r in predicted):
            checks.append(dict(pid=pid, seed=seed, unavailable=True, reason='Initial prediction failed; paired failures retained'))
            continue
        assert len({r['initial_xyz_sha256'] for r in predicted}) == 1
        assert all(r['initial_labels'] == rows['B']['initial_labels'] and r['initial_connections'] == rows['B']['initial_connections'] for r in predicted)
        assert rows['B']['labels'] == rows['D']['labels'] and rows['B']['connections'] == rows['D']['connections']
        assert rows['E_connection_only']['labels'] == rows['E_connection_only']['initial_labels']
        for event in rows['E_connection_only']['events']:
            assert event['old_labels'] == event['proposed_labels']
        for arm, row in rows.items():
            assert row['pose_NFE'] == 24
        checks.append(dict(pid=pid, seed=seed, passed=True, same_initial_pose=True, same_B_D_graph=True, E_identity_fixed=True))
    return dict(passed=True, pairs=len(checks), rows=checks)


def wait_quality(futures, phase):
    done = []
    for future in as_completed(futures):
        done.append(future.result())
        print('POSTPROCESS', phase, len(done), '/', len(futures), flush=True)
        set_status('quality_'+phase, quality_completed=len(done), quality_expected=len(futures))
    return done


def perform_preflight(settings, den, lib, pool, client, guidance, size, quality_pool):
    path = OUT/'preflight_verification.json'
    if path.exists():
        assert load(path)['passed']
        return
    set_status('five_arm_preflight')
    predicted = rx.prepare_all(settings['dev_pockets'][:2], settings['preflight_seeds'], 'preflight', lib, pool)
    true = oracle_cases(settings['dev_pockets'][:2], settings['preflight_seeds'], 'preflight')
    assert all(not c.get('preparation_failed') for c in predicted+true), 'Preflight input preparation failed'
    # New fragment counts are tested separately from the original N=5 development inputs.
    from validate_replay import validate
    validation_path = OUT/'replay_validation.json'
    existing = load(validation_path)
    extra = validate(den, predicted, sizes=(1, 4))
    dump(OUT/'preflight_replay_validation.json', extra)
    dump(validation_path, existing)
    records, futures = [], []
    for arm in rx.ARMS:
        cases = true if arm == 'A' else predicted
        for batch in chunks(cases, min(size, 4)):
            rows = rx.run_batch(batch, arm, den, client, pool, lib, guidance=guidance)
            records += rows
            for r in rows:
                assert r['status'] == 'native_complete'
                futures.append(quality_pool.submit(rx.postprocess, r['folder']))
    wait_quality(futures, 'preflight')
    pairing = verify_pairing('preflight', [(pid, seed) for pid in settings['dev_pockets'][:2] for seed in settings['preflight_seeds']])
    for r in records:
        d = load(Path(r['folder'])/'quality_complete.json')
        assert len(d['metrics']) == 3 and d['input_unchanged']
    drows = [r for r in records if r['arm'] == 'D']
    assert all(r['guidance'] for r in drows)
    assert any(event['gradient_norm'] > 0 for r in drows for event in r['guidance'])
    assert all(not p.requires_grad and p.grad is None for p in den.parameters())
    result = dict(passed=True, attempts=len(records), QC_records=len(records)*3, pairing=pairing,
                  nonzero_guidance_gradients=True, frozen_backbone_gradients_absent=True,
                  original_A_stereo_reports=all((Path(r['folder'])/'A_DECLARED_STEREO.json').exists() for r in records if r['arm']=='A'),
                  replay_new_fragment_counts=extra, excluded_from_formal=True)
    dump(path, result)


def formal(settings, den, lib, pool, client, guidance, size, quality_pool):
    set_status('prepare_formal_inputs')
    predicted = rx.prepare_all(settings['cohort'], settings['seeds'], 'main', lib, pool)
    true = oracle_cases(settings['cohort'], settings['seeds'], 'main')
    requested = len(settings['cohort'])*len(settings['seeds'])
    assert len(predicted) == len(true) == requested == 72
    available = sorted({r['pid'] for r in true if not r.get('preparation_failed')})
    dump(OUT/'oracle_input_audit.json', dict(requested_unique_complexes=6, available_unique_complexes=len(available),
         available_ids=available, requested_A_attempts=72, prepared_A_attempts=sum(not c.get('preparation_failed') for c in true),
         preparation_failures=[c for c in true if c.get('preparation_failed')],
         primary_denominator=dict(arms=rx.ARMS, per_arm=72, total=360),
         separate_known_reference=dict(unique_complexes=12, seeds=1, per_numerical_mode=12, included_in_primary=False)))
    frozen = OUT/'formal_start.json'
    if not frozen.exists():
        (OUT/'frozen_source').mkdir(exist_ok=True)
        sources = {}
        for path in (OUT/'source').glob('*.py'):
            shutil.copyfile(path, OUT/'frozen_source'/path.name)
            sources[path.name] = sha256(path)
        dump(frozen, dict(UTC=datetime.now(timezone.utc).isoformat(), effective_protocol_sha256=sha256(OUT/'effective_protocol.json'),
                         guidance_selection_sha256=sha256(OUT/'guidance_selection.json'), source_sha256=sources))
    else:
        expected = load(frozen)
        assert expected['effective_protocol_sha256'] == sha256(OUT/'effective_protocol.json')
        for name, digest in expected['source_sha256'].items():
            if name != 'reports.py':
                assert sha256(OUT/'source'/name) == digest, name
    futures = []
    completed = 0
    for arm in rx.ARMS:
        cases = true if arm == 'A' else predicted
        # Each full chunk contains multiple different molecules; final short chunks are retained.
        cases = sorted(cases, key=lambda c:len(c['graph'].x) if not c.get('preparation_failed') else -1)
        for batch in chunks(cases, size):
            set_status('formal_generation', current_arm=arm, formal_attempts_completed=completed, formal_attempts_expected=360)
            records = rx.run_batch(batch, arm, den, client, pool, lib, guidance=guidance)
            completed += len(records)
            for r in records:
                folder = Path(r['folder'])
                if (folder/'postprocess_input.pt').exists():
                    futures.append(quality_pool.submit(rx.postprocess, str(folder)))
            from reports import generate
            generate(final=False)
    dump(OUT/'pairing_verification.json', verify_pairing('main', [(pid, seed) for pid in settings['cohort'] for seed in settings['seeds']]))
    set_status('formal_quality', formal_attempts_completed=360, formal_attempts_expected=360)
    wait_quality(futures, 'formal')


def known_reference(settings, den, lib, pool, client, size, quality_pool):
    set_status('known_docking_reference')
    known = oracle_cases(settings['known_docking_reference_ids'], settings['known_docking_reference_seeds'], 'known')
    records, futures = [], []
    for batch in chunks(known, size):
        rows = rx.run_batch(batch, 'A', den, client, pool, lib, tag='A_known')
        records += rows
        for r in rows:
            if (Path(r['folder'])/'postprocess_input.pt').exists():
                futures.append(quality_pool.submit(rx.postprocess, r['folder']))
    # Unmodified original precision and sampler provide a separate familiar-task baseline.
    from stable_precision import original_precision
    from run_validation import docking
    with original_precision(den):
        native = []
        for case in known:
            path = OUT/'known/original_sampler'/f'{case["pid"]}_{case["seed"]}.json'
            if path.exists():
                native.append(load(path))
                continue
            row = dict(pid=case['pid'], seed=case['seed'], numerical_mode='unmodified_FP32_official_sampler', available=False)
            if not case.get('preparation_failed'):
                try:
                    xyz, trajectory, info = docking(den, case['graph'], seed=case['seed'], steps=25, device='cuda:0', noise_scale=0., save=path.with_suffix('.pt'))
                    target = case['target'].GetConformer().GetPositions()
                    row.update(available=True, docking_RMSD_A=float(np.sqrt(np.mean(np.sum((xyz.numpy()-target)**2, axis=-1)))), seconds=info['seconds'])
                except Exception as exc:
                    row.update(error=repr(exc), traceback=traceback.format_exc())
            else:
                row['error'] = case['error']
            dump(path, row)
            native.append(row)
    dump(OUT/'known_official_baseline.json', dict(requested=12, rows=native, included_in_primary=False,
         original_sampler_auxiliary_random_stream='Original global RNG; not identical to stable-edge draws, so not a same-random-draw quality comparison'))
    wait_quality(futures, 'known')


def final_audit(settings):
    old = load(OUT/'input_audit.json')
    for name, digest in old['frozen_files'].items():
        assert sha256(name) == digest, name
    historical = load(OUT/'historical_fingerprints.json')
    for name, digest in historical.items():
        assert sha256(name) == digest, name
    records = [load(p) for p in (OUT/'main/structures').glob('*/result.json')]
    assert len(records) == 360
    assert all(sum(r['arm'] == arm for r in records) == 72 for arm in rx.ARMS)
    assert load(OUT/'pairing_verification.json')['passed']
    for r in records:
        if r.get('pose_NFE') == 24:
            q = load(Path(r['folder'])/'quality_complete.json')
            assert len(q['metrics']) + len(q['repair_errors']) == 3
    dump(OUT/'completion_verification.json', dict(passed=True, formal_attempts=360, per_arm=72,
         frozen_files_verified=len(old['frozen_files']), historical_files_verified=len(historical),
         weights_unchanged=True, pairing_verified=True, raw_repair_and_guidance_separated=True,
         independent_validation_available=False, known_references_separate=True))


def complete_experiment(settings, den, lib, pool, client, dev, size):
    with ProcessPoolExecutor(16, mp_context=get_context('spawn')) as quality_pool:
        connection_device_audit(settings, lib, pool, dev)
        guidance = choose_guidance(settings, den, lib, pool, client, dev, size)
        perform_preflight(settings, den, lib, pool, client, guidance, size, quality_pool)
        formal(settings, den, lib, pool, client, guidance, size, quality_pool)
        known_reference(settings, den, lib, pool, client, size, quality_pool)
    final_audit(settings)
    from reports import generate, fingerprint_delivery
    generate(final=True)
    status = load(OUT/'status.json')
    status.update(stage='complete', execution_complete=True, formal_attempts_completed=360,
                  formal_attempts_expected=360, completed_deliverables=status['expected_deliverables'])
    dump(OUT/'status.json', status)
    fingerprint_delivery()
    print('FULL EXPERIMENT COMPLETE', flush=True)
