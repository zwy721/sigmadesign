"""Detach the authorized single-GPU diagnostic and record its exact command."""
from common import *
import argparse
import subprocess
import time
from datetime import datetime, timezone


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--through', choices=['audit', 'benchmark', 'complete'], default='complete')
    args = parser.parse_args()
    old = OUT/'process.json'
    if old.exists():
        previous = load(old)
        proc = Path('/proc')/str(previous['pid'])/'cmdline'
        if proc.exists() and b'run_experiment.py' in proc.read_bytes():
            raise RuntimeError('An experiment supervisor is already active')
        history = OUT/'process_history'
        history.mkdir(exist_ok=True)
        dump(history/f'{time.time_ns()}.json', previous)
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='0', CUBLAS_WORKSPACE_CONFIG=':4096:8',
               PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='2',
               PYTHONPATH=str(ROOT/'.quality_deps')+os.pathsep+str(ROOT))
    command = [sys.executable, '-B', str(OUT/'source/run_experiment.py'), '--through', args.through]
    path = OUT/('experiment.log' if args.through == 'complete' else args.through+'_current.log')
    with path.open('a') as log:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    record = dict(pid=process.pid, UTC=datetime.now(timezone.utc).isoformat(), command=command,
                  cwd=str(ROOT), log=str(path), physical_GPU=0, through=args.through)
    dump(old, record)
    print(json.dumps(record, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
