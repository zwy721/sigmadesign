import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from torch_geometric.data import Data, Batch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'source'))
import common  # Install the isolated official-source import path.
from random_frames import directions, official_frame, frame_with_uniform, attach
from reports import counts, pairwise


def graph():
    return Data(x=torch.zeros(3, 1), pos_t=torch.zeros(3, 3),
                edge_index=torch.tensor([[0, 1, 2], [1, 2, 0]]),
                edge_entity=torch.tensor([0, 1, 0]), edge_attr=torch.tensor([[1., 0.], [2., 1.], [1., 0.]]))


def test_edge_uniforms_are_batch_order_and_subset_invariant():
    a, b = SimpleNamespace(replay_key=123), SimpleNamespace(replay_key=456)
    single = directions(Batch.from_data_list([graph()]), [a], 3)
    packed = directions(Batch.from_data_list([graph(), graph()]), [b, a], 3)
    assert torch.equal(single, packed[3:])
    g = graph()
    g.edge_index = g.edge_index[:, [2, 0]]
    g.edge_entity = g.edge_entity[[2, 0]]
    g.edge_attr = g.edge_attr[[2, 0]]
    assert torch.equal(directions(Batch.from_data_list([g]), [a], 3), single[[2, 0]])
    assert not torch.equal(single, directions(Batch.from_data_list([graph()]), [a], 4))


def test_official_frame_algorithm_is_unchanged_for_same_uniforms():
    vector = torch.tensor([[1., 2., 3.], [0., 0., 0.], [-2., .2, .3]])
    state = torch.get_rng_state()
    expected = official_frame(vector)
    torch.set_rng_state(state)
    uniforms = torch.rand_like(vector)
    actual = frame_with_uniform(vector, uniforms)
    assert torch.equal(expected, actual)
    assert torch.isfinite(actual).all()


def test_unavailable_results_preserve_attempt_denominator():
    assert counts([True, False, None, None]) == dict(passed=1, failed=1, unavailable=2, denominator=4)
    rows = [dict(arm='B', receptor_id='x', seed=1, status='complete', native_final_high_quality=False),
            dict(arm='D', receptor_id='x', seed=1, status='failed', native_final_high_quality=None)]
    paired = pairwise(rows, 'B', 'D')
    assert len(paired) == 1 and paired[0]['HQ_difference_right_minus_left'] is None
    assert paired[0]['left_HQ'] is False and paired[0]['right_HQ'] is None


def test_common_edges_keep_random_inputs_after_chemistry_and_atom_count_changes():
    def example(extra):
        n = 6+extra
        first = [0, 1, 2] if extra else [0, 1]
        second = [3, 4] if extra else [2, 3]
        a, b = 1+second[0], 1+second[1]
        g = Data(x=torch.zeros(n, 1), pos_t=torch.zeros(n, 3),
                 frag_idx_map=torch.tensor([-1]+[0]*len(first)+[1]*3),
                 node_entity=torch.tensor([4]+[0]*(n-2)+[3]),
                 edge_index=torch.tensor([[0, a, n-1], [a, b, a]]),
                 edge_entity=torch.tensor([9, 0, 1]), edge_attr=torch.ones(3, 2))
        case = dict(pid='same_pocket', seed=123, labels=[9 if extra else 7, 8], groups=[first, second],
                    spec=dict(fragments=[{'identity':'changed' if extra else 'old'}, {'identity':'unchanged'}], connections=[extra], cut_order=[extra]))
        state = attach(SimpleNamespace(graph=g, pn=1), case)
        return g, state
    before, a = example(False)
    after, b = example(True)
    assert a.replay_key == b.replay_key
    assert torch.equal(directions(Batch.from_data_list([before]), [a], 5),
                       directions(Batch.from_data_list([after]), [b], 5))
