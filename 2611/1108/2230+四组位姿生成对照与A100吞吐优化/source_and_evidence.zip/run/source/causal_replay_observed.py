"""Read-only-to-primary deterministic replay for topology/transfer attribution.

Adds observations only. Final chemistry and unrounded coordinates must match
the corresponding primary C/E outputs before any replay measurement is used.
"""
from common import *
import copy
import time
import traceback
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import torch
import run_experiment as rx
import runtime
from runtime import Geometry
from joint_sampler import NativeState
from stable_precision import install
from run_validation import load_official
from random_frames import attach, directions
from torch_geometric.data import Batch

INITIAL, GRAPHS, PENDING = {}, {}, {}
ACTIVE_ARM = None
COMPONENT_TIMINGS = []
ORIGINAL_INIT = NativeState.__init__
ORIGINAL_FRAMES = NativeState.slot_frames
ORIGINAL_CHEMISTRY = rx.chemical_graph


def chemistry(*args, **kwargs):
    started = time.perf_counter()
    graph, groups, spec = ORIGINAL_CHEMISTRY(*args, **kwargs)
    GRAPHS[id(graph)] = (spec, args[3], time.perf_counter()-started)
    return graph, groups, spec


def frames(self, *args, **kwargs):
    started = time.perf_counter()
    result = ORIGINAL_FRAMES(self, *args, **kwargs)
    elapsed = time.perf_counter()-started
    arm, pid, seed = self._causal_id
    xyz = self.physical()[self.pn:self.pn+sum(map(len, self.groups))]
    geometry = Geometry(self._causal_spec, self._causal_context)
    PENDING[id(self)] = dict(identifier=(arm, pid, seed), state=self, step=self.step_index,
                            centers=np.array([xyz[g].mean(0) for g in self.groups]),
                            slot_frame_copy_and_fit_seconds=elapsed,
                            before_old_topology=geometry.metrics(xyz))
    return result


def initialize(self, den, graph, groups, device, *args, **kwargs):
    started = time.perf_counter()
    ORIGINAL_INIT(self, den, graph, groups, device, *args, **kwargs)
    torch.cuda.synchronize()
    init_seconds = time.perf_counter()-started
    if id(graph) in INITIAL:
        case = INITIAL[id(graph)]
        self._causal_id = (ACTIVE_ARM, case['pid'], case['seed'])
        self._causal_spec, self._causal_context = case['spec'], case['context']
        COMPONENT_TIMINGS.append(dict(arm=ACTIVE_ARM,pid=case['pid'],seed=case['seed'],kind='initial_native_state',seconds=init_seconds))
        return
    assert id(graph) in GRAPHS
    spec, ctx, graph_seconds = GRAPHS[id(graph)]
    wanted = kwargs['desired']
    centers = np.array([np.asarray(x).mean(0) for x in wanted])
    options = []
    for row in PENDING.values():
        if row['identifier'][0] != ACTIVE_ARM or row['centers'].shape != centers.shape:
            continue
        error = float(np.max(np.linalg.norm(centers-row['centers'], axis=-1)))
        options.append((error, row))
    error, previous = min(options, key=lambda item:item[0])
    assert error < .001, 'Cannot unambiguously associate coordinate transfer with its prior state'
    arm, pid, seed = previous['identifier']
    COMPONENT_TIMINGS.append(dict(arm=arm,pid=pid,seed=seed,step=previous['step'],kind='graph_chemistry_reference_and_conversion',seconds=graph_seconds))
    COMPONENT_TIMINGS.append(dict(arm=arm,pid=pid,seed=seed,step=previous['step'],kind='replacement_native_state',seconds=init_seconds))
    COMPONENT_TIMINGS.append(dict(arm=arm,pid=pid,seed=seed,step=previous['step'],kind='slot_frame_copy_and_rigid_fit',seconds=previous['slot_frame_copy_and_fit_seconds']))
    self._causal_id, self._causal_spec, self._causal_context = previous['identifier'], spec, ctx
    attach(self, dict(pid=pid, seed=seed, spec=spec, groups=groups,
                      labels=[int(f['vocab3684']) for f in spec['fragments']]), step=previous['step'])
    def edge_random_map(state):
        data = state.graph.clone()
        del data.mol_info
        data.pos_t = torch.zeros_like(data.ref_pos)
        data = Batch.from_data_list([data])
        keep = data.mask[data.edge_index[0]] & data.mask[data.edge_index[1]]
        data.edge_index, data.edge_entity, data.edge_attr = data.edge_index[:, keep], data.edge_entity[keep], data.edge_attr[keep]
        uniform = directions(data, [state], previous['step']).cpu().numpy()
        index = data.edge_index.numpy()
        return {(int(state.replay_node_keys[a]), int(state.replay_node_keys[b]), int(k), tuple(v.tolist())):u
                for a,b,k,v,u in zip(index[0], index[1], data.edge_entity, data.edge_attr, uniform)}
    before_random, after_random = edge_random_map(previous['state']), edge_random_map(self)
    common = set(before_random) & set(after_random)
    random_error = max((float(np.max(np.abs(before_random[k]-after_random[k]))) for k in common), default=0.)
    random_audit = dict(common_semantic_edges=len(common), common_edges_uniform_max_delta=random_error,
                        sample_random_key_equal=previous['state'].replay_key==self.replay_key)
    if max(self.transfer_errors, default=0) > .5:
        dump(OUT/'causal_replay/transfer_observations'/f'{arm}_{pid}_{seed}_{previous["step"]}.json',
             dict(arm=arm,receptor_id=pid,seed=seed,step=previous['step'],proposal_rejected_by_transfer_gate=True,random_audit=random_audit))
        return
    geometry = Geometry(spec, ctx)
    target = np.empty((geometry.mol.GetNumAtoms(), 3))
    for group, value in zip(groups, wanted):
        target[group] = value
    actual = self.physical()[self.pn:self.pn+geometry.mol.GetNumAtoms()]
    metrics = dict(arm=arm, receptor_id=pid, seed=seed, step=previous['step'],
                   old_topology_before=previous['before_old_topology'],
                   new_topology_before_transfer=geometry.metrics(target),
                   new_topology_after_transfer=geometry.metrics(actual),
                   transfer_target_RMSD_A=float(np.sqrt(np.mean(np.sum((actual-target)**2, axis=-1)))),
                   transfer_target_max_atom_delta_A=float(np.linalg.norm(actual-target, axis=-1).max()),
                   old_state_association_max_center_delta_A=error,
                   transfer_fit_rmsd_A=self.transfer_errors,
                   random_audit=random_audit,
                   attribution_note='C graph/identity mapping may change atom count; E holds identity and atom mapping fixed. Only accepted transfers count as applied effects.')
    dump(OUT/'causal_replay/transfer_observations'/f'{arm}_{pid}_{seed}_{previous["step"]}.json', metrics)


def run():
    global ACTIVE_ARM
    status = load(OUT/'status.json')
    assert status['execution_complete'] or status['stage'] == 'causal_replay'
    set_status('causal_replay', formal_attempts_completed=360)
    torch.set_num_threads(2)
    torch.cuda.set_device(0)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    settings = load(OUT/'effective_protocol.json')
    lib = rx.VocabLibrary()
    den = load_official(bootstrap.CHECKPOINT, OUT/'cache/official', 'cuda:0')
    install(den)
    size = load(OUT/'performance_benchmark.json')['selected_batch_size']
    cases = []
    for pid in settings['cohort']:
        for seed in settings['seeds']:
            case = torch.load(OUT/'main/initial'/f'{pid}_{seed}'/'case.pt', weights_only=False)
            case['role'] = 'causal_replay'
            cases.append(case)
    cases.sort(key=lambda c:len(c['graph'].x))
    NativeState.__init__ = initialize
    NativeState.slot_frames = frames
    rx.chemical_graph = chemistry
    checks = []
    started = time.perf_counter()
    with ProcessPoolExecutor(4, mp_context=get_context('spawn'), initializer=rx.cpu_init) as pool:
        client = rx.Client()
        try:
            for arm in ['C', 'E_connection_only']:
                ACTIVE_ARM = arm
                for start in range(0, len(cases), size):
                    batch = cases[start:start+size]
                    INITIAL.clear(); PENDING.clear(); GRAPHS.clear()
                    INITIAL.update({id(c['graph']):c for c in batch})
                    records = rx.run_batch(batch, arm, den, client, pool, lib)
                    for record in records:
                        original = load(OUT/'main/structures'/f'{record["receptor_id"]}_{record["seed"]}_{arm}'/'result.json')
                        old = torch.load(Path(original['folder'])/'postprocess_input.pt', weights_only=False)['mol']
                        new = torch.load(Path(record['folder'])/'postprocess_input.pt', weights_only=False)['mol']
                        assert rx.topology_key(original['labels'], original['connections']) == rx.topology_key(record['labels'], record['connections'])
                        error = float(np.max(np.abs(old.GetConformer().GetPositions()-new.GetConformer().GetPositions())))
                        assert error <= 1e-6, 'Replay does not reproduce primary coordinates'
                        assert [(e['accepted'],e.get('reason')) for e in original['events']] == [(e['accepted'],e.get('reason')) for e in record['events']]
                        checks.append(dict(arm=arm, pid=record['receptor_id'], seed=record['seed'], max_coordinate_component_delta_A=error,
                                           final_chemistry_equal=True, update_decisions_equal=True))
                    dump(OUT/'causal_replay/reproduction_checks.json', checks)
        finally:
            client.close()
    NativeState.__init__, NativeState.slot_frames, rx.chemical_graph = ORIGINAL_INIT, ORIGINAL_FRAMES, ORIGINAL_CHEMISTRY
    observations = {(r['arm'],r['receptor_id'],r['seed'],r['step']):r for r in
                    [load(p) for p in (OUT/'causal_replay/transfer_observations').glob('*.json')]}
    rows = []
    for arm in ['C', 'E_connection_only']:
        for pid in settings['cohort']:
            for seed in settings['seeds']:
                primary = load(OUT/'main/structures'/f'{pid}_{seed}_{arm}'/'result.json')
                for event in primary['events']:
                    row = dict(arm=arm, receptor_id=pid, seed=seed, step=event['step'], accepted=event['accepted'], reason=event.get('reason'),
                               identity_changed=event['old_labels']!=event['proposed_labels'],
                               before=event['before'], after_transfer=event['after_transfer'], after_next_network=event['after_next_network'])
                    observation = observations.get((arm,pid,seed,event['step']))
                    if observation and not observation.get('proposal_rejected_by_transfer_gate'):
                        row.update(observation)
                        for field in ['cross_bond_MAE_A','cross_angle_MAE_deg','severe_cross_internal_pairs','severe_protein_pairs']:
                            old = observation['old_topology_before'].get(field)
                            mapped = observation['new_topology_before_transfer'].get(field)
                            transferred = observation['new_topology_after_transfer'].get(field)
                            network = event['after_next_network'].get(field)
                            row[field+'_graph_mapping_difference'] = mapped-old if mapped is not None and old is not None else None
                            row[field+'_transfer_difference_same_topology'] = transferred-mapped if transferred is not None and mapped is not None else None
                            row[field+'_next_network_difference_same_topology'] = network-transferred if network is not None and transferred is not None and event['accepted'] else None
                    rows.append(row)
    assert len(checks) == 144 and len(rows) == 576
    assert all(r['random_audit']['common_edges_uniform_max_delta']==0 and r['random_audit']['sample_random_key_equal'] for r in observations.values())
    csvwrite(OUT/'GRAPH_TRANSFER_CAUSAL_DECOMPOSITION.csv', rows)
    dump(OUT/'causal_replay_verification.json', dict(passed=True, replay_attempts=144, events=576,
         excluded_from_primary_denominator=True, maximum_coordinate_component_delta_A=max(r['max_coordinate_component_delta_A'] for r in checks),
         all_final_chemistry_and_decisions_equal=True, wall_seconds=time.perf_counter()-started,
         applied_transfer_events=sum(r['accepted'] for r in rows), constructor_observations=len(observations)))
    csvwrite(OUT/'CAUSAL_REPLAY_COMPONENT_TIMINGS.csv',COMPONENT_TIMINGS)
    status = load(OUT/'status.json');status.update(stage='complete',execution_complete=True,causal_replay_complete=True)
    dump(OUT/'status.json',status)
    print('CAUSAL REPLAY COMPLETE', len(checks), len(rows), flush=True)


if __name__ == '__main__':
    try:
        run()
    except Exception as exc:
        set_status('causal_replay_failed', error=repr(exc), traceback=traceback.format_exc())
        raise
