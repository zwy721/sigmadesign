"""Verify complete scientific artifacts, interpret paired results and link the archive."""
from common import *
import csv
from collections import Counter
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from reports import generate, gather, pairwise, mean, fmt, counts, fingerprint_delivery


def table(headers, rows):
    return ['|'+'|'.join(headers)+'|', '|'+'|'.join(['---']*len(headers))+'|']+['|'+'|'.join(map(str,r))+'|' for r in rows]


def loadcsv(path):
    with path.open(newline='') as handle:
        return list(csv.DictReader(handle))


def main():
    assert OUT.name == 'paired_final'
    assert load(OUT/'status.json')['execution_complete']
    assert load(OUT/'completion_verification.json')['passed']
    causal = load(OUT/'causal_replay_verification.json')
    assert causal['passed'] and causal['replay_attempts']==144 and causal['events']==576
    assert load(OUT/'quality_protocol_verification.json')['passed']
    settings = load(OUT/'effective_protocol.json')
    assert settings['version']==3 and 'no whole-chemistry salt' in settings['stochastic_replay']
    generate(final=True)
    rows, raw, events, guidance, failures = gather(settings)
    byarm = {arm:[r for r in rows if r['arm']==arm] for arm in settings['arms']}
    native = {a:counts([r['native_final_high_quality'] for r in rs]) for a,rs in byarm.items()}
    assert all(len(rs)==72 for rs in byarm.values())
    assert all(r['status']!='pending' for r in rows)
    # Verify the prior run's scientific artifacts, explicitly excluding its mutable navigation.
    parent = OUT.parent
    old = load(parent/'delivery_manifest.json')
    mutable = {'status.json','README.md'}
    verified_prior = 0
    for name, info in old['files'].items():
        if name in mutable:
            continue
        assert sha256(parent/name)==info['sha256'],name
        verified_prior += 1
    assets = ROOT.parent/'geom_m12/assets'
    provenance = load(HISTORY/'generator_provenance.json')['files']
    assets_verified = []
    for name in ['mapping.json','templates.json','properties.json']:
        path = assets/name
        expected = provenance[str(path)]
        expected = expected['sha256'] if isinstance(expected,dict) else expected
        assert sha256(path)==expected,name
        assets_verified.append(dict(path=str(path),sha256=expected))
    qcs = [load(p) for p in (OUT/'main/structures').glob('*/quality_complete.json')]
    qc_records = [r for q in qcs for r in q['metrics']]
    assert all(r.get('input_unchanged') for r in qc_records)
    quality = dict(available_primary_QC_records=len(qc_records), intended_primary_stage_records=1080,
                   repair_failures=sum(len(q['repair_errors']) for q in qcs), all_QC_inputs_unchanged=True)
    changes = {}
    for arm in ['C','D','E_connection_only']:
        paired = pairwise(rows,'B',arm)
        available = [p for p in paired if p['HQ_difference_right_minus_left'] is not None]
        changes[arm] = dict(pairs=72, available=len(available),
                            HQ_gained=sum(p['HQ_difference_right_minus_left']==1 for p in available),
                            HQ_lost=sum(p['HQ_difference_right_minus_left']==-1 for p in available),
                            HQ_unchanged=sum(p['HQ_difference_right_minus_left']==0 for p in available),
                            HQ_unavailable=72-len(available),
                            mean_bond_MAE_difference_A=mean([p['cross_bond_MAE_A_difference_right_minus_left'] for p in paired]),
                            mean_angle_MAE_difference_deg=mean([p['cross_angle_MAE_deg_difference_right_minus_left'] for p in paired]),
                            mean_internal_pair_difference=mean([p['severe_cross_internal_pairs_difference_right_minus_left'] for p in paired]),
                            mean_protein_pair_difference=mean([p['severe_protein_pairs_difference_right_minus_left'] for p in paired]))
    decomposed = loadcsv(OUT/'GRAPH_TRANSFER_CAUSAL_DECOMPOSITION.csv')
    effects = []
    for arm in ['C','E_connection_only']:
        applied = [r for r in decomposed if r['arm']==arm and r['accepted']=='True']
        for field in ['cross_bond_MAE_A','cross_angle_MAE_deg','severe_cross_internal_pairs','severe_protein_pairs']:
            for component in ['graph_mapping_difference','transfer_difference_same_topology','next_network_difference_same_topology']:
                key=field+'_'+component
                vals=[float(r[key]) for r in applied if r.get(key) not in ['',None]]
                effects.append(dict(arm=arm, metric=field, component=component, accepted_events=len(applied),
                                    available_events=len(vals),mean_difference=mean(vals),
                                    increased=sum(v>1e-8 for v in vals),decreased=sum(v < -1e-8 for v in vals)))
    csvwrite(OUT/'CAUSAL_COMPONENT_SUMMARY.csv',effects)
    # Matched benchmark and actual batch costs have distinct denominators.
    performance = load(OUT/'performance_benchmark.json')
    benchmark = {r['batch_size']:r for r in performance['rows'] if not r.get('failed')}
    selected = performance['selected_batch_size']
    speedup = benchmark[selected]['molecule_steps_per_second']/benchmark[1]['molecule_steps_per_second']
    batches = [load(p) for p in (OUT/'main/batches').glob('*.json')]
    group_times = {a:sum(b['wall_seconds'] for b in batches if b['arm']==a) for a in settings['arms']}
    primary_start = datetime.fromisoformat(load(OUT/'formal_start.json')['UTC']).timestamp()
    primary_end = max((OUT/'main/structures').glob('*/quality_complete.json'),key=lambda p:p.stat().st_mtime).stat().st_mtime
    selected_guidance = load(OUT/'guidance_selection.json')['selected']
    A_values = [r['docking_RMSD_A'] for r in byarm['A'] if r['docking_RMSD_A'] is not None]
    baseline = load(OUT/'known_official_baseline.json')
    official_values=[r['docking_RMSD_A'] for r in baseline['rows'] if r.get('available')]
    worsening = sum(
        b.get('cross_bond_MAE_A') is not None and d.get('cross_bond_MAE_A') is not None and
        d['cross_bond_MAE_A']<b['cross_bond_MAE_A'] and
        d.get('severe_protein_pairs') is not None and b.get('severe_protein_pairs') is not None and
        d['severe_protein_pairs']>b['severe_protein_pairs']
        for b,d in zip(byarm['B'],byarm['D']))
    decision=['# 实验决策与八项研究问题', '',
              '最终结论仅使用paired_final运行；父目录中带整图随机盐的运行完整保留为实现诊断，排除于最终配对统计。', '',
              '## 正式分母与原生结果', '',
              '五组各72次，共360次。A来自6个真实复合物的12次初始化；B/C/D/E共72套严格配对起点。另列12次统一数值路径已知复合物参照及12次原官方FP32 sampler参照，不混入360。']
    decision += table(['组','原生/引导终态HQ','HQ失败','不可评估'], [[a,f'{native[a]["passed"]}/72',native[a]['failed'],native[a]['unavailable']] for a in settings['arms']])
    decision += ['', '## 1. 原始SigmaDock的Oracle docking是否正常', '',
                 f'主A组RMSD可评估{len(A_values)}/72，RMSD<2Å为{sum(v<2 for v in A_values)}/72；已知CASF原官方FP32 sampler参照可评估{len(official_values)}/12，RMSD<2Å为{sum(v<2 for v in official_values)}/12。',
                 '这些结果证明本地官方采样可执行并提供小样本能力参照；没有同条件大队列或论文复现分母，不能据此宣布整体性能完全正常或权重失效。A沿用官方配体定义口袋中心，B/C/D/E使用给定蛋白口袋中心初始化；A/B除化学分布外还含此条件差别，不作单因素归因。真实图立体一致性与历史几何重标HQ分别列出。', '',
                 '## 2. 固定预测图是否已经产生异常', '',
                 f'B原生HQ为{native["B"]["passed"]}/72，严重内碰撞检查失败{sum(r["native_final_no_severe_internal_clash"] is False for r in byarm["B"])}/72，严重蛋白碰撞检查失败{sum(r["native_final_no_severe_protein_clash"] is False for r in byarm["B"])}/72；键长MAE均值{fmt(mean([r.get("cross_bond_MAE_A") for r in byarm["B"]]))}Å、角度MAE均值{fmt(mean([r.get("cross_angle_MAE_deg") for r in byarm["B"]]))}°。',
                 '这些是图已固定时的直接终态测量，是否还有动态更新不能解释掉这里已发生的失败；MAE缺失另计，不以可用子集代替HQ全分母。', '',
                 '## 3. 动态更新是否进一步破坏构象', '']
    for arm in ['C','E_connection_only']:
        c=changes[arm]
        decision.append(f'B→{arm}：HQ配对增加{c["HQ_gained"]}、减少{c["HQ_lost"]}、不变{c["HQ_unchanged"]}，不可评估{c["HQ_unavailable"]}/72；键长MAE平均差{fmt(c["mean_bond_MAE_difference_A"])}Å，角度平均差{fmt(c["mean_angle_MAE_difference_deg"])}°。')
    decision += ['C衡量身份与连接联合协议，E保持身份不变，隔离连接更新协议。576个更新事件通过144次确定性重放复核，终态化学图、接受/拒绝决策及未舍入坐标均复现；构造新图时的共有语义边辅助随机输入也逐边核对。',
                 'GRAPH_TRANSFER_CAUSAL_DECOMPOSITION.csv将旧图评价→新图/身份映射但未转移→同新图实际参考转移→下一次神经运动分开。C的第一步包含身份和原子数变化；E身份固定，第一步反映图定义/非键排除关系变化。拒绝提议不当作已施加转移，原始事件分母完整保留。', '',
                 '## 4. 几何引导是否提高HQ', '',
                 f'开发集冻结配置：{selected_guidance["name"]}，t≤{selected_guidance["start_t"]}，权重{selected_guidance["weights"]}，步长{selected_guidance["step"]}，单步平移/旋转限{selected_guidance["max_translation_A"]}Å/{selected_guidance["max_rotation_rad"]}rad。',
                 f'B→D：HQ配对增加{changes["D"]["HQ_gained"]}、减少{changes["D"]["HQ_lost"]}、不变{changes["D"]["HQ_unchanged"]}，不可评估{changes["D"]["HQ_unavailable"]}/72。D终态HQ包含显式扩散内引导，不能归为无约束神经网络收益。', '',
                 '## 5. 引导改善的是哪些几何项', '',
                 f'B→D的平均变化：键长MAE {fmt(changes["D"]["mean_bond_MAE_difference_A"])}Å，键角MAE {fmt(changes["D"]["mean_angle_MAE_difference_deg"])}°，严重跨片段碰撞对 {fmt(changes["D"]["mean_internal_pair_difference"])}，严重蛋白碰撞对 {fmt(changes["D"]["mean_protein_pair_difference"])}。另有{worsening}/72对出现键长MAE下降但蛋白严重碰撞对增加，不能只看单一几何目标。', '',
                 '## 6. 哪些错误能由刚性修正解决', '']
    decision += table(['组','原生/引导HQ','刚性修复HQ','局部柔性修复HQ'],[[a,f'{native[a]["passed"]}/72',f'{sum(r["rigid_repair_high_quality"] is True for r in byarm[a])}/72',f'{sum(r["local_flex_repair_high_quality"] is True for r in byarm[a])}/72'] for a in settings['arms']])
    decision += ['修复输出各保留独立位移、终止状态及QC。修复后的收益属于后处理；不能用它证明位姿网络直接生成质量已达到同一水平。', '',
                 '## 7. 是否需要微调整个网络', '',
                 '本轮足以比较固定图、动态身份/连接及受限几何引导的作用，但不能从A/B的分布差直接决定重训。优先依据B/E和B/D的配对方向、同拓扑转移分解以及失败类别，确定需要改进的是连接时机、参考转移、几何引导或特定几何监督；再在独立开发/未查看口袋上验证。本轮不启动训练，也不把六个已查看口袋当作泛化证据。', '',
                 '## 8. A100吞吐改善多少', '',
                 f'同一已验收数值路径的预热去噪步基准：batch=1为{benchmark[1]["molecule_steps_per_second"]:.3f}分子步/秒，batch={selected}为{benchmark[selected]["molecule_steps_per_second"]:.3f}分子步/秒，提升{speedup:.3f}倍；峰值显存{benchmark[selected]["peak_allocated_bytes"]/2**30:.3f}GiB。这是匹配数值路径的基准，不是与旧历史全流水线的等口径加速比。',
                 f'正式生成与并行QC从formal_start至最后一项QC约{primary_end-primary_start:.1f}秒，不含已缓存的初始图准备、此前验收/开发选择、另列基线及因果重放。各组NN/搜索/引导成本、Profiler及CPU任务累计耗时见GPU_UTILIZATION_REPORT.md。']
    (OUT/'NEXT_STEP_DECISION.md').write_text('\n'.join(decision)+'\n')
    summary=load(OUT/'summary.json');summary.update(quality=quality,paired_changes=changes,primary_generation_and_QC_wall_seconds=primary_end-primary_start,
         known_reference_attempts_per_mode=12,total_primary_and_reference_attempts=384,causal_replay_attempts=144,causal_replay_excluded=True,
         dev_candidate_attempts=54,dev_B_attempts=6,preflight_attempts=10,prior_run_excluded=True)
    dump(OUT/'summary.json',summary)
    csvwrite(OUT/'PAIRED_EFFECT_SUMMARY.csv',[dict(comparison='B to '+a,**r) for a,r in changes.items()])
    # Present counts without treating repeated seeds as independent receptors.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9,4.6))
    x=np.arange(5);width=.24
    stages=['native_final','rigid_repair','local_flex_repair']
    for j,stage in enumerate(stages):
        values=[sum(r[stage+'_high_quality'] is True for r in byarm[a]) for a in settings['arms']]
        bars=ax.bar(x+(j-1)*width,values,width,label=['Native (D guided)','Rigid repair','Local-flex repair'][j])
        ax.bar_label(bars,padding=2,fontsize=8)
    ax.set_xticks(x,['A: true graph','B: fixed','C: dynamic','D: guided','E: conn-only'])
    ax.set_ylim(0,80);ax.set_ylabel('HQ_no_water passed / 72 attempts')
    ax.set_title('Frozen five-arm diagnostic; failures and unavailable remain in denominator')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.12),ncol=3,frameon=False)
    fig.tight_layout();fig.savefig(OUT/'FIVE_ARM_QUALITY.png',dpi=180,bbox_inches='tight');fig.savefig(OUT/'FIVE_ARM_QUALITY.svg',bbox_inches='tight');plt.close(fig)
    # Numeric count table makes auxiliary runs and exclusions explicit.
    (OUT/'RUN_COUNTS.md').write_text('\n'.join(['# 运行分母与归属', '', *table(['队列','生成/重放次数','是否并入正式360'],[
         ['A/B/C/D/E','5×72=360','是'],['已知CASF统一数值路径','12','否'],['原官方FP32 sampler','12','否'],
         ['开发B','6','否'],['开发D九候选','54','否'],['五组预检','10','否'],['C/E确定性因果重放','144','否'],
         ['父目录整图随机盐运行','360及其辅助队列','否，保留用于实现追溯']]), '',
         f'本轮正式阶段计划QC1080项，实际可用记录{len(qc_records)}项，修复异常{quality["repair_failures"]}项；缺失阶段仍在每组72的分母内。已知复合物各12项是不同数值/随机路径参照，不当作24个不同受体。',
         '数值验收中的静态输入重复轨迹用于算法核验，不加入生成成功率分母。未对失败重抽种子，也未在两次实现之间按质量挑选结果。'])+'\n')
    # Add actual component timing and profiler statistics without overstating scope.
    util=OUT/'profiler_utilization.json'
    if util.exists():
        prof=load(util)
        with (OUT/'GPU_UTILIZATION_REPORT.md').open('a') as handle:
            handle.write(f'\n短Profiler窗口核执行忙碌率约{100*prof["cuda_kernel_busy_fraction"]:.2f}%，核执行间隙约{100*prof["cuda_kernel_gap_fraction"]:.2f}%；窗口包含Profiler开销，仅覆盖开发去噪步骤。它不是整机或正式全过程利用率。\n')
    times=loadcsv(OUT/'CAUSAL_REPLAY_COMPONENT_TIMINGS.csv')
    timing=[]
    for kind in sorted({r['kind'] for r in times}):
        vals=[float(r['seconds']) for r in times if r['kind']==kind]
        timing.append([kind,len(vals),f'{sum(vals):.3f}',f'{np.mean(vals):.5f}'])
    with (OUT/'GPU_UTILIZATION_REPORT.md').open('a') as handle:
        handle.write('\n## 确定性重放中的部件实测\n\n以下计时在144次因果重放中采集，原始调用与观察器额外工作分开；不将重放墙钟冒充正式生成墙钟。slot_frame含GPU→CPU复制/同步与Kabsch拟合。\n\n'+'\n'.join(table(['部件','次数','累计秒','均值秒'],timing))+'\n')
        handle.write(f'\n正式各组批次墙钟秒：{group_times}。动态组还含CPU合法搜索、RDKit参考生成和图转换，以及网络/主机同步，这些开销不会被增加batch完全消除。\n')
    rel=OUT.relative_to(ROOT).as_posix()
    (OUT/'REPRODUCE.md').write_text(f'''# 复现与核验

从原工作区根目录执行，依赖原项目布局、已有权重、词表和输入。

```bash
export CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2
export PYTHONPATH="$PWD/.quality_deps:$PWD"
../.venv-cutoff-train/bin/python -B {rel}/source/validate_replay.py
../.venv-cutoff-train/bin/python -B {rel}/source/launch.py --through complete
../.venv-cutoff-train/bin/python -B {rel}/source/causal_replay_observed.py
../.venv-cutoff-train/bin/python -B {rel}/source/finalize_archive.py
```

已有文件的再次运行校验并恢复已有输入/结果，不构成独立重跑。独立重跑应在保持原布局的新副本中进行。frozen_source/和formal_start.json记录生成时代码及参数；因果观察器和最终报告代码另由交付指纹记录。父目录的旧运行原样保留，不能混入最终统计。
''')
    result=dict(passed=True,primary_attempts=360,per_arm=72,quality=quality,prior_run_scientific_files_verified=verified_prior,
        prior_mutable_navigation_exclusions=sorted(mutable),assets_verified=assets_verified,causal_replay=causal,
        generated_at_Asia_Shanghai=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat())
    dump(OUT/'final_verification.json',result)
    # Stable navigation for the original task folder; do not move scientific artifacts.
    task=ROOT/load(OUT/'status.json')['task_directory']
    names=load(OUT/'status.json')['expected_deliverables']+['ROOT_CAUSE_REPORT.md','REPRODUCE.md','RUN_COUNTS.md',
           'FIVE_ARM_QUALITY.png','FIVE_ARM_QUALITY.svg','PAIRED_EFFECT_SUMMARY.csv','GRAPH_TRANSFER_CAUSAL_DECOMPOSITION.csv',
           'CAUSAL_COMPONENT_SUMMARY.csv','final_verification.json','completion_verification.json','replay_validation.json']
    for name in names:
        link=task/name
        if link.is_symlink():
            assert link.resolve()==(OUT/name).resolve()
        else:
            assert not link.exists(),str(link)
            link.symlink_to(os.path.relpath(OUT/name,task))
    brief=f'''# 四组位姿生成对照与A100吞吐优化（已完成）

原任务时间：2026-11-08 22:30（北京时间，原prompt修改时间）；本次完成：{result['generated_at_Asia_Shanghai']}。

最终有效运行：[paired_final](完整实验目录/paired_final/)。五组各72次，共360次；另外12+12次已知复合物参照单列，144次因果重放不合入正式分母。

[完整比较](FOUR_ARM_COMPARISON.md) · [八项问题与决策](NEXT_STEP_DECISION.md) · [随机性/批量根因报告](ROOT_CAUSE_REPORT.md) · [完整运行分母](RUN_COUNTS.md) · [最终核验](final_verification.json)

[docking与真实图立体](DOCKING_BASELINE_RESULTS.md) · [失败和不可评估](QUALITY_FAILURE_BREAKDOWN.md) · [吞吐基准](PERFORMANCE_BENCHMARK.md) · [完整成本](GPU_UTILIZATION_REPORT.md) · [复现](REPRODUCE.md)

[原始任务](prompt.md) · [补充检查](prompt_check.md) · [此前问题快照](CURRENT_ISSUE.md)。父目录旧运行因整图随机盐破坏共有边随机流配对而排除，原始产物完整保留用于追溯；最终结论只使用paired_final。

![各组HQ计数](FIVE_ARM_QUALITY.png)
'''
    (task/'README.md').write_text(brief)
    (OUT/'README.md').write_text(brief.replace('完整实验目录/paired_final/','./').replace('(prompt.md)','(../prompt.md)').replace('(CURRENT_ISSUE.md)','(../CURRENT_ISSUE.md)'))
    parent_status=load(parent/'status.json');parent_status.update(stage='complete',execution_complete=True,active_run='paired_final',
        formal_attempts_completed=360,formal_attempts_expected=360,prior_run_excluded=True,causal_replay_complete=True)
    dump(parent/'status.json',parent_status)
    status=load(OUT/'status.json');status.update(stage='complete',execution_complete=True,archive_complete=True,completed_deliverables=names)
    dump(OUT/'status.json',status)
    index_path=ROOT/'TASK_LOG_INDEX.json';index=load(index_path)
    for entry in index['tasks']:
        if entry['key']=='pose_generation_four_arm_comparison_20261108':
            entry.update(status='complete',execution_complete=True,formal_attempts_completed=360,active_run=str(OUT.relative_to(ROOT)),
                         completion_or_final_update_Asia_Shanghai=result['generated_at_Asia_Shanghai'],time_basis='Verified final independent run; directory retains original prompt time')
    dump(index_path,index)
    root_readme=ROOT/'README.md';text=root_readme.read_text();text=text.replace('四组位姿生成对照与A100吞吐优化（预检待讨论）','四组位姿生成对照与A100吞吐优化（已完成）');text=text.replace('已执行输入审计和首轮批量诊断，正式实验尚未开始；当前问题与证据见日期目录的 CURRENT_ISSUE.md，后续代码和结果通过“完整实验目录”入口访问。','已完成独立最终运行的360次正式对照、另列基线及144次因果重放；报告、完整分母与核验见日期目录，最终有效结果在 paired_final。');root_readme.write_text(text)
    manifest=load(task/'MANIFEST.json');manifest.update(status='complete',active_run=str(OUT.relative_to(ROOT)),formal_attempts_completed=360,
            finalized_at_Asia_Shanghai=result['generated_at_Asia_Shanghai'],final_verification_sha256=sha256(OUT/'final_verification.json'),
            final_reports=[dict(path=name,sha256=sha256(OUT/name),bytes=(OUT/name).stat().st_size) for name in names])
    dump(task/'MANIFEST.json',manifest)
    fingerprint_delivery()
    print(json.dumps(dict(passed=True,formal_attempts=360,HQ_native={a:native[a] for a in settings['arms']},
         speedup=speedup,archive=str(task),final_run=str(OUT)),ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
