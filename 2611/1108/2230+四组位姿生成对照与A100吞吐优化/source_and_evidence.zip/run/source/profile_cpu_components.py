"""Time immutable graph construction on six cached cases, outside primary sampling."""
from common import *
import time
import torch
import joint_sampler as sampler
from vocab_chemistry import VocabLibrary


def main():
    torch.set_num_threads(1)
    settings = load(OUT / 'effective_protocol.json')
    library = VocabLibrary()
    originals = {name: getattr(sampler, name) for name in
                 ['assemble_slots', 'embedded_reference', 'spec_from_slots', 'rebuild']}
    rows = []
    active = {}
    def wrapper(name):
        def timed(*args, **kwargs):
            started = time.perf_counter()
            result = originals[name](*args, **kwargs)
            active[name+'_seconds'] = time.perf_counter()-started
            return result
        return timed
    for name in originals:
        setattr(sampler, name, wrapper(name))
    try:
        for repeat in range(2):
            for pid in settings['cohort']:
                seed = settings['seeds'][0]
                case = torch.load(OUT / 'main/initial' / f'{pid}_{seed}' / 'case.pt', weights_only=False)
                active.clear()
                started = time.perf_counter()
                graph, groups, spec = sampler.chemical_graph(library, case['labels'], case['connections'],
                    case['context'], [None]*case['N'], seed=seed)
                elapsed = time.perf_counter()-started
                assert spec == case['spec'] and groups == case['groups']
                path = OUT / 'diagnostics/cpu_profile_scratch.pt'
                started = time.perf_counter()
                torch.save(dict(graph=graph, groups=groups, spec=spec), path)
                write_seconds = time.perf_counter()-started
                size = path.stat().st_size
                path.unlink()
                rows.append(dict(pid=pid, seed=seed, repeat=repeat, warmup=repeat==0,
                                 **active, total_graph_seconds=elapsed,
                                 buffered_torch_save_seconds=write_seconds, serialized_bytes=size,
                                 spec_and_atom_groups_equal_to_cached_input=True))
    finally:
        for name, original in originals.items():
            setattr(sampler, name, original)
    csvwrite(OUT / 'CPU_GRAPH_COMPONENT_BENCHMARK.csv', rows)
    dump(OUT / 'cpu_component_benchmark.json', dict(passed=True, samples=6, warmup_calls=6,
         measured_calls=6, excluded_from_primary_denominator=True,
         scope='Six first-seed fixed initial graphs, warmed CPU-only construction; not historical primary timing. torch.save uses buffered filesystem writes and excludes fsync/QC exports.',
         definitions=dict(assemble_slots='RDKit legal molecule assembly',
             embedded_reference='RDKit unbound reference embedding and optimization',
             spec_from_slots='Reference atom/group specification',
             rebuild='Protein/ligand chemical graph conversion'),
         mean_warmed_seconds={key: float(np.mean([r[key] for r in rows if not r['warmup']]))
             for key in rows[0] if key.endswith('_seconds')}))
    print(json.dumps(load(OUT / 'cpu_component_benchmark.json'), indent=2))


if __name__ == '__main__':
    main()
