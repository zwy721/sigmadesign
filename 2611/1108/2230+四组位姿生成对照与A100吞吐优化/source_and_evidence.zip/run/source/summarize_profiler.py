"""Summarize the saved local trace; this is not whole-job GPU utilization."""
from common import *
from collections import defaultdict


def main():
    trace = load(OUT / 'performance_trace.json')['traceEvents']
    cpu = [e for e in trace if e.get('ph') == 'X' and e.get('cat') == 'cpu_op']
    assert cpu
    start = min(e['ts'] for e in cpu)
    end = max(e['ts'] + e['dur'] for e in cpu)
    kernels = sorted((max(start, e['ts']), min(end, e['ts'] + e['dur']))
                     for e in trace if e.get('ph') == 'X' and e.get('cat') == 'kernel'
                     and e['ts'] < end and e['ts'] + e['dur'] > start)
    assert kernels
    merged = []
    for a, b in kernels:
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(b, merged[-1][1])
        else:
            merged.append([a, b])
    busy = sum(b-a for a, b in merged)
    scopes = defaultdict(float)
    for event in trace:
        if event.get('ph') == 'X' and event.get('cat') == 'user_annotation':
            scopes[event['name']] += event['dur'] / 1e6
    dump(OUT / 'profiler_utilization.json', dict(
        trace_sha256=sha256(OUT / 'performance_trace.json'),
        window_seconds=(end-start)/1e6,
        cuda_kernel_busy_seconds=busy/1e6,
        cuda_kernel_busy_fraction=busy/(end-start),
        cuda_kernel_gap_fraction=1-busy/(end-start),
        kernels=len(kernels), user_annotation_inclusive_seconds=dict(scopes),
        scope='Union of CUDA kernels in CPU-op trace span of three warmed developer batch=32 steps; profiler overhead included. Inclusive CPU scopes overlap. Not whole-device/job utilization.'))
    print(json.dumps(load(OUT / 'profiler_utilization.json'), indent=2))


if __name__ == '__main__':
    main()
