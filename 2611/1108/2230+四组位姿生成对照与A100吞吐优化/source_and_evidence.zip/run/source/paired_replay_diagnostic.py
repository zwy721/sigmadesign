"""Summarize saved failed replay evidence without changing any generated sample."""
import json
from pathlib import Path
import numpy as np


OUT = Path(__file__).resolve().parents[1]
ROOT = next(p for p in OUT.parents if (p/'denovo_quality').is_dir())


def read(path):
    return json.loads(path.read_text())


def main():
    properties = read(ROOT.parent / 'geom_m12/assets/properties.json')
    rows = []
    for path in sorted((OUT / 'causal_replay/structures').glob('*/result.json')):
        original_folder = OUT / 'main/structures' / path.parent.name
        old, new = read(original_folder / 'result.json'), read(path)
        for left, right in zip(old['events'], new['events']):
            step = left['step']
            x = np.load(original_folder / f'identity_{step:02d}.npz')
            y = np.load(path.parent / f'identity_{step:02d}.npz')
            same_input_chemistry = left['old_labels'] == right['old_labels']
            row = dict(attempt=path.parent.name, step=step,
                same_input_labels=same_input_chemistry,
                old_accepted=left['accepted'], replay_accepted=right['accepted'],
                old_reason=left.get('reason'), replay_reason=right.get('reason'),
                same_proposed_labels=left['proposed_labels']==right['proposed_labels'])
            row.update({k+'_maximum_absolute_difference':float(np.max(np.abs(x[k]-y[k])))
                        for k in ['T','R','logits','sampling_probabilities']})
            row['slots'] = [dict(slot=i,label=label,heavy_atoms=properties[label]['n_heavy'],
                rotation_matrix_maximum_difference=float(np.max(np.abs(x['R'][i]-y['R'][i]))))
                for i,label in enumerate(left['old_labels'])] if same_input_chemistry else []
            rows.append(row)
    assert rows
    output=OUT/'diagnostics/dynamic_replay_failure.json'
    report=dict(passed=False,completed_replay_attempts=len(rows)//4,events=len(rows),
                primary_results_modified=False,
                identity_or_decision_divergence_events=sum(not r['same_proposed_labels'] or r['old_accepted']!=r['replay_accepted'] for r in rows),
                interpretation='At first updates, sub-microangstrom translation differences coexist with order-one SVD orientation differences on two-atom fragments. Two points do not determine rotation about their bond axis. This can alter dynamic identity logits and legal-transfer decisions. These replay runs must not be presented as reproducing primary C/E trajectories.',
                proposed_change_requires_user_decision='Use previous generated-state orientation to resolve degenerate template-fit rotation, first validate, then preserve and independently rerun affected comparisons. No bound ligand orientation is used.',
                rows=rows)
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='rows'},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
